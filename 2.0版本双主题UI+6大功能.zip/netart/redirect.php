<?php
/**
 * 广告跳转中间页 - 蓝色风格倒计时
 */
require_once __DIR__ . '/config/config.php';

$url = $_GET['url'] ?? '';
if (!$url || !filter_var($url, FILTER_VALIDATE_URL)) {
    header('Location: index.php');
    exit;
}

// 从数据库读取跳转页配置
$title = '广告跳转提示';
$loadingText = '广告加载中，请稍后...';
$disclaimer = '本站不担保任何广告内容，网络交易请谨慎自行甄别。如遇欺诈或纠纷，请联系管理员投诉下架该广告。';
$countdown = 5;

try {
    $db = getDB();
    $keys = ['redirect_title','redirect_loading_text','redirect_disclaimer','redirect_countdown'];
    $stmt = $db->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN (?,?,?,?)");
    $stmt->execute($keys);
    while ($row = $stmt->fetch()) {
        switch ($row['setting_key']) {
            case 'redirect_title': $title = $row['setting_value'] ?: $title; break;
            case 'redirect_loading_text': $loadingText = $row['setting_value'] ?: $loadingText; break;
            case 'redirect_disclaimer': $disclaimer = $row['setting_value'] ?: $disclaimer; break;
            case 'redirect_countdown': $countdown = max(1, (int)$row['setting_value'] ?: 5); break;
        }
    }
} catch (Exception $e) {}

$encodedUrl = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
$titleHtml = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
$loadingHtml = htmlspecialchars($loadingText, ENT_QUOTES, 'UTF-8');
$disclaimerHtml = htmlspecialchars($disclaimer, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $titleHtml; ?></title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #0a1628 0%, #1a2a4a 50%, #0d1f3c 100%);
    color: #fff;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow: hidden;
}
.container {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 28px;
    padding: 40px 20px;
    max-width: 500px;
    width: 90%;
}
.loading-text {
    font-size: 16px;
    color: rgba(255,255,255,.85);
    text-align: center;
    letter-spacing: 1px;
}
.countdown-wrap {
    position: relative;
    width: 120px;
    height: 120px;
}
.countdown-ring {
    width: 120px;
    height: 120px;
    transform: rotate(-90deg);
}
.countdown-ring-bg {
    fill: none;
    stroke: rgba(255,255,255,.1);
    stroke-width: 4;
}
.countdown-ring-progress {
    fill: none;
    stroke: url(#blueGradient);
    stroke-width: 4;
    stroke-linecap: round;
    stroke-dasharray: 339.292;
    stroke-dashoffset: 0;
    transition: stroke-dashoffset 1s linear;
    filter: drop-shadow(0 0 6px rgba(86,140,255,.5));
}
.countdown-number {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 32px;
    font-weight: 700;
    color: #fff;
    text-shadow: 0 0 20px rgba(86,140,255,.6);
}
.countdown-unit {
    font-size: 14px;
    font-weight: 400;
    color: rgba(255,255,255,.6);
    margin-left: 2px;
}
.disclaimer {
    font-size: 12px;
    color: rgba(255,255,255,.45);
    text-align: center;
    line-height: 1.8;
    max-width: 400px;
}
.skip-btn {
    background: rgba(255,255,255,.08);
    border: 1px solid rgba(255,255,255,.15);
    color: rgba(255,255,255,.7);
    padding: 8px 24px;
    border-radius: 20px;
    font-size: 13px;
    cursor: pointer;
    transition: all .2s;
}
.skip-btn:hover {
    background: rgba(86,140,255,.2);
    border-color: rgba(86,140,255,.4);
    color: #fff;
}
.particles {
    position: fixed;
    top: 0; left: 0; width: 100%; height: 100%;
    pointer-events: none;
    z-index: 0;
}
.container { position: relative; z-index: 1; }
.particle {
    position: absolute;
    width: 2px; height: 2px;
    background: rgba(86,140,255,.3);
    border-radius: 50%;
    animation: float 8s infinite ease-in-out;
}
@keyframes float {
    0%,100% { transform: translateY(0) translateX(0); opacity: 0; }
    25% { opacity: 1; }
    50% { transform: translateY(-100px) translateX(30px); opacity: .6; }
    75% { opacity: .3; }
}
</style>
</head>
<body>
<div class="particles" id="particles"></div>
<div class="container">
    <p class="loading-text"><?php echo $loadingHtml; ?></p>
    <div class="countdown-wrap">
        <svg class="countdown-ring" viewBox="0 0 120 120">
            <defs>
                <linearGradient id="blueGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#4A90FF"/>
                    <stop offset="100%" stop-color="#7B5FFF"/>
                </linearGradient>
            </defs>
            <circle class="countdown-ring-bg" cx="60" cy="60" r="54"/>
            <circle class="countdown-ring-progress" id="ringProgress" cx="60" cy="60" r="54"/>
        </svg>
        <div class="countdown-number">
            <span id="countdownNum"><?php echo $countdown; ?></span><span class="countdown-unit">s</span>
        </div>
    </div>
    <p class="disclaimer"><?php echo $disclaimerHtml; ?></p>
    <button class="skip-btn" id="skipBtn">立即跳转</button>
</div>
<script>
(function() {
    var seconds = <?php echo $countdown; ?>;
    var url = '<?php echo $encodedUrl; ?>';
    var circumference = 2 * Math.PI * 54;
    var ring = document.getElementById('ringProgress');
    var numEl = document.getElementById('countdownNum');
    var skipBtn = document.getElementById('skipBtn');

    ring.style.strokeDasharray = circumference;
    ring.style.strokeDashoffset = '0';

    function go() {
        window.location.href = url;
    }

    skipBtn.addEventListener('click', go);

    var remaining = seconds;
    var timer = setInterval(function() {
        remaining--;
        if (remaining <= 0) {
            clearInterval(timer);
            numEl.textContent = '0';
            ring.style.strokeDashoffset = circumference;
            setTimeout(go, 300);
            return;
        }
        numEl.textContent = remaining;
        var progress = (seconds - remaining) / seconds;
        ring.style.strokeDashoffset = circumference * progress;
    }, 1000);

    // particles
    var pc = document.getElementById('particles');
    for (var i = 0; i < 30; i++) {
        var p = document.createElement('div');
        p.className = 'particle';
        p.style.left = Math.random() * 100 + '%';
        p.style.top = Math.random() * 100 + '%';
        p.style.animationDelay = (Math.random() * 8) + 's';
        p.style.animationDuration = (6 + Math.random() * 6) + 's';
        pc.appendChild(p);
    }
})();
</script>
</body>
</html>
