<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/site_settings.php';
require_once __DIR__ . '/includes/layout.php';

$siteName = getSiteSetting('site_name', 'NetArt 流量消耗');
render_page_header([
    'title' => '流量消耗排行榜',
    'subtitle' => '按日 / 月 / 年统计全网流量消耗排名',
    'active' => 'rank',
    'css' => ['./css/rank.css'],
]);
?>

    <!-- 排行榜主体 -->
    <section class="np-card rank-page-section">
        <!-- 周期切换标签 -->
        <div class="rank-period-tabs">
            <button class="rank-tab active" data-period="day">今日排行</button>
            <button class="rank-tab" data-period="month">本月排行</button>
            <button class="rank-tab" data-period="year">本年排行</button>
        </div>

        <!-- 前三甲展示 -->
        <div class="rank-podium" id="rankPodium">
            <div class="podium-item podium-2nd" id="podium2">
                <div class="podium-avatar-wrap">
                    <div class="podium-avatar-box"><img class="podium-avatar" src="" alt=""><span class="podium-letter">?</span></div>
                    <span class="podium-badge badge-silver">&#129352;</span>
                </div>
                <div class="podium-name">虚位以待</div>
                <div class="podium-value">-</div>
                <div class="podium-bar"></div>
            </div>
            <div class="podium-item podium-1st" id="podium1">
                <div class="podium-avatar-wrap">
                    <div class="podium-avatar-box"><img class="podium-avatar" src="" alt=""><span class="podium-letter">?</span></div>
                    <span class="podium-badge badge-gold">&#129351;</span>
                </div>
                <div class="podium-name">虚位以待</div>
                <div class="podium-value">-</div>
                <div class="podium-bar"></div>
            </div>
            <div class="podium-item podium-3rd" id="podium3">
                <div class="podium-avatar-wrap">
                    <div class="podium-avatar-box"><img class="podium-avatar" src="" alt=""><span class="podium-letter">?</span></div>
                    <span class="podium-badge badge-bronze">&#129353;</span>
                </div>
                <div class="podium-name">虚位以待</div>
                <div class="podium-value">-</div>
                <div class="podium-bar"></div>
            </div>
        </div>

        <!-- 排行列表 -->
        <table class="rank-table-full" id="rankTableFull">
            <thead>
                <tr>
                    <th>排名</th>
                    <th>用户</th>
                    <th>流量消耗</th>
                </tr>
            </thead>
            <tbody id="rankBodyFull">
                <tr><td colspan="3" style="text-align:center;padding:30px;">加载中...</td></tr>
            </tbody>
        </table>
    </section>

    <?php render_page_footer(['scripts' => ['./js/rank.js']]); ?>
