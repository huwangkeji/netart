<?php
/**
 * 工具箱首页
 *
 * 汇总本站提供的小工具入口，便于导航与 SEO 收录。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/layout.php';

$tools = [
    [
        'icon' => '🌐',
        'name' => 'IP 归属查询',
        'url' => './ip.php',
        'desc' => '支持 IPv4 / IPv6 / 域名，查看归属地、运营商与 ASN，结果缓存 24 小时。',
    ],
    [
        'icon' => '📈',
        'name' => '网络流量计算器',
        'url' => './traffic.php',
        'desc' => '按速率与单价估算每小时 / 每天 / 每月 / 每年的流量消耗与费用。',
    ],
    [
        'icon' => '🔢',
        'name' => '字节转换工具',
        'url' => './byte.php',
        'desc' => 'B / KB / MB / GB / TB / PB 互转，一次性给出全部单位结果。',
    ],
    [
        'icon' => '🛰️',
        'name' => 'IP 进阶工具',
        'url' => './ip-tools.php',
        'desc' => '多地归属一致性对比、CDN/云厂商识别、TCP 延迟探测、多解析器 DNS 对比。',
    ],
    [
        'icon' => '🔌',
        'name' => 'NAT 类型检测',
        'url' => './nat.php',
        'desc' => '多 STUN 节点采样公网映射，在线估算全锥 / 受限锥 / 端口受限锥 / 对称型 NAT。',
    ],
];

render_page_header([
    'title' => '工具箱',
    'subtitle' => '网络测速之外的常用在线小工具，全部免费、无需安装',
    'description' => '网络工具集合：IP 归属查询、流量计算器、字节单位转换，全部在线免费使用。',
    'active' => 'tools',
]);
?>

<div class="np-grid np-grid-3" style="margin-bottom:18px;">
    <?php foreach ($tools as $tool): ?>
        <a class="np-tool-card" href="<?= e($tool['url']) ?>">
            <div class="np-tool-icon"><?= e($tool['icon']) ?></div>
            <div class="np-tool-name"><?= e($tool['name']) ?></div>
            <div class="np-tool-desc"><?= e($tool['desc']) ?></div>
        </a>
    <?php endforeach; ?>
</div>

<div class="np-card">
    <h2 class="np-card-title">ℹ️ 关于本站工具</h2>
    <p style="margin:0;color:var(--np-text-secondary);font-size:14px;line-height:1.9;">
        所有计算均在浏览器与本站服务端完成，不会上传您的任何输入内容用于其他用途。
        IP 查询仅会向第三方 IP 数据库提交待查询的 IP 地址本身；其余工具为纯数学换算，不涉及任何外部请求。
        如需查看数据如何处理，请阅读<a href="./privacy.php">《隐私政策》</a>。
    </p>
</div>

<?php
render_page_footer();
