<?php
/**
 * 关于我们
 *
 * 页面内容可在后台「系统设置 → 页面管理 → 关于我们」中完全自定义（支持图文、排版等）。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/page_view.php';

render_document_page('about');
