<?php
/**
 * NetworkPanel - 数据库配置文件
 */

// 数据库配置（宝塔面板环境）
define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_NAME', 'netart_czkree_co');
define('DB_USER', 'netart_czkree_co');
define('DB_PASS', 'xnjTPl8NdB3nX8SFPwYy599tz');
define('DB_CHARSET', 'utf8mb4');

// API配置
define('API_URL', 'https://api.netart.cn/');

// IP查询服务配置（使用ip9.com.cn免费IP归属地查询接口 https://www.ip9.com.cn）
define('IP_QUERY_API', 'https://ip9.com.cn/get');

// 会话 Cookie 安全加固：显式设置 SameSite=Lax，降低跨站请求伪造（CSRF）风险
// （现代浏览器对缺失 SameSite 的 Cookie 也默认按 Lax 处理，此处显式声明以保证一致性）
if (PHP_VERSION_ID >= 70300 && session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['samesite' => 'Lax']);
}

/**
 * 获取数据库连接（单例模式）
 */
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                DB_HOST,
                DB_PORT,
                DB_NAME,
                DB_CHARSET
            );
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            // MySQL 8.0 兼容：设置连接属性以支持 caching_sha2_password 认证
            if (defined('PDO::MYSQL_ATTR_MULTI_STATEMENTS')) {
                $options[PDO::MYSQL_ATTR_MULTI_STATEMENTS] = false;
            }
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            // 设置 SQL 模式兼容 MySQL 8.0（移除 ONLY_FULL_GROUP_BY 等可能导致问题的模式）
            $pdo->exec("SET sql_mode = 'NO_ENGINE_SUBSTITUTION'");
        } catch (PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            $msg = '数据库连接失败';
            if (strpos($e->getMessage(), 'caching_sha2_password') !== false) {
                $msg .= '（MySQL 8.0认证插件不兼容，请在宝塔面板中将MySQL认证插件改为mysql_native_password）';
            } else {
                $msg .= '（请确认已安装 pdo_mysql 扩展且数据库配置正确）';
            }
            die(json_encode(['status' => -1, 'message' => $msg], JSON_UNESCAPED_UNICODE));
        }
    }
    return $pdo;
}

/**
 * JSON响应输出
 */
function jsonResponse($data, int $statusCode = 200): void {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 获取客户端真实IP（统一委托 request_ip，避免重复实现与不一致）
 */
function getClientIP(): string {
    return request_ip();
}

/**
 * 获取客户端 IP（兼容反向代理，剔除端口与非法值）
 */
function request_ip(): string
{
    $candidates = [
        $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '',
        $_SERVER['HTTP_X_REAL_IP'] ?? '',
        $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '',
        $_SERVER['REMOTE_ADDR'] ?? '',
    ];

    foreach ($candidates as $candidate) {
        foreach (explode(',', (string) $candidate) as $ip) {
            $ip = trim($ip);
            if ($ip === '') {
                continue;
            }
            // 去掉 IPv4:port / [IPv6]:port
            if (strpos($ip, ':') !== false && substr_count($ip, ':') === 1) {
                $ip = explode(':', $ip)[0];
            }
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }

    return '127.0.0.1';
}

/**
 * 是否为内网/保留地址（含 IPv6 回环与 ULA）
 */
function is_private_ip(string $ip): bool
{
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return false;
    }

    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }

    // IPv6：回环 ::1、链路本地 fe80::/10、唯一本地 fc00::/7
    $lower = strtolower($ip);
    if ($lower === '::1') {
        return true;
    }

    return (strpos($lower, 'fe80') === 0 || strpos($lower, 'fc') === 0 || strpos($lower, 'fd') === 0);
}
