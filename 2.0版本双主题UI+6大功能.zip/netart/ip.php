<?php
/**
 * 本机 IP 查询 / IP 归属查询
 *
 * 视觉参考：FlowLoss 本机 IP 查询
 * 能力：IPv4 / IPv6 检测、多源对比、WebRTC 泄露检测、国内外延迟检测。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/layout.php';

render_page_header([
    'title'       => '本机 IP 查询',
    'subtitle'    => '查看你当前网络的 IP 地址、位置信息和网络连通性',
    'description' => '在线本机 IP 查询工具，支持 IPv4、IPv6、多源 IP 对比、WebRTC 泄露检测与国内外网络延迟检测。',
    'active'      => 'tools',
    'css'         => ['./css/ip.css'],
]);
?>

<section class="ipq-hero">
    <h1 class="ipq-title">本机 IP 查询</h1>
    <p class="ipq-subtitle">查看你当前网络的 IP 地址、位置信息和网络连通性</p>
</section>

<div class="ipq-grid ipq-top">
    <!-- 左侧：本机信息 -->
    <section class="ipq-card ipq-local" aria-label="本机信息">
        <div class="ipq-local-row">
            <span class="ipq-label">IPv4</span>
            <div class="ipq-ip-wrap">
                <span class="ipq-ip" id="localIpv4">--</span>
                <button type="button" class="ipq-icon-btn" id="btnCopyIpv4" title="复制 IPv4" aria-label="复制 IPv4">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                </button>
            </div>
        </div>
        <div class="ipq-local-row">
            <span class="ipq-label">Location</span>
            <span class="ipq-value" id="localLocation">--</span>
        </div>
        <div class="ipq-local-row">
            <span class="ipq-label">ISP</span>
            <span class="ipq-value" id="localIsp">--</span>
        </div>
        <div class="ipq-local-row">
            <span class="ipq-label">ASN</span>
            <span class="ipq-value" id="localAsn">--</span>
        </div>

        <div class="ipq-divider"></div>

        <div class="ipq-local-row ipq-ipv6-row">
            <span class="ipq-label">IPv6</span>
            <div class="ipq-ipv6-state" id="ipv6State">
                <span class="ipq-ipv6-status" id="ipv6Status">检测中…</span>
                <button type="button" class="ipq-btn-text" id="btnRetryIpv6">Retry</button>
            </div>
        </div>
    </section>

    <!-- 右侧：多源结果 -->
    <section class="ipq-card ipq-sources" aria-label="多源 IP 结果">
        <div class="ipq-source-list" id="sourcesList">
            <div class="ipq-source-item" data-key="ip138">
                <div class="ipq-source-head">
                    <span class="ipq-source-name">ip138.com</span>
                    <span class="ipq-tag ipq-tag-domestic">国内</span>
                </div>
                <div class="ipq-source-body">
                    <div class="ipq-source-ip" id="srcIp_ip138">--</div>
                    <div class="ipq-source-info" id="srcInfo_ip138">--</div>
                </div>
            </div>
            <div class="ipq-source-item" data-key="ipcn">
                <div class="ipq-source-head">
                    <span class="ipq-source-name">IP.cn 查询网</span>
                    <span class="ipq-tag ipq-tag-domestic">国内</span>
                </div>
                <div class="ipq-source-body">
                    <div class="ipq-source-ip" id="srcIp_ipcn">--</div>
                    <div class="ipq-source-info" id="srcInfo_ipcn">--</div>
                </div>
            </div>
            <div class="ipq-source-item" data-key="cloudflare">
                <div class="ipq-source-head">
                    <span class="ipq-source-name">Cloudflare</span>
                    <span class="ipq-tag ipq-tag-international">国际</span>
                </div>
                <div class="ipq-source-body">
                    <div class="ipq-source-ip" id="srcIp_cloudflare">--</div>
                    <div class="ipq-source-info" id="srcInfo_cloudflare">--</div>
                </div>
            </div>
            <div class="ipq-source-item" data-key="ipinfo">
                <div class="ipq-source-head">
                    <span class="ipq-source-name">IPinfo.io</span>
                    <span class="ipq-tag ipq-tag-international">国际</span>
                </div>
                <div class="ipq-source-body">
                    <div class="ipq-source-ip" id="srcIp_ipinfo">--</div>
                    <div class="ipq-source-info" id="srcInfo_ipinfo">--</div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- 隐私显示条 -->
<div class="ipq-privacy">
    <div class="ipq-privacy-note">
        <span class="ipq-info-icon" aria-hidden="true">ⓘ</span>
        隐私显示只影响当前页面，不会改变检测结果
    </div>
    <div class="ipq-toggles">
        <label class="ipq-toggle">
            <span>隐藏 IP</span>
            <input type="checkbox" id="toggleHideIp">
            <span class="ipq-switch"><span class="ipq-switch-knob"></span></span>
        </label>
        <label class="ipq-toggle">
            <span>隐藏国内信息</span>
            <input type="checkbox" id="toggleHideDomestic">
            <span class="ipq-switch"><span class="ipq-switch-knob"></span></span>
        </label>
        <label class="ipq-toggle">
            <span>隐藏国际信息</span>
            <input type="checkbox" id="toggleHideInternational">
            <span class="ipq-switch"><span class="ipq-switch-knob"></span></span>
        </label>
    </div>
</div>

<!-- 指定 IP 查询（保留原有能力） -->
<section class="ipq-card ipq-query" aria-label="指定 IP 或域名查询">
    <form class="ipq-query-form" id="ipqForm" autocomplete="off">
        <input class="ipq-input" type="text" id="ipqInput" name="target"
               placeholder="输入 IP 或域名，例如 8.8.8.8 / 2001:4860::8888 / example.com"
               maxlength="253" spellcheck="false">
        <button class="ipq-btn ipq-btn-primary" type="submit" id="btnIpqQuery">查询</button>
        <button class="ipq-btn" type="button" id="btnIpqMine">查询本机</button>
    </form>
    <div class="ipq-hint">
        快捷示例：
        <a href="#" data-ip="8.8.8.8">8.8.8.8</a> ·
        <a href="#" data-ip="1.1.1.1">1.1.1.1</a> ·
        <a href="#" data-ip="223.5.5.5">223.5.5.5</a> ·
        <a href="#" data-ip="2001:4860::8888">2001:4860::8888</a> ·
        <a href="#" data-ip="127.0.0.1">127.0.0.1</a>
    </div>
</section>

<!-- WebRTC 泄露检测 -->
<section class="ipq-card ipq-webrtc" aria-label="WebRTC 泄露检测">
    <div class="ipq-webrtc-head">
        <div class="ipq-webrtc-icon" aria-hidden="true">🛡</div>
        <div>
            <div class="ipq-section-title">WebRTC 泄露检测</div>
            <div class="ipq-section-desc">检测浏览器 WebRTC 支持状态，以及 ICE 候选中暴露的本地或公网 IP。</div>
        </div>
    </div>
    <div class="ipq-webrtc-grid">
        <div class="ipq-webrtc-stat">
            <div class="ipq-ws-label">WebRTC 支持</div>
            <div class="ipq-ws-value" id="webrtcSupport">--</div>
        </div>
        <div class="ipq-webrtc-stat">
            <div class="ipq-ws-label">泄露状态</div>
            <div class="ipq-ws-value" id="webrtcLeak">--</div>
        </div>
        <div class="ipq-webrtc-stat">
            <div class="ipq-ws-label">公网 / 本地</div>
            <div class="ipq-ws-value" id="webrtcCounts">--</div>
        </div>
    </div>
    <div class="ipq-webrtc-result">
        <div class="ipq-webrtc-result-main">
            <div class="ipq-ws-label">您的 WebRTC IP 地址</div>
            <div class="ipq-ws-ip" id="webrtcIp">--</div>
        </div>
        <div class="ipq-ws-tag" id="webrtcTag">--</div>
        <button type="button" class="ipq-btn-text" id="btnRetryWebrtc">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
            重新检测
        </button>
    </div>
</section>

<!-- 网络延迟检测 -->
<section class="ipq-card ipq-latency" aria-label="网络延迟检测">
    <div class="ipq-latency-head">
        <div>
            <div class="ipq-section-title">网络延迟检测</div>
            <div class="ipq-section-desc">从当前浏览器向国内外常用服务发起探测，数值仅供参考。</div>
        </div>
        <button type="button" class="ipq-btn-text" id="btnRetryLatency">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path></svg>
            重新检测
        </button>
    </div>
    <div class="ipq-latency-grid" id="latencyGrid">
        <!-- JS 填充 -->
    </div>
</section>

<?php
render_page_footer(['scripts' => ['./js/ip.js']]);
