<?php
/**
 * 自检脚本（CLI）：验证单位换算、流量计算、页面内容存取与 IP 查询
 *
 * 运行：php tests/selfcheck.php
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/units.php';
require_once __DIR__ . '/../includes/pages.php';
require_once __DIR__ . '/../includes/ip_service.php';

$passed = 0;
$failed = 0;

function check(string $name, $actual, $expected): void
{
    global $passed, $failed;

    $ok = ($actual == $expected);
    if ($ok) {
        $passed++;
        echo "  ✓ {$name}\n";
    } else {
        $failed++;
        echo "  ✗ {$name}\n";
        echo "      期望: " . var_export($expected, true) . "\n";
        echo "      实际: " . var_export($actual, true) . "\n";
    }
}

echo "== 单位换算 ==\n";
check('1 MB → GB', number_trim(convert_bytes(1, 'MB', 'GB'), 8), '0.00097656');
check('1 GB → MB', convert_bytes(1, 'GB', 'MB'), 1024.0);
check('1024 KB → MB', convert_bytes(1024, 'KB', 'MB'), 1.0);
check('1 MB → B', convert_bytes(1, 'MB', 'B'), 1048576.0);
check('全部单位 B 值', convert_to_all_units(1, 'MB')[0]['value'], '1048576');

echo "\n== 速率与流量 ==\n";
check('1 Mbps → 字节/秒', rate_to_bytes_per_second(1, 'Mbps'), 131072.0);
// 1 Gbps = 1000 Mbps × 0.125 MB/s = 125 MB/s（比特按 1000 进制，字节按 1024 进制）
check('1 Gbps → 字节/秒', rate_to_bytes_per_second(1, 'Gbps'), 131072000.0);
check('1 Kbps → 字节/秒', rate_to_bytes_per_second(1000, 'Kbps'), 131072.0);

$report = traffic_report(2, 'Mbps', 1.10);
check('2 Mbps 每小时流量', $report['rows'][0]['traffic'], '900.00 MB');
check('2 Mbps 每小时 GB', (float) number_format($report['rows'][0]['gigabytes'], 4, '.', ''), 0.8789);
check('2 Mbps 每小时费用', $report['rows'][0]['cost'], '0.97');
check('2 Mbps 每天流量', $report['rows'][1]['traffic'], '21.09 GB');
check('单价为 0 时费用为 0', traffic_report(10, 'Mbps', 0)['rows'][0]['cost'], '0.00');
check('速率为 0 时流量为 0', traffic_report(0, 'Mbps', 1)['rows'][0]['traffic'], '0 B');

echo "\n== 异常输入 ==\n";
$caught = false;
try { convert_bytes(1, 'XX', 'MB'); } catch (InvalidArgumentException $e) { $caught = true; }
check('非法存储单位抛异常', $caught, true);

$caught = false;
try { traffic_report(-1, 'Mbps', 1); } catch (InvalidArgumentException $e) { $caught = true; }
check('负速率抛异常', $caught, true);

$caught = false;
try { traffic_report(1, 'ZZbps', 1); } catch (InvalidArgumentException $e) { $caught = true; }
check('非法速率单位抛异常', $caught, true);

echo "\n== 内容净化 ==\n";
$dirty = '<h2>标题</h2><script>alert(1)</script><p onclick="evil()">段落</p><a href="javascript:alert(2)">恶意链接</a>';
$clean = sanitize_page_html($dirty);
check('移除 script 标签', strpos($clean, '<script') === false, true);
check('移除事件属性', strpos($clean, 'onclick') === false, true);
check('移除 javascript: 协议', strpos($clean, 'javascript:') === false, true);
check('保留 h2 标签', strpos($clean, '<h2>标题</h2>') !== false, true);

echo "\n== 页面存取 ==\n";
$original = page_get('agreement');
$saveResult = page_save('agreement', '<h2>自定义小节</h2><p>这是测试内容</p>');
check('保存返回成功', $saveResult['ok'], true);

$saved = page_get('agreement');
check('读取到自定义内容', $saved['is_custom'], true);
check('内容包含自定义标题', strpos($saved['html'], '自定义小节') !== false, true);
check('目录解析出 1 条', count(page_toc($saved['html'])), 1);
check('锚点已注入', strpos(page_with_anchors($saved['html']), 'id="section-1"') !== false, true);

$resetResult = page_reset('agreement');
check('恢复默认成功', $resetResult['ok'], true);
check('恢复后为默认模板', page_get('agreement')['is_custom'], false);

echo "\n== IP 查询 ==\n";
$privateResult = ip_lookup('192.168.1.1');
check('内网判定', $privateResult['data']['private'], true);
check('内网来源为本地', $privateResult['data']['source'], 'local');

$ipv6Result = ip_lookup('::1');
check('IPv6 回环判定为内网', $ipv6Result['data']['private'], true);

$badResult = ip_lookup('not a valid ip!!!');
check('非法输入返回失败状态', $badResult['status'], 1);
check('非法输入有错误提示', $badResult['message'] !== '', true);

echo "\n== IP 进阶能力 ==";
check('CDN 识别 Cloudflare(AS13335)', ip_detect_cdn('Cloudflare, Inc.', '', 13335)['vendor'], 'Cloudflare');
check('CDN 识别 Akamai', ip_detect_cdn('Akamai International', '', 0)['vendor'], 'Akamai');
check('CDN 识别 阿里云', ip_detect_cdn('Hangzhou Alibaba Advertising Co.,Ltd.', '', 37963)['vendor'], '阿里云 (Alibaba Cloud)');
check('CDN 识别 腾讯 EdgeOne', ip_detect_cdn('Tencent EdgeOne', '', 0)['vendor'], '腾讯 EdgeOne');
check('CDN 类别命中 CDN', ip_detect_cdn('Cloudflare', '', 13335)['category'], 'CDN');
check('非 CDN 未命中', ip_detect_cdn('China Telecom', '', 0)['detected'], false);
check('ip_cdn_vendors 非空', count(ip_cdn_vendors()) > 10, true);
check('ip_normalize 去协议', ip_normalize_target('https://8.8.8.8/path')['value'], '8.8.8.8');
check('ip_normalize 去端口', ip_normalize_target('1.2.3.4:8080')['value'], '1.2.3.4');
check('函数 ip_consistency 可调用', function_exists('ip_consistency'), true);
check('函数 ip_dns_comparison 可调用', function_exists('ip_dns_comparison'), true);
check('函数 ip_tcp_latency 可调用', function_exists('ip_tcp_latency'), true);

echo "\n== 整站框架统一（index/rank 迁移到 layout.php）==\n";
function file_has(string $path, string $needle): bool
{
    return strpos(file_get_contents($path), $needle) !== false;
}
$idxPath    = __DIR__ . '/../index.php';
$rankPath   = __DIR__ . '/../rank.php';
$layoutPath = __DIR__ . '/../includes/layout.php';
$appjsPath  = __DIR__ . '/../js/app.js';
$ipService  = __DIR__ . '/../includes/ip_service.php';

check('index 使用 render_page_header', file_has($idxPath, 'render_page_header('), true);
check('index 使用 render_page_footer', file_has($idxPath, 'render_page_footer('), true);
check('index 不再引用 site_header.php', !file_has($idxPath, 'site_header.php'), true);
check('index 无 main-content 容器', !file_has($idxPath, 'class="main-content"'), true);
check('index 无 footer-public', !file_has($idxPath, 'footer-public'), true);
check('index 保留 app.js（测速引擎）', file_has($idxPath, 'js/app.js'), true);

check('rank 使用 render_page_header', file_has($rankPath, 'render_page_header('), true);
check('rank 使用 render_page_footer', file_has($rankPath, 'render_page_footer('), true);
check('rank 不再引用 site_header.php', !file_has($rankPath, 'site_header.php'), true);
check('rank 无 main-content 容器', !file_has($rankPath, 'class="main-content"'), true);
check('rank 无 footer-public', !file_has($rankPath, 'footer-public'), true);

check('layout 注入 __NP_LAYOUT 守卫', file_has($layoutPath, '__NP_LAYOUT'), true);
check('app.js 受 __NP_LAYOUT 守卫', file_has($appjsPath, '__NP_LAYOUT'), true);

/* ---- 整站查询记录管理 ---- */
$qlogPath = __DIR__ . '/../includes/query_log.php';
check('查询记录辅助文件存在', file_exists($qlogPath), true);
check('查询记录上报接口存在', file_exists(__DIR__ . '/../api/query_log.php'), true);
check('query_log.php 定义 logQuery', file_has($qlogPath, 'function logQuery'), true);
check('query_log.php 定义 resolveQueryUser', file_has($qlogPath, 'function resolveQueryUser'), true);
check('api/ip.php 已挂接 logQuery', file_has(__DIR__ . '/../api/ip.php', 'logQuery'), true);
check('api/ip_advanced.php 已挂接 logQuery', file_has(__DIR__ . '/../api/ip_advanced.php', 'logQuery'), true);
check('api/log.php 已挂接 logQuery', file_has(__DIR__ . '/../api/log.php', 'logQuery'), true);
check('layout.js 提供 reportQuery', file_has(__DIR__ . '/../js/layout.js', 'window.reportQuery'), true);
check('traffic.js 调用 reportQuery', file_has(__DIR__ . '/../js/traffic.js', 'reportQuery'), true);
check('byte.js 调用 reportQuery', file_has(__DIR__ . '/../js/byte.js', 'reportQuery'), true);
check('admin 导航含 查询记录', file_has(__DIR__ . '/../admin/index.php', 'data-page="querylogs"'), true);
check('admin 含 page-querylogs 区块', file_has(__DIR__ . '/../admin/index.php', 'id="page-querylogs"'), true);
check('后台页面编辑器自包含引导脚本存在', file_has(__DIR__ . '/../admin/index.php', 'loadPageEditor'), true);
check('后台页面编辑器接入 page_get 接口', file_has(__DIR__ . '/../admin/index.php', "action=page_get"), true);
check('后台页面编辑器接入 page_save 接口', file_has(__DIR__ . '/../admin/index.php', "action=page_save"), true);
check('ip_source.php 生效源改为下拉选择', file_has(__DIR__ . '/../admin/ip_source.php', 'id="ipSourceActive"'), true);
check('ip_source.php 生效源不再使用 radio', !file_has(__DIR__ . '/../admin/ip_source.php', 'type="radio"'), true);
check('ip_source.php 保存支持 JSON 返回', file_has(__DIR__ . '/../admin/ip_source.php', "['format'] === 'json'"), true);
check('admin 系统设置含 IP 设置模块', file_has(__DIR__ . '/../admin/index.php', 'id="settingsIpSource"'), true);
check('admin IP 设置含保存按钮', file_has(__DIR__ . '/../admin/index.php', 'id="btnSaveIpSource"'), true);
check('admin IP 设置含 loadIpSourceSettings', file_has(__DIR__ . '/../admin/index.php', 'function loadIpSourceSettings'), true);
check('admin IP 设置限定三家提供商', file_has(__DIR__ . '/../admin/index.php', "key: 'uapis'") && file_has(__DIR__ . '/../admin/index.php', "key: 'ip9'") && file_has(__DIR__ . '/../admin/index.php', "key: 'xxapi'"), true);
check('admin 基本设置不再重复渲染 ip_source_active', file_has(__DIR__ . '/../admin/index.php', "key === 'ip_source_active'"), true);
check('layout.php 全局导航含 概览', file_has(__DIR__ . '/../includes/layout.php', "'overview'"), true);
check('layout.php 全局导航 首页 指向 index.php', file_has(__DIR__ . '/../includes/layout.php', "'home' => ['url' => './index.php'"), true);
check('layout.php 全局导航 概览 指向 home.php', file_has(__DIR__ . '/../includes/layout.php', "'overview' => ['url' => './home.php'"), true);
check('index.php 首页导航高亮', file_has(__DIR__ . '/../index.php', "active' => 'home'"), true);
check('home.php 概览导航高亮', file_has(__DIR__ . '/../home.php', "active'   => 'overview'"), true);
check('api/ip.php 提供 registry 接口列出可用源', file_has(__DIR__ . '/../api/ip.php', "case 'registry'"), true);
check('api/ip.php 含 handle_ip_registry', file_has(__DIR__ . '/../api/ip.php', 'function handle_ip_registry'), true);
check('api/ip.php lookup 支持 source 覆盖', file_has(__DIR__ . '/../api/ip.php', 'handle_ip_lookup($target, $sourceOverride)'), true);
check('ip_service.php ip_lookup 接受 sourceOverride', file_has($ipService, 'function ip_lookup(string $target = \'\', ?string $sourceOverride = null)'), true);
check('ip_service.php ip_fetch_remote 接受 preferred', file_has($ipService, 'function ip_fetch_remote(string $ip, ?string $preferred = null)'), true);
check('首页 IP 面板含数据源下拉', file_has(__DIR__ . '/../index.php', 'id="ipSourceSelect"'), true);
check('app.js 含 loadIpSources', file_has(__DIR__ . '/../js/app.js', 'function loadIpSources'), true);
check('app.js 含 bindIpSourceSelector', file_has(__DIR__ . '/../js/app.js', 'function bindIpSourceSelector'), true);
check('app.js 含 currentIpSource 变量', file_has(__DIR__ . '/../js/app.js', 'var currentIpSource'), true);
check('api/admin.php 处理 query_log_list', file_has(__DIR__ . '/../api/admin.php', "case 'query_log_list'"), true);
check('api/admin.php 处理 query_log_delete', file_has(__DIR__ . '/../api/admin.php', "case 'query_log_delete'"), true);
check('feedback_list 安全读取 status（无参数不报 Undefined index）', !file_has(__DIR__ . '/../api/admin.php', "\$_GET['status'] !== ''"), true);

echo "\n== 代码审查加固（2026-09-11） ==";
check('config.php 定义 request_ip（统一 IP 检测入口）', file_has(__DIR__ . '/../config/config.php', 'function request_ip(): string'), true);
check('config.php 定义 is_private_ip', file_has(__DIR__ . '/../config/config.php', 'function is_private_ip(string $ip): bool'), true);
check('helpers.php 不再重复定义 request_ip（消除重声明风险）', !file_has(__DIR__ . '/../includes/helpers.php', 'function request_ip(): string'), true);
check('helpers.php 不再重复定义 is_private_ip', !file_has(__DIR__ . '/../includes/helpers.php', 'function is_private_ip(string $ip): bool'), true);
check('http_get_with_headers 委托 http_get（消除重复实现）', file_has(__DIR__ . '/../includes/helpers.php', 'return http_get($url, $timeout, $headers);'), true);
check('api/admin.php 异常处理器不泄露原始 message', file_has(__DIR__ . '/../api/admin.php', "'message' => '服务器内部错误，请稍后重试'") && !file_has(__DIR__ . '/../api/admin.php', "'服务器内部错误：' . \$e->getMessage()"), true);
check('api/admin.php 致命错误处理器不泄露 file/line', !file_has(__DIR__ . '/../api/admin.php', "'file'   => \$error['file'] . ':' . \$error['line']"), true);
check('api/admin.php hasColumn 校验标识符防止注入', file_has(__DIR__ . '/../api/admin.php', "preg_match('/^[A-Za-z_][A-Za-z0-9_]*\$/', \$table)"), true);
check('config.php 会话 Cookie 设置 SameSite=Lax（CSRF 纵深防御）', file_has(__DIR__ . '/../config/config.php', "session_set_cookie_params(['samesite' => 'Lax'])"), true);
check('Web 根目录已无数据库导出 SQL 文件', count(glob(__DIR__ . '/../*.sql')) === 0, true);
check('Web 根目录已无未授权重置密码工具', !file_exists(__DIR__ . '/../reset_password.php'), true);
check('api/admin.php 处理 query_log_clear', file_has(__DIR__ . '/../api/admin.php', "case 'query_log_clear'"), true);
check('modules.js 定义 loadQueryLogs', file_has(__DIR__ . '/../admin/js/modules.js', 'function loadQueryLogs'), true);
check('core.js 路由 querylogs', file_has(__DIR__ . '/../admin/js/core.js', "case 'querylogs'"), true);
check('建表 SQL 含 query_logs', file_has(__DIR__ . '/../database/upgrade_query_log.sql', 'CREATE TABLE IF NOT EXISTS `query_logs`'), true);

echo "\n== reset_admin.php（CLI / Web 双模式管理员密码重置工具，用完可自毁）==\n";
$resetAdmin = __DIR__ . '/../reset_admin.php';
check('reset_admin.php 存在', file_exists($resetAdmin), true);
check('reset_admin.php 支持 Web/CLI 双模式（不再强制 CLI-only）', !file_has($resetAdmin, "if (PHP_SAPI !== 'cli')"), true);
check('reset_admin.php 提供 Web 表单界面（method=post）', file_has($resetAdmin, 'method="post"'), true);
check('reset_admin.php 含「销毁当前文件」自毁按钮（action=destroy）', file_has($resetAdmin, 'value="destroy"'), true);
check('reset_admin.php 自毁逻辑 unlink(__FILE__)', file_has($resetAdmin, 'unlink(__FILE__)'), true);
check('reset_admin.php 含可选令牌门禁 RESET_KEY', file_has($resetAdmin, 'const RESET_KEY'), true);
check('reset_admin.php 令牌不匹配返回 403', file_has($resetAdmin, '访问被拒绝：需提供正确的 ?token= 参数'), true);
check('reset_admin.php 销毁前二次确认（confirm）', file_has($resetAdmin, "confirm('确定要销毁"), true);
check('reset_admin.php 裸标志分支使用 $opts[$kv]（修复 $k 未定义误写 $opts[\'\'] 的 bug）', file_has($resetAdmin, '$opts[$kv] = true;'), true);
check('reset_admin.php 不再误用 $opts[$k] 写裸标志', !file_has($resetAdmin, '$opts[$k] = true;'), true);
check('reset_admin.php 密码使用 password_hash', file_has($resetAdmin, 'password_hash($newPass'), true);
check('reset_admin.php 不加 noindex/无缓存响应头', file_has($resetAdmin, "header('Cache-Control: no-store"), true);

echo "\n== 新增页面（NAT / 关于我们 / 新版首页）==\n";
$homePath  = __DIR__ . '/../home.php';
$natPath   = __DIR__ . '/../nat.php';
$aboutPath = __DIR__ . '/../about.php';
check('home.php 使用 render_page_header', file_has($homePath, 'render_page_header('), true);
check('home.php 使用 render_page_footer', file_has($homePath, 'render_page_footer('), true);
check('nat.php 使用 render_page_header', file_has($natPath, 'render_page_header('), true);
check('nat.php 使用 render_page_footer', file_has($natPath, 'render_page_footer('), true);
check('about.php 使用 文档页渲染', file_has($aboutPath, 'render_document_page('), true);
check('页面定义含 about', isset(page_definitions()['about']), true);
check('api/nat.php 存在', file_exists(__DIR__ . '/../api/nat.php'), true);
$aboutDef = page_get('about');
check('关于我们默认内容含「关于我们」', strpos($aboutDef['html'], '关于我们') !== false, true);
check('净化保留 img 标签（图文支持）', strpos(sanitize_page_html('<img src="https://x/y.png" alt="z">'), '<img') !== false, true);
check('净化仍移除 script', strpos(sanitize_page_html('<script>x</script><img src="a.png">'), '<script') === false, true);

echo "\n== 首页控制台主题（参照 net.arsn.cn 复原）==\n";
$consoleCss = __DIR__ . '/../css/console.css';
check('console.css 存在', file_exists($consoleCss), true);
check('index 引入 console.css', file_has($idxPath, 'css/console.css'), true);
check('index 标记 body_class=np-console', file_has($idxPath, "'body_class' => 'np-console'"), true);
check('index 使用宽版容器（1280px）', file_has($idxPath, "'wide' => true"), true);
check('console.css 含参考站强调色 #3b82f6', file_has($consoleCss, '#3b82f6'), true);
check('console.css 定义 fl-card 组件', file_has($consoleCss, '.fl-card'), true);
check('console.css 定义 fl-pulse-dot 状态点', file_has($consoleCss, '.fl-pulse-dot'), true);
check('console.css 含响应式断点', file_has($consoleCss, '@media (max-width: 768px)'), true);

/* 关键 DOM id 必须保留，否则 app.js 功能失效 */
$idxSrc = (string) file_get_contents($idxPath);
foreach (['urlSelect', 'threadSlider', 'threadNumLabel', 'switchAutoStart', 'switchKeepAlive',
          'btnPlay', 'btnStop', 'loadingSpinner', 'chartContainer', 'ipInfoContent',
          'allUsedValue', 'speedValue', 'speedBitValue', 'maxUseDisplay', 'maxSpeedDisplay',
          'trafficLimitInput', 'trafficLimitUnit', 'limitHint', 'heartbeatIcon', 'displayCurrentIp',
          'todayRankList'] as $keepId) {
    check("index 保留 #{$keepId}", strpos($idxSrc, 'id="' . $keepId . '"') !== false, true);
}
/* 复原的功能入口（原 index.php 缺失，app.js 已实现但无触发点） */
foreach (['btnEditNodes', 'btnCopyUrl', 'btnEditMax', 'btnEditSpeed', 'btnPredict'] as $entryId) {
    check("index 补回入口 #{$entryId}", strpos($idxSrc, 'id="' . $entryId . '"') !== false, true);
}
check('index 已移除旧类 main-panel', !file_has($idxPath, 'main-panel'), true);
check('index 已移除旧类 data-cards', !file_has($idxPath, 'data-cards'), true);

/* id 唯一性（layout.php 头部 + index.php 主体） */
$layoutSrc = (string) file_get_contents($layoutPath);
preg_match_all('/id="([\w-]+)"/', $idxSrc . $layoutSrc, $idMatches);
$idDupes = array_keys(array_filter(array_count_values($idMatches[1]), function ($c) { return $c > 1; }));
check('index/layout 无重复 id', empty($idDupes) ? 'none' : implode(',', $idDupes), 'none');

echo "\n== 首页功能修复（重复入口 / 图表 / 上限 / IP 信息）==\n";

/* 1) 登录注册唯一入口：会话条不再重复渲染 */
check('index 已移除重复的 authBtnGroup', !file_has($idxPath, 'authBtnGroup'), true);
check('index 不再出现「登录」「注册」链接', !file_has($idxPath, '>登录</a>') && !file_has($idxPath, '>注册</a>'), true);
check('layout 保留唯一登录入口 btnLogin', file_has($layoutPath, 'id="btnLogin"'), true);
check('layout 保留唯一注册入口 btnRegister', file_has($layoutPath, 'id="btnRegister"'), true);

/* 2) 实时图表：必须加载 ECharts 运行时 */
check('public/echarts.min.js 存在', file_exists(__DIR__ . '/../public/echarts.min.js'), true);
check('index 引入 echarts.min.js', file_has($idxPath, 'public/echarts.min.js'), true);
check('echarts 排在 app.js 之前', strpos($idxSrc, 'echarts.min.js') < strpos($idxSrc, 'js/app.js'), true);
check('app.js 定义 setChartState', file_has($appjsPath, 'function setChartState'), true);
check('index 含图表空态容器 chartState', file_has($idxPath, 'id="chartState"'), true);

/* 3) 三项功能：$() 必须兼容 "#id" 写法（此前未剥离 # 导致 13 处弹窗全部失效） */
check('app.js $() 剥离 # 前缀', file_has($appjsPath, "replace(/^#/, '')"), true);
check('app.js 定义 parseLimitInput 边界校验', file_has($appjsPath, 'function parseLimitInput'), true);
check('app.js 定义 syncTrafficLimitInputs 双向同步', file_has($appjsPath, 'function syncTrafficLimitInputs'), true);
check('app.js 定义 bindActivate 键盘可达', file_has($appjsPath, 'function bindActivate'), true);
check('app.js 上限未设置显示「未设置」', file_has($appjsPath, "? formatBytes(state.maxUse, 0) : '未设置'"), true);
check('index 含用量预测无数据提示 predictTip', file_has($idxPath, 'id="predictTip"'), true);

/* 4) IP 信息区块 */
check('app.js 定义 renderIpInfoCard', file_has($appjsPath, 'function renderIpInfoCard'), true);
foreach (['ipAddr' => 'IP 地址', 'ipRegion' => '归属地', 'ipIsp' => '运营商', 'ipStatus' => '连接状态'] as $fid => $label) {
    check("index 含 {$label} 字段 #{$fid}", file_has($idxPath, 'id="' . $fid . '"'), true);
}
check('index 含 IP 信息重新检测按钮', file_has($idxPath, 'id="btnRefreshIp"'), true);
check('console.css 定义 cn-ip-grid 网格', file_has($consoleCss, '.cn-ip-grid'), true);
check('console.css 移动端 IP 网格单列', file_has($consoleCss, 'body.np-console .cn-ip-grid { grid-template-columns: 1fr; }'), true);

/* 5) 静态资源版本号（避免浏览器沿用旧 JS/CSS 缓存） */
check('layout 定义 asset_url', file_has($layoutPath, 'function asset_url'), true);
check('layout 脚本走 asset_url', file_has($layoutPath, 'asset_url($script)'), true);

echo "\n== NAT 检测能力 ==\n";
$natPage = __DIR__ . '/../nat.php';
$natApi  = __DIR__ . '/../api/nat.php';
$natJs   = __DIR__ . '/../js/nat.js';
$natCss  = __DIR__ . '/../css/nat.css';

/* 1) 页面框架与资源 */
check('nat.php 使用 render_page_header', file_has($natPage, 'render_page_header('), true);
check('nat.php 使用 render_page_footer', file_has($natPage, 'render_page_footer('), true);
check('nat.php 引入 css/nat.css', file_has($natPage, 'css/nat.css'), true);
check('nat.php 引入 js/nat.js', file_has($natPage, 'js/nat.js'), true);

/* 2) 五种 NAT 类型结论卡必须齐全（含直连 / 无 NAT） */
$natTypes = [
    'open'             => '直连或无 NAT',
    'cone'             => '全锥型 Full Cone',
    'restricted'       => '受限锥型 Restricted Cone',
    'port-restricted'  => '端口受限锥型 Port-Restricted Cone',
    'symmetric'        => '对称型 Symmetric',
];
foreach ($natTypes as $k => $label) {
    check("nat.php 含 {$label} 说明卡 #natCard-{$k}", file_has($natPage, 'id="natCard-' . $k . '"'), true);
}

/* 3) 报告面板关键字段 */
$natFields = [
    'natResultType'   => 'NAT 类型结论',
    'natResultTag'    => 'RFC 编号标签',
    'natMappingLabel' => '映射行为标签',
    'natBasisList'    => '判定依据 chips',
    'natMappingTable' => '映射行为分析表',
    'natRaw'          => '原始探测数据',
    'statEndpoints'   => '映射端点数',
    'statMappedIps'   => '映射地址数',
    'statSrflxCands'  => 'srflx 候选数',
    'statLocalCands'  => 'host 候选数',
    'statTcpCands'    => 'TCP 候选数',
    'statRounds'      => '采样轮次',
    'statElapsed'     => '检测耗时',
    'crossHttpIp'     => 'HTTP 出口 IP',
    'crossStunIp'     => 'STUN 映射 IP',
    'crossClue'       => '交叉校验线索',
    'natConfidence'   => '置信度',
    'confReason'      => '置信度依据',
    'btnStartNat'     => '开始检测按钮',
];
foreach ($natFields as $fid => $label) {
    check("nat.php 含 {$label} #{$fid}", file_has($natPage, 'id="' . $fid . '"'), true);
}

/* 4) 未确认项必须显式标注（过滤行为 / hairpinning / TCP） */
foreach (['filterVerdict' => '过滤行为', 'hairpinVerdict' => 'Hairpinning', 'tcpVerdict' => 'TCP 差异'] as $fid => $label) {
    check("nat.php 含 {$label} 结论位 #{$fid}", file_has($natPage, 'id="' . $fid . '"'), true);
}
check('nat.php 含「未能确认的检测项」区块', file_has($natPage, '未能确认的检测项'), true);
check('nat.php 说明检测流程与判定规则', file_has($natPage, '检测流程与判定规则'), true);
check('nat.php 说明多层 NAT/CGNAT/防火墙限制', file_has($natPage, '边界情况与限制'), true);

/* 5) 检测核心方法论（关键：同一连接挂载全部 STUN，保证本地端口相同才可比） */
check('nat.js 定义 STUN_SERVERS', file_has($natJs, 'var STUN_SERVERS'), true);
check('nat.js STUN 节点 >= 10 个', preg_match_all('/^\s*\'stun:/m', file_get_contents($natJs)) >= 10, true);
check('nat.js 单连接挂载全部 STUN（同一本地端口）', file_has($natJs, 'iceServers: STUN_SERVERS.map'), true);
check('nat.js 未使用 addIceServer（避免破坏单端口前提）', !file_has($natJs, 'addIceServer'), true);
check('nat.js 定义 sampleRound 采样轮', file_has($natJs, 'function sampleRound'), true);
check('nat.js 多轮采样 ROUND_COUNT = 3', file_has($natJs, 'ROUND_COUNT = 3'), true);
check('nat.js 通过 getStats 的 url 归属映射目标', file_has($natJs, 'url: r.url'), true);
check('nat.js 识别 srflx 候选', file_has($natJs, "'srflx'"), true);
check('nat.js 判定 APDM（对称型）', file_has($natJs, 'APDM'), true);
check('nat.js 判定 EIM（锥型族）', file_has($natJs, 'EIM'), true);
check('nat.js 识别 mDNS 混淆地址', file_has($natJs, 'function isMdns'), true);
check('nat.js 本地/私网出口不做 CGNAT 误判', file_has($natJs, '不能代表公网出口'), true);
check('nat.js 仅 GET 拉取出口地址', file_has($natJs, "fetch('./api/nat.php'"), true);

/* 6) 隐私：候选仅本地使用，不上传服务端 */
check('api/nat.php 不读取请求体（无候选上报）', !file_has($natApi, 'php://input'), true);
check('api/nat.php 返回出口 IP', file_has($natApi, "'ip'"), true);
check('api/nat.php 返回地址族 family', file_has($natApi, "'family'"), true);
check('api/nat.php 返回代理头 forwarded', file_has($natApi, "'forwarded'"), true);

/* 7) 样式完整性 */
foreach (['.nat-verdict', '.nat-table', '.nat-raw', '.nat-type', '.nat-chip-ok', '.nat-unknown'] as $cls) {
    check("css/nat.css 定义 {$cls}", file_has($natCss, $cls), true);
}
check('css/nat.css 含移动端断点', file_has($natCss, '@media'), true);

echo "\n== IP 源模块（多供应商 + 后台切换） ==";
$helpers   = __DIR__ . '/../includes/helpers.php';
$ipApi     = __DIR__ . '/../api/ip.php';
check('ip_service.php 含供应商注册表 ip_source_registry', file_has($ipService, 'function ip_source_registry'), true);
check('ip_service.php 含既有源 ip9（未被移除）', file_has($ipService, 'function ip_source_ip9'), true);
check('ip_service.php 含 uapis.cn 源 ip_source_uapis', file_has($ipService, 'function ip_source_uapis'), true);
check('ip_service.php 含 xxapi.cn 源 ip_source_xxapi', file_has($ipService, 'function ip_source_xxapi'), true);
check('ip_service.php 支持 uapis token 覆盖参数', file_has($ipService, 'tokenOverride'), true);
check('ip_service.php 按 ip_source_active 调度（不硬编码破坏既有）', file_has($ipService, "app_setting('ip_source_active'"), true);
check('helpers.php 含带请求头 HTTP 函数（供 token 鉴权）', file_has($helpers, 'function http_get_with_headers'), true);
check('helpers.php 含 app_setting 单项配置读取', file_has($helpers, 'function app_setting'), true);
check('api/ip.php 复用 ip_service 调度', file_has($ipApi, 'ip_lookup') || file_has($ipApi, 'ip_fetch_remote'), true);
check('api/ip.php 支持 IPv6 检测 action=ipv6', file_has($ipApi, "case 'ipv6':"), true);
check('api/ip.php 支持多源 action=sources', file_has($ipApi, "case 'sources':"), true);
check('api/ip.php 支持延迟目标 action=latency', file_has($ipApi, "case 'latency':"), true);

$ipQueryPage = __DIR__ . '/../ip.php';
$ipQueryJs   = __DIR__ . '/../js/ip.js';
$ipQueryCss  = __DIR__ . '/../css/ip.css';
check('ip.php 升级为 FlowLoss 风格并引入 css/ip.css', file_has($ipQueryPage, "css/ip.css") && file_has($ipQueryPage, '本机 IP 查询'), true);
check('ip.php 含 IPv6 检测区', file_has($ipQueryPage, 'id="ipv6Status"'), true);
check('ip.php 含多源结果区', file_has($ipQueryPage, 'id="sourcesList"'), true);
check('ip.php 含 WebRTC 检测区', file_has($ipQueryPage, 'id="webrtcSupport"') && file_has($ipQueryPage, 'id="webrtcIp"'), true);
check('ip.php 含延迟检测区', file_has($ipQueryPage, 'id="latencyGrid"'), true);
check('ip.php 含隐私开关（隐藏 IP / 国内 / 国际）', file_has($ipQueryPage, 'id="toggleHideIp"') && file_has($ipQueryPage, 'id="toggleHideDomestic"') && file_has($ipQueryPage, 'id="toggleHideInternational"'), true);
check('js/ip.js 实现 WebRTC 泄露检测', file_has($ipQueryJs, 'RTCPeerConnection') && file_has($ipQueryJs, 'detectWebrtc'), true);
check('js/ip.js 实现延迟检测 fetch', file_has($ipQueryJs, 'measureLatency') && file_has($ipQueryJs, "mode: 'no-cors'"), true);
check('js/ip.js 实现 IPv6 重试', file_has($ipQueryJs, 'loadIpv6') && file_has($ipQueryJs, 'btnRetryIpv6'), true);
check('css/ip.css 含国内 badge', file_has($ipQueryCss, 'ipq-tag-domestic'), true);
check('css/ip.css 含国际 badge', file_has($ipQueryCss, 'ipq-tag-international'), true);
check('css/ip.css 含深色模式适配', file_has($ipQueryCss, 'html[data-theme="dark"]'), true);

echo "\n== 面板设置 / 紧凑 / 蓝控 / 主题切换 ==";
$settingsPage = __DIR__ . '/../settings.php';
$panelCss     = __DIR__ . '/../css/panel.css';
$pagesCss     = __DIR__ . '/../css/pages.css';
$themeJs      = __DIR__ . '/../js/theme.js';
$settingsJs   = __DIR__ . '/../js/settings.js';
$layoutFile   = __DIR__ . '/../includes/layout.php';
$speedApi     = __DIR__ . '/../api/speedtest.php';

check('settings.php 使用 render_page_header', file_has($settingsPage, 'render_page_header('), true);
check('settings.php 使用 render_page_footer', file_has($settingsPage, 'render_page_footer('), true);
check('settings.php 引入 panel.css', file_has($settingsPage, 'css/panel.css'), true);
check('settings.php 引入 theme.js + settings.js', file_has($settingsPage, 'js/theme.js') && file_has($settingsPage, 'js/settings.js'), true);
check('settings.php 含主题选择 #setTheme', file_has($settingsPage, 'id="setTheme"'), true);
check('settings.php 含按时间段自动切换 #setAutoTime', file_has($settingsPage, 'id="setAutoTime"'), true);
check('settings.php 含紧凑排版开关 #setCompact', file_has($settingsPage, 'id="setCompact"'), true);
check('settings.php 含定时测速启用 #setStEnabled', file_has($settingsPage, 'id="setStEnabled"'), true);
check('settings.php 含立即测速 #btnRunNow', file_has($settingsPage, 'id="btnRunNow"'), true);
check('settings.php 含历史记录区 #stHistory', file_has($settingsPage, 'id="stHistory"'), true);
check('settings.php 含 AOD 开关 #setAodEnabled', file_has($settingsPage, 'id="setAodEnabled"'), true);
check('settings.php 含 AOD 预览 #btnAodPreview', file_has($settingsPage, 'id="btnAodPreview"'), true);
check('settings.php 含 AOD 叠层 #npAod', file_has($settingsPage, 'id="npAod"'), true);
check('settings.php 含开机自启(降级禁用) #setAutoStart', file_has($settingsPage, 'id="setAutoStart"'), true);
check('settings.php 含后台常驻(降级禁用) #setBackground', file_has($settingsPage, 'id="setBackground"'), true);
check('settings.php 标注「需桌面客户端」', file_has($settingsPage, '需桌面客户端'), true);

check('layout 引入 panel.css', file_has($layoutFile, 'css/panel.css'), true);
check('layout 引入 js/theme.js', file_has($layoutFile, 'js/theme.js'), true);
check('layout 头部含外观菜单 #npThemeMenu', file_has($layoutFile, 'id="npThemeMenu"'), true);
check('layout 首帧前内联应用 data-theme（防闪烁）', file_has($layoutFile, "setAttribute('data-theme'"), true);
check('layout 导航含面板设置', file_has($layoutFile, "'settings'"), true);

check('pages.css 页脚全局居中 .np-footer text-align: center', file_has($pagesCss, '.np-footer {') && file_has($pagesCss, 'text-align: center'), true);
check('pages.css 页脚链接水平居中 justify-content: center', file_has($pagesCss, '.np-footer-links {') && file_has($pagesCss, 'justify-content: center'), true);
check('pages.css 页脚元信息水平居中 .np-footer-meta justify-content: center', file_has($pagesCss, '.np-footer-meta {') && file_has($pagesCss, 'justify-content: center'), true);

check('panel.css 定义浅色变量 [data-theme=light]', file_has($panelCss, 'html[data-theme="light"]'), true);
check('panel.css 定义深色变量 [data-theme=dark]', file_has($panelCss, 'html[data-theme="dark"]'), true);
check('panel.css 紧凑模式 html.np-compact', file_has($panelCss, 'html.np-compact'), true);
check('panel.css 蓝控主按钮四态(禁用)', file_has($panelCss, '.np-btn:disabled'), true);
check('panel.css 开关控件 .np-switch', file_has($panelCss, '.np-switch'), true);
check('panel.css 滑块 .np-range', file_has($panelCss, '.np-range'), true);
check('panel.css 进度条 .np-progress', file_has($panelCss, '.np-progress'), true);
check('panel.css AOD 叠层 #npAod', file_has($panelCss, '#npAod'), true);

check('theme.js 定义 NPSettings', file_has($themeJs, 'window.NPSettings'), true);
check('theme.js 配置键 np_panel_settings', file_has($themeJs, "'np_panel_settings'"), true);
check('theme.js 解析主题 resolveTheme', file_has($themeJs, 'function resolveTheme'), true);
check('theme.js 时间段深色 inDarkWindow', file_has($themeJs, 'function inDarkWindow'), true);
check('theme.js 应用紧凑 np-compact', file_has($themeJs, 'np-compact'), true);
check('theme.js 历史记录键 np_speed_history', file_has($themeJs, "'np_speed_history'"), true);

check('settings.js 绑定主题 #setTheme', file_has($settingsJs, "'setTheme'"), true);
check('settings.js 测速 runSpeedTest', file_has($settingsJs, 'function runSpeedTest'), true);
check('settings.js AOD openAod', file_has($settingsJs, 'function openAod'), true);
check('aod.js 申请 Wake Lock', file_has(__DIR__ . '/../js/aod.js', "navigator.wakeLock.request('screen')"), true);

// 熄灯模式：网页内全屏 / 整体全屏
check('settings.php 含熄灯模式选择 #setAodMode', file_has($settingsPage, 'id="setAodMode"'), true);
check('settings.php 含当前模式指示 #aodModeIndicator', file_has($settingsPage, 'id="aodModeIndicator"'), true);
check('aod.js 含整体全屏 requestFullscreen', file_has(__DIR__ . '/../js/aod.js', 'requestFullscreen'), true);
check('aod.js 监听 fullscreenchange 退出 AOD', file_has(__DIR__ . '/../js/aod.js', 'fullscreenchange'), true);
check('aod.js 根据配置切换全屏 enterFullscreenIfNeeded', file_has(__DIR__ . '/../js/aod.js', 'enterFullscreenIfNeeded'), true);
check('theme.js 默认 aod.mode = web', file_has($themeJs, "mode: 'web'"), true);
check('settings.js 绑定熄灯模式切换', file_has($settingsJs, "setAodMode") || (file_has($settingsJs, "'#setAodMode'")), true);
check('panel.css 定义分段控制 .np-seg', file_has($panelCss, '.np-seg'), true);
check('settings.js 定时调度 startScheduler', file_has($settingsJs, 'function startScheduler'), true);

check('api/speedtest.php 支持 download', file_has($speedApi, "action === 'download'"), true);
check('api/speedtest.php 支持 ping', file_has($speedApi, "action === 'ping'"), true);
check('api/speedtest.php size 已被 clamp', file_has($speedApi, '$sizeMb > 16'), true);

echo "\n----------------------------------------\n";
echo "通过 {$passed} 项，失败 {$failed} 项\n";

exit($failed === 0 ? 0 : 1);
