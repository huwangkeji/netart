-- ============================================================
-- UCenter 账号互通：本地用户 <-> UCenter uid 绑定表
-- 幂等：重复执行安全
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_ucenter` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL COMMENT '本地用户ID',
    `uc_uid` INT UNSIGNED NOT NULL COMMENT 'UCenter 用户ID',
    `username` VARCHAR(64) DEFAULT '' COMMENT 'UCenter 用户名（冗余，便于排查）',
    `email` VARCHAR(128) DEFAULT '' COMMENT 'UCenter 邮箱（冗余）',
    `synced_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uniq_user` (`user_id`),
    UNIQUE KEY `uniq_uc_uid` (`uc_uid`),
    KEY `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='UCenter 账号绑定';
