-- ============================================================
-- 升级脚本：自定义页面（用户协议 / 隐私政策）+ 工具页默认配置
-- 兼容 MySQL 5.7 / 8.0，可重复执行（幂等）
-- ============================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `site_settings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(80) NOT NULL UNIQUE COMMENT '配置键',
    `setting_value` TEXT COMMENT '配置值',
    `setting_type` ENUM('string','int','bool','json','text') DEFAULT 'string' COMMENT '值类型',
    `title` VARCHAR(100) DEFAULT '' COMMENT '中文标题',
    `description` VARCHAR(255) DEFAULT '' COMMENT '说明',
    `group_name` VARCHAR(50) DEFAULT 'basic' COMMENT '配置分组',
    `sort_order` INT DEFAULT 0,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='网站设置表';

-- 页面内容（留空 = 使用系统内置默认模板；后台「页面管理」可随时覆盖）
INSERT IGNORE INTO `site_settings`
    (`setting_key`, `setting_value`, `setting_type`, `title`, `description`, `group_name`, `sort_order`)
VALUES
    ('page_agreement', '', 'text', '用户协议内容', '《用户协议》正文，留空则使用系统默认模板；支持 h2/h3/p/ul/li/strong/a 等标签', 'pages', 1),
    ('page_privacy',   '', 'text', '隐私政策内容', '《隐私政策》正文，留空则使用系统默认模板；支持 h2/h3/p/ul/li/strong/a 等标签', 'pages', 2);

-- 流量计算器默认参数
INSERT IGNORE INTO `site_settings`
    (`setting_key`, `setting_value`, `setting_type`, `title`, `description`, `group_name`, `sort_order`)
VALUES
    ('traffic_price',         '1.10', 'string', '流量单价(元/GB)', '流量计算器的默认单价', 'basic', 10),
    ('traffic_default_speed', '2',    'string', '计算器默认速率(Mbps)', '流量计算器打开时的默认速率', 'basic', 11);

-- 顶部导航指向真实页面（仅在仍为旧占位值时更新，避免覆盖管理员自定义配置）
UPDATE `site_settings`
SET `setting_value` = '[{"name":"IP查询","url":"./ip.php"},{"name":"流量计算器","url":"./traffic.php"},{"name":"字节转换","url":"./byte.php"}]'
WHERE `setting_key` = 'nav_links'
  AND (
        `setting_value` = ''
     OR `setting_value` = '[{"name":"IP查询","url":"#ipPanel"},{"name":"流量计算器","url":"#"}]'
     OR `setting_value` = '[{"name":"IP查询","url":"#"},{"name":"流量计算器","url":"#"}]'
  );

-- ============================================================
-- 首页动态模块配置（重要合规提示 / 公告提示），后台可开关 + 自定义内容
-- ============================================================
INSERT IGNORE INTO `site_settings`
    (`setting_key`, `setting_value`, `setting_type`, `title`, `description`, `group_name`, `sort_order`)
VALUES
    ('home_compliance_enabled', '0',    'bool',  '首页重要合规提示-启用', '首页是否展示「重要合规提示」模块', 'homepage', 1),
    ('home_compliance_text',    '',     'text',  '首页重要合规提示-内容', '合规提示正文，支持 HTML（未成年人保护、合规使用、免责声明等）', 'homepage', 2),
    ('home_compliance_bg',      '#fff9e6', 'string', '首页重要合规提示-底色', '合规提示模块背景色，默认浅黄', 'homepage', 3),
    ('home_notice_enabled',     '0',    'bool',  '首页公告提示-启用',       '首页是否展示「公告提示」模块', 'homepage', 4),
    ('home_notice_text',        '',     'text',  '首页公告提示-内容',       '公告提示正文，支持 HTML（活动通知、维护公告、推广信息等）', 'homepage', 5);

