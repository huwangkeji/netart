-- ============================================================
-- 第三方登录（QQ / 微信扫码登录）相关结构
-- 幂等：重复执行安全
-- ============================================================

CREATE TABLE IF NOT EXISTS `user_social` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `provider` ENUM('qq','wx') NOT NULL,
    `openid` VARCHAR(64) NOT NULL,
    `unionid` VARCHAR(64) DEFAULT '',
    `nickname` VARCHAR(64) DEFAULT '',
    `avatar` VARCHAR(500) DEFAULT '',
    `access_token` VARCHAR(500) DEFAULT '',
    `refresh_token` VARCHAR(500) DEFAULT '',
    `expires_in` INT DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uniq_provider_openid` (`provider`,`openid`),
    KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='第三方账号绑定';

INSERT IGNORE INTO `site_settings` (`setting_key`,`setting_value`,`setting_type`,`title`,`description`,`group_name`,`sort_order`) VALUES
('oauth_qq_enabled','0','bool','QQ 登录-启用','开启后登录页显示 QQ 扫码登录入口（需配置 AppID/AppKey）','oauth',1),
('oauth_qq_appid','','string','QQ 登录-AppID','QQ 互联（connect.qq.com）网站应用 AppID','oauth',2),
('oauth_qq_appkey','','string','QQ 登录-AppKey','QQ 互联应用 AppKey（即 AppSecret）','oauth',3),
('oauth_qq_callback','','string','QQ 登录-回调地址','完整回调 URL，例如 http://域名/user/oauth.php?action=callback&provider=qq','oauth',4),
('oauth_wx_enabled','0','bool','微信登录-启用','开启后登录页显示微信扫码登录入口（需配置 AppID/AppSecret）','oauth',5),
('oauth_wx_appid','','string','微信登录-AppID','微信开放平台 网站应用 AppID','oauth',6),
('oauth_wx_appsecret','','string','微信登录-AppSecret','微信开放平台 网站应用 AppSecret','oauth',7),
('oauth_wx_callback','','string','微信登录-回调地址','完整回调 URL，例如 http://域名/user/oauth.php?action=callback&provider=wx','oauth',8);

-- UCenter 账号互通配置
INSERT IGNORE INTO `site_settings` (`setting_key`,`setting_value`,`setting_type`,`title`,`description`,`group_name`,`sort_order`) VALUES
('uc_enabled','0','bool','UCenter 同步-启用','开启后与 Discuz UCenter 双向同步账号','ucenter',1),
('uc_api','','string','UCenter 通信地址','UCenter 服务端地址，例如 http://bbs.example.com/uc_server','ucenter',2),
('uc_key','','string','UCenter 通信密钥','UCenter 应用通信密钥（uc_key）','ucenter',3),
('uc_appid','','string','当前应用 ID','在 UCenter 中本应用的 APP ID','ucenter',4),
('uc_ip','','string','UCenter 服务器 IP','留空则自动解析（可选）','ucenter',5),
('uc_charset','utf-8','string','字符集','与 UCenter 一致的字符集','ucenter',6),
('uc_connect','mysql','string','数据库连接方式','mysql 或 default','ucenter',7),
('uc_dbhost','','string','UCenter 数据库主机','直连 UCenter 数据库主机（可选）','ucenter',8),
('uc_dbuser','','string','UCenter 数据库用户','直连数据库用户名（可选）','ucenter',9),
('uc_dbpw','','string','UCenter 数据库密码','直连数据库密码（可选）','ucenter',10),
('uc_dbname','','string','UCenter 数据库名','直连数据库名（可选）','ucenter',11),
('uc_dbtablepre','uc_','string','UCenter 表前缀','UCenter 数据库表前缀','ucenter',12);
