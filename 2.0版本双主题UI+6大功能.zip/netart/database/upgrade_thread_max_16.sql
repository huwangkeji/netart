-- ============================================================
-- 升级脚本：最大线程数从 64 调整为 16
-- 与前端 slider max="16"、api/log.php 服务端钳制保持一致
-- ============================================================

SET NAMES utf8mb4;

-- 幂等更新：若记录存在则改为 16，不存在则插入
INSERT INTO `site_settings` (`setting_key`, `setting_value`, `setting_type`, `title`, `description`, `group_name`, `sort_order`)
VALUES ('max_thread_num', '16', 'int', '最大线程数限制', '用户可设置的最大线程数', 'advanced', 2)
ON DUPLICATE KEY UPDATE
    `setting_value` = '16',
    `setting_type` = 'int',
    `title` = VALUES(`title`),
    `description` = VALUES(`description`),
    `group_name` = VALUES(`group_name`),
    `sort_order` = VALUES(`sort_order`);
