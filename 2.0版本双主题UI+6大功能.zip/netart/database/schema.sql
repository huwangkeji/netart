-- ============================================================
-- NetworkPanel PHP版本 - 完整数据库结构（含后台管理/会员系统）
-- 兼容 MySQL 5.7 / 8.0
-- ============================================================

-- 兼容性设置
SET NAMES utf8mb4;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET time_zone = '+00:00';

-- ============================================================
-- 数据库创建（按需取消注释）
-- ============================================================
-- CREATE DATABASE IF NOT EXISTS `network_panel` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE `network_panel`;

-- ==================== 会员/用户表 ====================
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    `email` VARCHAR(100) DEFAULT '' COMMENT '邮箱',
    `password_hash` VARCHAR(255) NOT NULL COMMENT '密码哈希',
    `access_token` VARCHAR(64) NOT NULL UNIQUE COMMENT '访问令牌(API用)',
    `headimg` VARCHAR(500) DEFAULT '' COMMENT '头像URL',
    `isp` VARCHAR(50) DEFAULT '' COMMENT '运营商',
    `region` VARCHAR(100) DEFAULT '' COMMENT '地区',
    `region_short` VARCHAR(100) DEFAULT '' COMMENT '地区简称',
    `ip` VARCHAR(45) DEFAULT '' COMMENT '最后登录IP',
    `role` ENUM('user','vip','admin') DEFAULT 'user' COMMENT '角色:普通/VIP/管理员',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0禁用 1正常',
    `total_bytes` BIGINT UNSIGNED DEFAULT 0 COMMENT '累计使用流量(字节)',
    `total_time` DECIMAL(12,2) DEFAULT 0 COMMENT '累计在线时长(秒)',
    `last_active` DATETIME DEFAULT NULL COMMENT '最后活跃时间',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_role` (`role`),
    INDEX `idx_status` (`status`),
    INDEX `idx_access_token` (`access_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员/用户表';

-- ==================== 管理员表 ====================
CREATE TABLE IF NOT EXISTS `admins` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '管理员账号',
    `password_hash` VARCHAR(255) NOT NULL COMMENT '密码哈希',
    `nickname` VARCHAR(50) DEFAULT '' COMMENT '昵称',
    `role` ENUM('super_admin','admin','editor') DEFAULT 'admin' COMMENT '角色',
    `last_login` DATETIME DEFAULT NULL,
    `last_ip` VARCHAR(45) DEFAULT '',
    `login_count` INT UNSIGNED DEFAULT 0,
    `status` TINYINT DEFAULT 1 COMMENT '0禁用 1正常',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='后台管理员表';

-- ==================== 节点表（服务端全局节点，所有用户可见）====================
CREATE TABLE IF NOT EXISTS `nodes` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `group_name` VARCHAR(50) NOT NULL DEFAULT '默认' COMMENT '分组名',
    `label` VARCHAR(100) NOT NULL COMMENT '节点显示名称',
    `url` VARCHAR(500) NOT NULL COMMENT '下载URL或NetworkPanel协议地址',
    `url_type` ENUM('http','api') DEFAULT 'http' COMMENT 'URL类型:http直接下载/api协议解析',
    `sort_order` INT DEFAULT 0 COMMENT '排序权重(越小越前)',
    `status` TINYINT DEFAULT 1 COMMENT '0隐藏 1启用',
    `description` VARCHAR(255) DEFAULT '' COMMENT '备注描述',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_group` (`group_name`),
    INDEX `idx_status` (`status`),
    INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测速节点表';

-- ==================== 网站配置表（键值对）====================
CREATE TABLE IF NOT EXISTS `site_settings` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(80) NOT NULL UNIQUE COMMENT '配置键',
    `setting_value` TEXT COMMENT '配置值',
    `setting_type` ENUM('string','int','bool','json','text') DEFAULT 'string' COMMENT '值类型',
    `title` VARCHAR(100) DEFAULT '' COMMENT '中文标题',
    `description` VARCHAR(255) DEFAULT '' COMMENT '说明',
    `group_name` VARCHAR(50) DEFAULT 'basic' COMMENT '配置分组',
    `sort_order` INT DEFAULT 0,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='网站设置表';

-- ==================== 流量日志表 ====================
CREATE TABLE IF NOT EXISTS `traffic_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT 0 COMMENT '用户ID，0表示匿名',
    `url` VARCHAR(500) NOT NULL DEFAULT '' COMMENT '测速URL/节点地址',
    `thread_num` TINYINT UNSIGNED DEFAULT 1 COMMENT '线程数',
    `bytes_used` BIGINT UNSIGNED DEFAULT 0 COMMENT '使用的流量字节数',
    `duration` DECIMAL(10,2) DEFAULT 0 COMMENT '持续时间（秒）',
    `speed` BIGINT UNSIGNED DEFAULT 0 COMMENT '平均速度(B/s)',
    `ip` VARCHAR(45) DEFAULT '' COMMENT '客户端IP',
    `user_agent` VARCHAR(500) DEFAULT '' COMMENT '浏览器UA',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_bytes_used` (`bytes_used`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='流量日志表';

-- ==================== IP缓存表 ====================
CREATE TABLE IF NOT EXISTS `ip_cache` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `ip` VARCHAR(45) NOT NULL UNIQUE,
    `country_code` CHAR(2) DEFAULT '',
    `country_name` VARCHAR(100) DEFAULT '',
    `registered_country_code` CHAR(2) DEFAULT '',
    `registered_country_name` VARCHAR(100) DEFAULT '',
    `regions` JSON DEFAULT NULL,
    `regions_short` JSON DEFAULT NULL,
    `asn_number` INT UNSIGNED DEFAULT 0,
    `asn_name` VARCHAR(255) DEFAULT '',
    `asn_info` VARCHAR(255) DEFAULT '',
    `type` VARCHAR(20) DEFAULT '',
    `addr` VARCHAR(255) DEFAULT '',
    `cached_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_cached_at` (`cached_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='IP查询缓存表';

-- ==================== 统计聚合表 ====================
CREATE TABLE IF NOT EXISTS `stats_hourly` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT 0,
    `hour_start` DATETIME NOT NULL,
    `total_bytes` BIGINT UNSIGNED DEFAULT 0,
    `total_duration` DECIMAL(12,2) DEFAULT 0,
    `avg_speed` DECIMAL(15,2) DEFAULT 0,
    UNIQUE KEY `uk_user_hour` (`user_id`, `hour_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `stats_daily` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT 0,
    `day_start` DATE NOT NULL,
    `total_bytes` BIGINT UNSIGNED DEFAULT 0,
    `total_duration` DECIMAL(12,2) DEFAULT 0,
    `avg_speed` DECIMAL(15,2) DEFAULT 0,
    UNIQUE KEY `uk_user_day` (`user_id`, `day_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `stats_monthly` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT 0,
    `month_start` DATE NOT NULL,
    `total_bytes` BIGINT UNSIGNED DEFAULT 0,
    `total_duration` DECIMAL(12,2) DEFAULT 0,
    `avg_speed` DECIMAL(15,2) DEFAULT 0,
    UNIQUE KEY `uk_user_month` (`user_id`, `month_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `stats_yearly` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT 0,
    `year` SMALLINT UNSIGNED NOT NULL,
    `total_bytes` BIGINT UNSIGNED DEFAULT 0,
    `total_duration` DECIMAL(12,2) DEFAULT 0,
    `avg_speed` DECIMAL(15,2) DEFAULT 0,
    UNIQUE KEY `uk_user_year` (`user_id`, `year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== 操作日志表（审计）====================
CREATE TABLE IF NOT EXISTS `admin_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `admin_id` INT UNSIGNED NOT NULL COMMENT '操作管理员ID',
    `action` VARCHAR(50) NOT NULL COMMENT '操作类型',
    `target_type` VARCHAR(30) DEFAULT '' COMMENT '目标类型:user/node/setting',
    `target_id` INT UNSIGNED DEFAULT 0 COMMENT '目标ID',
    `detail` TEXT COMMENT '操作详情(JSON)',
    `ip` VARCHAR(45) DEFAULT '',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_admin` (`admin_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员操作日志表';

-- ==================== 公告管理表 ====================
CREATE TABLE IF NOT EXISTS `announcements` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(100) DEFAULT '公告' COMMENT '公告标题',
    `content` TEXT NOT NULL COMMENT '公告内容(支持HTML)',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0禁用 1启用',
    `sort_order` INT DEFAULT 0 COMMENT '排序权重(越小越前)',
    `show_popup` TINYINT DEFAULT 1 COMMENT '是否弹窗展示:0否 1是',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_status` (`status`),
    INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公告管理表';

-- ==================== 广告管理表 ====================
CREATE TABLE IF NOT EXISTS `ads` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(200) NOT NULL COMMENT '广告文字',
    `url` VARCHAR(500) NOT NULL COMMENT '跳转链接',
    `color` VARCHAR(20) DEFAULT '' COMMENT '文字颜色(空=默认)',
    `status` TINYINT DEFAULT 1 COMMENT '状态:0禁用 1启用',
    `sort_order` INT DEFAULT 0 COMMENT '排序权重',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='广告管理表';

-- ==================== 用户反馈表 ====================
CREATE TABLE IF NOT EXISTS `user_feedback` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL COMMENT '提交用户ID',
    `username` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '用户名(冗余)',
    `content` TEXT NOT NULL COMMENT '反馈内容(最多500字)',
    `status` TINYINT DEFAULT 0 COMMENT '状态:0未读 1已读 2已处理',
    `reply` TEXT DEFAULT NULL COMMENT '管理员回复(仅后台可见)',
    `ip` VARCHAR(45) DEFAULT '' COMMENT '提交IP',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `replied_at` DATETIME DEFAULT NULL COMMENT '回复时间',
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户反馈表';


-- ============================================================
-- 默认数据（INSERT IGNORE 确保可重复执行不冲突）
-- ============================================================

-- 默认超级管理员 (密码: admin123, 请上线前修改!)
INSERT IGNORE INTO `admins` (`username`,`password_hash`,`nickname`,`role`) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '超级管理员', 'super_admin');

-- 默认测速节点
INSERT IGNORE INTO `nodes` (`group_name`,`label`,`url`,`url_type`,`sort_order`) VALUES
('运营商','咪咕视频','https://img.cmvideo.cn/publish/noms/2023/12/06/1O4SHFIFR36BD.gif','http',1),
('运营商','和彩云','https://img.mcloud.139.com/material_prod/material_media/20221128/1669626861087.png','http',2),
('运营商','联通电视','NetworkPanelApi://listen.10155.com','api',3),
('运营商','天翼云桌面','https://desk.ctyun.cn:8999/desktop-prod/software/windows_tob_client/15/64/202030001/CtyunClouddeskUniversal_2.3.0_202030001_x86_20240327104015_Setup.exe','http',4),
('全球[Global]','Cachefly','https://web1.cachefly.net/speedtest/downloading','http',1),
('全球[Global]','Cloudflare Speed','https://speed.cloudflare.com/__down?bytes=99614720','http',2),
('全球[Global]','Steam Akamai','https://cdn.akamai.steamstatic.com/steam/apps/1063730/extras/NW_Sword_Sorcery_2.gif','http',3),
('全球[Global]','Steam Cloudflare','https://cdn.cloudflare.steamstatic.com/steam/apps/1063730/extras/NW_Sword_Sorcery_2.gif','http',4),
('全球[Global]','Microsoft Akamai','https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RW16Ptm','http',5);

-- 默认网站配置
INSERT IGNORE INTO `site_settings` (`setting_key`,`setting_value`,`setting_type`,`title`,`description`,`group_name`,`sort_order`) VALUES
-- 基础设置
('site_name','网络面板','string','网站名称','显示在页面标题等位置','basic',1),
('site_description','专业的网络流量监控工具','text','网站描述','SEO描述信息','basic',2),
('site_logo','','string','网站Logo URL','留空则使用默认图标','basic',3),
('banner_url','','string','顶部横幅广告图URL','首页顶部的横幅图片','basic',4),
('banner_link','','string','横幅链接','点击横幅跳转的URL','basic',5),
('footer_text','本工具由 Tencent Edgeone 提供CDN服务','text','页脚文字','底部页脚显示的文字','basic',6),
-- 系统设置
('register_open','1','bool','开放注册','是否允许新用户注册','system',1),
('default_thread_num','8','int','默认线程数','初始线程数设置','advanced',1),
('max_thread_num','16','int','最大线程数限制','用户可设置的最大线程数','advanced',2),
('log_interval','60','int','日志上报间隔(秒)','流量数据上报到服务器的间隔','advanced',3),
('about_content','','json','关于弹窗内容','关于对话框的HTML内容(JSON格式)','content',1),
-- 联系方式
('contact_qq','582424565','string','联系QQ','页面中展示的联系QQ号','contact',1),
('contact_qq_group','463481772','string','QQ群','交流群号码','contact',2),
-- 底部设置
('footer_custom_text','','text','自定义底部文字','显示在页脚上方的自定义文字说明','footer',1),
('footer_copyright','© 2026 NetArt 网络测速系统','string','版权信息','底部版权文字，如 © 2026 网站名称','footer',2),
('footer_icp','','string','ICP备案号','如：京ICP备xxxxxxxx号，留空则不显示','footer',3),
('footer_icp_url','#','string','ICP备案链接','点击ICP备案号跳转的URL','footer',4),
('friend_links','[{"name":"示例链接","url":"#"}]','json','友情链接','JSON数组格式：[{"name":"显示名","url":"地址"}]','footer',5),
('footer_html','','text','自定义HTML代码','支持完整HTML/JS/CSS代码，直接输出到页面最底部，请谨慎使用','footer',6),
('notices','','text','公告/广告内容','多行公告文字，每行一条。支持HTML标签（如链接）。5秒自动滚动切换','footer',7),
-- 顶部导航配置
('nav_links','[{"name":"IP查询","url":"#ipPanel"},{"name":"流量计算器","url":"#"}]','json','顶部导航链接','JSON数组格式：[{"name":"显示名","url":"地址"}]。首页和排行榜已固定显示，无需添加','header',0),
-- 会员中心自定义卡片
('uc_card_enabled','0','bool','会员中心卡片-启用','是否在用户中心统计区域显示自定义可点击卡片','user_center',1),
('uc_card_text','','string','会员中心卡片-显示文字','卡片上显示的文字，如"查看套餐"、"联系客服"等','user_center',2),
('uc_card_url','','string','会员中心卡片-跳转URL','点击卡片跳转的链接地址','user_center',3),
-- 工具页参数
('traffic_price','1.10','string','流量单价(元/GB)','流量计算器的默认单价','basic',10),
('traffic_default_speed','2','string','计算器默认速率(Mbps)','流量计算器打开时的默认速率','basic',11),
-- 自定义页面（留空=使用系统内置默认模板，后台「页面管理」可覆盖）
('page_agreement','','text','用户协议内容','《用户协议》正文，支持 h2/h3/p/ul/li/strong/a 等标签，留空使用默认模板','pages',1),
('page_privacy','','text','隐私政策内容','《隐私政策》正文，支持 h2/h3/p/ul/li/strong/a 等标签，留空使用默认模板','pages',2),
-- 首页动态模块（重要合规提示 / 公告提示，后台可开关、自定义内容）
('home_compliance_enabled','0','bool','首页重要合规提示-启用','首页是否展示「重要合规提示」模块','homepage',1),
('home_compliance_text','','text','首页重要合规提示-内容','合规提示正文，支持 HTML。如：未成年人保护、合规使用、免责声明等','homepage',2),
('home_compliance_bg','#fff9e6','string','首页重要合规提示-底色','合规提示模块背景色，默认浅黄','homepage',3),
('home_notice_enabled','0','bool','首页公告提示-启用','首页是否展示「公告提示」模块','homepage',4),
('home_notice_text','','text','首页公告提示-内容','公告提示正文，支持 HTML。如：活动通知、维护公告、推广信息等','homepage',5);


-- ============================================================
-- 示例/演示数据（INSERT IGNORE，已有数据时跳过）
-- 如需全新安装，可删除本段
-- ============================================================

-- 示例用户 (密码: 111111)
INSERT IGNORE INTO `users` (`id`,`username`,`email`,`password_hash`,`access_token`,`headimg`,`isp`,`region`,`region_short`,`ip`,`role`,`status`,`total_bytes`,`total_time`,`last_active`,`created_at`,`updated_at`) VALUES
(1,'ikun','zesso1@qq.com','$2y$10$zytO32P1tSUraT/jqQUJKOjGXs.j7.TYTyQ6ZONZssGOSRu30VAUW','ffe00bbb344df52fb6ce1ce2462efc876e9ed6f638e77e1ffb7a29b8868e0e3d','','','','','127.0.0.1','user',1,52021224,21.74,'2026-04-13 21:30:11','2026-04-11 23:36:20','2026-04-13 21:30:11');

-- 示例流量日志
INSERT IGNORE INTO `traffic_logs` (`id`,`user_id`,`url`,`thread_num`,`bytes_used`,`duration`,`speed`,`ip`,`user_agent`,`created_at`) VALUES
(1,1,'https://example.com/test',4,104857600,12.50,8388608,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','2026-04-13 21:19:39'),
(2,0,'https://desk.ctyun.cn:8999/desktop-prod/software/windows_tob_client/15/64/202030001/CtyunClouddeskUniversal_2.3.0_202030001_x86_20240327104015_Setup.exe',2,0,6.98,0,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 QuarkPC/6.4.5.737','2026-04-13 21:23:48'),
(3,0,'https://cdn.cloudflare.steamstatic.com/steam/apps/1063730/extras/NW_Sword_Sorcery_2.gif',2,44862921,3.14,14287554,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 QuarkPC/6.4.5.737','2026-04-13 21:23:54'),
(4,0,'https://web1.cachefly.net/speedtest/downloading',2,14327953,6.77,2116389,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 QuarkPC/6.4.5.737','2026-04-13 21:24:06'),
(5,0,'https://app.123pan.com/app/android/v1/app_release_v3.2.3_3208_signed.apk',2,37517078,2.29,16383003,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 QuarkPC/6.4.5.737','2026-04-13 21:27:45');

-- 示例统计聚合数据
INSERT IGNORE INTO `stats_hourly` (`id`,`user_id`,`hour_start`,`total_bytes`,`total_duration`,`avg_speed`) VALUES
(1,0,'2026-04-10 22:00:00',0,611.04,0.00),
(14,0,'2026-04-10 23:00:00',78471531,433.88,180387.08),
(15,1,'2026-04-13 00:00:00',53707389,8.89,4969862.42),
(18,1,'2026-04-13 01:00:00',7067953,4.28,1651390.89),
(19,1,'2026-04-13 21:00:00',27396500,13.12,2167265.83),
(20,0,'2026-04-13 21:00:00',120068155,37.80,3930786.56);

INSERT IGNORE INTO `stats_daily` (`id`,`user_id`,`day_start`,`total_bytes`,`total_duration`,`avg_speed`) VALUES
(1,0,'2026-04-10',78471531,1044.92,75239.86),
(2,1,'2026-04-13',88171842,26.29,3106166.24),
(4,0,'2026-04-13',120068155,37.80,3930786.56);

INSERT IGNORE INTO `stats_monthly` (`id`,`user_id`,`month_start`,`total_bytes`,`total_duration`,`avg_speed`) VALUES
(1,0,'2026-04-01',198539686,1082.72,217561.83),
(2,1,'2026-04-01',88171842,26.29,3106166.24);

INSERT IGNORE INTO `stats_yearly` (`id`,`user_id`,`year`,`total_bytes`,`total_duration`,`avg_speed`) VALUES
(1,0,2026,198539686,1082.72,217561.83),
(2,1,2026,88171842,26.29,3106166.24);

-- 示例IP缓存
INSERT IGNORE INTO `ip_cache` (`id`,`ip`,`country_code`,`country_name`,`registered_country_code`,`registered_country_name`,`regions`,`regions_short`,`asn_number`,`asn_name`,`asn_info`,`type`,`addr`,`cached_at`) VALUES
(1,'165.154.194.93','TW','Taiwan','TW','Taiwan','[\"Taiwan\", \"Taoyuan\"]','[\"Taiwan\", \"Taoyuan\"]',142002,'SCLOUDPTELTD-AS','Scloud Pte Ltd','IPv4','Taiwan Taoyuan','2026-04-13 00:12:10');

-- 示例用户反馈
INSERT IGNORE INTO `user_feedback` (`id`,`user_id`,`username`,`content`,`status`,`reply`,`ip`,`created_at`,`replied_at`) VALUES
(1,1,'ikun','1111',2,NULL,'127.0.0.1','2026-04-12 23:19:00','2026-04-12 23:25:03'),
(2,1,'ikun','测试',1,NULL,'127.0.0.1','2026-04-12 23:19:04','2026-04-12 23:24:57'),
(3,1,'ikun','在数字时代，语言障碍常常成为我们享受全球内容的阻碍。无论是玩外文游戏、观看外语视频，还是使用国际软件，看不懂的文字总让人感到挫败。Translumo作为一款先进的实时屏幕翻译工具，正是为解决这些问题而生。',2,NULL,'127.0.0.1','2026-04-12 23:19:37','2026-04-12 23:38:27'),
(4,1,'ikun','小帆 最帅',1,NULL,'127.0.0.1','2026-04-12 23:29:08','2026-04-12 23:29:16'),
(5,1,'ikun','杨帆 最帅',2,NULL,'127.0.0.1','2026-04-12 23:38:14','2026-04-12 23:39:19');

-- 示例操作日志
INSERT IGNORE INTO `admin_logs` (`id`,`admin_id`,`action`,`target_type`,`target_id`,`detail`,`ip`,`created_at`) VALUES
(1,1,'update_setting','setting',0,'site_name=网络面板','127.0.0.1','2026-04-10 23:35:35'),
(2,1,'update_setting','setting',0,'site_description=专业的网络流量监控工具','127.0.0.1','2026-04-10 23:35:35'),
(3,1,'update_setting','setting',0,'site_logo=','127.0.0.1','2026-04-10 23:35:35'),
(4,1,'update_setting','setting',0,'register_open=1','127.0.0.1','2026-04-10 23:35:35'),
(5,1,'update_setting','setting',0,'contact_qq=582424565','127.0.0.1','2026-04-10 23:35:35'),
(6,1,'update_setting','setting',0,'contact_qq_group=463481772','127.0.0.1','2026-04-10 23:35:35'),
(26,1,'clear_feedback','feedback',0,'清空了 5 条反馈数据','127.0.0.1','2026-04-12 23:18:53'),
(52,1,'update_user','user',1,'{\"action\":\"user_update\",\"id\":1,\"username\":\"ikun\",\"email\":\"zesso@qq.com\",\"password\":\"\",\"role\":\"vip\",\"status\":1}','127.0.0.1','2026-04-13 00:00:08'),
(100,1,'create','node',10,'{\"label\":\"电信一区\",\"url\":\"https://dailybing.com/images/bing/aa4807933ff3ebb0bfcdf9a5f4b752e4c5c12d35.webp\"}','127.0.0.1','2026-04-13 21:25:47'),
(101,1,'create','node',11,'{\"label\":\"123\",\"url\":\"https://app.123pan.com/app/android/v1/app_release_v3.2.3_3208_signed.apk\"}','127.0.0.1','2026-04-13 21:27:32');

-- 示例额外节点（用户自定义添加的）
INSERT IGNORE INTO `nodes` (`id`,`group_name`,`label`,`url`,`url_type`,`sort_order`,`status`,`description`,`created_at`,`updated_at`) VALUES
(10,'沧州电信','电信一区','https://dailybing.com/images/bing/aa4807933ff3ebb0bfcdf9a5f4b752e4c5c12d35.webp','http',0,1,'','2026-04-13 21:25:47','2026-04-13 21:25:47'),
(11,'123','123','https://app.123pan.com/app/android/v1/app_release_v3.2.3_3208_signed.apk','http',0,1,'','2026-04-13 21:27:32','2026-04-13 21:27:32');

-- ==================== 前台查询记录表 ====================
CREATE TABLE IF NOT EXISTS `query_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT 0 COMMENT '用户ID，0表示游客',
    `username` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '用户名或游客标识（游客记 游客）',
    `query_type` VARCHAR(32) NOT NULL DEFAULT '' COMMENT '查询类型：ip / ip_advanced / traffic / byte / speedtest / ip_tools',
    `query_input` VARCHAR(1000) NOT NULL DEFAULT '' COMMENT '查询输入（目标IP/域名/参数）',
    `result_summary` VARCHAR(500) NOT NULL DEFAULT '' COMMENT '结果摘要',
    `ip` VARCHAR(45) DEFAULT '' COMMENT '客户端IP',
    `user_agent` VARCHAR(500) DEFAULT '' COMMENT '浏览器UA',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '查询时间',
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_query_type` (`query_type`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='前台查询记录表（用户/游客行为溯源）';
