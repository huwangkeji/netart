-- ==================== 前台查询记录表 ====================
-- 记录前台所有查询功能（IP查询 / 流量计算 / 字节转换 / IP进阶 / 测速 等）
-- 的用户与游客行为，供后台「查询记录管理」做数据溯源与追踪。
-- 幂等：可重复执行。

CREATE TABLE IF NOT EXISTS `query_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT 0 COMMENT '用户ID，0表示游客',
    `username` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '用户名或游客标识（游客记 游客）',
    `query_type` VARCHAR(32) NOT NULL DEFAULT '' COMMENT '查询类型：ip / ip_advanced / traffic / byte / speedtest / ip_tools',
    `query_input` VARCHAR(1000) NOT NULL DEFAULT '' COMMENT '查询输入（目标IP/域名/参数）',
    `result_summary` VARCHAR(500) NOT NULL DEFAULT '' COMMENT '结果摘要',
    `ip` VARCHAR(45) DEFAULT '' COMMENT '客户端IP',
    `user_agent` VARCHAR(500) DEFAULT '' COMMENT '浏览器UA',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '查询时间',
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_query_type` (`query_type`),
    INDEX `idx_created_at` (`created_at`),
    INDEX `idx_ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='前台查询记录表（用户/游客行为溯源）';
