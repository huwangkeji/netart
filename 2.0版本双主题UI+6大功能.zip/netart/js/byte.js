/**
 * 字节单位转换
 *
 * 与服务端 includes/units.php 保持同一套 1024 进制规则：
 * 优先使用本地计算保证即时响应，并在需要时调用服务端接口校验（api/tools.php）。
 */
(function () {
    'use strict';

    var API = './api/tools.php';

    var fromValue = document.getElementById('fromValue');
    var fromUnit = document.getElementById('fromUnit');
    var toUnit = document.getElementById('toUnit');
    var toValue = document.getElementById('toValue');
    var swapBtn = document.getElementById('swapBtn');
    var copyBtn = document.getElementById('btnCopyResult');
    var hint = document.getElementById('convertHint');
    var errorBox = document.getElementById('convertError');

    var UNITS = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    var FACTORS = {
        B: 1,
        KB: 1024,
        MB: 1024 * 1024,
        GB: 1024 * 1024 * 1024,
        TB: 1024 * 1024 * 1024 * 1024,
        PB: 1024 * 1024 * 1024 * 1024 * 1024
    };

    var timer = null;

    function formatNumber(value) {
        if (!isFinite(value)) return '0';
        if (value === 0) return '0';
        if (Math.abs(value) >= 1e15 || (Math.abs(value) < 1e-6 && value !== 0)) {
            return value.toExponential(6);
        }
        return String(parseFloat(value.toFixed(6)));
    }

    function debounce(fn, wait) {
        return function () {
            clearTimeout(timer);
            timer = setTimeout(fn, wait);
        };
    }

    function showError(message) {
        errorBox.textContent = message;
        errorBox.hidden = false;
    }

    function convert() {
        var value = parseFloat(fromValue.value);
        var from = fromUnit.value;
        var to = toUnit.value;

        if (fromValue.value.trim() === '' || !isFinite(value)) {
            showError('请输入有效的数值');
            return;
        }
        if (value < 0) {
            showError('请输入非负数值');
            return;
        }

        errorBox.hidden = true;

        var bytes = value * (FACTORS[from] || 1);
        var result = bytes / (FACTORS[to] || 1);

        toValue.value = formatNumber(result);
        if (hint) {
            hint.textContent = formatNumber(value) + ' ' + from + ' = ' + formatNumber(result) + ' ' + to;
        }

        UNITS.forEach(function (unit) {
            var el = document.getElementById('result-' + unit);
            if (el) {
                el.textContent = formatNumber(bytes / FACTORS[unit]) + ' ' + unit;
            }
        });

        if (window.reportQuery) {
            window.reportQuery('byte', value + ' ' + from + ' -> ' + to, (hint ? hint.textContent : ''));
        }

        // 与服务端对账（节流，避免频繁请求）
        debounce(function () {
            fetch(API + '?action=convert_all', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ value: value, from_unit: from })
            })
                .then(function (resp) { return resp.json(); })
                .then(function (res) {
                    if (!res || res.status !== 0 || !res.data || !res.data.results) return;
                    res.data.results.forEach(function (item) {
                        var el = document.getElementById('result-' + item.unit);
                        if (el) el.textContent = item.value + ' ' + item.unit;
                    });
                })
                .catch(function () { /* 服务端不可用时保留本地结果 */ });
        }, 400)();
    }

    if (fromValue) fromValue.addEventListener('input', convert);
    if (fromUnit) fromUnit.addEventListener('change', convert);
    if (toUnit) toUnit.addEventListener('change', convert);

    if (swapBtn) {
        swapBtn.addEventListener('click', function () {
            var temp = fromUnit.value;
            fromUnit.value = toUnit.value;
            toUnit.value = temp;
            convert();
        });
    }

    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            var payload = toValue.value + ' ' + toUnit.value;
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(payload).then(function () {
                    copyBtn.textContent = '已复制';
                    setTimeout(function () { copyBtn.textContent = '复制'; }, 1600);
                });
            } else {
                window.prompt('请手动复制：', payload);
            }
        });
    }

    convert();
})();
