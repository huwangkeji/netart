/**
 * IP 进阶工具页交互逻辑
 * 对应 api/ip_advanced.php 的 consistency / cdn / latency / dns 四个动作
 */
(function () {
    'use strict';

    var API = './api/ip_advanced.php';

    function el(id) {
        return document.getElementById(id);
    }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function showResult(box, ok) {
        box.hidden = false;
        if (!ok) return;
    }

    function setLoading(btn, loading) {
        if (!btn) return;
        btn.disabled = !!loading;
        btn.dataset.label = btn.dataset.label || btn.textContent;
        btn.textContent = loading ? '查询中…' : btn.dataset.label;
    }

    /**
     * 统一请求封装
     * @param {string} action
     * @param {object} params
     * @param {HTMLButtonElement} btn
     * @returns {Promise<object>}
     */
    function callApi(action, params, btn) {
        var url = API + '?action=' + encodeURIComponent(action);
        var opt = {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: Object.keys(params).map(function (k) {
                return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
            }).join('&')
        };
        setLoading(btn, true);
        return fetch(url, opt)
            .then(function (r) { return r.json(); })
            .catch(function () { return { status: 1, message: '网络错误，请稍后重试', data: null }; })
            .finally(function () { setLoading(btn, false); });
    }

    /* ---------- 1. 多地一致性对比 ---------- */
    var consistencyForm = el('consistencyForm');
    if (consistencyForm) {
        consistencyForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var input = el('consistencyInput');
            callApi('consistency', { target: input.value.trim() }, el('consistencyForm').querySelector('button'))
                .then(function (res) {
                    var box = el('consistencyResult');
                    showResult(box, true);
                    var badge = el('consistencyBadge');
                    var body = el('consistencyBody');
                    var note = el('consistencyNote');
                    body.innerHTML = '';

                    if (res.status !== 0 || !res.data) {
                        badge.innerHTML = '<span class="np-badge np-badge-warn">未获取到足够数据</span>';
                        note.textContent = res.message || '对比失败';
                        return;
                    }
                    var d = res.data;
                    if (d.consistent) {
                        badge.innerHTML = '<span class="np-badge np-badge-ok">归属一致 ✓</span>';
                    } else {
                        badge.innerHTML = '<span class="np-badge np-badge-warn">检测到差异 ⚠</span>';
                    }
                    badge.innerHTML += ' <span class="np-badge-muted">IP: ' + esc(d.ip) + (d.resolved_from ? '（来自 ' + esc(d.resolved_from) + '）' : '') + '</span>';

                    (d.sources || []).forEach(function (s) {
                        var tr = document.createElement('tr');
                        tr.innerHTML =
                            '<td>' + esc(s.source) + '</td>' +
                            '<td>' + esc(s.country_name || s.country_code || '-') + '</td>' +
                            '<td>' + esc(s.region || '-') + '</td>' +
                            '<td>' + (s.asn_number ? 'AS' + esc(s.asn_number) : '-') + '</td>' +
                            '<td>' + esc(s.asn_name || '-') + '</td>';
                        body.appendChild(tr);
                    });
                    note.textContent = d.note || '';
                });
        });
    }

    /* ---------- 2. CDN / 云厂商识别 ---------- */
    var cdnForm = el('cdnForm');
    if (cdnForm) {
        cdnForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var input = el('cdnInput');
            callApi('cdn', { target: input.value.trim() }, el('cdnForm').querySelector('button'))
                .then(function (res) {
                    var box = el('cdnResult');
                    showResult(box, true);
                    if (res.status !== 0 || !res.data) {
                        box.innerHTML = '<p class="np-note np-note-warn">' + esc(res.message || '识别失败') + '</p>';
                        return;
                    }
                    var d = res.data;
                    var html = '';
                    if (d.detected) {
                        html += '<div class="np-badge-row">';
                        html += '<span class="np-badge np-badge-ok">' + esc(d.vendor) + '</span>';
                        html += '<span class="np-badge np-badge-muted">类别：' + esc(d.category) + '</span>';
                        html += '</div>';
                        html += '<p class="np-note">识别依据：' + esc(d.evidence || '') + '</p>';
                        if (d.official) {
                            html += '<p class="np-note"><a href="' + esc(d.official) + '" target="_blank" rel="noopener">官方站点 ↗</a></p>';
                        }
                    } else {
                        html += '<div class="np-badge-row"><span class="np-badge np-badge-muted">未匹配到已知 CDN / 云厂商</span></div>';
                        html += '<p class="np-note">AS' + esc((d.evidence || '').replace(/^AS/, '')) + ' 可能属于运营商骨干网或企业专线。</p>';
                    }
                    html += '<p class="np-note np-note-muted">查询目标：' + esc(d.query || '') + '（' + esc(d.ip || '') + '）</p>';
                    box.innerHTML = html;
                });
        });
    }

    /* ---------- 3. 延迟探测 ---------- */
    var latencyForm = el('latencyForm');
    if (latencyForm) {
        latencyForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var input = el('latencyInput');
            var ports = el('latencyPorts').value.trim() || '80,443,53,22';
            callApi('latency', { target: input.value.trim(), ports: ports }, el('latencyForm').querySelector('button'))
                .then(function (res) {
                    var box = el('latencyResult');
                    showResult(box, true);
                    if (res.status !== 0 || !res.data) {
                        box.innerHTML = '<p class="np-note np-note-warn">' + esc(res.message || '探测失败') + '</p>';
                        return;
                    }
                    var d = res.data;
                    var html = '<p class="np-note">目标：' + esc(d.host) + '（' + esc(d.ip) + '）</p>';
                    html += '<div class="np-grid np-grid-4">';
                    (d.results || []).forEach(function (r) {
                        if (r.reachable) {
                            html += '<div class="np-stat">' +
                                '<div class="np-stat-label">端口 ' + esc(r.port) + '</div>' +
                                '<div class="np-stat-value is-primary">' + esc(r.avg_ms) + '<span class="np-unit">ms</span></div>' +
                                '<div class="np-stat-sub">min ' + esc(r.min_ms) + ' · max ' + esc(r.max_ms) + '</div>' +
                                '</div>';
                        } else {
                            html += '<div class="np-stat">' +
                                '<div class="np-stat-label">端口 ' + esc(r.port) + '</div>' +
                                '<div class="np-stat-value is-danger">✕</div>' +
                                '<div class="np-stat-sub">不可达 / 超时</div>' +
                                '</div>';
                        }
                    });
                    html += '</div>';
                    box.innerHTML = html;
                });
        });
    }

    /* ---------- 4. 多解析器 DNS 对比 ---------- */
    var dnsForm = el('dnsForm');
    if (dnsForm) {
        dnsForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var input = el('dnsInput');
            callApi('dns', { target: input.value.trim() }, el('dnsForm').querySelector('button'))
                .then(function (res) {
                    var box = el('dnsResult');
                    showResult(box, true);
                    var badge = el('dnsBadge');
                    var body = el('dnsBody');
                    var nsEl = el('dnsNs');
                    var note = el('dnsNote');
                    body.innerHTML = '';

                    if (res.status !== 0 || !res.data) {
                        badge.innerHTML = '<span class="np-badge np-badge-warn">查询失败</span>';
                        note.textContent = res.message || '';
                        return;
                    }
                    var d = res.data;
                    badge.innerHTML = d.consistent
                        ? '<span class="np-badge np-badge-ok">解析一致 ✓</span>'
                        : '<span class="np-badge np-badge-warn">解析存在差异 ⚠</span>';

                    (d.resolvers || []).forEach(function (r) {
                        var tr = document.createElement('tr');
                        var rec = r.ok ? (r.records.length ? r.records.join(' , ') : '（无 A 记录）') : ('失败：' + r.error);
                        tr.innerHTML =
                            '<td>' + esc(r.resolver) + '</td>' +
                            '<td>' + esc(rec) + '</td>' +
                            '<td>' + (r.ok ? '<span class="np-dot-ok">ok</span>' : '<span class="np-dot-bad">fail</span>') + '</td>';
                        body.appendChild(tr);
                    });

                    nsEl.textContent = (d.ns && d.ns.length)
                        ? '权威 NS：' + d.ns.join(' , ')
                        : '未获取到权威 NS 记录';
                    note.textContent = d.note || '';
                });
        });
    }
})();
