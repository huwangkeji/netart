/* ============================================================
 * 新版首页（home.php）交互增强
 * 轻量：锚点平滑滚动 + 区块进入视口时的渐显动画，无外部依赖。
 * ============================================================ */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        // 同页锚点平滑滚动
        document.querySelectorAll('a[href^="#"]').forEach(function (link) {
            link.addEventListener('click', function (e) {
                var id = link.getAttribute('href');
                if (id === '#' || id.length < 2) return;
                var target = document.querySelector(id);
                if (!target) return;
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
        });

        // 区块渐显（不支持时直接显示）
        var sections = document.querySelectorAll('.home-section, .home-hero');
        if (!('IntersectionObserver' in window) || !('classList' in document.createElement('div'))) {
            sections.forEach(function (s) { s.classList.add('is-visible'); });
            return;
        }
        sections.forEach(function (s) { s.classList.add('home-reveal'); });
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    en.target.classList.add('is-visible');
                    io.unobserve(en.target);
                }
            });
        }, { threshold: 0.08 });
        sections.forEach(function (s) { io.observe(s); });
    });
})();
