/**
 * 网络流量计算器
 *
 * 计算结果由服务端 api/tools.php（includes/units.php）产出，保证前后端口径一致；
 * 接口异常时自动回退到本地计算，避免页面完全不可用。
 */
(function () {
    'use strict';

    var API = './api/tools.php?action=calc_traffic';

    var speedInput = document.getElementById('speedInput');
    var speedUnit = document.getElementById('speedUnit');
    var priceInput = document.getElementById('priceInput');
    var tbody = document.getElementById('resultBody');
    var errorBox = document.getElementById('calcError');
    var summary = document.getElementById('calcSummary');

    var RATE = { Kbps: 0.001, Mbps: 1, Gbps: 1000 };
    var timer = null;

    function debounce(fn, wait) {
        return function () {
            clearTimeout(timer);
            timer = setTimeout(fn, wait);
        };
    }

    function formatBytes(bytes) {
        var units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        var value = bytes;
        var index = 0;
        while (value >= 1024 && index < units.length - 1) {
            value /= 1024;
            index++;
        }
        return value.toFixed(index === 0 ? 0 : 2) + ' ' + units[index];
    }

    function renderRows(rows, unitLabel) {
        var html = '';
        rows.forEach(function (row) {
            html += '<tr>'
                + '<td>' + row.label + '</td>'
                + '<td class="np-num" style="color:var(--np-success);font-weight:600;">' + row.traffic + '</td>'
                + '<td class="np-num">' + row.gigabytes.toFixed(2) + ' GB</td>'
                + '<td class="np-num" style="color:var(--np-warning);font-weight:600;">¥ ' + row.cost + '</td>'
                + '</tr>';
        });
        tbody.innerHTML = html;

        if (summary && unitLabel) {
            summary.textContent = '当前速率：' + unitLabel + '，按 1024 进制换算（1 GB = 1024 MB）。';
        }
    }

    function localFallback(speed, unit, price) {
        var bytesPerSecond = speed * (RATE[unit] || 1) * 0.125 * 1024 * 1024;
        var periods = [
            { label: '每小时', seconds: 3600 },
            { label: '每天', seconds: 3600 * 24 },
            { label: '每月', seconds: 3600 * 24 * 30 },
            { label: '每年', seconds: 3600 * 24 * 365 }
        ];

        return periods.map(function (period) {
            var bytes = bytesPerSecond * period.seconds;
            var gb = bytes / (1024 * 1024 * 1024);
            return {
                label: period.label,
                traffic: formatBytes(bytes),
                gigabytes: gb,
                cost: (gb * price).toFixed(2)
            };
        });
    }

    function calculate() {
        var speed = parseFloat(speedInput.value);
        var price = parseFloat(priceInput.value);
        var unit = speedUnit.value;

        if (!isFinite(speed) || speed < 0) {
            errorBox.textContent = '请输入有效的网络速率（≥ 0）';
            errorBox.hidden = false;
            return;
        }
        if (!isFinite(price) || price < 0) {
            price = 0;
            priceInput.value = '0';
        }
        errorBox.hidden = true;

        fetch(API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ speed: speed, unit: unit, price: price })
        })
            .then(function (resp) { return resp.json(); })
            .then(function (res) {
                if (!res || res.status !== 0 || !res.data || !res.data.rows) {
                    throw new Error((res && res.message) || '计算失败');
                }
                renderRows(res.data.rows, speed + ' ' + unit);
                if (window.reportQuery) {
                    window.reportQuery('traffic', speed + ' ' + unit + ' @ ¥' + price + '/GB', '已计算每小时/每天/每月/每年流量');
                }
            })
            .catch(function () {
                // 服务端不可用时退化为本地计算，界面仍可用
                renderRows(localFallback(speed, unit, price), speed + ' ' + unit + '（本地计算）');
            });
    }

    var trigger = debounce(calculate, 220);

    if (speedInput) speedInput.addEventListener('input', trigger);
    if (priceInput) priceInput.addEventListener('input', trigger);
    if (speedUnit) speedUnit.addEventListener('change', trigger);

    document.querySelectorAll('[data-step]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var target = document.getElementById(btn.getAttribute('data-target'));
            if (!target) return;

            var delta = parseFloat(btn.getAttribute('data-step')) || 0;
            var value = (parseFloat(target.value) || 0) + delta;
            target.value = Math.max(0, Math.round(value * 100) / 100);
            trigger();
        });
    });

    calculate();
})();
