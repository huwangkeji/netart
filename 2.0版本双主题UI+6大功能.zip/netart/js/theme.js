/* ============================================================
 * theme.js — 主题 / 紧凑模式 / 面板配置 统一管理器
 *
 * 职责：
 *  1. 维护 localStorage 中的面板配置（单一 JSON 键 np_panel_settings）；
 *  2. 解析并应用「浅色 / 深色 / 跟随系统」三模式，支持按时间段自动切换；
 *  3. 应用紧凑排版（html.np-compact）；
 *  4. 在首帧绘制前（由 layout.php 内联脚本调用 applyEarly）应用，避免主题闪烁。
 *
 * 纯 Web 限制：开机自启 / 后台常驻 / 系统托盘 / 真正的熄屏常亮 无法在浏览器中实现，
 * 相关开关仅持久化存储并在 UI 中标注「需桌面客户端」，详见 settings.js。
 * ============================================================ */
(function () {
    'use strict';

    var STORAGE_KEY = 'np_panel_settings';
    var HISTORY_KEY = 'np_speed_history';

    /* ---------- 默认配置（单一数据源） ---------- */
    var DEFAULTS = {
        theme: 'system',            // 'light' | 'dark' | 'system'
        autoThemeByTime: false,     // 按时间段自动切换深色
        darkStart: '18:00',         // 进入深色的时间点
        darkEnd: '06:00',           // 恢复浅色的时间点
        compact: false,             // 紧凑排版

        scheduledTest: {
            enabled: false,
            intervalMin: 30,        // 测速间隔（分钟）
            onlyOnline: true,       // 仅联网时执行
            saveHistory: true,      // 结果写入历史
            lastRun: 0              // 上次执行时间戳
        },

        aod: {
            enabled: false,         // 熄屏常亮（Web 降级：保持亮屏 + 全屏叠层）
            mode: 'web',            // 熄屏模式：'web'=网页内全屏（仅覆盖页面区域）；'whole'=整体全屏（浏览器/系统全屏）
            brightness: 60,         // 模拟亮度 0-100（叠层不透明度）
            timeoutSec: 0,          // 0 = 不超时；否则无操作 N 秒后退出
            content: {
                time: true,
                traffic: true,
                speed: true,
                custom: ''
            }
        },

        // 桌面端专属项：纯 Web 无法实现，仅存储并标注
        desktop: {
            autoStart: false,
            backgroundResident: false
        }
    };

    /* ---------- 安全读写（容错：解析失败回退默认） ---------- */
    function clone(o) { return JSON.parse(JSON.stringify(o)); }

    function deepMerge(base, override) {
        var out = clone(base);
        if (!override || typeof override !== 'object') return out;
        Object.keys(override).forEach(function (k) {
            if (override[k] && typeof override[k] === 'object' && !Array.isArray(override[k]) && base[k] && typeof base[k] === 'object') {
                out[k] = deepMerge(base[k], override[k]);
            } else if (typeof override[k] !== 'undefined') {
                out[k] = override[k];
            }
        });
        return out;
    }

    function load() {
        try {
            var raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return clone(DEFAULTS);
            var parsed = JSON.parse(raw);
            return deepMerge(DEFAULTS, parsed);
        } catch (e) {
            // 配额异常 / JSON 损坏 → 回退默认，避免白屏
            try { localStorage.removeItem(STORAGE_KEY); } catch (_) {}
            return clone(DEFAULTS);
        }
    }

    function save(cfg) {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
            return true;
        } catch (e) {
            // iOS 隐私模式 / 配额满 → 静默失败，返回 false 由调用方提示
            return false;
        }
    }

    var state = load();

    /* ---------- 主题解析 ---------- */
    function inDarkWindow(now, start, end) {
        function toMin(hhmm) {
            var p = String(hhmm || '0:0').split(':');
            return (parseInt(p[0], 10) || 0) * 60 + (parseInt(p[1], 10) || 0);
        }
        var cur = now.getHours() * 60 + now.getMinutes();
        var s = toMin(start), e = toMin(end);
        if (s === e) return false;
        if (s < e) return cur >= s && cur < e;          // 如 08:00-18:00
        return cur >= s || cur < e;                      // 跨午夜，如 18:00-06:00
    }

    function systemPrefersDark() {
        try { return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches; }
        catch (e) { return false; }
    }

    function resolveTheme(cfg) {
        cfg = cfg || state;
        if (cfg.autoThemeByTime && inDarkWindow(new Date(), cfg.darkStart, cfg.darkEnd)) {
            return 'dark';
        }
        if (cfg.theme === 'system') {
            return systemPrefersDark() ? 'dark' : 'light';
        }
        return cfg.theme === 'dark' ? 'dark' : 'light';
    }

    /* ---------- 应用（首帧前调用不会触发过渡） ---------- */
    function applyVisual(cfg) {
        cfg = cfg || state;
        var root = document.documentElement;
        var resolved = resolveTheme(cfg);
        root.setAttribute('data-theme', resolved);
        root.classList.toggle('np-compact', !!cfg.compact);
        // 首帧后开启过渡（避免初始应用时的动画）
        if (!root.classList.contains('theme-ready')) {
            requestAnimationFrame(function () { root.classList.add('theme-ready'); });
        }
    }

    /* ---------- 公共 API ---------- */
    window.NPSettings = {
        DEFAULTS: DEFAULTS,
        STORAGE_KEY: STORAGE_KEY,
        HISTORY_KEY: HISTORY_KEY,

        get: function () { return state; },
        getTheme: function () { return state.theme; },
        getResolvedTheme: function () { return resolveTheme(state); },

        set: function (patch, opts) {
            state = deepMerge(state, patch || {});
            if (save(state)) {
                applyVisual(state);
            }
            if (opts && typeof opts.onSaved === 'function') opts.onSaved(state);
            return state;
        },

        // 由 layout.php 在 <head> 内联调用：首帧前应用，防闪烁
        applyEarly: function () { applyVisual(state); },

        resolveTheme: resolveTheme,
        inDarkWindow: inDarkWindow,
        applyVisual: applyVisual,

        // 历史记录（测速结果）存取，独立于配置键
        loadHistory: function () {
            try {
                var raw = localStorage.getItem(HISTORY_KEY);
                var arr = raw ? JSON.parse(raw) : [];
                return Array.isArray(arr) ? arr : [];
            } catch (e) { return []; }
        },
        pushHistory: function (record, cap) {
            cap = cap || 200;
            var arr = this.loadHistory();
            arr.unshift(record);
            if (arr.length > cap) arr = arr.slice(0, cap);
            try { localStorage.setItem(HISTORY_KEY, JSON.stringify(arr)); } catch (e) {}
            return arr;
        }
    };

    /* ---------- 系统主题变化时实时跟随 ---------- */
    if (window.matchMedia) {
        try {
            var mq = window.matchMedia('(prefers-color-scheme: dark)');
            var handler = function () { if (state.theme === 'system' && !state.autoThemeByTime) applyVisual(state); };
            if (mq.addEventListener) mq.addEventListener('change', handler);
            else if (mq.addListener) mq.addListener(handler);
        } catch (e) {}
    }

    // 页面加载即应用（针对直接打开而非经 layout 内联脚本的场景）
    if (document.readyState !== 'loading') {
        applyVisual(state);
    } else {
        document.addEventListener('DOMContentLoaded', function () { applyVisual(state); });
    }
})();
