    // ========== 排行榜页面逻辑 ==========

    const RANK_API_BASE = './api/';
    let currentPeriod = 'day';

    document.addEventListener('DOMContentLoaded', function() {
        // 加载顶部动态导航（与首页一致，需先从API获取配置）
        if (typeof loadTopNav === 'function') loadTopNav();
        // 检查登录状态（与首页一致）
        if (typeof checkAuthStatus === 'function') checkAuthStatus();

        loadRankData(currentPeriod);

        // 标签切换
        document.querySelectorAll('.rank-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.rank-tab').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                currentPeriod = this.dataset.period;
                loadRankData(currentPeriod);
            });
        });
    });

    function $$(sel) { return document.querySelector(sel); }

    async function loadRankData(period) {
        const tbody = document.querySelector('#rankBodyFull');
        tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;padding:40px;">加载中...</td></tr>';

        try {
            const params = new URLSearchParams({ period: period });
            const resp = await fetch(RANK_API_BASE + 'rank_period.php?' + params.toString());
            const result = await resp.json();

            console.log('Rank API response:', result);

            if (result.status !== 0 || !result.data || !result.data.length) {
                renderEmpty();
                return;
            }

            const data = result.data;

            // 渲染前三名领奖台
            renderPodium(data);

            // 渲染完整表格
            let html = '';
            data.forEach((row, idx) => {
                const medalClass = idx === 0 ? 'rank-gold' : (idx === 1 ? 'rank-silver' : (idx === 2 ? 'rank-bronze': ''));
                const avatarHtml = row.headimg
                    ? `<img src="${escapeAttr(row.headimg)}" class="rank-list-avatar">`
                    : `<span class="rank-list-noavatar">${escapeHtml(row.username)?.[0]?.toUpperCase() || '?'}</span>`;
                
                html += `<tr>
                    <td><span class="rank-num ${medalClass}">${idx + 1}</span></td>
                    <td>
                        <div class="rank-user-cell">
                            ${avatarHtml}
                            <span>${escapeHtml(row.username)}</span>
                        </div>
                    </td>
                    <td><strong>${formatBytes(row.bytes)}</strong></td>
                </tr>`;
            });
            tbody.innerHTML = html;

        } catch(e) {
            console.error('Rank load error:', e);
            tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;padding:40px;color:#f56c6c;">加载失败，请刷新重试</td></tr>';
        }
    }

    function renderPodium(data) {
        for (let i = 1; i <= 3; i++) {
            const el = document.querySelector('#podium' + i);
            const row = data[i - 1];
            if (!row) {
                // 无数据 → 显示"虚位以待"，头像显示问号
                el.querySelector('.podium-name').textContent = '\u865a\u4f4d\u62df\u5f85';
                el.querySelector('.podium-value').textContent = '';
                const avatarImg = el.querySelector('.podium-avatar');
                avatarImg.src = '';
                avatarImg.style.display = 'none';
                const letterEl = el.querySelector('.podium-letter');
                letterEl.textContent = '?';
                letterEl.style.display = 'flex';
                el.style.display = '';
                el.querySelector('.podium-bar').style.height = '0';
                continue;
            }
            
            el.style.display = '';
            el.querySelector('.podium-name').textContent = row.username || '匿名';
            el.querySelector('.podium-value').textContent = formatBytes(row.bytes);
            
            // 头像处理：始终显示，有图用图，无图用首字母
            const avatarImg = el.querySelector('.podium-avatar');
            const letterEl = el.querySelector('.podium-letter');
            if (row.headimg) {
                avatarImg.src = row.headimg;
                avatarImg.style.display = '';
                letterEl.style.display = 'none';
            } else {
                avatarImg.style.display = 'none';
                letterEl.textContent = (row.username || '?')[0].toUpperCase();
                letterEl.style.display = 'flex';
            }

            const maxBytes = data[0] ? data[0].bytes : 1;
            const pct = Math.max(15, (row.bytes / maxBytes) * 100);
            el.querySelector('.podium-bar').style.height = pct + '%';
        }
    }

    function renderEmpty() {
        document.querySelector('#rankBodyFull').innerHTML = '<tr><td colspan="3" style="text-align:center;padding:40px;color:#909399;">暂无数据</td></tr>';
        for (let i = 1; i <= 3; i++) {
            const el = document.querySelector('#podium' + i);
            el.querySelector('.podium-name').textContent = '\u865a\u4f4d\u62df\u5f85';
            el.querySelector('.podium-value').textContent = '';
            const avatarImg = el.querySelector('.podium-avatar');
            avatarImg.src = '';
            avatarImg.style.display = 'none';
            const letterEl = el.querySelector('.podium-letter');
            letterEl.textContent = '?';
            letterEl.style.display = 'flex';
            el.style.display = '';
            el.querySelector('.podium-bar').style.height = '0';
        }
    }

    /** 格式化字节数 - 自动选择单位 */
    function formatBytes(num) {
        if (!num || num <= 0) return '0 B';
        const gb = num / (1024 * 1024 * 1024);
        if (gb >= 1) return gb.toFixed(2) + ' GB';
        const mb = num / (1024 * 1024);
        if (mb >= 1) return mb.toFixed(2) + ' MB';
        return num.toFixed(0) + ' B';
    }

    function escapeHtml(str) {
        if (!str) return '';
        var d = document.createElement('div'); d.textContent = str; return d.innerHTML;
    }
    function escapeAttr(str) {
        if (!str) return '';
        return str.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    /** 加载底部设置 */
    async function loadFooterSettings() {
        try {
            const resp = await fetch('./api/footer_settings.php');
            const data = await resp.json();
            if (data.status === 0 && data.data) {
                const s = data.data;
                if (s.custom_text) document.querySelector('#footerCustomText').innerHTML = escapeHtml(s.custom_text);
                if (s.copyright) document.querySelector('#footerCopyright').textContent = s.copyright;
                if (s.icp) {
                    document.querySelector('#footerIcp').textContent = s.icp;
                    document.querySelector('#footerIcp').href = s.icp_url || '#';
                } else {
                    document.querySelector('#footerIcp').style.display = 'none';
                    document.querySelector('#footerDivider')?.remove();
                }
                if (s.custom_html) document.querySelector('#footerHtmlArea').innerHTML = s.custom_html;
                // 隐藏空元素
                if (!s.custom_text) document.querySelector('#footerCustomText').style.display = 'none';
            }
        } catch(e) {}
    }
