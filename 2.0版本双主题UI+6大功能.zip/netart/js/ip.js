/**
 * 本机 IP 查询
 *
 * 能力：
 * - 本机 IPv4 / IPv6 检测
 * - 多源 IP 结果（国内 / 国际）
 * - WebRTC 泄露检测
 * - 国内外网络延迟检测
 * - 隐私显示开关
 */
(function () {
    'use strict';

    var API = './api/ip.php';

    var els = {
        localIpv4: document.getElementById('localIpv4'),
        localLocation: document.getElementById('localLocation'),
        localIsp: document.getElementById('localIsp'),
        localAsn: document.getElementById('localAsn'),
        btnCopyIpv4: document.getElementById('btnCopyIpv4'),
        ipv6Status: document.getElementById('ipv6Status'),
        ipv6State: document.getElementById('ipv6State'),
        btnRetryIpv6: document.getElementById('btnRetryIpv6'),

        toggleHideIp: document.getElementById('toggleHideIp'),
        toggleHideDomestic: document.getElementById('toggleHideDomestic'),
        toggleHideInternational: document.getElementById('toggleHideInternational'),

        form: document.getElementById('ipqForm'),
        input: document.getElementById('ipqInput'),
        btnQuery: document.getElementById('btnIpqQuery'),
        btnMine: document.getElementById('btnIpqMine'),

        webrtcSupport: document.getElementById('webrtcSupport'),
        webrtcLeak: document.getElementById('webrtcLeak'),
        webrtcCounts: document.getElementById('webrtcCounts'),
        webrtcIp: document.getElementById('webrtcIp'),
        webrtcTag: document.getElementById('webrtcTag'),
        btnRetryWebrtc: document.getElementById('btnRetryWebrtc'),

        latencyGrid: document.getElementById('latencyGrid'),
        btnRetryLatency: document.getElementById('btnRetryLatency')
    };

    var lastLocalIp = '';
    var pending = false;

    function $(id) { return document.getElementById(id); }

    function text(value, fallback) {
        var v = (value === null || value === undefined || value === '') ? '' : String(value);
        return v === '' ? (fallback || '--') : v;
    }

    function apiFetch(url) {
        return fetch(url, { headers: { 'Accept': 'application/json' }, referrerPolicy: 'no-referrer' })
            .then(function (resp) {
                if (!resp.ok) throw new Error('HTTP ' + resp.status);
                return resp.json();
            })
            .then(function (res) {
                if (!res || res.status !== 0 || res.data === undefined) {
                    throw new Error((res && res.message) || '请求失败');
                }
                return res.data;
            });
    }

    function setLoading(loading) {
        pending = loading;
        if (els.btnQuery) els.btnQuery.disabled = loading;
        if (els.btnMine) els.btnMine.disabled = loading;
        if (els.btnQuery) els.btnQuery.textContent = loading ? '查询中…' : '查询';
    }

    /* ---------- 本机 IPv4 ---------- */
    function loadLocal(target) {
        var url = API + (target ? ('?target=' + encodeURIComponent(target)) : '');
        return apiFetch(url).then(function (data) {
            lastLocalIp = data.ip || '';
            renderLocal(data);
            return data;
        });
    }

    function renderLocal(data) {
        var as = data.as || {};
        var asnText = as.number ? ('AS' + as.number) : '';
        if (asnText && as.name) asnText += ' · ' + as.name;

        if (els.localIpv4) els.localIpv4.textContent = text(data.ip);
        if (els.localLocation) els.localLocation.textContent = text(data.addr || data.location);
        if (els.localIsp) els.localIsp.textContent = text(data.isp || as.info || as.name);
        if (els.localAsn) els.localAsn.textContent = text(asnText);

        applyPrivacy();
    }

    /* ---------- 多源结果 ---------- */
    function loadSources(target) {
        var url = API + '?action=sources' + (target ? ('&target=' + encodeURIComponent(target)) : '');
        return apiFetch(url).then(function (data) {
            renderSources(data.sources || []);
            if (data.ip && !target) lastLocalIp = data.ip;
            return data;
        });
    }

    var sourceKeyMap = {
        'ip138.com': 'ip138',
        'IP.cn 查询网': 'ipcn',
        'Cloudflare': 'cloudflare',
        'IPinfo.io': 'ipinfo'
    };

    function renderSources(sources) {
        // 清空全部
        ['ip138', 'ipcn', 'cloudflare', 'ipinfo'].forEach(function (k) {
            var ipEl = $('srcIp_' + k);
            var infoEl = $('srcInfo_' + k);
            if (ipEl) ipEl.textContent = '--';
            if (infoEl) infoEl.textContent = '--';
        });

        sources.forEach(function (s) {
            var key = sourceKeyMap[s.name] || s.name.toLowerCase().replace(/[^a-z0-9]/g, '');
            var ipEl = $('srcIp_' + key);
            var infoEl = $('srcInfo_' + key);
            if (!ipEl || !infoEl) return;

            ipEl.textContent = text(s.ip);
            var infoParts = [s.location];
            if (s.isp && s.isp !== '未知') infoParts.push(s.isp);
            if (s.asn) infoParts.push(s.asn);
            infoEl.textContent = infoParts.join(' · ');

            var item = ipEl.closest('.ipq-source-item');
            if (item) {
                item.classList.toggle('is-domestic', s.tagClass === 'domestic');
                item.classList.toggle('is-international', s.tagClass === 'international');
            }
        });

        applyPrivacy();
    }

    /* ---------- IPv6 ---------- */
    function loadIpv6() {
        if (els.ipv6Status) els.ipv6Status.textContent = '检测中…';
        if (els.btnRetryIpv6) els.btnRetryIpv6.disabled = true;

        return apiFetch(API + '?action=ipv6').then(function (data) {
            renderIpv6(data);
        }).catch(function () {
            renderIpv6({ supported: false, message: '检测失败' });
        }).then(function () {
            if (els.btnRetryIpv6) els.btnRetryIpv6.disabled = false;
        });
    }

    function renderIpv6(data) {
        var statusEl = els.ipv6Status;
        if (!statusEl) return;

        // 移除旧的详细节点
        var oldDetail = els.ipv6State && els.ipv6State.querySelector('.ipq-ipv6-detail');
        if (oldDetail) oldDetail.remove();

        if (data.supported) {
            statusEl.textContent = '已支持';
            statusEl.className = 'ipq-ipv6-status is-supported';

            var detail = document.createElement('div');
            detail.className = 'ipq-ipv6-detail';
            detail.innerHTML = '<span class="ipq-ip">' + text(data.ip) + '</span> · ' +
                text(data.location) + ' · ' + text(data.isp);
            if (els.ipv6State) els.ipv6State.appendChild(detail);
        } else {
            statusEl.textContent = text(data.message, '你的网络可能不支持 IPv6');
            statusEl.className = 'ipq-ipv6-status';
        }

        applyPrivacy();
    }

    /* ---------- 隐私开关 ---------- */
    function applyPrivacy() {
        var hideIp = els.toggleHideIp && els.toggleHideIp.checked;
        var hideDom = els.toggleHideDomestic && els.toggleHideDomestic.checked;
        var hideInt = els.toggleHideInternational && els.toggleHideInternational.checked;

        document.querySelectorAll('.ipq-ip, .ipq-source-ip, .ipq-ws-ip').forEach(function (el) {
            el.classList.toggle('is-hidden', hideIp);
        });

        document.querySelectorAll('.ipq-source-item.is-domestic').forEach(function (item) {
            item.querySelectorAll('.ipq-source-ip, .ipq-source-info').forEach(function (el) {
                el.classList.toggle('is-hidden', hideDom);
            });
        });

        document.querySelectorAll('.ipq-source-item.is-international').forEach(function (item) {
            item.querySelectorAll('.ipq-source-ip, .ipq-source-info').forEach(function (el) {
                el.classList.toggle('is-hidden', hideInt);
            });
        });

        document.querySelectorAll('.ipq-latency-item[data-type="domestic"]').forEach(function (item) {
            item.classList.toggle('is-content-hidden', hideDom);
        });
        document.querySelectorAll('.ipq-latency-item[data-type="international"]').forEach(function (item) {
            item.classList.toggle('is-content-hidden', hideInt);
        });
    }

    function bindToggle(el) {
        if (!el) return;
        el.addEventListener('change', applyPrivacy);
    }

    /* ---------- WebRTC 泄露检测 ---------- */
    function detectWebrtc() {
        if (els.webrtcSupport) els.webrtcSupport.textContent = '检测中…';
        if (els.webrtcLeak) els.webrtcLeak.textContent = '--';
        if (els.webrtcCounts) els.webrtcCounts.textContent = '--';
        if (els.webrtcIp) els.webrtcIp.textContent = '--';
        if (els.webrtcTag) {
            els.webrtcTag.textContent = '--';
            els.webrtcTag.className = 'ipq-ws-tag';
        }
        if (els.btnRetryWebrtc) els.btnRetryWebrtc.disabled = true;

        try {
            if (!window.RTCPeerConnection) {
                renderWebrtcResult({ supported: false, message: '浏览器不支持' });
                return;
            }

            var pc = new RTCPeerConnection({
                iceServers: [
                    { urls: 'stun:stun.l.google.com:19302' },
                    { urls: 'stun:stun1.l.google.com:19302' }
                ]
            });

            pc.createDataChannel('probe');

            var candidates = [];
            var doneTimer = null;

            function finish() {
                if (doneTimer) { clearTimeout(doneTimer); doneTimer = null; }
                try { pc.close(); } catch (e) {}
                analyzeWebrtcCandidates(candidates);
                if (els.btnRetryWebrtc) els.btnRetryWebrtc.disabled = false;
            }

            pc.onicecandidate = function (e) {
                if (e.candidate && e.candidate.candidate) {
                    candidates.push(e.candidate.candidate);
                }
            };

            pc.onicegatheringstatechange = function () {
                if (pc.iceGatheringState === 'complete') finish();
            };

            pc.createOffer().then(function (offer) {
                return pc.setLocalDescription(offer);
            }).catch(function () {
                renderWebrtcResult({ supported: true, error: true, message: '创建 offer 失败' });
                if (els.btnRetryWebrtc) els.btnRetryWebrtc.disabled = false;
            });

            doneTimer = setTimeout(function () {
                finish();
            }, 8000);
        } catch (e) {
            renderWebrtcResult({ supported: false, message: '检测异常' });
            if (els.btnRetryWebrtc) els.btnRetryWebrtc.disabled = false;
        }
    }

    function analyzeWebrtcCandidates(candidates) {
        var publicIps = [];
        var localIps = [];

        candidates.forEach(function (cand) {
            var ip = parseCandidateIp(cand);
            if (!ip) return;
            if (isPrivateIp(ip)) {
                if (localIps.indexOf(ip) === -1) localIps.push(ip);
            } else {
                if (publicIps.indexOf(ip) === -1) publicIps.push(ip);
            }
        });

        var hasPublic = publicIps.length > 0;
        var hasLocal = localIps.length > 0;

        renderWebrtcResult({
            supported: true,
            hasPublic: hasPublic,
            hasLocal: hasLocal,
            publicIps: publicIps,
            localIps: localIps,
            publicCount: publicIps.length,
            localCount: localIps.length
        });
    }

    function parseCandidateIp(candidate) {
        // candidate: ... <ip> <port> typ ...
        var m = candidate.match(/\s([0-9a-fA-F.:]+)\s+\d+\s+typ/);
        return m ? m[1] : null;
    }

    function isPrivateIp(ip) {
        if (ip.indexOf(':') !== -1) {
            return (/^fc00:/i.test(ip) || /^fe80:/i.test(ip) || /^::1$/.test(ip) || /^::$/.test(ip));
        }
        var parts = ip.split('.').map(Number);
        if (parts.length !== 4) return false;
        return (
            parts[0] === 10 ||
            (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
            (parts[0] === 192 && parts[1] === 168) ||
            parts[0] === 127 ||
            (parts[0] === 169 && parts[1] === 254) ||
            (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127)
        );
    }

    function renderWebrtcResult(r) {
        if (!r.supported) {
            if (els.webrtcSupport) els.webrtcSupport.textContent = '不支持';
            if (els.webrtcLeak) els.webrtcLeak.textContent = r.message || '不支持';
            if (els.webrtcCounts) els.webrtcCounts.textContent = '--';
            if (els.webrtcIp) els.webrtcIp.textContent = '--';
            if (els.webrtcTag) {
                els.webrtcTag.textContent = '--';
                els.webrtcTag.className = 'ipq-ws-tag';
            }
            return;
        }

        if (els.webrtcSupport) els.webrtcSupport.textContent = '已支持';

        if (r.error) {
            if (els.webrtcLeak) els.webrtcLeak.textContent = r.message || '检测失败';
            if (els.webrtcCounts) els.webrtcCounts.textContent = '--';
            return;
        }

        var leakEl = els.webrtcLeak;
        if (leakEl) {
            if (r.hasPublic) {
                leakEl.textContent = '发现公网地址';
                leakEl.className = 'ipq-ws-value is-leak';
            } else if (r.hasLocal) {
                leakEl.textContent = '仅本地地址';
                leakEl.className = 'ipq-ws-value';
            } else {
                leakEl.textContent = '未发现泄露';
                leakEl.className = 'ipq-ws-value is-safe';
            }
        }

        if (els.webrtcCounts) els.webrtcCounts.textContent = r.publicCount + ' / ' + r.localCount;

        var displayIp = r.publicIps[0] || r.localIps[0] || '--';
        if (els.webrtcIp) els.webrtcIp.textContent = displayIp;

        if (els.webrtcTag) {
            if (r.publicIps.length > 0) {
                els.webrtcTag.textContent = 'IPv' + (r.publicIps[0].indexOf(':') !== -1 ? '6' : '4') + ' · 公网';
                els.webrtcTag.className = 'ipq-ws-tag is-public';
            } else if (r.localIps.length > 0) {
                els.webrtcTag.textContent = 'IPv' + (r.localIps[0].indexOf(':') !== -1 ? '6' : '4') + ' · 本地';
                els.webrtcTag.className = 'ipq-ws-tag is-local';
            } else {
                els.webrtcTag.textContent = '--';
                els.webrtcTag.className = 'ipq-ws-tag';
            }
        }

        applyPrivacy();
    }

    /* ---------- 延迟检测 ---------- */
    var latencyTargets = [];

    function loadLatencyTargets() {
        if (els.latencyGrid) els.latencyGrid.innerHTML = '<div class="ipq-latency-error">加载目标中…</div>';
        return apiFetch(API + '?action=latency').then(function (data) {
            latencyTargets = data.targets || [];
            renderLatencySkeleton(latencyTargets);
            measureLatency();
        }).catch(function () {
            if (els.latencyGrid) els.latencyGrid.innerHTML = '<div class="ipq-latency-error">延迟目标加载失败</div>';
        });
    }

    var brandColors = {
        douyin: '#000000', bilibili: '#00a1d6', weixin: '#07c160', taobao: '#ff5000',
        github: '#181717', jsdelivr: '#e84d3d', cloudflare: '#f48120', youtube: '#ff0000'
    };

    function renderLatencySkeleton(targets) {
        if (!els.latencyGrid) return;
        els.latencyGrid.innerHTML = '';

        targets.forEach(function (t) {
            var color = brandColors[t.key] || '#5668ee';
            var initial = t.name.charAt(0).toUpperCase();
            var item = document.createElement('div');
            item.className = 'ipq-latency-item';
            item.setAttribute('data-type', t.type);
            item.setAttribute('data-key', t.key);
            item.innerHTML =
                '<div class="ipq-latency-headline">' +
                    '<div class="ipq-latency-name">' +
                        '<span class="ipq-latency-icon" style="background:' + color + '">' + initial + '</span>' +
                        text(t.name) +
                    '</div>' +
                    '<span class="ipq-tag ipq-tag-' + (t.type === 'domestic' ? 'domestic' : 'international') + '">' +
                        (t.type === 'domestic' ? '国内' : '国际') +
                    '</span>' +
                '</div>' +
                '<div class="ipq-latency-ms" id="latMs_' + t.key + '">检测中…</div>' +
                '<div class="ipq-latency-bar" id="latBar_' + t.key + '"></div>';
            els.latencyGrid.appendChild(item);
        });
    }

    function measureLatency() {
        latencyTargets.forEach(function (t) {
            measureOneLatency(t);
        });
    }

    function measureOneLatency(t) {
        var msEl = $('latMs_' + t.key);
        var barEl = $('latBar_' + t.key);
        if (!msEl || !barEl) return;

        msEl.textContent = '检测中…';
        msEl.className = 'ipq-latency-ms';
        barEl.innerHTML = '';

        var start = performance.now();
        var controller = new AbortController();
        var timer = setTimeout(function () { controller.abort(); }, 8000);

        fetch(t.url, {
            method: 'HEAD',
            mode: 'no-cors',
            cache: 'no-store',
            signal: controller.signal
        }).then(function () {
            clearTimeout(timer);
            var ms = Math.round(performance.now() - start);
            renderLatencyValue(t.key, ms);
        }).catch(function () {
            clearTimeout(timer);
            renderLatencyValue(t.key, -1);
        });
    }

    function renderLatencyValue(key, ms) {
        var msEl = $('latMs_' + key);
        var barEl = $('latBar_' + key);
        if (!msEl || !barEl) return;

        if (ms < 0) {
            msEl.textContent = '超时 / 失败';
            msEl.className = 'ipq-latency-ms';
            barEl.innerHTML = '<span class="ipq-latency-error">无法连接</span>';
            return;
        }

        var levelClass = ms < 100 ? 'is-good' : (ms < 250 ? 'is-warn' : 'is-bad');
        msEl.textContent = ms + 'ms';
        msEl.className = 'ipq-latency-ms ' + levelClass;

        // 每点约 30ms，最多 12 点
        var dots = Math.min(12, Math.max(1, Math.round(ms / 30)));
        var html = '';
        for (var i = 0; i < dots; i++) {
            html += '<span class="ipq-latency-dot ' + levelClass + '"></span>';
        }
        barEl.innerHTML = html;
    }

    /* ---------- 查询表单 ---------- */
    function doQuery(target) {
        if (pending) return;
        setLoading(true);

        Promise.all([
            loadLocal(target),
            loadSources(target)
        ]).catch(function (err) {
            alert(err && err.message ? err.message : '查询失败');
        }).then(function () {
            setLoading(false);
        });
    }

    if (els.form) {
        els.form.addEventListener('submit', function (e) {
            e.preventDefault();
            doQuery(els.input.value.trim());
        });
    }

    if (els.btnMine) {
        els.btnMine.addEventListener('click', function () {
            if (els.input) els.input.value = '';
            doQuery('');
        });
    }

    document.querySelectorAll('[data-ip]').forEach(function (link) {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            var ip = link.getAttribute('data-ip');
            if (els.input) els.input.value = ip;
            doQuery(ip);
        });
    });

    /* ---------- 复制 ---------- */
    if (els.btnCopyIpv4) {
        els.btnCopyIpv4.addEventListener('click', function () {
            var ip = els.localIpv4 ? els.localIpv4.textContent : '';
            if (!ip || ip === '--') return;
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(ip).then(function () {
                    els.btnCopyIpv4.classList.add('copied');
                    els.btnCopyIpv4.title = '已复制';
                    setTimeout(function () {
                        els.btnCopyIpv4.classList.remove('copied');
                        els.btnCopyIpv4.title = '复制 IPv4';
                    }, 1600);
                });
            } else {
                window.prompt('请手动复制：', ip);
            }
        });
    }

    /* ---------- 事件绑定 ---------- */
    bindToggle(els.toggleHideIp);
    bindToggle(els.toggleHideDomestic);
    bindToggle(els.toggleHideInternational);

    if (els.btnRetryIpv6) {
        els.btnRetryIpv6.addEventListener('click', function () {
            loadIpv6();
        });
    }

    if (els.btnRetryWebrtc) {
        els.btnRetryWebrtc.addEventListener('click', function () {
            detectWebrtc();
        });
    }

    if (els.btnRetryLatency) {
        els.btnRetryLatency.addEventListener('click', function () {
            measureLatency();
        });
    }

    /* ---------- 初始化 ---------- */
    function init() {
        loadLocal('');
        loadIpv6();
        loadSources('');
        detectWebrtc();
        loadLatencyTargets();
    }

    init();
})();
