'use strict';
/**
 * 认证页共用提示函数（登录/注册/找回密码）
 */
function showMsg(el, text, type) {
    if (!el) return;
    el.textContent = text;
    el.className = 'msg-tip msg-' + type;
    if (type !== 'success') {
        setTimeout(function () { el.className = 'msg-tip'; }, 5000);
    }
}
