/* ============================================================
 * NAT 类型在线检测（nat.php）—— 专业版
 *
 * 方法论（关键）：
 *   浏览器无法发送 RFC 3489 / RFC 5780 里的 CHANGE-REQUEST，也无法让
 *   外部主机主动向映射端口回连，因此「过滤行为（Filtering）」在纯前端
 *   条件下无法测量。本模块测量的是**映射行为（Mapping Behavior）**：
 *
 *   1) 在【同一条 RTCPeerConnection】上挂载全部 STUN 节点。
 *      ICE 只会为该连接的每个网络接口分配【一个本地 UDP 端口】，
 *      因此所有 srflx 候选都出自同一个内网端口 —— 这正是判断
 *      「同一内网端口访问不同目标时外网映射是否一致」的必要条件。
 *      （若每个 STUN 节点各建一条连接，本地端口不同，跨节点比较端口
 *        在方法论上是无效的。）
 *
 *   2) 通过 pc.getStats() 的 local-candidate 记录拿到每个 srflx 候选
 *      的 url 字段，从而把「映射端点」精确归属到「探测目标」。
 *
 *   3) 重复多轮采样，观察映射是否随轮次（即本地端口）变化。
 *
 * 判定依据（RFC 4787 术语）：
 *   - Endpoint-Independent Mapping (EIM)  同连接内所有目标 → 同一映射端点
 *   - Address-Dependent Mapping (ADM)     映射随目标地址变化
 *   - Address & Port-Dependent (APDM)     映射随目标地址+端口变化 → 对称型
 * ============================================================ */
(function () {
    'use strict';

    /* ---------- 配置 ---------- */

    // 已完成可用性实测的公共 STUN 节点（国内 + 海外混合，避免单一出口）
    var STUN_SERVERS = [
        'stun:stun.miwifi.com:3478',
        'stun:stun.chat.bilibili.com:3478',
        'stun:stun.hitv.com:3478',
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
        'stun:stun2.l.google.com:19302',
        'stun:stun.cloudflare.com:3478',
        'stun:stun.nextcloud.com:443',
        'stun:stun.voipbuster.com:3478',
        'stun:stun.xten.com:3478',
        'stun:stun.schlund.de:3478'
    ];

    var ROUND_COUNT = 3;      // 采样轮数
    var ROUND_TIMEOUT = 8000; // 单轮最长等待（ms）

    var $ = function (id) { return document.getElementById(id); };

    /* ---------- 基础工具 ---------- */

    function isPublicIP(ip) {
        if (!ip) return false;
        if (ip === '127.0.0.1' || ip === '::1') return false;
        if (ip.endsWith('.local')) return false;               // mDNS 混淆
        if (/^(fe80|fc|fd)/i.test(ip)) return false;           // 链路本地 / ULA
        var m = ip.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
        if (m) {
            var a = +m[1], b = +m[2];
            if (a === 0 || a === 10 || a === 127) return false;
            if (a === 172 && b >= 16 && b <= 31) return false;
            if (a === 192 && b === 168) return false;
            if (a === 100 && b >= 64 && b <= 127) return false; // CGNAT 100.64/10
            if (a === 169 && b === 254) return false;
            if (a >= 224) return false;                         // 组播 / 保留
            return true;
        }
        if (/^[0-9a-f:]+$/i.test(ip) && ip.indexOf(':') !== -1) return true; // 公网 IPv6
        return false;
    }

    function isMdns(addr) { return !!addr && /\.local$/i.test(addr); }

    function uniq(arr) {
        var seen = {}, out = [];
        for (var i = 0; i < arr.length; i++) {
            var k = String(arr[i]);
            if (!seen[k]) { seen[k] = 1; out.push(arr[i]); }
        }
        return out;
    }

    function setText(id, text) { var el = $(id); if (el) el.textContent = text; }

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function shortUrl(u) { return String(u || '').replace(/^stun:/, ''); }

    /* ---------- 阶段一：环境检查 ---------- */

    function envCheck() {
        var out = {
            webrtc: typeof RTCPeerConnection !== 'undefined',
            secure: (typeof window.isSecureContext === 'boolean') ? window.isSecureContext : null,
            candidate: typeof RTCIceCandidate !== 'undefined',
            stats: !!(window.RTCPeerConnection &&
                (RTCPeerConnection.prototype.getStats || RTCPeerConnection.prototype.getStats === undefined))
        };
        if (!out.webrtc) {
            out.reason = '当前浏览器不支持 WebRTC（RTCPeerConnection 不可用）';
        } else if (out.secure === false) {
            out.reason = '非安全上下文（需 HTTPS 或 localhost），浏览器会屏蔽 ICE 采集';
        }
        return out;
    }

    /* ---------- 阶段二：单轮采样 ---------- */

    /**
     * 一轮采样：建一条连接挂载全部 STUN，同一个本地 UDP 端口向所有目标探测。
     */
    function sampleRound(index) {
        return new Promise(function (resolve) {
            var t0 = performance.now();
            var pc = null;
            var raw = [];
            var finished = false;

            var finish = async function () {
                if (finished) return;
                finished = true;

                var stats = [];
                if (pc) {
                    try {
                        var report = await pc.getStats();
                        report.forEach(function (r) {
                            if (r.type === 'local-candidate' && r.candidateType === 'srflx') {
                                stats.push({
                                    address: r.address || '',
                                    port: r.port || 0,
                                    protocol: (r.protocol || 'udp').toLowerCase(),
                                    url: r.url || '',
                                    relatedAddress: r.relatedAddress || '',
                                    relatedPort: r.relatedPort || 0
                                });
                            }
                        });
                    } catch (e) { /* 归属失败不影响采样 */ }
                }
                try { if (pc) pc.close(); } catch (e) { }

                var host = [];
                var srflx = [];
                var seenSrflx = {};

                raw.forEach(function (c) {
                    if (c.type === 'host') {
                        host.push({
                            address: c.address,
                            port: c.port,
                            protocol: c.protocol,
                            mdns: isMdns(c.address),
                            isPublic: isPublicIP(c.address)
                        });
                    } else if (c.type === 'srflx') {
                        if (seenSrflx[c.address + ':' + c.port]) return;
                        seenSrflx[c.address + ':' + c.port] = 1;
                        srflx.push({
                            address: c.address,
                            port: c.port,
                            protocol: c.protocol,
                            relatedAddress: c.relatedAddress || '',
                            relatedPort: c.relatedPort || 0,
                            server: ''   // 下面用 stats 归属
                        });
                    }
                });

                // 用 getStats 的 url 字段把映射端点归属到探测目标
                stats.forEach(function (s) {
                    for (var i = 0; i < srflx.length; i++) {
                        if (srflx[i].address === s.address && srflx[i].port === s.port) {
                            if (!srflx[i].server) srflx[i].server = s.url;
                            if (!srflx[i].relatedPort && s.relatedPort) srflx[i].relatedPort = s.relatedPort;
                            break;
                        }
                    }
                });

                var responded = {};
                srflx.forEach(function (s) { if (s.server) responded[s.server] = 1; });

                resolve({
                    index: index,
                    elapsed: Math.round(performance.now() - t0),
                    host: host,
                    srflx: srflx,
                    targetCount: STUN_SERVERS.length,
                    respondedCount: Object.keys(responded).length,
                    ok: srflx.length > 0,
                    error: srflx.length > 0 ? null : '本轮未收到任何 STUN 映射响应'
                });
            };

            try {
                pc = new RTCPeerConnection({
                    iceServers: STUN_SERVERS.map(function (u) { return { urls: u }; }),
                    iceCandidatePoolSize: 0
                });
                pc.createDataChannel('nat-probe');
                pc.onicecandidate = function (e) {
                    if (e.candidate && e.candidate.candidate) {
                        raw.push({
                            type: e.candidate.type,
                            protocol: (e.candidate.protocol || '').toLowerCase(),
                            address: e.candidate.address,
                            port: e.candidate.port,
                            relatedAddress: e.candidate.relatedAddress,
                            relatedPort: e.candidate.relatedPort
                        });
                    } else if (!e.candidate) {
                        setTimeout(finish, 250);   // 给 getStats 一点时间落库
                    }
                };
                pc.createOffer()
                    .then(function (o) { return pc.setLocalDescription(o); })
                    .catch(function () { finish(); });
            } catch (e) {
                finish();
                return;
            }

            setTimeout(finish, ROUND_TIMEOUT);
        });
    }

    /* ---------- 阶段三：服务端出口交叉校验 ---------- */

    async function fetchServerEgress() {
        try {
            var r = await fetch('./api/nat.php', { cache: 'no-store', credentials: 'omit' });
            var d = await r.json();
            if (d && d.status === 0) return d;
            return null;
        } catch (e) {
            return null;
        }
    }

    /* ---------- 阶段四：判定引擎 ---------- */

    function analyze(rounds, env, egress, totalElapsed) {
        var allHost = [];
        var allSrflx = [];
        rounds.forEach(function (r) {
            allHost = allHost.concat(r.host || []);
            allSrflx = allSrflx.concat(r.srflx || []);
        });

        var endedEndpoints = uniq(allSrflx.map(function (s) { return s.address + ':' + s.port; }));
        var mappedIPs = uniq(allSrflx.map(function (s) { return s.address; }));
        var localPorts = uniq(rounds.map(function (r) {
            return r.host && r.host.length && !isMdns(r.host[0].address) ? r.host[0].port : null;
        }).filter(Boolean));

        var okRounds = rounds.filter(function (r) { return r.ok; });
        var localHosts = uniq(allHost.filter(function (h) { return !h.isPublic; }).map(function (h) {
            return (isMdns(h.address) ? 'mDNS 隐藏' : h.address) + ':' + h.port;
        }));
        var publicHosts = uniq(allHost.filter(function (h) { return h.isPublic; }).map(function (h) {
            return h.address + ':' + h.port;
        }));
        var mdnsHidden = allHost.some(function (h) { return h.mdns; });
        var tcpCandidates = uniq(allHost.filter(function (h) { return h.protocol === 'tcp'; })
            .map(function (h) { return h.address + ':' + h.port; }));

        // 每轮内的映射端点分布（同一本地端口 → 多个目标）
        var perRound = rounds.map(function (r) {
            var eps = uniq((r.srflx || []).map(function (s) { return s.address + ':' + s.port; }));
            var ips = uniq((r.srflx || []).map(function (s) { return s.address; }));
            var localPort = (r.host && r.host.length) ? r.host[0].port : null;
            return {
                index: r.index,
                ok: r.ok,
                localPort: localPort,
                targetCount: r.targetCount,
                respondedCount: r.respondedCount,
                endpointCount: eps.length,
                ipCount: ips.length,
                endpoints: eps,
                ips: ips,
                elapsed: r.elapsed,
                srflx: r.srflx || [],
                error: r.error
            };
        });

        // 同轮内是否出现多个映射端点 → 目的地相关映射
        var roundsWithMultiple = perRound.filter(function (r) { return r.endpointCount > 1; });
        var maxResponded = 0;
        perRound.forEach(function (r) { if (r.respondedCount > maxResponded) maxResponded = r.respondedCount; });

        /* ---- 映射行为判定 ---- */
        var mapping, mappingLabel, natType, natLabel, natTag, headline, sub;

        if (allSrflx.length === 0 && publicHosts.length > 0) {
            mapping = 'none';
            mappingLabel = '无 NAT 转换';
            natType = 'open'; natTag = 'NAT0'; natLabel = '开放网络 / 无 NAT';
            headline = '开放网络（无 NAT）';
            sub = '本机持有公网地址并直接暴露 host 候选，未经过 NAT 转换。外部主机可直接访问本机端口，P2P 与联机最友好。';
        } else if (allSrflx.length === 0) {
            mapping = 'unknown';
            mappingLabel = '未知（无样本）';
            natType = 'blocked'; natTag = '未知'; natLabel = 'UDP 受阻 / STUN 不可达';
            headline = '无法判定（UDP 受阻或 STUN 不可达）';
            sub = '未采集到任何公网映射候选：可能是 UDP 被防火墙屏蔽、WebRTC 被策略禁用，或所有 STUN 节点均不可达。此时映射行为与 NAT 类型均标注为未知。';
        } else if (roundsWithMultiple.length > 0) {
            mapping = mappedIPs.length > 1 ? 'apdm-addr' : 'apdm-port';
            mappingLabel = 'Address & Port-Dependent Mapping（APDM）';
            natType = 'symmetric'; natTag = 'NAT4'; natLabel = '对称型（Symmetric）';
            headline = '对称型 NAT（Symmetric / NAT4）';
            sub = '在同一个本地端口上，向不同探测目标发起的请求被分配到了不同的公网映射端点，符合「地址与端口相关映射（APDM）」。P2P 打洞最困难，通常需要 TURN 中继。';
            if (mappedIPs.length > 1) {
                sub += ' 且映射后的公网地址也存在差异，说明出口侧存在地址池或运营商级 NAT（CGNAT）。';
            }
        } else {
            mapping = 'eim';
            mappingLabel = 'Endpoint-Independent Mapping（EIM）';
            natType = 'cone'; natTag = 'NAT1/2/3'; natLabel = '锥形族（Cone）';
            headline = '锥形 NAT（Cone Family）';
            sub = '同一个本地端口访问不同目标时，公网映射端点保持一致，符合「端点无关映射（EIM）」。全锥 / 受限锥 / 端口受限锥的细分需要服务端从另外的地址主动回连（RFC 3489 Test II/III），浏览器无法完成，因此子类型标注为未知。';
        }

        // 样本不足时降级为「未知」
        if (natType === 'cone' && maxResponded < 2) {
            mapping = 'unknown';
            mappingLabel = '样本不足（仅 1 个目标响应）';
            natType = 'unknown'; natTag = '未知'; natLabel = '无法判定';
            headline = '样本不足，无法判定 NAT 类型';
            sub = '只有 1 个 STUN 目标返回了映射信息。判定「端点无关映射」至少需要 2 个独立目标在同一本地端口上做对照，否则与对称型无法区分。请重试或更换网络后再次检测。';
        }

        /* ---- 端口保持与地址稳定性 ---- */
        var portPreserved = false;
        perRound.forEach(function (r) {
            if (r.localPort && r.endpoints.length) {
                r.endpoints.forEach(function (ep) {
                    if (parseInt(ep.split(':')[1], 10) === r.localPort) portPreserved = true;
                });
            }
        });

        var portSequenceNote = '';
        perRound.forEach(function (r) {
            if (r.srflx.length < 2) return;
            var byIp = {};
            r.srflx.forEach(function (s) { (byIp[s.address] = byIp[s.address] || []).push(s.port); });
            var seq = false;
            Object.keys(byIp).forEach(function (ip) {
                var pts = byIp[ip].slice().sort(function (a, b) { return a - b; });
                if (pts.length >= 2) {
                    var consecutive = true;
                    for (var i = 1; i < pts.length; i++) {
                        if (pts[i] - pts[i - 1] > 2) { consecutive = false; break; }
                    }
                    if (consecutive) seq = true;
                }
            });
            if (seq && !portSequenceNote) {
                portSequenceNote = '同轮内同一映射地址上观察到连续递增的端口号，符合 NAT 按目标顺序分配映射端口的典型行为。';
            }
        });

        /* ---- 可信度 ---- */
        var conf, confReason;
        if (natType === 'open') {
            conf = '高'; confReason = '直接观察到公网 host 候选';
        } else if (natType === 'blocked' || natType === 'unknown') {
            conf = '低'; confReason = '缺少足够样本，结论为未知';
        } else if (okRounds.length >= 2 && maxResponded >= 3) {
            conf = '高'; confReason = okRounds.length + ' 轮独立采样成功，单轮最多 ' + maxResponded + ' 个目标响应';
        } else if (okRounds.length >= 1 && maxResponded >= 2) {
            conf = '中'; confReason = okRounds.length + ' 轮采样成功，单轮 ' + maxResponded + ' 个目标响应';
        } else {
            conf = '低'; confReason = '样本偏少';
        }

        /* ---- 交叉校验线索 ---- */
        var httpIp = (egress && egress.ip) ? egress.ip : null;
        var stunIp = mappedIPs.length ? mappedIPs[0] : null;
        var clue, clueLevel;
        if (!httpIp) {
            clue = '服务端出口 IP 获取失败，无法交叉校验';
            clueLevel = 'unknown';
        } else if (!stunIp) {
            clue = '未获得公网映射地址，无法比对';
            clueLevel = 'unknown';
        } else if (!isPublicIP(httpIp)) {
            clue = '服务端看到的请求来源为 ' + httpIp + '（环回/私有地址），说明浏览器与本站点部署在同一台主机或同一内网，该地址不能代表公网出口，本次交叉校验不具参考意义（请以 STUN 映射地址为准）';
            clueLevel = 'muted';
        } else if (mappedIPs.indexOf(httpIp) !== -1) {
            clue = 'HTTP 出口 IP 出现在 STUN 映射地址集合中，出口与映射同源，未观察到出口偏移';
            clueLevel = 'ok';
        } else if (mappedIPs.length > 1) {
            clue = 'HTTP 出口 IP 不在 STUN 映射地址集合内，且映射地址存在多个（' + mappedIPs.length + ' 个），符合运营商级 NAT（CGNAT）地址池或多出口/多线路的典型特征';
            clueLevel = 'warn';
        } else {
            clue = 'HTTP 出口 IP 与 STUN 映射地址不一致，可能存在多层 NAT、出口负载均衡或代理';
            clueLevel = 'warn';
        }

        /* ---- 应用场景 ---- */
        var scenarios;
        if (natType === 'open') {
            scenarios = { game: ['s-excellent', '极佳'], p2p: ['s-excellent', '极佳'], video: ['s-excellent', '极佳'], remote: ['s-excellent', '极佳'] };
        } else if (natType === 'cone') {
            scenarios = { game: ['s-good', '良好'], p2p: ['s-fair', '一般'], video: ['s-good', '良好'], remote: ['s-good', '良好'] };
        } else if (natType === 'symmetric') {
            scenarios = { game: ['s-poor', '较差'], p2p: ['s-poor', '受限'], video: ['s-fair', '一般'], remote: ['s-poor', '需中继'] };
        } else {
            scenarios = { game: ['s-unknown', '未知'], p2p: ['s-unknown', '未知'], video: ['s-unknown', '未知'], remote: ['s-unknown', '未知'] };
        }

        return {
            env: env,
            rounds: rounds,
            perRound: perRound,
            totalElapsed: totalElapsed,
            allHost: allHost,
            allSrflx: allSrflx,
            mappedEndpoints: endedEndpoints,
            mappedIPs: mappedIPs,
            localHosts: localHosts,
            localPorts: localPorts,
            publicHosts: publicHosts,
            mdnsHidden: mdnsHidden,
            tcpCandidates: tcpCandidates,
            okRounds: okRounds.length,
            maxResponded: maxResponded,
            mapping: mapping,
            mappingLabel: mappingLabel,
            natType: natType,
            natTag: natTag,
            natLabel: natLabel,
            headline: headline,
            sub: sub,
            portPreserved: portPreserved,
            portSequenceNote: portSequenceNote,
            conf: conf,
            confReason: confReason,
            httpIp: httpIp,
            stunIp: stunIp,
            clue: clue,
            clueLevel: clueLevel,
            egress: egress,
            scenarios: scenarios
        };
    }

    /* ---------- 阶段五：渲染 ---------- */

    var TYPE_KEYS = ['open', 'cone', 'restricted', 'port-restricted', 'symmetric'];

    function renderChips(R) {
        var box = $('natBasisList');
        if (!box) return;
        var chips = [];

        chips.push({ t: R.rounds.length + ' 轮独立采样', k: R.okRounds > 0 ? 'ok' : 'muted' });
        chips.push({ t: '成功轮次 ' + R.okRounds + '/' + R.rounds.length, k: R.okRounds >= 2 ? 'ok' : 'warn' });
        chips.push({ t: '单轮最多响应目标 ' + R.maxResponded, k: R.maxResponded >= 2 ? 'ok' : 'warn' });
        chips.push({ t: '观察到映射端点 ' + R.mappedEndpoints.length, k: 'info' });
        chips.push({ t: '观察到映射地址 ' + R.mappedIPs.length, k: 'info' });

        if (R.mapping === 'eim') chips.push({ t: '同端口多目标映射一致', k: 'ok' });
        if (R.mapping === 'apdm-addr') chips.push({ t: '同端口多目标映射地址发生变化', k: 'danger' });
        if (R.mapping === 'apdm-port') chips.push({ t: '同端口多目标映射端口发生变化', k: 'danger' });
        if (R.mapping === 'unknown') chips.push({ t: '映射行为：未知', k: 'muted' });
        if (R.portPreserved) chips.push({ t: '存在端口保持（Port Preservation）', k: 'info' });

        box.innerHTML = chips.map(function (c) {
            return '<span class="nat-chip nat-chip-' + c.k + '">' + esc(c.t) + '</span>';
        }).join('');
    }

    function renderStats(R) {
        setText('statRounds', R.okRounds + '/' + R.rounds.length);
        setText('statEndpoints', String(R.mappedEndpoints.length));
        setText('statMappedIps', String(R.mappedIPs.length));
        setText('statSrflxCands', String(R.allSrflx.length));
        setText('statLocalCands', String(R.localHosts.length));
        setText('statTcpCands', String(R.tcpCandidates.length));
        setText('statElapsed', R.totalElapsed + ' ms');

        setText('statStatus', R.okRounds > 0 ? '完成' : '未取得样本');
        setText('statConfidence', R.conf);
    }

    function renderCross(R) {
        setText('crossHttpIp', R.httpIp || '获取失败');
        setText('crossStunIp', R.mappedIPs.length
            ? (R.mappedIPs.length === 1 ? R.mappedIPs[0] : R.mappedIPs.slice(0, 3).join('、') + (R.mappedIPs.length > 3 ? ' 等 ' + R.mappedIPs.length + ' 个' : ''))
            : '无');

        var clueEl = $('crossClue');
        if (clueEl) {
            clueEl.textContent = R.clue;
            clueEl.className = 'nat-stat-value nat-clue nat-clue-' + R.clueLevel;
        }

        var envEl = $('crossEnv');
        if (envEl) {
            var parts = [];
            parts.push('WebRTC ' + (R.env.webrtc ? '可用' : '不可用'));
            if (R.env.secure === false) parts.push('非安全上下文');
            else if (R.env.secure === true) parts.push('安全上下文 OK');
            if (R.mdnsHidden) parts.push('内网地址被 mDNS 混淆隐藏');
            if (R.egress && R.egress.family) parts.push('HTTP 出口地址族 ' + R.egress.family);
            if (R.egress && R.egress.https) parts.push('HTTPS');
            if (R.tcpCandidates.length) parts.push('观察到 TCP host 候选 ' + R.tcpCandidates.length + ' 个');
            envEl.textContent = '运行环境：' + parts.join(' · ');

            // 代理链线索（可能被伪造，仅作参考）
            if (R.egress && R.egress.forwarded && R.egress.forwarded.length) {
                envEl.textContent += '。服务端还读到转发头地址 ' + R.egress.forwarded.slice(0, 3).join(' → ')
                    + (R.egress.forwarded.length > 3 ? ' 等 ' + R.egress.forwarded.length + ' 个' : '')
                    + '（转发头可被伪造，仅作线索）。';
            }
            if (R.egress && R.egress.via) {
                envEl.textContent += ' Via: ' + R.egress.via + '。';
            }
        }
    }

    function renderMappingTable(R) {
        var box = $('natMappingTable');
        if (!box) return;

        var rows = R.perRound.map(function (r) {
            var localPort = r.localPort ? String(r.localPort) : '未知';
            var verdict, cls;
            if (!r.ok) {
                verdict = '无样本';
                cls = 'is-muted';
            } else if (r.endpointCount > 1) {
                verdict = r.ipCount > 1
                    ? '映射地址 + 端口均随目标变化'
                    : '映射端口随目标变化';
                cls = 'is-danger';
            } else {
                verdict = '映射端点在全部目标上一致';
                cls = 'is-ok';
            }
            return '<tr>' +
                '<td>第 ' + r.index + ' 轮</td>' +
                '<td class="nat-mono">' + esc(localPort) + '</td>' +
                '<td>' + r.respondedCount + ' / ' + r.targetCount + '</td>' +
                '<td class="nat-mono">' + r.endpointCount + '</td>' +
                '<td class="nat-mono">' + r.ipCount + '</td>' +
                '<td class="' + cls + '">' + esc(verdict) + '</td>' +
                '<td class="nat-mono">' + r.elapsed + ' ms</td>' +
                '</tr>';
        }).join('');

        box.innerHTML =
            '<table class="nat-table">' +
            '<thead><tr>' +
            '<th>采样轮次</th><th>本地端口</th><th>目标响应</th>' +
            '<th>映射端点</th><th>映射地址</th><th>判定</th><th>耗时</th>' +
            '</tr></thead><tbody>' + rows + '</tbody></table>';

        var noteEl = $('natMappingNote');
        if (noteEl) {
            var notes = [];
            if (R.mapping === 'eim') {
                notes.push('同一本地端口向多个目标探测时，返回的映射端点完全相同，这是端点无关映射（EIM）的直接证据。');
            } else if (R.mapping && R.mapping.indexOf('apdm') === 0) {
                notes.push('同一本地端口向多个目标探测时，返回了多个不同的映射端点——本地端口相同而映射结果不同，只能由「映射取决于目标」解释，这是地址/端口相关映射（APDM，即对称型）的直接证据。');
            }
            if (R.portSequenceNote) notes.push(R.portSequenceNote);
            if (R.portPreserved) notes.push('检测到端口保持：部分映射端口与本地端口相同。');
            if (R.tcpCandidates.length) notes.push('本机同时产生了 TCP host 候选（' + R.tcpCandidates.length + ' 个），但浏览器无法对 TCP 发起 STUN 探测，TCP 映射行为标注为未知。');
            noteEl.innerHTML = notes.length ? notes.map(function (n) {
                return '<p class="nat-note-line">· ' + esc(n) + '</p>';
            }).join('') : '<p class="nat-note-line">· 暂无额外观察。</p>';
        }
    }

    function renderRaw(R) {
        var box = $('natRaw');
        if (!box) return;

        if (!R.rounds.length) {
            box.innerHTML = '<div class="nat-empty">暂无探测数据</div>';
            return;
        }

        box.innerHTML = R.perRound.map(function (r) {
            var localLine = r.localPort
                ? '<span class="nat-kv"><b>本地端口</b><code>' + esc(r.localPort) + '</code></span>'
                : '<span class="nat-kv"><b>本地端口</b><code>未获取（mDNS 混淆）</code></span>';

            var rows = r.srflx.map(function (s) {
                return '<div class="nat-raw-row">' +
                    '<span class="nat-raw-target">' + esc(shortUrl(s.server) || '未知目标') + '</span>' +
                    '<span class="nat-raw-arrow">→</span>' +
                    '<span class="nat-raw-mapped nat-mono">' + esc(s.address) + ':' + esc(s.port) + '</span>' +
                    '<span class="nat-tag nat-tag-' + (s.protocol === 'tcp' ? 'tcp' : 'udp') + '">' + esc((s.protocol || 'udp').toUpperCase()) + '</span>' +
                    '<span class="nat-tag nat-tag-srflx">srflx</span>' +
                    (s.relatedPort ? '<span class="nat-raw-rel">raddr ' + esc(s.relatedAddress || '-') + ' rport ' + esc(s.relatedPort) + '</span>' : '') +
                    '</div>';
            }).join('');

            if (!r.srflx.length) {
                rows = '<div class="nat-raw-row nat-raw-none">本轮未收到 STUN 映射响应</div>';
            }

            var hosts = r.ok && r.localPort
                ? '<div class="nat-raw-row nat-raw-local"><span class="nat-tag nat-tag-host">host</span> ' +
                  '<code class="nat-mono">' + esc(r.localPort) + '</code> 本地候选（内网侧）</div>'
                : '';

            return '<details class="nat-raw-round"' + (r.index === 1 ? ' open' : '') + '>' +
                '<summary>' +
                '<span class="nat-raw-title">第 ' + r.index + ' 轮</span>' +
                localLine +
                '<span class="nat-kv"><b>映射端点</b><code>' + r.endpointCount + '</code></span>' +
                '<span class="nat-kv"><b>耗时</b><code>' + r.elapsed + ' ms</code></span>' +
                '</summary>' +
                '<div class="nat-raw-body">' + hosts + rows + '</div>' +
                '</details>';
        }).join('');
    }

    function renderTypes(R) {
        TYPE_KEYS.forEach(function (k) {
            var el = $('natCard-' + k);
            if (!el) return;
            el.classList.remove('is-detected', 'is-family');
            var old = el.querySelector('.nat-type-badge');
            if (old) old.remove();
        });

        var tag = function (el, text, cls) {
            if (!el) return;
            el.classList.add(cls);
            var badge = document.createElement('span');
            badge.className = 'nat-type-badge';
            badge.textContent = text;
            el.appendChild(badge);
        };

        if (R.natType === 'cone') {
            // EIM 只能确认「锥形族」，全锥 / 受限锥 / 端口受限锥 子类型无法在浏览器端细分
            ['cone', 'restricted', 'port-restricted'].forEach(function (k) {
                tag($('natCard-' + k), '属于此族', 'is-family');
            });
        } else if (R.natType === 'symmetric') {
            tag($('natCard-symmetric'), '检测到', 'is-detected');
        } else if (R.natType === 'open') {
            tag($('natCard-open'), '检测到', 'is-detected');
        }
        // unknown / blocked：不点亮任何卡片，避免暗示未经证实的结论
    }

    function renderScenarios(R) {
        var map = {
            scGame: R.scenarios.game,
            scP2p: R.scenarios.p2p,
            scVideo: R.scenarios.video,
            scRemote: R.scenarios.remote
        };
        Object.keys(map).forEach(function (id) {
            var el = $(id);
            if (!el) return;
            var s = el.querySelector('.nat-scenario-status');
            if (!s) return;
            s.className = 'nat-scenario-status ' + map[id][0];
            s.textContent = map[id][1];
        });
    }

    function renderFilterUnknowns() {
        // 过滤行为 / Hairpinning / TCP 映射：浏览器不可测，统一标注未知
        setText('filterVerdict', '未知（浏览器无法测量）');
        setText('hairpinVerdict', '未知（无同侧 STUN 服务端）');
        setText('tcpVerdict', '未知（仅采集到 host 候选）');
    }

    /* ---------- 主流程 ---------- */

    async function runDetection() {
        var btn = $('btnStartNat');
        var pill = $('natStatusPill');
        var confPill = $('natConfidence');

        if (btn) { btn.disabled = true; btn.textContent = '检测中…'; }
        if (pill) { pill.className = 'nat-pill is-running'; pill.textContent = '采样中…'; }
        setText('statStatus', '检测中');

        var env = envCheck();
        if (!env.webrtc) {
            var typeEl = $('natResultType');
            if (typeEl) {
                typeEl.className = 'nat-result-type nat-result-blocked';
                typeEl.textContent = '当前浏览器不支持 WebRTC';
            }
            setText('natResultSub', '无法采集 ICE candidate：' + (env.reason || '请更换现代浏览器后重试'));
            if (btn) { btn.disabled = false; btn.textContent = '重新检测'; }
            if (pill) { pill.className = 'nat-pill is-error'; pill.textContent = '不可用'; }
            if (confPill) { confPill.className = 'nat-pill nat-pill-muted'; confPill.textContent = '可信度：—'; }
            return;
        }

        var t0 = performance.now();
        var rounds = [];

        // 逐轮串行：避免多连接竞争同一出口，保证「同一本地端口」的前提成立
        for (var i = 1; i <= ROUND_COUNT; i++) {
            if (pill) pill.textContent = '采样中…（第 ' + i + '/' + ROUND_COUNT + ' 轮）';
            /* eslint-disable no-await-in-loop */
            var r = await sampleRound(i);
            rounds.push(r);
        }

        var egress = await fetchServerEgress();
        var total = Math.round(performance.now() - t0);

        var R = analyze(rounds, env, egress, total);
        if (R.mapping === 'unknown' && R.allSrflx.length === 0) {
            renderFilterUnknowns();
        }

        // 头条
        var typeEl2 = $('natResultType');
        if (typeEl2) {
            typeEl2.className = 'nat-result-type nat-result-' + R.natType;
            typeEl2.textContent = R.headline;
        }
        setText('natResultSub', R.sub);
        setText('natResultTag', R.natTag);
        setText('natResultName', R.natLabel);
        setText('natMappingLabel', R.mappingLabel);

        if (pill) { pill.className = 'nat-pill is-done'; pill.textContent = '检测完成'; }
        if (confPill) {
            confPill.className = 'nat-pill nat-pill-muted';
            confPill.textContent = '可信度：' + R.conf;
        }
        setText('confReason', R.confReason);

        renderChips(R);
        renderStats(R);
        renderCross(R);
        renderMappingTable(R);
        renderRaw(R);
        renderTypes(R);
        renderScenarios(R);

        if (btn) { btn.disabled = false; btn.textContent = '重新检测'; }

        try {
            if (typeof window.reportQuery === 'function') {
                window.reportQuery('nat', R.localPorts.join(',') || '', R.headline + ' · ' + R.mappingLabel);
            }
        } catch (e) { /* 上报失败不影响结果 */ }
    }

    document.addEventListener('DOMContentLoaded', function () {
        var btn = $('btnStartNat');
        if (btn) btn.addEventListener('click', runDetection);
    });
})();
