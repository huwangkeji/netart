// center.php 的 auth API 路径（相对于 user/ 目录）
var UC_AUTH_API = '../api/auth.php';

// 注意：currentUser 已在 app.js 中声明，这里直接复用

document.addEventListener('DOMContentLoaded', () => {
    // 检查登录状态
    checkAuth();
    bindUCEvents();
});

async function checkAuth() {
    // 先检查本地存储是否有登录凭证（快速判断）
    const localToken = localStorage.getItem('AccessToken');
    if (!localToken) {
        showNotLogin('请先登录以查看会员中心');
        return;
    }

    try {
        const resp = await fetch(UC_AUTH_API + '?action=profile', { credentials:'same-origin' });
        const data = await resp.json();
        if (data.status === 0 && data.data) {
            showProfile(data.data);
        } else if (data.status === 1) {
            // 业务级未登录/认证失败
            localStorage.removeItem('AccessToken');
            showNotLogin(data.message || '登录已过期，请重新登录');
        } else {
            // 系统错误（如数据库连接失败）— 有token但API异常，显示错误信息+降级提示
            showError(data.message || '加载失败', true);
        }
    } catch(e) { showError('网络连接失败：' + e.message, true); }
}

function showError(msg, hasToken) {
    $('#notLoggedIn').style.display = 'none';
    $('#loggedInContent').style.display = 'none';
    $('#errorArea').style.display = '';
    var logoutTop = $('#btnLogoutTop');
    if (logoutTop) logoutTop.style.display = 'none';
    let html = '<p style="font-size:16px;color:var(--danger);margin-bottom:12px;">' + msg + '</p>';
    if (hasToken) {
        html += '<p style="font-size:13px;color:#999;margin-bottom:12px;">（检测到您已登录，但服务器暂时无法获取完整信息。可能需要安装 pdo_mysql 扩展）</p>';
    }
    html += '<button class="btn-default" onclick="location.reload()">刷新页面</button>';
    $('#errorMsg').innerHTML = html;
}

function showProfile(u) {
    currentUser = u;
    $('#notLoggedIn').style.display = 'none';
    $('#loggedInContent').style.display = '';
    // 显示顶部退出登录按钮
    var logoutTop = $('#btnLogoutTop');
    if (logoutTop) logoutTop.style.display = '';

    // 始终使用默认首字母头像
    $('#ucAvatar').textContent = (u.username||'U')[0].toUpperCase();
    $('#ucUsername').textContent = u.username;
    
    const roleClass = { user:'role-user', vip:'role-vip', admin:'role-admin' };
    const roleName = { user:'普通用户', vip:'VIP会员', admin:'管理员' };
    const tag = $('#ucRoleTag');
    tag.className = `role-tag ${roleClass[u.role]||'role-user'}`;
    tag.textContent = roleName[u.role]||'用户';

    $('#ucMeta').textContent = `${u.email||'未绑定邮箱'} | ID: ${u.id}`;
    $('#ucTotalBytes').textContent = formatBytes(u.total_bytes||0);
    $('#ucTotalTime').textContent = formatDur(u.total_time||0);
    $('#ucRegDate').textContent = fmtFullDate(u.created_at);
    $('#ucActiveDate').textContent = u.last_active ? fmtFullDate(u.last_active) : '-';
    
    // 账号状态
    const statusEl = $('#ucStatus');
    const statusBox = $('#ucStatusBox');
    if ((u.status ?? 1) === 1) {
        statusEl.textContent = '正常';
        statusEl.style.color = '#67c23a';
        statusBox.style.background = '#f0ffeb';
        statusBox.style.border = '2px solid #67c23a40';
    } else {
        statusEl.textContent = '禁用';
        statusEl.style.color = '#f56c6c';
        statusBox.style.background = '#fff5f5';
        statusBox.style.border = '2px solid #f56c6c40';
    }
    
    // 填充表单
    $('#pUsername').value = u.username;
    $('#pEmail').value = u.email||'';
    
    // Token
    $('#tokenDisplay').value = localStorage.getItem('AccessToken') || u.access_token || '';
    
    // 会员中心自定义卡片
    const ucCard = u.uc_card || {};
    if (ucCard.uc_card_enabled === 1 && ucCard.uc_card_text) {
        const cardBox = $('#ucCustomCardBox');
        const cardLink = $('#ucCustomCardLink');
        const cardText = $('#ucCustomCardText');
        cardBox.style.display = '';
        cardLink.href = ucCard.uc_card_url || '#';
        cardText.textContent = ucCard.uc_card_text;
    } else {
        $('#ucCustomCardBox').style.display = 'none';
    }
}

function showNotLogin(msg) {
    $('#notLoggedIn').style.display = '';
    $('#loggedInContent').style.display = 'none';
    $('#errorArea').style.display = 'none';
    var logoutTop = $('#btnLogoutTop');
    if (logoutTop) logoutTop.style.display = 'none';
    if (msg) $('#loginTip').textContent = msg;
}

function bindUCEvents() {
    // Tab切换
    $$('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            $$('.tab-btn').forEach(b => { b.classList.remove('active'); b.style.color='var(--text-secondary)'; b.style.fontWeight='normal';});
            this.classList.add('active'); this.style.color='var(--primary)'; this.style.fontWeight='600';
            $$('.tab-panel').forEach(p=>p.style.display='none');
            $(this.dataset.tab).style.display='';
        });
    });

    $$('#authModal [data-close]').forEach(b=>b.onclick=function(){this.closest('.modal')?.close?.()});
    $('#confirmModal [data-close]')?.setAttribute('onclick', ''); // 由 showConfirm 动态绑定

    // 登录
    $('#btnDoLogin').addEventListener('click', doLogin);
    // 注册
    $('#btnDoRegister').addEventListener('click', doRegister);
    // 保存资料
    $('#btnSaveProfile').addEventListener('click', saveProfile);
    // 改密码
    $('#btnChangePwd').addEventListener('click', changePassword);
    // 复制Token
    $('#btnCopyToken').addEventListener('click', () => copyText($('#tokenDisplay').value));
    // 刷新Token
    $('#btnRefreshToken').addEventListener('click', async () => {
        const ok = await showConfirm('刷新令牌', '<p style="color:var(--danger);font-weight:600;margin-bottom:8px;">⚠ 确定要刷新令牌？</p><p style="font-size:13px;color:#999;">旧令牌将失效，新令牌将自动生成</p>');
        if (!ok) return;
        try {
            const r = await fetch(UC_AUTH_API, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'refresh_token'}) });
            const d = await r.json();
            if (d.status === 0 && d.data && d.data.access_token) {
                localStorage.setItem('AccessToken', d.data.access_token);
                $('#tokenDisplay').value = d.data.access_token;
                toast('令牌已刷新');
            } else {
                toast(d.message || '刷新失败');
            }
        } catch(e) { toast('网络错误'); }
    });

    // 反馈字数统计
    const fbTextarea = $('#fbContent');
    const fbCharCount = $('#fbCharCount');
    fbTextarea.addEventListener('input', () => {
        const len = fbTextarea.value.length;
        fbCharCount.textContent = len + '/200';
        fbCharCount.style.color = len > 180 ? '#f56c6c' : (len > 160 ? '#e6a23c' : '#999');
    });
    // 提交反馈
    $('#btnSubmitFeedback').addEventListener('click', submitFeedback);
    // 登出
    $('#btnLogout').click = async () => {
        try {
            const r = await fetch(UC_AUTH_API, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'logout'})});
            const d = await r.json().catch(() => null);
            if (d && d.data && d.data.synlogout_html) injectUcSync(d.data.synlogout_html);
        } catch (e) {}
        localStorage.removeItem('AccessToken');
        location.reload();
    };
}

window.showLoginModal = function() { $('#authModal').showModal(); };
function injectUcSync(html) {
    if (!html) return;
    const box = document.createElement('div');
    box.style.display = 'none';
    box.innerHTML = html;
    document.body.appendChild(box);
}
async function doLogout() {
    try {
        const r = await fetch(UC_AUTH_API, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'logout'})});
        const d = await r.json().catch(() => null);
        if (d && d.data && d.data.synlogout_html) injectUcSync(d.data.synlogout_html);
    } catch (e) {}
    localStorage.removeItem('AccessToken');
    location.href = '../index.php';
}

// ========== 消息反馈 ==========

async function submitFeedback() {
    const content = $('#fbContent').value.trim();
    const msgEl = $('#feedbackMsg');
    if (!content) return msgShow(msgEl, '请输入反馈内容', 'error');
    if (content.length > 200) return msgShow(msgEl, '反馈内容不能超过200字', 'error');

    const btn = $('#btnSubmitFeedback');
    btn.disabled = true;
    btn.textContent = '提交中...';

    try {
        const r = await fetch(UC_AUTH_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ action: 'submit_feedback', content })
        });
        // 先检查HTTP状态码
        if (!r.ok) {
            let errText = '';
            try { errText = await r.text(); } catch(e2) {}
            return msgShow(msgEl, '服务器错误(' + r.status + ')' + (errText ? ': ' + errText.substring(0, 100) : ''), 'error');
        }
        const d = await r.json();
        if (d.status === 0) {
            msgShow(msgEl, d.message || '提交成功！感谢您的反馈', 'success');
            $('#fbContent').value = '';
            $('#fbCharCount').textContent = '0/200';
        } else {
            msgShow(msgEl, d.message || '提交失败', 'error');
        }
    } catch (e) {
        msgShow(msgEl, '请求失败: ' + (e.message || '网络错误'), 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = '提交反馈';
    }
}

// ========== 认证操作 ==========

async function doLogin() {
    const user = $('#loginUser').value.trim(), pass = $('#loginPass').value;
    const msg = $('#loginMsg');
    if (!user || !pass) return msgShow(msg,'请填写完整','error');
    
    try {
        const r = await fetch(UC_AUTH_API, {method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({action:'login', username:user,password:pass})});
        const d = await r.json();
        if(d.status===0){
            localStorage.setItem('AccessToken', d.data.access_token);
            msgShow(msg,'登录成功！正在跳转...','success');
            setTimeout(()=>{$('#authModal')?.close?.(); checkAuth();},800);
        }else{ msgShow(msg,d.message||'登录失败','error');}
    } catch(e){ msgShow(msg,'网络错误','error'); }
}

async function doRegister() {
    const user=$('#regUser').value.trim(), email=$('#regEmail').value.trim(),
          pass=$('#regPass').value, confirm=$('#regPassConfirm').value;
    const msg = $('#regMsg');
    if(pass!==confirm) return msgShow(msg,'两次密码不一致','error');
    if(!user||!pass) return msgShow(msg,'请填写完整','error');

    try {
        const r = await fetch(UC_AUTH_API, {method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({action:'register',username:user,email,password:pass})});
        const d = await r.json();
        if(d.status===0){
            localStorage.setItem('AccessToken', d.data.access_token);
            msgShow(msg,'注册成功！','success');
            setTimeout(()=>{$('#authModal')?.close?.(); checkAuth();},800);
        }else{ msgShow(msg,d.message||'注册失败','error');}
    } catch(e){ msgShow(msg,'网络错误','error'); }
}

async function saveProfile() {
    const payload = { action:'update', username:$('#pUsername').value.trim(), email:$('#pEmail').value.trim() };
    const msg = $('#profileMsg');
    try {
        const r = await fetch(UC_AUTH_API, {method:'POST',headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
        const d = await r.json();
        if(d.status===0){ msgShow(msg,'保存成功','success'); checkAuth(); }
        else{ msgShow(msg,d.message||'保存失败','error'); }
    } catch(e){ msgShow(msg,'网络错误','error'); }
}

async function changePassword() {
    const oldP=$('#oldPwd').value, newP=$('#newPwd').value, confP=$('#confirmPwd').value;
    const msg = $('#pwdMsg');
    if(newP!==confP) return msgShow(msg,'两次密码不一致','error');
    if(newP.length<6) return msgShow(msg,'新密码至少6位','error');
    
    try {
        const r = await fetch(UC_AUTH_API, {method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({action:'update', old_password:oldP, new_password:newP})});
        const d = await r.json();
        if(d.status===0){ msgShow(msg,'密码已更改','success'); $('#oldPwd').value='';$('#newPwd').value='';$('#confirmPwd').value='';}
        else{ msgShow(msg,d.message||'失败','error'); }
    } catch(e){ msgShow(msg,'网络错误','error'); }
}

function msgShow(el,text,type){ el.textContent=text; el.className='msg-tip msg-'+type; setTimeout(()=>el.style.display='none',4000); }

function formatBytes(b){if(!b)return'0B';const u=['B','KB','MB','GB','TB'];let i=0,v=b;while(v>=1024&&i<u.length-1){v/=1024;i++;}return v.toFixed(i>1?1:0)+' '+u[i];}
function formatDur(s){if(!s)return'-';s=Number(s);if(s<60)return(s/60).toFixed(1)+'分';s/=60;if(s<60)return s.toFixed(0)+'分';s/=60;if(s<24)return s.toFixed(0)+'时';return(s/24).toFixed(0)+'天';}
function fmtShort(t){if(!t)return'-';const d=new Date(t);return`${d.getMonth()+1}-${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;}
function fmtFullDate(t){if(!t)return'-';const d=new Date(t);return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;}
function copyText(t){navigator.clipboard?.writeText(t).then(()=>toast('已复制')).catch(()=>{const ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);toast('已复制');});}
function toast(m){const e=document.createElement('div');e.textContent=m;Object.assign(e.style,{position:'fixed',top:'20px',left:'50%',transform:'translateX(-50%)',background:'rgba(86,104,238,.9)',color:'#fff',padding:'10px 24px',borderRadius:'8px',zIndex:99999});document.body.appendChild(e);setTimeout(()=>e.remove(),2000);}

// ========== 自定义确认弹窗 ==========
let _resolveConfirm = null;

function showConfirm(title, bodyHtml) {
    return new Promise(resolve => {
        _resolveConfirm = resolve;
        const modal = $('#confirmModal');
        if (!modal) { resolve(false); return; }
        $('#confirmTitle').textContent = title;
        $('#confirmBody').innerHTML = bodyHtml;
        // 显示弹窗（兼容处理）
        if (typeof modal.showModal === 'function') {
            try { modal.showModal(); } catch(e) { modal.style.display = 'flex'; }
        } else {
            modal.style.display = 'flex';
        }
        // 绑定按钮
        const doClose = function(ok) {
            return function() {
                if (typeof modal.close === 'function') modal.close();
                else modal.style.display = 'none';
                resolve(ok);
            };
        };
        $('#confirmOk').onclick = doClose(true);
        $('#confirmCancel').onclick = doClose(false);
        const closeBtn = modal.querySelector('[data-close]');
        if (closeBtn) closeBtn.onclick = doClose(false);
        modal.oncancel = function() { resolve(false); };
    });
}

// ========== 重置统计数据 ==========
async function resetStat(field) {
    const fieldName = field === 'total_bytes' ? '累计使用流量' : '累计在线时长';
    const step1 = await showConfirm('确认重置', '<p style="color:var(--danger);font-weight:600;margin-bottom:8px;">⚠ 确定要重置「' + fieldName + '」为 0 吗？</p><p style="font-size:13px;color:#999;">此操作不可恢复！</p>');
    if (!step1) return;
    const step2 = await showConfirm('再次确认', '<p style="color:var(--danger);font-weight:600;margin-bottom:8px;">🔴 请再次确认</p><p>真的要将「' + fieldName + '」归零吗？</p>');
    if (!step2) return;
    try {
        const r = await fetch(UC_AUTH_API, {method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({action:'reset_stat', field: field})});
        const d = await r.json();
        if (d && d.status === 0 || !d) {
            // 后端已执行成功或响应解析失败时，均视为成功并刷新
            toast('已重置');
            const elId = field === 'total_bytes' ? 'ucTotalBytes' : 'ucTotalTime';
            $(elId).textContent = field === 'total_bytes' ? '0B' : '0分';
        } else {
            toast(d.message || '重置失败');
        }
    } catch(e) { toast('已重置'); }
}
function $(s){return document.querySelector(s);}
function $$(s){return document.querySelectorAll(s);}
