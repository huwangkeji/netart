'use strict';
/**
 * 第三方登录（QQ / 微信扫码）前端交互
 * 依赖登录页已声明的 window.__REDIRECT__（来自 login.php）
 */
(function () {
    function getRedirect() {
        var r = (window.__REDIRECT__ && window.__REDIRECT__ !== '') ? window.__REDIRECT__ : '../index.php';
        return r;
    }

    // QQ 登录：直接跳转授权页（厂商页支持二维码扫码）
    window.doQQLogin = function () {
        var r = encodeURIComponent(getRedirect());
        window.location.href = 'oauth.php?action=qq_auth&redirect=' + r;
    };

    // 微信登录：弹出二维码（iframe 加载厂商二维码页）
    window.openWechatModal = function () {
        var modal = document.getElementById('wxLoginModal');
        if (!modal) return;
        var r = encodeURIComponent(getRedirect());
        var frame = document.getElementById('wxQrFrame');
        if (frame) frame.src = 'oauth.php?action=wx_qr&redirect=' + r;
        modal.style.display = 'flex';
    };

    window.closeWechatModal = function () {
        var modal = document.getElementById('wxLoginModal');
        if (modal) modal.style.display = 'none';
    };
})();
