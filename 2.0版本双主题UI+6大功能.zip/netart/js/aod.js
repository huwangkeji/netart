/**
 * aod.js — 共享「熄屏显示 / 息屏常亮」(AOD) 模块
 *
 * 参照 net.arsn.cn 的 screen-saver 视觉与交互实现：
 *   - 全屏纯黑叠层，居中两栏（左：品牌 / 时间 / 日期 / 设备；右：数据指标）
 *   - 点击任意处 或 按 Esc 退出（带 0.2s 淡入淡出）
 *   - 实时时钟、运行时长、电量（Wake Lock 保持亮屏）
 *   - 数据指标（总流量 / 平均速度 / 平均带宽）实时读取首页 DOM
 *
 * 同时被 index.php（首页「息屏」按钮）与 settings.php（AOD 预览）复用，
 * 暴露 window.NP_AOD = { open, close, toggle, isOpen, setBrightness }。
 */
(function () {
    'use strict';

    function $(id) { return document.getElementById(String(id).replace(/^#/, '')); }
    function p2(n) { return (n < 10 ? '0' : '') + n; }
    var WEEK = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

    var AOD = {
        el: null, tick: null, timer: null, lock: null,
        _battery: null, _batteryChecked: false,
        open: openAod, close: closeAod, toggle: toggleAod,
        isOpen: isOpen, setBrightness: setBrightness
    };

    /* ---------- DOM 构建 / 复用 ---------- */
    function defaultMarkup() {
        return '' +
            '<div class="aod-container">' +
            '  <div class="aod-left">' +
            '    <div class="aod-brand" id="aodBrand">网络面板</div>' +
            '    <div class="aod-time" id="aodTime">--:--</div>' +
            '    <div class="aod-date" id="aodDate"></div>' +
            '    <div class="aod-device">' +
            '      <span id="aodBattery">电量 --%</span>' +
            '      <span id="aodRuntime">运行 00s</span>' +
            '    </div>' +
            '  </div>' +
            '  <div class="aod-right">' +
            '    <div class="aod-stat"><span>总流量</span><strong id="aodTraffic">—</strong></div>' +
            '    <div class="aod-stat"><span>平均速度</span><strong id="aodSpeed">—</strong></div>' +
            '    <div class="aod-stat"><span>平均带宽</span><strong id="aodBandwidth">—</strong></div>' +
            '  </div>' +
            '</div>' +
            '<div class="aod-custom" id="aodCustom" style="display:none;"></div>' +
            '<div class="aod-hint">点击任意处或按 Esc 退出</div>';
    }
    function ensureEl() {
        if (AOD.el) return AOD.el;
        AOD.el = $('npAod');
        if (!AOD.el) {
            var d = document.createElement('div');
            d.id = 'npAod';
            d.setAttribute('aria-hidden', 'true');
            d.innerHTML = defaultMarkup();
            (document.body || document.documentElement).appendChild(d);
            AOD.el = d;
        }
        return AOD.el;
    }

    /* ---------- 数据刷新 ---------- */
    function setStat(targetId, srcId) {
        var t = $(targetId), s = $(srcId);
        if (t && s) {
            var v = (s.textContent || '').trim();
            t.textContent = v ? v : '—';
        }
    }
    function refreshData() {
        setStat('aodTraffic', 'allUsedValue');
        setStat('aodSpeed', 'speedValue');
        setStat('aodBandwidth', 'speedBitValue');
    }
    function updateClock() {
        var d = new Date();
        var t = $('aodTime'); if (t) t.textContent = p2(d.getHours()) + ':' + p2(d.getMinutes());
        var dt = $('aodDate');
        if (dt) dt.textContent = d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()) + ' ' + WEEK[d.getDay()];
    }
    function updateRuntime() {
        var r = $('aodRuntime'); if (!r) return;
        var s = Math.max(0, Math.floor((Date.now() - (performance.timeOrigin || Date.now())) / 1000));
        if (s < 60) r.textContent = '运行 ' + s + 's';
        else if (s < 3600) r.textContent = '运行 ' + Math.floor(s / 60) + '分' + p2(s % 60) + '秒';
        else r.textContent = '运行 ' + Math.floor(s / 3600) + '时' + p2(Math.floor((s % 3600) / 60)) + '分';
    }
    function updateBattery() {
        var b = $('aodBattery'); if (!b) return;
        if (AOD._battery) {
            var lvl = Math.round((AOD._battery.level || 0) * 100);
            b.textContent = '电量 ' + lvl + '%' + (AOD._battery.charging ? ' ⚡' : '');
        }
    }

    /* ---------- 内容可见性 ---------- */
    function show(node, on) { if (node) node.style.display = on ? '' : 'none'; }
    function applyContent(opts) {
        var el = ensureEl(); if (!el) return;
        var c = (opts && opts.content) || null;
        var timeOn = !c || c.time !== false;
        var trafficOn = !c || c.traffic !== false;
        var speedOn = !c || c.speed !== false;
        show(el.querySelector('.aod-time'), timeOn);
        show(el.querySelector('.aod-date'), timeOn);
        show(el.querySelector('.aod-device'), timeOn);
        var tr = $('aodTraffic'); if (tr) show(tr.parentNode, trafficOn);
        var sp = $('aodSpeed'); if (sp) show(sp.parentNode, speedOn);
        var bw = $('aodBandwidth'); if (bw) show(bw.parentNode, speedOn);
    }

    /* ---------- 开 / 关 ---------- */
    function openAod(opts) {
        opts = opts || {};
        var el = ensureEl(); if (!el) return;
        if (el.classList.contains('is-open')) return;

        // 关键：关闭其它可能处于「顶层（<dialog showModal> 会进入浏览器 top-layer，
        // 无视 z-index）」的弹窗，确保 AOD 始终全屏置顶、不被任何模态框穿透。
        try {
            var openDialogs = document.querySelectorAll('dialog[open]');
            for (var i = 0; i < openDialogs.length; i++) {
                if (openDialogs[i] === el) continue;
                try { openDialogs[i].close(); } catch (e) {}
            }
        } catch (e) {}

        el.classList.add('is-open');
        el.setAttribute('aria-hidden', 'false');

        // AOD 为全屏纯黑叠层，始终不透明；亮度设置不通过 opacity 模拟，避免底层页面透出

        var brand = $('aodBrand');
        if (brand && !brand.dataset.set) {
            var b = (document.querySelector('.np-brand-name') || {}).textContent;
            if (window.NPSettings && NPSettings.get && NPSettings.get().aod && NPSettings.get().aod.brand) b = NPSettings.get().aod.brand;
            brand.textContent = (b || '').trim() || '网络面板';
            brand.dataset.set = '1';
        }

        var custom = opts.custom;
        if (custom === undefined && window.NPSettings && NPSettings.get && NPSettings.get().aod && NPSettings.get().aod.content) {
            custom = NPSettings.get().aod.content.custom || '';
        }
        var ce = $('aodCustom');
        if (ce) { if (custom) { ce.textContent = custom; ce.style.display = ''; } else { ce.style.display = 'none'; } }

        applyContent(opts);
        updateClock(); updateRuntime(); refreshData(); updateBattery();

        if (AOD.tick) clearInterval(AOD.tick);
        AOD.tick = setInterval(function () { updateClock(); updateRuntime(); refreshData(); updateBattery(); }, 1000);

        requestWakeLock();
        enterFullscreenIfNeeded();
        if (opts.timeoutSec && opts.timeoutSec > 0) resetTimeout(opts.timeoutSec);

        el.addEventListener('click', onAodClick);
        document.addEventListener('keydown', onKey, true);
    }
    function onAodClick() { closeAod(); }
    function onKey(e) { if (e.key === 'Escape') closeAod(); }
    function closeAod() {
        var el = ensureEl(); if (!el) return;
        // 整体全屏模式下，先退出系统全屏（避免浏览器 UI 残留）
        exitFullscreenIfNeeded();
        el.classList.remove('is-open');
        el.setAttribute('aria-hidden', 'true');
        if (AOD.tick) { clearInterval(AOD.tick); AOD.tick = null; }
        if (AOD.timer) { clearTimeout(AOD.timer); AOD.timer = null; }
        releaseWakeLock();
        el.removeEventListener('click', onAodClick);
        document.removeEventListener('keydown', onKey, true);
    }
    function isOpen() { return !!(AOD.el && AOD.el.classList.contains('is-open')); }
    function toggleAod(opts) { if (isOpen()) closeAod(); else openAod(opts); }
    function setBrightness(v) {
        // 全屏熄屏叠层应保持不透明；亮度参数保留 API 兼容，但实际不降低 opacity
        var el = ensureEl(); if (!el) return;
        el.style.opacity = '1';
    }
    function resetTimeout(sec) {
        if (AOD.timer) clearTimeout(AOD.timer);
        AOD.timer = setTimeout(closeAod, sec * 1000);
    }

    /* ---------- 屏幕常亮锁 (Wake Lock) ---------- */
    function requestWakeLock() {
        if ('wakeLock' in navigator) {
            navigator.wakeLock.request('screen')
                .then(function (l) { AOD.lock = l; l.addEventListener('release', function () { AOD.lock = null; }); })
                .catch(function () { /* 用户拒绝或不支持：不阻断 AOD 显示 */ });
        }
    }
    function releaseWakeLock() {
        if (AOD.lock) { try { AOD.lock.release(); } catch (e) {} AOD.lock = null; }
    }

    /* ---------- 熄屏模式：网页内全屏 / 整体全屏 ---------- */
    function fsElement() {
        return document.fullscreenElement || document.webkitFullscreenElement ||
            document.mozFullScreenElement || document.msFullscreenElement || null;
    }
    function requestFs(el) {
        if (!el) return Promise.reject();
        if (el.requestFullscreen) return el.requestFullscreen();
        if (el.webkitRequestFullscreen) return el.webkitRequestFullscreen();
        if (el.mozRequestFullScreen) return el.mozRequestFullScreen();
        if (el.msRequestFullscreen) return el.msRequestFullscreen();
        return Promise.reject();
    }
    function exitFs() {
        if (!fsElement()) return Promise.resolve();
        if (document.exitFullscreen) return document.exitFullscreen();
        if (document.webkitExitFullscreen) return document.webkitExitFullscreen();
        if (document.mozCancelFullScreen) return document.mozCancelFullScreen();
        if (document.msExitFullscreen) return document.msExitFullscreen();
        return Promise.resolve();
    }
    function getAodMode() {
        try {
            if (window.NPSettings && NPSettings.get && NPSettings.get().aod) {
                return NPSettings.get().aod.mode === 'whole' ? 'whole' : 'web';
            }
        } catch (e) {}
        return 'web';
    }
    function enterFullscreenIfNeeded() {
        if (getAodMode() !== 'whole') return;
        var el = ensureEl();
        if (!el) return;
        // 必须位于用户手势调用栈内（openAod 由点击触发），否则浏览器会拒绝
        try {
            var p = requestFs(el);
            if (p && typeof p.catch === 'function') {
                p.catch(function () {
                    // 整体全屏不可用（如受限环境 / 非安全上下文）：降级为网页内全屏，不阻断 AOD 显示
                });
            }
        } catch (e) {
            // 同步异常（极少数浏览器在不允许时机调用会抛错）：忽略，保持网页内全屏
        }
    }
    function exitFullscreenIfNeeded() {
        if (fsElement()) { try { exitFs(); } catch (e) {} }
    }
    function onFsChange() {
        // 整体全屏模式下：用户退出系统全屏（Esc 或系统手势）即视为退出 AOD
        if (getAodMode() === 'whole' && !fsElement() && isOpen()) {
            closeAod();
        }
    }

    /* ---------- 电量 ---------- */
    if ('getBattery' in navigator) {
        navigator.getBattery()
            .then(function (b) { AOD._battery = b; AOD._batteryChecked = true; b.addEventListener('levelchange', updateBattery); b.addEventListener('chargingchange', updateBattery); updateBattery(); })
            .catch(function () { AOD._batteryChecked = true; });
    } else { AOD._batteryChecked = true; }

    /* ---------- 页面重新可见时恢复锁 ---------- */
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible' && isOpen() && !AOD.lock) requestWakeLock();
    });

    /* ---------- 整体全屏模式下：退出系统全屏即退出 AOD ---------- */
    document.addEventListener('fullscreenchange', onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange);
    document.addEventListener('mozfullscreenchange', onFsChange);
    document.addEventListener('MSFullscreenChange', onFsChange);

    window.NP_AOD = AOD;
})();
