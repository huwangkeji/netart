'use strict';
/**
 * 首页动态模块渲染（重要合规提示 / 公告提示）
 *
 * 设计目标：
 * 1. 后台可开关、可自定义内容；
 * 2. 内容通过 window.__HM 以 base64 形式下发，JS 解码后注入 DOM，
 *    避免静态 HTML 中的文字/类名被广告拦截或内容安全插件误伤；
 * 3. 类名避免 ad/notice/promo/banner/announcement 等敏感词。
 */
(function () {
    function escHtml(str) {
        return str.replace(/[&<>"']/g, function (m) {
            return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]);
        });
    }

    function decodeBase64(str) {
        try {
            if (typeof window.atob === 'function') {
                return binToUtf8(window.atob(str));
            }
        } catch (e) { /* fallback below */ }
        // 兼容老浏览器的 base64 -> UTF-8 polyfill
        var b64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
        var bytes = [], i = 0;
        do {
            var h1 = b64.indexOf(str.charAt(i++));
            var h2 = b64.indexOf(str.charAt(i++));
            var h3 = b64.indexOf(str.charAt(i++));
            var h4 = b64.indexOf(str.charAt(i++));
            if (h1 < 0 || h2 < 0 || h3 < 0 || h4 < 0) break;
            var bits = h1 << 18 | h2 << 12 | h3 << 6 | h4;
            bytes.push(bits >> 16 & 0xff);
            if (h3 !== 64) bytes.push(bits >> 8 & 0xff);
            if (h4 !== 64) bytes.push(bits & 0xff);
        } while (i < str.length);
        return bytesToUtf8(bytes);
    }

    function binToUtf8(bin) {
        if (typeof TextDecoder === 'function') {
            var bytes = new Uint8Array(bin.length);
            for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
            return new TextDecoder('utf-8').decode(bytes);
        }
        try { return decodeURIComponent(escape(bin)); } catch (e) { return bin; }
    }

    function bytesToUtf8(bytes) {
        if (typeof TextDecoder === 'function') {
            return new TextDecoder('utf-8').decode(new Uint8Array(bytes));
        }
        try {
            var bin = String.fromCharCode.apply(null, bytes);
            return decodeURIComponent(escape(bin));
        } catch (e) { return String.fromCharCode.apply(null, bytes); }
    }

    function renderHomeModules() {
        if (!window.__HM || !Array.isArray(window.__HM) || window.__HM.length === 0) return;

        var container = document.getElementById('hm');
        if (!container) return;

        var html = '';
        window.__HM.forEach(function (item) {
            if (!item || !item.html) return;
            var typeClass = item.type === 'cs' ? 'h-m-cs' : 'h-m-nt';
            var bg = item.bg || '';
            var content = decodeBase64(item.html);
            // 通过 CSS 变量传入自定义底色（默认留空由 .h-m-cs/.h-m-nt 类控制，兼容深色模式）
            var styleAttr = bg
                ? ' style="--hm-bg:' + escHtml(bg) + ';--hm-border:' + escHtml(bg) + ';"'
                : '';
            // 额外一层 DOM 包裹，方便样式控制与插件规避
            html += '<section class="h-m ' + typeClass + '">' +
                '<div class="h-m-i"' + styleAttr + '>' +
                content +
                '</div></section>';
        });

        if (html) {
            container.innerHTML = html;
            container.style.display = '';
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', renderHomeModules);
    } else {
        renderHomeModules();
    }
})();
