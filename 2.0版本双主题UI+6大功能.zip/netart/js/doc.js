/**
 * 文档页交互：目录滚动高亮 + 返回顶部
 */
(function () {
    'use strict';

    var backTop = document.getElementById('npBackTop');
    var links = Array.prototype.slice.call(document.querySelectorAll('#npToc a[data-toc-target]'));
    var sections = links
        .map(function (link) { return document.getElementById(link.getAttribute('data-toc-target')); })
        .filter(function (el) { return !!el; });

    function setActive(id) {
        links.forEach(function (link) {
            link.classList.toggle('is-active', link.getAttribute('data-toc-target') === id);
        });
    }

    function onScroll() {
        var offset = window.pageYOffset || document.documentElement.scrollTop;

        if (backTop) {
            backTop.classList.toggle('is-visible', offset > 320);
        }

        if (sections.length === 0) return;

        var currentId = sections[0].id;
        sections.forEach(function (section) {
            if (section.getBoundingClientRect().top <= 120) {
                currentId = section.id;
            }
        });
        setActive(currentId);
    }

    if (backTop) {
        backTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('DOMContentLoaded', onScroll);
    onScroll();
})();
