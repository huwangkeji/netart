/* ============================================================
 * settings.js — 面板设置页逻辑
 *
 * 依赖 theme.js 暴露的 window.NPSettings（配置读写 + 历史记录）。
 *
 * 纯 Web 边界（务必知晓）：
 *  - 定时测速仅在页面保持打开时运行；浏览器关闭/标签页休眠后不再执行；
 *  - 历史记录存于 localStorage（容量有限，封顶 200 条）；
 *  - AOD 仅能「保持屏幕亮起 + 全屏叠层」，屏幕真正关闭/锁屏后浏览器停止渲染，
 *    无法做到真·熄屏常亮（需桌面客户端）；
 *  - 开机自启 / 后台常驻 / 托盘 属桌面原生，UI 保存状态但功能不生效。
 * ============================================================ */
(function () {
    'use strict';

    var S = window.NPSettings;
    if (!S) { console.error('NPSettings 未加载'); return; }

    var $ = function (id) { return document.getElementById(id); };
    function toast(msg) {
        var t = $('npToast');
        if (!t) return;
        t.textContent = msg;
        t.classList.add('show');
        clearTimeout(t._t);
        t._t = setTimeout(function () { t.classList.remove('show'); }, 2600);
    }

    /* ---------- 绑定开关/输入到配置项 ---------- */
    function bindSwitch(id, path, onChange) {
        var el = $(id);
        if (!el) return;
        el.addEventListener('change', function () {
            var patch = {};
            var keys = path.split('.');
            var cur = patch;
            for (var i = 0; i < keys.length - 1; i++) { cur[keys[i]] = {}; cur = cur[keys[i]]; }
            cur[keys[keys.length - 1]] = el.checked;
            S.set(patch, { onSaved: onChange || null });
        });
    }
    function bindInput(id, path, type) {
        var el = $(id);
        if (!el) return;
        el.addEventListener('change', function () {
            var val = type === 'int' ? (parseInt(el.value, 10) || 0) : el.value;
            var patch = {};
            var keys = path.split('.');
            var cur = patch;
            for (var i = 0; i < keys.length - 1; i++) { cur[keys[i]] = {}; cur = cur[keys[i]]; }
            cur[keys[keys.length - 1]] = val;
            S.set(patch);
        });
    }

    /* ---------- 初始化控件为当前配置值 ---------- */
    function hydrate() {
        var cfg = S.get();
        $('setTheme').value = cfg.theme;
        $('setAutoTime').checked = !!cfg.autoThemeByTime;
        $('setDarkStart').value = cfg.darkStart;
        $('setDarkEnd').value = cfg.darkEnd;
        $('timeRangeRow').style.display = cfg.autoThemeByTime ? '' : 'none';

        $('setCompact').checked = !!cfg.compact;

        $('setStEnabled').checked = !!cfg.scheduledTest.enabled;
        $('setStInterval').value = cfg.scheduledTest.intervalMin;
        $('setStOnline').checked = !!cfg.scheduledTest.onlyOnline;
        $('setStHistory').checked = !!cfg.scheduledTest.saveHistory;

        $('setAodEnabled').checked = !!cfg.aod.enabled;
        $('setAodBright').value = cfg.aod.brightness;
        $('aodBrightVal').textContent = cfg.aod.brightness;
        $('setAodTimeout').value = cfg.aod.timeoutSec;
        $('setAodTime').checked = !!cfg.aod.content.time;
        $('setAodTraffic').checked = !!cfg.aod.content.traffic;
        $('setAodSpeed').checked = !!cfg.aod.content.speed;
        $('setAodCustom').value = cfg.aod.content.custom || '';

        // 熄灯模式（网页内全屏 / 整体全屏）
        var m = cfg.aod.mode || 'web';
        var aodBtns = document.querySelectorAll('#setAodMode .np-seg-btn');
        aodBtns.forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-mode') === m); });
        var ind = $('aodModeIndicator');
        if (ind) ind.textContent = '当前模式：' + (m === 'whole' ? '整体全屏' : '网页内全屏');

        // 桌面专属项：仅反映存储值（disabled，不生效）
        $('setAutoStart').checked = !!cfg.desktop.autoStart;
        $('setBackground').checked = !!cfg.desktop.backgroundResident;

        renderHistory();
        renderCfgJson();
    }

    /* ---------- 测速实现 ---------- */
    function fmtMBps(bytes, ms) {
        if (!ms) return 0;
        return (bytes * 8 / 1e6) / (ms / 1000); // Mbps
    }
    function fmtBps(bytes, ms) {
        if (!ms) return 0;
        return (bytes / 1e6) / (ms / 1000); // MB/s
    }
    function measureLatency() {
        return new Promise(function (resolve) {
            var t0 = performance.now();
            fetch('./api/speedtest.php?action=ping&_=' + Date.now(), { cache: 'no-store' })
                .then(function () { resolve(Math.round(performance.now() - t0)); })
                .catch(function () { resolve(-1); });
        });
    }
    function measureDownload(sizeMb) {
        return new Promise(function (resolve) {
            var t0 = performance.now();
            var bytes = Math.round(sizeMb * 1024 * 1024);
            fetch('./api/speedtest.php?action=download&size=' + sizeMb + '&_=' + Date.now(), { cache: 'no-store' })
                .then(function (r) { return r.blob(); })
                .then(function (b) {
                    var ms = performance.now() - t0;
                    resolve({ mbps: fmtMBps(b.size || bytes, ms), mbs: fmtBps(b.size || bytes, ms), ms: ms });
                })
                .catch(function () { resolve({ mbps: 0, mbs: 0, ms: 0, err: true }); });
        });
    }

    async function runSpeedTest() {
        var btn = $('btnRunNow');
        if (btn) { btn.disabled = true; }
        $('stStatus').textContent = '测速中…';
        // 仅联网校验（若开启）
        if (S.get().scheduledTest.onlyOnline && navigator.onLine === false) {
            $('stStatus').textContent = '离线，已跳过';
            if (btn) btn.disabled = false;
            return;
        }
        var lat = await measureLatency();
        var dl = await measureDownload(4);
        var rec = {
            ts: Date.now(),
            latency: lat,
            download: Math.round(dl.mbps * 10) / 10,
            ok: !dl.err && lat >= 0
        };
        if (S.get().scheduledTest.saveHistory) {
            S.pushHistory(rec);
        }
        S.set({ scheduledTest: { lastRun: rec.ts } });
        $('stStatus').textContent = '完成：下行 ' + rec.download + ' Mbps · 延迟 ' + lat + ' ms';
        renderHistory();
        if (btn) btn.disabled = false;
    }

    function renderHistory() {
        var box = $('stHistory');
        var arr = S.loadHistory();
        if (!arr.length) { box.innerHTML = '<div class="np-empty">暂无测速记录</div>'; return; }
        var html = '<div class="np-history-row" style="font-weight:600;color:var(--np-text-muted);">' +
            '<span>时间</span><span>下行(Mbps)</span><span>延迟(ms)</span><span>状态</span></div>';
        arr.slice(0, 50).forEach(function (r) {
            var d = new Date(r.ts);
            function p(n) { return (n < 10 ? '0' : '') + n; }
            var t = p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
            html += '<div class="np-history-row"><span>' + t + '</span><span>' + r.download +
                '</span><span>' + r.latency + '</span><span>' + (r.ok ? '正常' : '失败') + '</span></div>';
        });
        box.innerHTML = html;
    }

    /* ---------- 定时调度 ---------- */
    var stTimer = null;
    function startScheduler() {
        stopScheduler();
        if (!S.get().scheduledTest.enabled) return;
        var intervalMs = Math.max(1, S.get().scheduledTest.intervalMin) * 60 * 1000;
        // 立即跑一次（若距上次超过一个周期，避免频繁）
        var last = S.get().scheduledTest.lastRun || 0;
        if (Date.now() - last >= intervalMs) {
            setTimeout(runSpeedTest, 1500);
        }
        stTimer = setInterval(function () {
            if (document.visibilityState === 'hidden') return; // 后台标签不测，省资源
            if (S.get().scheduledTest.onlyOnline && navigator.onLine === false) return;
            runSpeedTest();
        }, intervalMs);
    }
    function stopScheduler() { if (stTimer) { clearInterval(stTimer); stTimer = null; } }

    /* ---------- AOD 控制器（委托给共享模块 js/aod.js） ---------- */
    function openAod() {
        var cfg = S.get().aod;
        if (window.NP_AOD) {
            NP_AOD.open({
                brightness: cfg.brightness,
                timeoutSec: cfg.timeoutSec,
                custom: cfg.content.custom || '',
                content: { time: true, traffic: cfg.content.traffic, speed: cfg.content.speed }
            });
        }
        var pv = $('btnAodPreview'); if (pv) pv.style.display = 'none';
        var ex = $('btnAodExit'); if (ex) ex.style.display = '';
    }
    function closeAod() {
        if (window.NP_AOD) NP_AOD.close();
        var pv = $('btnAodPreview'); if (pv) pv.style.display = '';
        var ex = $('btnAodExit'); if (ex) ex.style.display = 'none';
    }
    function applyAodBrightness(v) {
        if (window.NP_AOD && NP_AOD.isOpen && NP_AOD.isOpen()) NP_AOD.setBrightness(v);
    }

    /* ---------- 配置导入/导出/重置 ---------- */
    function renderCfgJson() {
        var ta = $('cfgJson');
        if (ta) ta.value = JSON.stringify(S.get(), null, 2);
    }
    function resetConfig() {
        try { localStorage.removeItem(S.STORAGE_KEY); } catch (e) {}
        try { localStorage.removeItem(S.HISTORY_KEY); } catch (e) {}
        location.reload();
    }

    /* ---------- 事件绑定 ---------- */
    function bind() {
        $('setTheme').addEventListener('change', function () {
            S.set({ theme: this.value });
            toast('主题已切换为：' + ({ light: '浅色', dark: '深色', system: '跟随系统' }[this.value] || this.value));
        });
        bindSwitch('setAutoTime', 'autoThemeByTime', function () {
            $('timeRangeRow').style.display = S.get().autoThemeByTime ? '' : 'none';
        });
        bindInput('setDarkStart', 'darkStart', 'str');
        bindInput('setDarkEnd', 'darkEnd', 'str');
        bindSwitch('setCompact', 'compact');

        bindSwitch('setStEnabled', 'scheduledTest.enabled', function () {
            startScheduler();
            if (S.get().scheduledTest.enabled) toast('定时测速已启用（页面打开时生效）');
        });
        bindInput('setStInterval', 'scheduledTest.intervalMin', 'int');
        bindSwitch('setStOnline', 'scheduledTest.onlyOnline');
        bindSwitch('setStHistory', 'scheduledTest.saveHistory');
        $('btnRunNow').addEventListener('click', runSpeedTest);

        bindSwitch('setAodEnabled', 'aod.enabled', function () {
            toast(S.get().aod.enabled ? 'AOD 已启用（点预览查看）' : 'AOD 已关闭');
        });
        $('setAodBright').addEventListener('input', function () {
            $('aodBrightVal').textContent = this.value;
            var patch = { aod: { brightness: parseInt(this.value, 10) } };
            S.set(patch);
            if ($('npAod').classList.contains('is-open')) applyAodBrightness(this.value);
        });
        bindInput('setAodTimeout', 'aod.timeoutSec', 'int');
        bindSwitch('setAodTime', 'aod.content.time');
        bindSwitch('setAodTraffic', 'aod.content.traffic');
        bindSwitch('setAodSpeed', 'aod.content.speed');
        $('setAodCustom').addEventListener('change', function () {
            S.set({ aod: { content: { custom: this.value } } });
        });
        $('btnAodPreview').addEventListener('click', openAod);
        $('btnAodExit').addEventListener('click', closeAod);

        // 熄灯模式切换（网页内全屏 / 整体全屏）
        document.querySelectorAll('#setAodMode .np-seg-btn').forEach(function (b) {
            b.addEventListener('click', function () {
                var mode = b.getAttribute('data-mode') || 'web';
                S.set({ aod: { mode: mode } });
                document.querySelectorAll('#setAodMode .np-seg-btn').forEach(function (x) {
                    x.classList.toggle('active', x === b);
                });
                var ind = $('aodModeIndicator');
                if (ind) ind.textContent = '当前模式：' + (mode === 'whole' ? '整体全屏' : '网页内全屏');
                toast('熄灯模式已切换为：' + (mode === 'whole' ? '整体全屏' : '网页内全屏'));
            });
        });

        // 桌面专属项（禁用态，仅保存意图）
        $('setAutoStart').addEventListener('change', function () {
            S.set({ desktop: { autoStart: this.checked } });
            toast('已记录「开机自启」偏好（需桌面客户端方可生效）');
        });
        $('setBackground').addEventListener('change', function () {
            S.set({ desktop: { backgroundResident: this.checked } });
            toast('已记录「后台常驻」偏好（需桌面客户端方可生效）');
        });

        $('btnExport').addEventListener('click', function () {
            var blob = new Blob([JSON.stringify(S.get(), null, 2)], { type: 'application/json' });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'panel-settings.json';
            a.click();
            setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
        });
        $('btnImport').addEventListener('click', function () {
            var ta = $('cfgJson');
            try {
                var obj = JSON.parse(ta.value);
                S.set(obj);
                hydrate();
                toast('已导入配置');
            } catch (e) { toast('导入失败：JSON 格式错误'); }
        });
        $('btnReset').addEventListener('click', function () {
            if (confirm('确定恢复默认设置？将清空本地配置与测速历史。')) resetConfig();
        });
    }

    /* ---------- 启动 ---------- */
    hydrate();
    bind();
    startScheduler();
    renderCfgJson();
})();
