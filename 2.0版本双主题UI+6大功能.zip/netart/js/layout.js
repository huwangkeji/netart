/**
 * 站点公共布局脚本
 *
 * 职责（与 index.php 主逻辑解耦，任何新页面引入本脚本即可获得一致体验）：
 *   1. 从后台配置加载附加导航（nav_links）
 *   2. 加载登录状态（已登录显示个人中心，管理员额外显示后台入口）
 *   3. 加载页脚设置（自定义文字、版权、ICP、自定义 HTML）
 *
 * 所有请求都做了容错：接口异常时静默降级，不影响页面主功能。
 */
(function () {
    'use strict';

    var FOOTER_API = './api/footer_settings.php';
    var AUTH_API = './api/auth.php';

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function safeJson(resp) {
        return resp.json().catch(function () { return null; });
    }

    /** 加载后台配置的顶部导航 */
    function loadNavLinks() {
        var container = document.getElementById('topNavContainer');
        if (!container) return;

        fetch(FOOTER_API)
            .then(safeJson)
            .then(function (res) {
                if (!res || res.status !== 0 || !res.data) return;

                var raw = res.data.nav_links;
                if (!raw) return;

                var links = [];
                try {
                    links = JSON.parse(raw);
                } catch (e) {
                    return;
                }
                if (!Array.isArray(links) || links.length === 0) return;

                var html = '';
                links.forEach(function (item) {
                    if (!item || !item.name) return;
                    var url = item.url || '#';
                    var target = item.target === '_blank' ? '_blank' : '_self';
                    html += '<a class="np-nav-link" href="' + escapeHtml(url) + '" target="' + target + '" rel="noopener">'
                        + escapeHtml(item.name) + '</a>';
                });
                container.innerHTML = html;
            })
            .catch(function () { /* 导航加载失败不影响主功能 */ });
    }

    /** 加载登录状态 */
    function loadAuthState() {
        var loginBtn = document.getElementById('btnLogin');
        var registerBtn = document.getElementById('btnRegister');
        var centerBtn = document.getElementById('btnUserCenter');
        var adminBtn = document.getElementById('btnAdminLink');

        fetch(AUTH_API + '?action=profile', { credentials: 'same-origin' })
            .then(safeJson)
            .then(function (res) {
                if (!res || res.status !== 0 || !res.data || !res.data.username) return;

                if (loginBtn) loginBtn.style.display = 'none';
                if (registerBtn) registerBtn.style.display = 'none';
                if (centerBtn) {
                    centerBtn.style.display = '';
                    centerBtn.textContent = res.data.username;
                    centerBtn.title = '个人中心';
                }
                if (adminBtn && (res.data.role === 'admin')) {
                    adminBtn.style.display = '';
                }
            })
            .catch(function () { /* 未登录或接口异常时保持默认展示 */ });
    }

    /** 加载页脚设置 */
    function loadFooter() {
        fetch(FOOTER_API)
            .then(safeJson)
            .then(function (res) {
                if (!res || res.status !== 0 || !res.data) return;

                var data = res.data;
                var customText = document.getElementById('footerCustomText');
                var copyright = document.getElementById('footerCopyright');
                var icp = document.getElementById('footerIcp');
                var htmlArea = document.getElementById('footerHtmlArea');

                if (customText && data.custom_text) {
                    customText.textContent = data.custom_text;
                }
                if (copyright && data.copyright) {
                    copyright.textContent = data.copyright;
                }
                if (icp && data.icp) {
                    icp.textContent = data.icp;
                    icp.href = data.icp_url || '#';
                    icp.style.display = '';
                }
                if (htmlArea && data.custom_html) {
                    htmlArea.innerHTML = data.custom_html;
                }

                /* 公告滚动条（仅首页 noticeBar 存在时渲染） */
                if (data.notices && Array.isArray(data.notices)) {
                    var bar = document.getElementById('noticeBar');
                    var inner = document.getElementById('noticeScrollInner');
                    if (bar && inner) {
                        var filtered = data.notices.filter(function (n) { return n && String(n).trim(); });
                        if (filtered.length) {
                            inner.innerHTML = filtered.map(function (item) {
                                return '<div class="notice-item">' + escapeHtml(item) + '</div>';
                            }).join('');
                            bar.style.display = '';
                            inner.style.transform = 'translateY(0)';
                            if (filtered.length > 1) {
                                var nIdx = 0;
                                if (window.__noticeTimer) clearInterval(window.__noticeTimer);
                                window.__noticeTimer = setInterval(function () {
                                    nIdx = (nIdx + 1) % filtered.length;
                                    inner.style.transform = 'translateY(-' + (nIdx * 22) + 'px)';
                                }, 5000);
                            }
                        } else {
                            bar.style.display = 'none';
                        }
                    }
                }
            })
            .catch(function () { /* 页脚加载失败保持默认内容 */ });
    }

    /**
     * 上报一次前台查询行为到「查询记录管理」。
     * 供纯前端工具（流量计算器 / 字节转换）调用；服务端查询（IP / 进阶 / 测速）已在后端直接记录。
     * 失败静默忽略，不影响主功能。
     */
    window.reportQuery = function (type, input, summary) {
        try {
            var token = '';
            try { token = localStorage.getItem('AccessToken') || ''; } catch (e) { token = ''; }
            var fd = {
                type: String(type),
                input: String(input == null ? '' : input).slice(0, 1000),
                summary: String(summary == null ? '' : summary).slice(0, 500),
                access_token: token
            };
            fetch('api/query_log.php?action=add', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(fd)
            }).catch(function () { /* 上报失败忽略 */ });
        } catch (e) { /* 忽略 */ }
    };

    document.addEventListener('DOMContentLoaded', function () {
        loadNavLinks();
        loadAuthState();
        loadFooter();
        initThemeMenu();
    });

    /** 顶部「外观」菜单：主题切换 + 紧凑排版（依赖 theme.js 的 NPSettings） */
    function initThemeMenu() {
        var S = window.NPSettings;
        var menu = document.getElementById('npThemeMenu');
        if (!menu || !S) return;
        var btn = document.getElementById('npThemeBtn');
        var pop = menu.querySelector('.np-theme-pop');

        function renderActive() {
            var t = S.get().theme;
            menu.querySelectorAll('.np-theme-item[data-theme]').forEach(function (it) {
                it.classList.toggle('is-active', it.getAttribute('data-theme') === t);
            });
            var compact = !!S.get().compact;
            var cs = document.getElementById('npCompactState');
            if (cs) cs.textContent = compact ? '开' : '关';
            var btnText = document.getElementById('npThemeBtnText');
            if (btnText) {
                var labels = { light: '浅色', dark: '深色', system: '跟随系统' };
                btnText.textContent = '外观·' + (labels[t] || '跟随系统');
            }
        }

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = menu.classList.toggle('open');
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        pop.addEventListener('click', function (e) { e.stopPropagation(); });
        document.addEventListener('click', function () { menu.classList.remove('open'); });

        menu.querySelectorAll('.np-theme-item[data-theme]').forEach(function (it) {
            it.addEventListener('click', function () {
                S.set({ theme: it.getAttribute('data-theme') });
                renderActive();
            });
        });
        var compactToggle = document.getElementById('npCompactToggle');
        if (compactToggle) {
            compactToggle.addEventListener('click', function () {
                S.set({ compact: !S.get().compact });
                renderActive();
            });
        }
        renderActive();
    }
})();
