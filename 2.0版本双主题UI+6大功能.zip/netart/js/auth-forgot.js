'use strict';
const AUTH_API = '../api/auth.php';

function doSendReset() {
    showMsg(document.getElementById('msgTip'), '该功能不可用，请联系客服', 'warning');
}
