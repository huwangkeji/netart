'use strict';
const AUTH_API = '../api/auth.php';
const REDIRECT = window.__REDIRECT__ || '../index.php';

function doLogin(mode) {
    mode = mode || 'local';
    const user = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value;
    const btn  = mode === 'uc' ? document.getElementById('btnUcLogin') : document.getElementById('btnSubmit');
    const msg  = document.getElementById('msgTip');

    if (!user || !pass) { showMsg(msg, '请填写完整信息', 'error'); return; }

    if (btn) {
        btn.disabled = true;
        const label = mode === 'uc' ? 'UCenter 登录中...' : '正在登录...';
        btn.innerHTML = '<span class="loading-icon"></span>' + label;
    }

    // local=本站优先（失败回退 UCenter）；uc=仅走 UCenter 账号登录
    const action = (mode === 'uc') ? 'uc_login' : 'login';

    fetch(AUTH_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: action, username: user, password: pass })
    })
    .then(r => r.json())
    .then(d => {
        if (d.status === 0) {
            localStorage.setItem('AccessToken', d.data.access_token);
            // UCenter 同步登录脚本：注入隐藏容器，由浏览器执行跨应用免登
            if (d.data && d.data.synlogin_html) {
                const box = document.createElement('div');
                box.style.display = 'none';
                box.innerHTML = d.data.synlogin_html;
                document.body.appendChild(box);
            }
            showMsg(msg, '登录成功！正在跳转...', 'success');
            setTimeout(() => { window.location.href = REDIRECT; }, 900);
        } else {
            showMsg(msg, d.message || '用户名或密码错误', 'error');
            resetLoginBtn(btn, mode);
        }
    })
    .catch(e => {
        showMsg(msg, '网络错误，请稍后重试', 'error');
        resetLoginBtn(btn, mode);
    });
}

/** 还原登录按钮状态与文案（区分本站 / UCenter 两种入口） */
function resetLoginBtn(btn, mode) {
    if (!btn) return;
    btn.disabled = false;
    btn.textContent = (mode === 'uc') ? 'UCenter 账号登录' : '登 录';
}

// 回车提交
document.getElementById('password').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') doLogin();
});
document.getElementById('username').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') document.getElementById('password').focus();
});
