'use strict';
const AUTH_API = '../api/auth.php';
const REDIRECT = window.__REDIRECT__ || '../index.php';

function checkPwdStrength() {
    const v  = document.getElementById('password').value;
    const el = document.getElementById('pwdStrength');
    if (v.length < 6) { el.className = 'pwd-strength'; return; }
    let s = 0;
    if (/[A-Z]/.test(v)) s++;
    if (/[0-9]/.test(v)) s++;
    if (/[^A-Za-z0-9]/.test(v)) s++;
    if (v.length >= 10) s++;
    el.className = 'pwd-strength ' + (s <= 1 ? 'weak' : s <= 2 ? 'medium' : 'strong');
}

function doRegister() {
    const user    = document.getElementById('username').value.trim();
    const email   = document.getElementById('email').value.trim();
    const pass    = document.getElementById('password').value;
    const confirm = document.getElementById('confirmPwd').value;
    const btn     = document.getElementById('btnSubmit');
    const msg     = document.getElementById('msgTip');

    if (pass !== confirm) { showMsg(msg, '两次输入的密码不一致', 'error'); document.getElementById('confirmPwd').focus(); return; }
    if (!user || pass.length < 6) { showMsg(msg, '请正确填写必填信息', 'error'); return; }

    const agreeEl = document.getElementById('agreeTerms');
    if (agreeEl && !agreeEl.checked) { showMsg(msg, '请先阅读并同意《用户协议》与《隐私政策》', 'error'); return; }

    btn.disabled = true;
    btn.innerHTML = '<span class="loading-icon"></span>正在注册...';

    fetch(AUTH_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'register', username: user, email: email, password: pass })
    })
    .then(r => r.json())
    .then(d => {
        if (d.status === 0) {
            localStorage.setItem('AccessToken', d.data.access_token);
            if (d.data && d.data.synlogin_html) {
                const box = document.createElement('div');
                box.style.display = 'none';
                box.innerHTML = d.data.synlogin_html;
                document.body.appendChild(box);
            }
            showMsg(msg, '注册成功！正在跳转...', 'success');
            setTimeout(() => { window.location.href = REDIRECT; }, 1200);
        } else {
            showMsg(msg, d.message || '注册失败，请稍后重试', 'error');
            btn.disabled = false; btn.textContent = '注 册';
        }
    })
    .catch(e => {
        showMsg(msg, '网络错误，请检查连接', 'error');
        btn.disabled = false; btn.textContent = '注 册';
    });
}
