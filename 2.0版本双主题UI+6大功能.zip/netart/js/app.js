/**
 * NetworkPanel PHP版本 - 核心JavaScript逻辑（重写架构）
 * 设计原则：
 *   1. 所有DOM操作前检查元素是否存在
 *   2. 所有异步调用独立try-catch，互不影响
 *   3. 核心功能（节点+事件）与辅助功能分离
 *   4. 防御性编程：null/undefined/类型检查
 */

// ============================================================
// 第一层：全局配置与状态（纯数据，不涉及DOM）
// ============================================================

var CONFIG = {
    API_BASE: './api/',
    LOG_INTERVAL: 60000,
    URL_RESOLVE_INTERVAL: 60000,
    FRAME_INTERVAL: 16,
    SEC_INTERVAL: 1000,
    CHART_MAX_POINTS: 200
};

var AUTH_API = './api/auth.php';

/** 应用运行状态 */
var state = {
    show: { allUsed: '-', speed: '-', speedBit: '-' },
    predict: { min: '-', hour: '-', day: '-', mon: '-' },
    isChecking: false,
    bytesUsed: 0,
    logged: 0,
    lastLogTime: 0,
    recordUse: 0,
    recordTime: 0,
    startUse: 0,
    startTime: 0,
    maxUse: 0,
    maxSpeed: 0
};

/** 运行时变量 */
var isRunning = false;
var isVisible = true;
var chartShow = false;
var threadNum = 2;
var MAX_THREAD_NUM = 16;
var autoStart = false;
var keepAlive = false;   // 后台保活开关
var currentUser = null;
var customNodes = [];
var runUrl = '';
var solvedRunUrl = '';

/** 定时器句柄数组 */
var _timers = [];
var myChart = null;
var showArray = [];
var speedTemp = [];
var stepLength = 1;

/** 公告滚动相关 */
var _noticeTimer = null;

// ============================================================
// 第二层：工具函数（纯函数，无副作用）
// ============================================================

/**
 * 安全获取DOM元素
 * @param {string} id 元素ID
 * @returns {Element|null}
 */
function $(id) {
    // 兼容 "#modalX" 与 "modalX" 两种写法：
    // 本文件内 openModal()/closeModal() 全部以 "#id" 形式传参，而 getElementById
    // 需要的是不带 "#" 的纯 id。此前未剥离 "#"，导致所有弹窗（用量预测 / 流量上限 /
    // 带宽上限 / 自定义地址 / 添加链接 / 登录注册）全部取不到元素而失效。
    return document.getElementById(String(id).replace(/^#/, ''));
}

/**
 * 安全querySelector
 * @param {string} sel 选择器
 * @returns {Element|null}
 */
function $q(sel) {
    return document.querySelector(sel);
}

/**
 * 安全querySelectorAll
 * @param {string} sel 选择器
 * @returns {NodeList}
 */
function $qa(sel) {
    return document.querySelectorAll(sel);
}

/** HTML转义（防XSS） */
function escapeHtml(str) {
    var d = document.createElement('div');
    d.textContent = str == null ? '' : String(str);
    return d.innerHTML;
}

/** HTML属性转义（防XSS，用于属性值中） */
function escapeAttr(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

/** 格式化字节数（速度用，显示 MB/s 单位） */
function formatBytes(num, decimals) {
    if (isNaN(num)) return '-';
    num = Number(num);
    if (num <= 0 && num > -1) return '0 B/s';  // 速度=0时显示"0 B/s"
    if (num < 0) return '-';
    var units = ['B', 'KB', 'MB', 'GB', 'TB'];
    var idx = 0;
    while (num >= 1024 && idx < units.length - 1) {
        num /= 1024;
        idx++;
    }
    return num.toFixed(decimals !== undefined ? decimals : 1) + units[idx];
}

/** 格式化比特数（带宽用，显示 Mbps 单位） */
function formatBits(num, decimals) {
    // 输入是 bit/s，转换为 Kbps/Mbps/Gbps
    if (isNaN(num)) return '-';
    num = Number(num);
    if (num <= 0 && num > -1) return '0 bps';  // 带宽=0时显示
    if (num < 0) return '-';
    var units = ['bps', 'Kbps', 'Mbps', 'Gbps', 'Tbps'];
    var idx = 0;
    while (num >= 1000 && idx < units.length - 1) {
        num /= 1000;
        idx++;
    }
    return num.toFixed(decimals !== undefined ? decimals : 2) + units[idx];
}

/** 格式化时长 */
function formatDuration(sec) {
    if (!sec) return '-';
    sec = Number(sec);
    if (sec < 60) return sec.toFixed(0) + '秒';
    sec /= 60;
    if (sec < 60) return sec.toFixed(0) + '分钟';
    sec /= 60;
    if (sec < 24) return sec.toFixed(0) + '小时';
    sec /= 24;
    return sec.toFixed(0) + '天';
}

/** 解析URL */
function parseUrl(str) {
    if (!str) return '';
    var m = str.match(/https?:\/\/([\w-]+\.)+[\w-]+(:[0-9]+)?(\/\S*)?/);
    return m ? m[0] : '';
}

/** 显示Toast提示 */
function showToast(msg, type) {
    var existing = $q('.toast');
    if (existing) existing.remove();

    var toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = msg;
    var colors = { error: 'rgba(245,108,108,0.9)', warning: 'rgba(230,162,60,0.9)' };
    toast.style.background = colors[type] || 'rgba(0,0,0,0.8)';
    document.body.appendChild(toast);
    setTimeout(function() { toast.remove(); }, 2500);
}
var toast = showToast;

/** 复制到剪贴板 */
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        toast('已复制');
    } catch(e) {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;top:-9999px;';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        toast('已复制');
    }
}

/** 打开弹窗 */
function openModal(id) {
    var el = $(id);
    if (el && typeof el.showModal === 'function') el.showModal();
}

/** 关闭弹窗 */
function closeModal(id) {
    var el = $(id);
    if (el && typeof el.close === 'function') el.close();
}

/**
 * 给元素绑定「点击」与「键盘激活」：
 * 概览卡片是 role="button" + tabindex="0" 的 div，只绑 click 会导致
 * 键盘用户（Enter / Space）无法触发，这里一并补齐，保证交互完整可用。
 */
function bindActivate(el, fn) {
    if (!el) return;
    el.addEventListener('click', fn);
    el.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') {
            e.preventDefault();
            fn.call(this, e);
        }
    });
}

/** 把已保存的字节/比特上限回填到弹窗输入框（按能整除的最大单位） */
function _prefillLimitInput(inputId, unitId, value, map, defaultUnit) {
    var input = $(inputId);
    var unit = $(unitId);
    if (!input || !unit) return;

    if (!value) {
        input.value = '';
        unit.value = defaultUnit;
        return;
    }

    var best = defaultUnit;
    var bestVal = value / map[defaultUnit];
    // 从大到小挑选能整除的单位，避免 1024GB 这类不直观的数字
    var order = Object.keys(map).sort(function(a, b) { return map[b] - map[a]; });
    for (var i = 0; i < order.length; i++) {
        if (value % map[order[i]] === 0) { best = order[i]; bestVal = value / map[order[i]]; break; }
    }
    input.value = bestVal;
    unit.value = best;
}

/**
 * 全局：信息面板登录按钮点击处理（内联onclick + JS绑定双重保障）
 */
window.handleInfoLoginClick = function(e) {
    if (e) e.stopPropagation();
    console.log('[Auth] handleInfoLoginClick 触发');
    // 切换到登录tab
    var panels = $qa('.auth-tab-panel');
    for (var p = 0; p < panels.length; p++) panels[p].style.display = 'none';
    var loginTabEl = $('loginTab');
    if (loginTabEl) loginTabEl.style.display = '';
    var tabs = $qa('.auth-tab');
    for (var t = 0; t < tabs.length; t++) tabs[t].classList.remove('active');
    var loginTabBtn = $('authLoginTab');
    if (loginTabBtn) loginTabBtn.classList.add('active');
    openModal('#modalAuth');
};

/**
 * 全局：信息面板注册按钮点击处理（内联onclick + JS绑定双重保障）
 */
window.handleInfoRegClick = function(e) {
    if (e) e.stopPropagation();
    console.log('[Auth] handleInfoRegClick 触发');
    // 切换到注册tab
    var panels = $qa('.auth-tab-panel');
    for (var p = 0; p < panels.length; p++) panels[p].style.display = 'none';
    var regTabEl = $('registerTab');
    if (regTabEl) regTabEl.style.display = '';
    var tabs = $qa('.auth-tab');
    for (var t = 0; t < tabs.length; t++) tabs[t].classList.remove('active');
    var regTabBtn = $('authRegTab');
    if (regTabBtn) regTabBtn.classList.add('active');
    openModal('#modalAuth');
};

// ============================================================
// 第三层：预定义节点数据
// ============================================================

var defaultNodes = {
    '运营商': {
        '咪咕视频': 'https://img.cmvideo.cn/publish/noms/2023/12/06/1O4SHFIFR36BD.gif',
        '和彩云': 'https://img.mcloud.139.com/material_prod/material_media/20221128/1669626861087.png',
        '联通电视': 'NetworkPanelApi://listen.10155.com',
        '天翼云桌面': 'https://desk.ctyun.cn:8999/desktop-prod/software/windows_tob_client/15/64/202030001/CtyunClouddeskUniversal_2.3.0_20240327104015_Setup.exe'
    },
    '全球[Global]': {
        'Cachefly': 'https://web1.cachefly.net/speedtest/downloading',
        'Cloudflare Speed': 'https://speed.cloudflare.com/__down?bytes=99614720',
        'Steam Akamai': 'https://cdn.akamai.steamstatic.com/steam/apps/1063730/extras/NW_Sword_Sorcery_2.gif',
        'Steam Cloudflare': 'https://cdn.cloudflare.steamstatic.com/steam/apps/1063730/extras/NW_Sword_Sorcery_2.gif',
        'Microsoft Akamai': 'https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageFileData/RW16Ptm'
    }
};

// ============================================================
// 第四层：初始化入口（顶层错误兜底）
// ============================================================

document.addEventListener('DOMContentLoaded', function() {
    try {
        // 读取localStorage配置
        _loadLocalConfig();

        // 核心：必须成功
        initNodes();
        bindAllEvents();

        // 辅助功能：独立try-catch
        _safeRun(initChart, '图表初始化');
        _safeRun(fetchIPInfo, 'IP查询');
        _safeRun(loadIpSources, 'IP数据源');
        _safeRun(checkAuthStatus, '登录状态');
        _safeRun(initInfoPanel, '信息面板');
        if (!window.__NP_LAYOUT) _safeRun(loadTopNav, '顶部导航');
        _safeRun(loadFriendLinks, '友情链接');
        if (!window.__NP_LAYOUT) _safeRun(loadFooterSettings, '底部设置');
        _safeRun(initAnnouncementPopup, '公告弹窗');
        _safeRun(loadAds, '广告区块');

        // 自动运行（延迟1秒确保页面完全加载）
        if (autoStart) {
            setTimeout(function() {
                console.log('[NetworkPanel] 自动运行触发');
                tryStart();
            }, 1000);
        }

        console.log('[NetworkPanel] 初始化完成');
    } catch(err) {
        console.error('[NetworkPanel] 致命错误:', err);

        // 兜底：至少保证节点和事件可用
        try { initNodes(); } catch(e) {}
        try { bindAllEvents(); } catch(e) {}
    }
});

/** 安全执行函数 */
function _safeRun(fn, label) {
    try { fn(); } catch(e) { console.error('[NetworkPanel] ' + label + ' 失败:', e); }
}

/** 从localStorage加载用户配置 */
function _loadLocalConfig() {
    try {
        customNodes = JSON.parse(localStorage.getItem('customNodes') || '[]');
        runUrl = localStorage.getItem('url') || '';
        chartShow = localStorage.getItem('chartShow') === 'true';
        threadNum = Math.max(1, Math.min(MAX_THREAD_NUM, parseInt(localStorage.getItem('threadNum')) || 2));
        autoStart = localStorage.getItem('autoStart') === 'true';
        keepAlive = localStorage.getItem('keepAlive') === 'true';
        state.maxUse = parseInt(localStorage.getItem('maxUse')) || 0;
        state.maxSpeed = parseInt(localStorage.getItem('maxSpeed')) || 0;
    } catch(e) {
        customNodes = [];
    }
}

// ============================================================
// 第五层：核心功能 - 节点管理
// ============================================================

/** 初始化节点下拉列表（核心功能） */
function initNodes() {
    var select = $('urlSelect');
    if (!select) {
        console.error('[NetworkPanel] #urlSelect 不存在!');
        return;
    }
    select.innerHTML = '';

    // 先异步从后台加载节点，成功后渲染；失败则用本地默认兜底
    _loadServerNodes(select);
}

/** 从后台API加载管理员配置的节点 */
async function _loadServerNodes(selectEl) {
    try {
        var resp = await fetch(CONFIG.API_BASE + 'nodes.php');
        var data = await resp.json();
        if (data.status === 0 && data.data && data.data.length > 0) {
            // 用 Set 去重（按 URL）
            var seenUrls = new Set();
            var groups = {};
            data.data.forEach(function(node) {
                var url = node.url || '';
                if (!url || seenUrls.has(url)) return;
                seenUrls.add(url);
                var grp = node.group_name || '官方测速';
                if (!groups[grp]) groups[grp] = [];
                groups[grp].push({name: node.label || '未命名', url: url});
            });

            // 渲染后台节点
            for (var gn in groups) {
                var og = document.createElement('optgroup');
                og.label = gn;
                groups[gn].forEach(function(n) {
                    var op = document.createElement('option');
                    op.value = n.url; op.textContent = n.name;
                    og.appendChild(op);
                });
                selectEl.appendChild(og);
            }

            // 追加用户自定义节点（去重）
            _appendCustomNodes(selectEl, seenUrls);

            // 追加预设默认节点（仅未被覆盖的）
            _appendDefaultNodes(selectEl, seenUrls);

            // 设置选中项
            if (!runUrl && selectEl.options.length > 0) runUrl = selectEl.options[0].value;
            selectEl.value = runUrl;
            return;
        }
    } catch(e) { console.warn('[NetworkPanel] 后台节点加载失败:', e); }

    // 兜底：使用本地默认 + 自定义
    _renderLocalFallback(selectEl);
}

/** 追加自定义节点（localStorage），自动跳过已存在的URL */
function _appendCustomNodes(sel, seen) {
    if (!customNodes || !customNodes.length) return;
    var hasAny = false;
    customNodes.forEach(function(n) {
        if (!n.url || seen.has(n.url)) return;
        seen.add(n.url); hasAny = true;
        var o = document.createElement('option');
        o.value = n.url; o.textContent = n.label || '未命名';
        sel.appendChild(o);
    });
    if (hasAny) {
        // 包裹到 optgroup 中：把最后一个 option 之前的非 optgroup 子元素归入"自定义"
        // 简化处理：直接追加一个独立分组标记
    }
}

/** 追加预设默认节点（仅未被覆盖的URL） */
function _appendDefaultNodes(sel, seen) {
    for (var groupName in defaultNodes) {
        var g = document.createElement('optgroup');
        g.label = groupName;
        var data = defaultNodes[groupName];
        var hasChild = false;
        for (var name in data) {
            if (seen.has(data[name])) continue;
            seen.add(data[name]); hasChild = true;
            var o = document.createElement('option');
            o.value = data[name]; o.textContent = name;
            g.appendChild(o);
        }
        if (hasChild) sel.appendChild(g);
    }
}

/** 兜底：无后台数据时使用本地默认+自定义 */
function _renderLocalFallback(selectEl) {
    var firstUrl = '';
    if (customNodes && customNodes.length > 0) {
        var group = document.createElement('optgroup'); group.label = '自定义';
        for (var i = 0; i < customNodes.length; i++) {
            var node = customNodes[i]; var opt = document.createElement('option');
            opt.value = node.url || ''; opt.textContent = node.label || '未命名';
            group.appendChild(opt); if (!firstUrl && node.url) firstUrl = node.url;
        }
        selectEl.appendChild(group);
    }
    for (var groupName in defaultNodes) {
        var g = document.createElement('optgroup'); g.label = groupName;
        var data = defaultNodes[groupName];
        for (var name in data) {
            var o = document.createElement('option'); o.value = data[name]; o.textContent = name;
            g.appendChild(o); if (!firstUrl) firstUrl = data[name];
        }
        selectEl.appendChild(g);
    }
    if (!runUrl && firstUrl) runUrl = firstUrl;
    selectEl.value = runUrl;
}

/** 保存自定义节点到localStorage */
function saveCustomNodes() {
    try {
        localStorage.setItem('customNodes', JSON.stringify(customNodes));
    } catch(e) {}
    initNodes();
}

/** 渲染自定义节点列表UI */
function renderCustomNodeList() {
    var container = $('customNodesList');
    if (!container) return;

    if (!customNodes || customNodes.length === 0) {
        container.innerHTML = '<div style="text-align:center;padding:16px;color:#bbb;">没有自定义地址</div>';
        return;
    }

    var html = '';
    for (var i = 0; i < customNodes.length; i++) {
        var n = customNodes[i];
        html += '<div class="node-list-item">' +
            '<span class="node-name">' + escapeHtml(n.label) + '</span>' +
            '<span class="node-url">' + escapeHtml(n.url) + '</span>' +
            '<button class="delete-node-btn" data-index="' + i + '" title="删除">&times;</button>' +
            '</div>';
    }
    container.innerHTML = html;

    // 绑定删除事件
    var btns = container.querySelectorAll('.delete-node-btn');
    for (var j = 0; j < btns.length; j++) {
        (function(btn) {
            btn.addEventListener('click', function() {
                var idx = parseInt(this.getAttribute('data-index'));
                if (!isNaN(idx)) {
                    customNodes.splice(idx, 1);
                    saveCustomNodes();
                    renderCustomNodeList();
                }
            });
        })(btns[j]);
    }
}

/** 确认添加节点 */
function confirmAddNode() {
    var nameInput = $('nodeName');
    var urlInput = $('nodeUrl');
    if (!nameInput || !urlInput) return;

    var label = nameInput.value.trim();
    var url = parseUrl(urlInput.value.trim());

    if (!label || !url) {
        toast('请填写完整信息', 'error');
        return;
    }

    customNodes.push({ label: label, url: url });
    saveCustomNodes();
    renderCustomNodeList();

    nameInput.value = '';
    urlInput.value = '';
    closeModal('#modalAddNode');
}

// ============================================================
// 第六层：核心功能 - 事件绑定
// ============================================================

/** 绑定所有事件（核心功能，必须成功） */
function bindAllEvents() {
    // ---- 测速控制 ----
    var playBtn = $('btnPlay');
    if (playBtn) playBtn.addEventListener('click', tryStart);

    var stopBtn = $('btnStop');
    if (stopBtn) stopBtn.addEventListener('click', stopTest);

    // ---- 控制台工具网格：排行榜 / 息屏 / 用户 / 设置 ----
    var toolRank = $('btnToolRank');
    if (toolRank) toolRank.addEventListener('click', function () { openModal('#modalRank'); });
    var toolAod = $('btnToolAod');
    if (toolAod) toolAod.addEventListener('click', function () { if (window.NP_AOD) window.NP_AOD.open(); });

    // ---- URL选择 ----
    var urlSelect = $('urlSelect');
    if (urlSelect) {
        urlSelect.addEventListener('change', function() {
            // 运行中禁止切换节点
            if (isRunning || state.isChecking) {
                // 恢复之前的值
                this.value = runUrl;
                showToast(isRunning ? '请先停止测速后再切换节点' : '正在启动中，请稍候...', 'warning');
                return;
            }
            runUrl = this.value;
            localStorage.setItem('url', runUrl);
        });
    }

    // ---- 线程滑块 ----
    var slider = $('threadSlider');
    var threadLabel = $('threadNumLabel');
    if (slider) {
        // 初始化：同步localStorage值到slider（关键！否则进度条不同步）
        slider.value = threadNum;
        slider.style.setProperty('--val', threadNum);
        slider.dataset.prev = threadNum;

        slider.addEventListener('input', function() {
            threadNum = Math.max(1, Math.min(MAX_THREAD_NUM, parseInt(this.value) || 2));
            this.value = threadNum;
            if (threadLabel) threadLabel.textContent = threadNum;
            this.style.setProperty('--val', threadNum);
            localStorage.setItem('threadNum', threadNum);

            // 运行中增加线程
            if (isRunning) {
                var oldVal = Math.max(1, Math.min(MAX_THREAD_NUM, parseInt(this.dataset.prev) || threadNum));
                if (threadNum > oldVal) {
                    for (var k = oldVal; k < threadNum; k++) startThread(k);
                }
            }
            this.dataset.prev = threadNum;
        });
        slider.style.setProperty('--val', threadNum);
        slider.dataset.prev = threadNum;
    }

    // ---- 复制URL ----
    var copyBtn = $('btnCopyUrl');
    if (copyBtn) copyBtn.addEventListener('click', copyCurrentUrl);

    // ---- 编辑节点按钮 ----
    var editNodesBtn = $('btnEditNodes');
    bindActivate(editNodesBtn, function() {
        openModal('#modalCustomNodes');
        renderCustomNodeList();
    });

    var addNodeBtn = $('btnAddNode');
    bindActivate(addNodeBtn, function() {
        openModal('#modalAddNode');
    });

    var confirmAddBtn = $('btnConfirmAdd');
    if (confirmAddBtn) confirmAddBtn.addEventListener('click', confirmAddNode);

    // ---- 流量上限：点击概览卡片打开设置弹窗，并把当前值回填到输入框 ----
    var editMaxBtn = $('btnEditMax');
    bindActivate(editMaxBtn, function() {
        _prefillLimitInput('maxUseInput', 'maxUseUnit', state.maxUse, { MB: 1048576, GB: 1073741824, TB: 1099511627776 }, 'GB');
        openModal('#modalMaxUse');
    });
    var confirmMaxBtn = $('btnConfirmMaxUse');
    if (confirmMaxBtn) confirmMaxBtn.addEventListener('click', editMaxUse);

    // ---- 带宽上限：同上 ----
    var editSpeedBtn = $('btnEditSpeed');
    bindActivate(editSpeedBtn, function() {
        _prefillLimitInput('maxSpeedInput', 'maxSpeedUnit', state.maxSpeed, { Kbps: 1024, Mbps: 1048576, Gbps: 1073741824 }, 'Mbps');
        openModal('#modalMaxSpeed');
    });
    var confirmSpeedBtn = $('btnConfirmMaxSpeed');
    if (confirmSpeedBtn) confirmSpeedBtn.addEventListener('click', editMaxSpeed);

    // ---- 用量预测：无采样数据时给出明确提示 ----
    var predictBtn = $('btnPredict');
    bindActivate(predictBtn, function() {
        var hasData = state.predict.min && state.predict.min !== '-';
        var tip = $('predictTip');
        if (tip) tip.style.display = hasData ? 'none' : '';
        openModal('#modalPredict');
    });

    // ---- IP 信息：重新检测 ----
    var refreshIpBtn = $('btnRefreshIp');
    if (refreshIpBtn) refreshIpBtn.addEventListener('click', function() {
        if (this.disabled) return;
        this.disabled = true;
        fetchIPInfo().then(function() { refreshIpBtn.disabled = false; },
                          function() { refreshIpBtn.disabled = false; });
    });

    // ---- IP 信息：数据源下拉切换 ----
    bindIpSourceSelector();

    // ---- 自动运行开关 ----
    var autoSwitch = $('switchAutoStart');
    if (autoSwitch) {
        autoSwitch.checked = autoStart;
        autoSwitch.addEventListener('change', function() {
            autoStart = this.checked;
            localStorage.setItem('autoStart', autoStart ? 'true' : 'false');
        });
    }

    // ---- 后台保活开关 ----
    var keepAliveSwitch = $('switchKeepAlive');
    if (keepAliveSwitch) {
        keepAliveSwitch.checked = keepAlive;
        keepAliveSwitch.addEventListener('change', function() {
            keepAlive = this.checked;
            localStorage.setItem('keepAlive', keepAlive ? 'true' : 'false');
            if (keepAlive && isRunning) {
                showToast('后台保活已开启，切换标签页不会中断测速', 'success');
            }
        });
    }

    // ---- 找回密码按钮 ----
    var sendResetBtn = $('btnSendReset');
    if (sendResetBtn) sendResetBtn.addEventListener('click', handleSendReset);

    // ---- 限额管理 ----
    initTrafficLimit();

    // ---- 顶部导航由 loadTopNav 动态加载（后台可配置） ----

    var searchIp = $('btnSearchIp');
    if (searchIp) searchIp.addEventListener('click', fetchIPInfo);

    // ---- 弹窗关闭按钮 ----
    var closeBtns = $qa('[data-close]');
    for (var ci = 0; ci < closeBtns.length; ci++) {
        (function(btn) {
            btn.addEventListener('click', function() {
                var modal = this.closest('.modal');
                if (modal && typeof modal.close === 'function') modal.close();
            });
        })(closeBtns[ci]);
    }

    // ---- 用户中心（现为<a>标签，无需JS绑定） ----

    // ---- 认证相关 ----
    bindAuthEvents();

    // ---- 排行榜筛选 ----
    var sortByRadios = $qa('[name="sortBy"]');
    for (var si = 0; si < sortByRadios.length; si++) {
        sortByRadios[si].addEventListener('change', refreshRank);
    }
    var gradeRadios = $qa('[name="grade"]');
    for (var gi = 0; gi < gradeRadios.length; gi++) {
        gradeRadios[gi].addEventListener('change', refreshRank);
    }
    var pastCheck = $('isPast');
    if (pastCheck) pastCheck.addEventListener('change', refreshRank);

    // ---- 全屏覆盖层点击退出 ----
    var fsOverlay = $('fullscreenOverlay');
    if (fsOverlay) fsOverlay.addEventListener('click', function() {
        this.style.display = 'none';
        clearInterval(this._clockTask);
    });

    // ---- Android检测 ----
    if (/Android/i.test(navigator.userAgent)) {
        var appBtn = $('btnApp');
        if (appBtn) appBtn.style.display = '';
    }

    // ---- 粘贴监听 ----
    window.addEventListener('handlePasteEvent', handlePaste);
    window.addEventListener('paste', handlePaste);

    // ---- 可见性变化 ----
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // 初始化显示限额/带宽
    updateMaxUseDisplay();
    updateMaxSpeedDisplay();
}

// ============================================================
// 第七层：测速引擎
// ============================================================

async function tryStart() {
    if (!runUrl) {
        showToast('请先选择测速地址', 'error');
        return;
    }
    if (isRunning || state.isChecking) return;

    // 检查用户账号状态：如果已登录但账号被禁用，阻止测速
    if (currentUser && (currentUser.status === 0 || currentUser.status === '0')) {
        showDisabledAccountModal();
        return;
    }

    // NetworkPanel协议直接启动
    if (runUrl.indexOf('NetworkPanelApi://') === 0) {
        startTest();
        return;
    }

    // 先检查URL可用性（finally确保状态一定重置）
    state.isChecking = true;
    updatePlayButtonUI('loading');

    try {
        var status = await checkUrl(runUrl);

        if (status.status) {
            startTest();
        } else {
            showToast(status.info || '地址不可用', 'error');
            updatePlayButtonUI('play');
        }
    } catch(e) {
        console.error('[NetworkPanel] URL检查异常:', e);
        showToast('地址检查失败，请重试', 'error');
        updatePlayButtonUI('play');
    } finally {
        state.isChecking = false;
    }
}

async function startTest() {
    if (isRunning) return;
    isRunning = true;

    clearChartData();
    state.isChecking = true;
    await apiSolver(false);
    state.isChecking = false;

    if (!isRunning) return;
    if (!solvedRunUrl) {
        showToast('无法解析测速地址，请重试', 'error');
        isRunning = false;
        updatePlayButtonUI('play');
        return;
    }

    // 重置流量计数
    if (state.maxUse && state.bytesUsed >= state.maxUse) {
        state.bytesUsed = 0;
        state.logged = 0;
    }

    state.lastLogTime = Date.now() / 1000;
    state.startUse = state.bytesUsed;
    state.startTime = Date.now() / 1000;
    state.recordUse = state.bytesUsed;
    state.recordTime = Date.now() / 1000;

    updatePlayButtonUI('stop');
    var speedLabel = $('speedLabel');
    if (speedLabel) speedLabel.textContent = '实时速度';

    // 启动线程
    for (var t = 0; t < threadNum; t++) startThread(t);

    // 启动定时器
    _timers.push(setInterval(frameEvent, CONFIG.FRAME_INTERVAL));
    _timers.push(setInterval(uploadLog, CONFIG.LOG_INTERVAL));
    _timers.push(setInterval(function() { apiSolver(true); }, CONFIG.URL_RESOLVE_INTERVAL));
    secEvent();
    _timers.push(setInterval(secEvent, CONFIG.SEC_INTERVAL));
}

function stopTest() {
    isRunning = false;
    state.isChecking = false;  // 确保停止后可以重新启动

    // 清除定时器
    for (var i = 0; i < _timers.length; i++) {
        clearInterval(_timers[i]);
    }
    _timers = [];

    uploadLog();

    var elapsed = Date.now() / 1000 - state.startTime;
    var speed = elapsed > 0 ? (state.bytesUsed - state.startUse) / elapsed : 0;
    setSpeedDisplay(speed);
    setUsedDisplay();

    updatePlayButtonUI('play');
    var speedLabel = $('speedLabel');
    if (speedLabel) speedLabel.textContent = '平均速度';

    if (!isVisible) updateTitle(0);

    console.log('[NetworkPanel] 已停止, isRunning=' + isRunning + ' isChecking=' + state.isChecking);
}

var solvedRunUrl = '';

async function apiSolver(isRefresh) {
    if (runUrl.indexOf('NetworkPanelApi://') !== 0) {
        solvedRunUrl = runUrl;
        return;
    }

    var host = runUrl.split('NetworkPanelApi://')[1];
    try {
        var resp = await fetch(CONFIG.API_BASE + 'url_resolve.php?host=' + encodeURIComponent(host), {
            mode: 'cors', redirect: 'follow', referrerPolicy: 'no-referrer'
        });
        var data = await resp.json();
        if (data.status !== 0) {
            isRunning = false;
            updatePlayButtonUI('play');
            showToast(data.message || '节点解析失败', 'error');
            return;
        }
        solvedRunUrl = data.url;
    } catch(e) {
        console.error('API solver error:', e);
        if (!isRefresh) {
            isRunning = false;
            updatePlayButtonUI('play');
            showToast('网络请求失败', 'error');
        }
    }
}

async function startThread(index) {
    if (!solvedRunUrl) { isRunning = false; return; }

    var _url = solvedRunUrl;
    try {
        var response = await fetch(_url, {
            cache: 'no-store', mode: 'cors', referrerPolicy: 'no-referrer'
        });

        if (!response.body) throw new Error('No body');

        var contentLength = response.headers.get('content-length');
        var realLength = contentLength ? parseInt(contentLength) : Infinity;
        var reader = response.body.getReader();
        var decodeLength = 0;

        while (true) {
            // 限速控制
            if (state.maxSpeed) await speedControl();

            var result = await reader.read();
            var chunkLength = (result && result.value) ? result.value.length : 0;

            if (!chunkLength || solvedRunUrl !== _url) {
                startThread(index);
                break;
            }

            var usefulChunkLength = chunkLength;
            if (decodeLength >= realLength) {
                usefulChunkLength = 0;
            } else if (decodeLength + chunkLength > realLength) {
                usefulChunkLength = realLength - decodeLength;
            }

            state.bytesUsed += usefulChunkLength;

            if (index >= threadNum || !isRunning) break;
            decodeLength += chunkLength;
        }
        reader.cancel();
    } catch(err) {
        console.log('Thread error:', err);
        if (isRunning) startThread(index);
    }
}

function speedControl() {
    var diff = state.bytesUsed - state.recordUse;
    var limitPerSecond = state.maxSpeed / 8;
    if (diff > limitPerSecond) {
        return new Promise(function(resolve) {
            setTimeout(resolve, 1000 - (Date.now() % 1000));
        });
    }
    return Promise.resolve();
}

// ---- 数据更新 ----

function frameEvent() {
    if (isVisible) setUsedDisplay();

    // 检查流量限额
    if (state.maxUse && state.bytesUsed >= state.maxUse) {
        showToast('已达限额 ' + formatBytes(state.maxUse, 0) + '，自动停止', 'success');
        stopTest();
    }
}

function secEvent() {
    var now = Date.now() / 1000;
    var elapsed = now - state.recordTime;
    var speed = elapsed > 0 ? (state.bytesUsed - state.recordUse) / elapsed : 0;

    updateChart(speed);

    // 始终更新显示（即使是0也要显示，不要显示"-"）
    if (!isNaN(speed) && isVisible) {
        setSpeedDisplay(speed);
    } else if (!isNaN(speed)) {
        updateTitle(speed);
    }

    state.recordUse = state.bytesUsed;
    state.recordTime = now;
}

function setUsedDisplay() {
    state.show.allUsed = formatBytes(state.bytesUsed, 0);

    var el = $('allUsedValue');
    if (el) el.textContent = state.show.allUsed;

    var fsEl = $('fsAllUsed');
    if (fsEl) fsEl.textContent = state.show.allUsed;
}

function setSpeedDisplay(speed) {
    state.show.speed = formatBytes(speed, 1);
    state.show.speedBit = formatBits(speed * 8, 2);

    state.predict.min = formatBytes(speed * 60, 0);
    state.predict.hour = formatBytes(speed * 3600, 0);
    state.predict.day = formatBytes(speed * 86400, 0);
    state.predict.mon = formatBytes(speed * 2592000, 0);

    var els = {
        predictMin: state.predict.min,
        predictHour: state.predict.hour,
        predictDay: state.predict.day,
        predictMon: state.predict.mon,
        speedValue: state.show.speed,
        speedBitValue: state.show.speedBit,
        fsSpeed: state.show.speed,
        fsSpeedBit: state.show.speedBit
    };

    for (var id in els) {
        var el = $(id);
        if (el) el.textContent = els[id];
    }

    var fsLabel = $('fsSpeedLabel');
    if (fsLabel) fsLabel.textContent = isRunning ? '实时速度' : '平均速度';

    var fsBandwidthLabel = $('fsBandwidthLabel');
    if (fsBandwidthLabel) fsBandwidthLabel.textContent = isRunning ? '实时带宽' : '平均带宽';
}

// 保存页面初始标题（由PHP从数据库设置）
var _originalTitle = document.title;

function updateTitle(speed) {
    if (isVisible) {
        document.title = _originalTitle;
    } else if (isRunning) {
        document.title = formatBytes(state.bytesUsed, 0) + ' ' + formatBytes(speed, 1);
    } else if (state.maxUse && state.bytesUsed >= state.maxUse) {
        document.title = '已完成';
    } else {
        document.title = '已暂停';
    }
}

function updatePlayButtonUI(mode) {
    var playBtn = $('btnPlay');
    var stopBtn = $('btnStop');
    var spinner = $('loadingSpinner');
    var urlSelect = $('urlSelect');

    if (playBtn) playBtn.style.display = (mode === 'play' || mode === 'loading') ? '' : 'none';
    if (stopBtn) stopBtn.style.display = mode === 'stop' ? '' : 'none';
    if (spinner) spinner.style.display = mode === 'loading' ? '' : 'none';

    // 启动中状态：按钮禁用 + 文案变化
    if (playBtn) {
        playBtn.disabled = (mode === 'loading');
        if (mode === 'loading') {
            playBtn.textContent = '启动中...';
            playBtn.style.opacity = '0.6';
            playBtn.style.cursor = 'not-allowed';
        } else {
            playBtn.textContent = '开始测速';
            playBtn.style.opacity = '';
            playBtn.style.cursor = '';
        }
    }

    // 运行中禁用节点选择
    if (urlSelect) {
        urlSelect.disabled = (mode === 'stop' || mode === 'loading');
        urlSelect.style.opacity = (mode === 'stop' || mode === 'loading') ? '0.5' : '';
        urlSelect.style.cursor = (mode === 'stop' || mode === 'loading') ? 'not-allowed' : '';
    }
}

// ============================================================
// 第八层：ECharts图表
// ============================================================

/**
 * 图表状态提示：'loading' 加载中 / 'empty' 暂无数据 / 'error' 组件或接口异常
 * 空态与异常态必须给出明确文案，避免出现"空白大框"让人误以为页面坏了。
 */
function setChartState(kind, text) {
    var stateEl = $('chartState');
    var chipText = $('chartChipText');
    var chipDot = $('chartChipDot');

    var texts = {
        loading: '图表加载中…',
        empty: '暂无数据，点击上方「开始测速」后显示实时速度曲线',
        error: text || '图表组件加载失败，请刷新页面重试'
    };
    var chipLabels = { loading: '加载中', empty: '等待数据', error: '不可用' };

    if (stateEl) {
        stateEl.textContent = texts[kind] || texts.empty;
        stateEl.style.display = (kind === 'empty' || kind === 'error') ? '' : 'none';
        stateEl.classList.toggle('is-error', kind === 'error');
    }
    if (chipText) chipText.textContent = chipLabels[kind] || chipLabels.empty;
    if (chipDot) {
        chipDot.classList.toggle('is-err', kind === 'error');
        chipDot.classList.toggle('is-ok', kind === 'loading');
    }
}

function initChart() {
    var container = $('chartContainer');
    if (!container) return;

    setChartState('loading');

    if (typeof echarts === 'undefined') {
        // 运行时缺失：明确报错，而不是留一个空白容器
        chartShow = false;
        setChartState('error', '图表组件（ECharts）未加载，请检查 public/echarts.min.js 是否可访问');
        console.error('[NetworkPanel] ECharts 未加载，图表不可用');
        return;
    }

    myChart = echarts.init(container);

    myChart.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(255,255,255,0.96)',
            borderColor: '#e8e8e8',
            borderWidth: 1,
            textStyle: { color: '#333', fontSize: 12 },
            formatter: function(params) {
                if (!params || !params.length) return '';
                var d = params[0];
                var time = new Date(d.data[0] * 1000);
                var tStr = time.getHours().toString().padStart(2,'0') + ':' + time.getMinutes().toString().padStart(2,'0') + ':' + time.getSeconds().toString().padStart(2,'0');
                return '<div style="font-weight:600;margin-bottom:4px;">' + tStr + '</div>' +
                    '<div>速度: <span style="color:#5668EE;font-weight:600;">' + formatBytes(d.data[1], 2) + '</span></div>';
            },
            axisPointer: { type: 'line', lineStyle: { color: '#5668EE', width: 1, type: 'dashed' } }
        },
        toolbox: {
            show: true,
            right: 10,
            top: 0,
            feature: {
                saveAsImage: {
                    title: '保存图片',
                    pixelRatio: 2,
                    backgroundColor: '#fff'
                }
            }
        },
        grid: {
            left: 50,
            right: 15,
            top: 30,
            bottom: 25,
            containLabel: false
        },
        xAxis: {
            type: 'time',
            boundaryGap: false,
            axisLabel: {
                show: true,
                color: '#999',
                fontSize: 11,
                formatter: function(v) {
                    var d = new Date(v);
                    return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
                }
            },
            axisLine: { lineStyle: { color: '#eee' } },
            axisTick: { show: false },
            splitLine: { show: false }
        },
        yAxis: {
            type: 'value',
            min: function(value) { return value.min > 0 ? 0 : value.min; },
            axisLabel: {
                color: '#999',
                fontSize: 11,
                formatter: function(v) {
                    if (v <= 0) return '0';
                    // 只在较大值时显示单位，避免"1B/s"
                    if (v >= 1073741824) return (v / 1073741824).toFixed(1) + ' GB';
                    if (v >= 1048576) return (v / 1048576).toFixed(v >= 104857600 ? 0 : 1) + ' MB';
                    if (v >= 1024) return (v / 1024).toFixed(0) + ' KB';
                    return v.toFixed(0);
                }
            },
            axisLine: { show: false },
            axisTick: { show: false },
            splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } }
        },
        series: [{
            name: '速度',
            type: 'line',
            smooth: 0.3,
            symbol: 'none',
            sampling: 'lttb',
            lineStyle: {
                width: 2.5,
                color: '#5668EE'
            },
            areaStyle: {
                color: {
                    type: 'linear',
                    x: 0, y: 0, x2: 0, y2: 1,
                    colorStops: [
                        { offset: 0, color: 'rgba(86,104,238,0.35)' },
                        { offset: 0.5, color: 'rgba(86,104,238,0.12)' },
                        { offset: 1, color: 'rgba(86,104,238,0.01)' }
                    ]
                }
            },
            data: [[Date.now() / 1000, 0]],
            zlevel: 1
        }],
        animation: true,
        animationDuration: 300
    });

    window.addEventListener('resize', function() { if (myChart) myChart.resize(); });

    // 图表默认显示
    if (!chartShow) {
        chartShow = true;
        localStorage.setItem('chartShow', 'true');
    }
    toggleChart(true);

    // 初始化完成但尚无采样点 → 展示空状态
    setChartState('empty');
}

function clearChartData() {
    speedTemp = [];
    showArray = [[Date.now() / 1000, 0]];
    if (myChart) myChart.setOption({ series: [{ data: showArray }] });
    setChartState('empty');
}

function updateChart(speed) {
    if (!myChart || typeof echarts === 'undefined') return;

    speedTemp.push(speed);

    while (speedTemp.length >= stepLength) {
        var tmp = speedTemp.splice(0, stepLength);
        var avg = tmp.includes(0) ? 0 : tmp.reduce(function(a, b) { return a + b; }, 0) / stepLength;
        showArray.push([Date.now() / 1000, avg]);
    }

    while (showArray.length >= CONFIG.CHART_MAX_POINTS) {
        var result = [];
        var len = showArray.length % 2 === 0 ? showArray.length : showArray.length - 1;
        for (var i = 0; i < len; i += 2) {
            result.push([showArray[i][0], (showArray[i][1] + showArray[i+1][1]) / 2]);
        }
        showArray = result;
        stepLength *= 2;
    }

    if (chartShow) {
        myChart.setOption({ series: [{ data: showArray }] });
    }

    // 已有真实采样点（>1 个）→ 隐藏空状态，并同步右上角标签
    if (showArray.length > 1) {
        var stateEl = $('chartState');
        if (stateEl && stateEl.style.display !== 'none') stateEl.style.display = 'none';
        var chipText = $('chartChipText');
        if (chipText) chipText.textContent = showArray.length + ' 个采样点';
    }
}

function toggleChart(show) {
    if (typeof echarts === 'undefined') {
        setChartState('error');
        return;
    }
    chartShow = show;
    localStorage.setItem('chartShow', show ? 'true' : 'false');
    var container = $('chartContainer');
    if (container) container.style.display = show ? 'block' : 'none';
    if (show && myChart) setTimeout(function() { myChart.resize(); }, 100);
}

// ============================================================
// 第九层：限额管理
// ============================================================

function initTrafficLimit() {
    var input = $('trafficLimitInput');
    var unit = $('trafficLimitUnit');
    var hint = $('limitHint');
    if (!input || !unit) return;

    // 恢复保存的值：优先用限额管理自己的键；否则用弹窗保存的 state.maxUse（字节）反推
    var savedVal = localStorage.getItem('trafficLimitValue');
    if (savedVal) {
        input.value = savedVal;
        unit.value = localStorage.getItem('trafficLimitUnit') || 'GB';
    } else if (state.maxUse > 0) {
        // 此前由「总流量上限」弹窗设置过 → 反向补齐输入框，避免被误清零
        syncTrafficLimitInputs();
    } else {
        input.value = '';
        unit.value = localStorage.getItem('trafficLimitUnit') || 'GB';
    }

    function updateLimit() {
        var val = parseFloat(input.value);
        if (!val || val <= 0) {
            state.maxUse = 0;
            localStorage.removeItem('trafficLimitValue');
            if (hint) hint.textContent = '(不限)';
            if (hint) hint.style.color = '';
            updateMaxUseDisplay();
            return;
        }
        var u = unit.value;
        var bytes;
        if (u === 'TB') bytes = val * 1099511627776;
        else if (u === 'GB') bytes = val * 1073741824;
        else bytes = val * 1048576;

        state.maxUse = bytes;
        localStorage.setItem('trafficLimitValue', val);
        localStorage.setItem('trafficLimitUnit', u);

        if (hint) {
            hint.textContent = '(达到 ' + val + u + ' 后自动停止)';
            hint.style.color = '#e85555';
        }
        updateMaxUseDisplay();
    }

    input.addEventListener('input', updateLimit);
    unit.addEventListener('change', updateLimit);
    updateLimit();
}

// ============================================================
// 第十层：流量/带宽上限设置
// ============================================================

/** 上限数值边界：0 = 不限制；负值/非数字按 0 处理；上限 1,048,576 单位（防溢出与误填） */
var MAX_LIMIT_UNITS = 1048576;

/** 解析并校验弹窗输入，返回规范化后的数值（单位数），非法时返回 null 并提示 */
function parseLimitInput(numInput, label) {
    if (!numInput) return null;
    var raw = String(numInput.value == null ? '' : numInput.value).trim();
    if (raw === '') return 0;                       // 留空 = 不限制

    var num = parseFloat(raw);
    if (isNaN(num)) {
        showToast(label + '必须是数字', 'error');
        return null;
    }
    if (num < 0) {
        showToast(label + '不能为负数', 'error');
        return null;
    }
    if (num === 0) return 0;                        // 显式填 0 = 不限制
    if (num > MAX_LIMIT_UNITS) {
        showToast(label + '过大，已按上限 ' + MAX_LIMIT_UNITS + ' 处理', 'warning');
        num = MAX_LIMIT_UNITS;
    }
    return num;
}

/**
 * 把 state.maxUse 回写到「限额管理」输入框，保证两个入口（概览卡片与限额管理）
 * 展示与保存始终一致。
 */
function syncTrafficLimitInputs() {
    var input = $('trafficLimitInput');
    var unit = $('trafficLimitUnit');
    var hint = $('limitHint');
    if (!input || !unit) return;

    if (!state.maxUse) {
        input.value = '';
        localStorage.removeItem('trafficLimitValue');
        if (hint) { hint.textContent = '(不限)'; hint.style.color = ''; }
        return;
    }

    var val, u;
    if (state.maxUse % 1099511627776 === 0) {
        val = state.maxUse / 1099511627776; u = 'TB';
    } else if (state.maxUse % 1073741824 === 0) {
        val = state.maxUse / 1073741824; u = 'GB';
    } else {
        val = Math.round(state.maxUse / 1048576); u = 'MB';
    }

    input.value = val;
    unit.value = u;
    localStorage.setItem('trafficLimitValue', String(val));
    localStorage.setItem('trafficLimitUnit', u);
    if (hint) { hint.textContent = '(达到 ' + val + u + ' 后自动停止)'; hint.style.color = '#e85555'; }
}

function editMaxUse() {
    var numInput = $('maxUseInput');
    var unitSel = $('maxUseUnit');
    if (!numInput || !unitSel) return;

    var num = parseLimitInput(numInput, '总流量上限');
    if (num === null) return;

    var map = { MB: 1048576, GB: 1073741824, TB: 1099511627776 };
    var unit = map[unitSel.value] ? unitSel.value : 'GB';

    state.maxUse = num ? Math.floor(num * map[unit]) : 0;
    try { localStorage.setItem('maxUse', String(state.maxUse)); } catch (e) {}
    localStorage.setItem('trafficLimitUnit', unit);
    if (num) localStorage.setItem('trafficLimitValue', String(num));
    else localStorage.removeItem('trafficLimitValue');

    updateMaxUseDisplay();
    syncTrafficLimitInputs();
    showToast(num ? '已设置总流量上限为 ' + num + unit : '已取消总流量上限', 'success');
    closeModal('#modalMaxUse');
}

function updateMaxUseDisplay() {
    var el = $('maxUseDisplay');
    if (!el) return;
    el.textContent = state.maxUse ? formatBytes(state.maxUse, 0) : '未设置';
    el.classList.toggle('is-unset', !state.maxUse);
}

function editMaxSpeed() {
    var numInput = $('maxSpeedInput');
    var unitSel = $('maxSpeedUnit');
    if (!numInput || !unitSel) return;

    var num = parseLimitInput(numInput, '带宽上限');
    if (num === null) return;

    var map = { Kbps: 1024, Mbps: 1048576, Gbps: 1073741824 };
    var unit = map[unitSel.value] ? unitSel.value : 'Mbps';

    state.maxSpeed = num ? Math.floor(num * map[unit]) : 0;
    try { localStorage.setItem('maxSpeed', String(state.maxSpeed)); } catch (e) {}

    updateMaxSpeedDisplay();
    showToast(num ? '已设置带宽上限为 ' + num + unit : '已取消带宽上限', 'success');
    closeModal('#modalMaxSpeed');
}

function updateMaxSpeedDisplay() {
    var el = $('maxSpeedDisplay');
    if (!el) return;
    el.textContent = state.maxSpeed ? formatBits(state.maxSpeed, 2) : '未设置';
    el.classList.toggle('is-unset', !state.maxSpeed);
}

// ============================================================
// 第十一层：URL检查
// ============================================================

async function checkUrl(url) {
    var blockList = ['ljxnet.cn', 'netart.cn', '.gov.cn'];
    try {
        var structUrl = new URL(url);
        for (var i = 0; i < blockList.length; i++) {
            if (structUrl.hostname.endsWith(blockList[i])) {
                return { status: false, info: '该域名不在允许列表中' };
            }
        }
    } catch(e) {
        if (e.message !== '该域名不在允许列表中') return { status: false, info: e.message };
        return { status: false, info: e.message };
    }

    try {
        var controller = new AbortController();
        var timeoutId = setTimeout(function() { controller.abort(); }, 5000);
        var response = await fetch(url, {
            cache: 'no-store', mode: 'cors', referrerPolicy: 'no-referrer', signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (response.status === 404) throw new Error('资源响应异常: 404');
        if (!response.body) throw new Error('资源响应异常: No body');

        var reader = response.body.getReader();
        var result = await reader.read();
        if (!result || !result.value || result.value.length <= 0) throw new Error('资源响应异常: Empty body');
        reader.cancel();

        return { status: true, info: '' };
    } catch(err) {
        return { status: false, info: err.message };
    }
}

// ============================================================
// 第十二层：日志上报
// ============================================================

async function uploadLog() {
    var now = Date.now() / 1000;
    var num = state.bytesUsed - state.logged;
    var time = now - state.lastLogTime;

    state.logged = state.bytesUsed;
    state.lastLogTime = now;

    try {
        var resp = await fetch(CONFIG.API_BASE + 'log.php', {
            method: 'POST', mode: 'cors', redirect: 'follow', referrerPolicy: 'no-referrer',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                AccessToken: localStorage.getItem('AccessToken') || '',
                url: runUrl,
                threadNum: threadNum,
                used: Math.floor(num),
                time: time.toFixed(2)
            })
        });
        var data = await resp.json();
        if (data.status === -1) localStorage.removeItem('AccessToken');
    } catch(e) {
        console.error('Upload log failed:', e);
    }
}

function copyCurrentUrl() {
    copyToClipboard(runUrl);
}

// ============================================================
// 第十三层：粘贴处理 & 可见性
// ============================================================

async function handlePaste(e) {
    var items = e.clipboardData && e.clipboardData.items;
    if (!items || (document.activeElement && document.activeElement.tagName === 'INPUT')) return;

    for (var i = 0; i < items.length; i++) {
        if (items[i].type === 'text/plain') {
            (function(item) {
                item.getAsString(async function(str) {
                    var parsedUrl = parseUrl(str);
                    if (parsedUrl) {
                        toast('检测到链接，正在验证...');
                        var ret = await checkUrl(parsedUrl);
                        if (ret.status) {
                            runUrl = parsedUrl;
                            var sel = $('urlSelect');
                            if (sel) sel.value = runUrl;
                            localStorage.setItem('url', runUrl);
                            toast('链接已应用！');
                        } else {
                            toast(ret.info, 'error');
                        }
                    }
                });
            })(items[i]);
            break;
        }
    }
}

function handleVisibilityChange() {
    var hidden = document.visibilityState === 'hidden';
    isVisible = !hidden;
    // 后台保活模式：切换标签页/最小化时不停止测速
    if (hidden && isRunning && !keepAlive) {
        stopTest();
    }
    if (!hidden) updateTitle(0);
}

// ============================================================
// 第十四层：IP信息查询
// ============================================================

/** 渲染 IP 信息结构化字段（IP / 归属地 / 运营商 / 连接状态） */
function renderIpInfoCard(data, state, extra) {
    var addrEl = $('ipAddr');
    var regionEl = $('ipRegion');
    var ispEl = $('ipIsp');
    var statusEl = $('ipStatus');
    var chipText = $('ipStateText');
    var chipDot = $('ipStateDot');

    var setText = function(el, v) { if (el) el.textContent = (v === undefined || v === null || v === '') ? '-' : v; };

    if (state !== 'ok' || !data) {
        setText(addrEl, '-');
        setText(regionEl, '-');
        setText(ispEl, '-');
        setText(statusEl, state === 'error' ? '检测失败，请点击「重新检测」' : '暂无数据');
        if (chipText) chipText.textContent = state === 'error' ? '异常' : '无数据';
        if (chipDot) {
            chipDot.classList.toggle('is-err', state === 'error');
            chipDot.classList.remove('is-ok');
        }
        if (statusEl) statusEl.classList.add('is-error');
        return;
    }

    var regions = data.regions_short || [];
    var countryName = (data.country && data.country.name) || '';
    var regionParts = [];
    if (countryName) regionParts.push(countryName);
    if (regions.length) regionParts.push(regions.join(' '));

    setText(addrEl, data.ip + (data.type ? '（' + data.type + '）' : ''));
    setText(regionEl, regionParts.join(' ') || data.location || '-');
    setText(ispEl, (data.as && (data.as.name || data.as.info)) || data.isp || '-');

    var onlineText = data.private ? '已连接（内网 / 本机）' : '已连接（公网出口）';
    if (extra && extra.latency) onlineText += ' · 出口延迟 ' + extra.latency + 'ms';
    setText(statusEl, onlineText);
    if (statusEl) statusEl.classList.remove('is-error');

    if (chipText) chipText.textContent = '正常';
    if (chipDot) {
        chipDot.classList.remove('is-err');
        chipDot.classList.add('is-ok');
    }
}

/**
 * 获取公网出口 IP
 * 优先 Cloudflare trace（带延迟），其次 ipify / httpbin 兜底。
 * @return {Promise<{ip:string, latency:number|null}|null>}
 */
async function fetchPublicIP() {
    try {
        var startTs = Date.now();
        var cfResp = await fetch('https://cp.cloudflare.com/cdn-cgi/trace', { referrerPolicy: 'no-referrer' });
        var latency = Date.now() - startTs;
        var text = await cfResp.text();
        var ipMatch = text.match(/ip=([0-9a-f.:]+)/);
        if (ipMatch && ipMatch[1]) {
            return { ip: ipMatch[1], latency: latency };
        }
    } catch (e) {}

    try {
        var ipResp = await fetch('https://api.ipify.org?format=json', { referrerPolicy: 'no-referrer' });
        var ipData = await ipResp.json();
        if (ipData && ipData.ip) {
            return { ip: ipData.ip, latency: null };
        }
    } catch (e) {}

    try {
        var hbResp = await fetch('https://httpbin.org/ip', { referrerPolicy: 'no-referrer' });
        var hbData = await hbResp.json();
        if (hbData && hbData.origin) {
            return { ip: hbData.origin, latency: null };
        }
    } catch (e) {}

    return null;
}

/** 格式化延迟（毫秒） */
function formatLatency(ms) {
    if (ms === null || ms === undefined || ms === '') return null;
    var n = parseInt(ms, 10);
    if (isNaN(n)) return null;
    return n + ' ms';
}

/**
 * 拼接出口探测一行中的归属/运营商信息。
 *
 * 参考 net.arsn.cn「出口地址」双行逻辑：
 *   - 国内视角(domestic)：中文归属 —— 国家 + 省份(regions_short) + 运营商(isp，中文)
 *   - 国外视角(foreign) ：国际归属 —— 国家代码(CN) + AS 组织(as.info，技术/英文风格)
 * 两者字段不同，即便 IP 相同也会呈现可区分的归属描述（如国内「中国 广东 移动」、
 * 国外「CN China Mobile Communications Corporation」），避免两行内容完全一致。
 */
function buildEgressInfo(data, kind) {
    if (!data) return '未知';
    var parts = [];
    if (kind === 'foreign') {
        var cc = (data.country && data.country.code) ? data.country.code
            : (data.country && data.country.name ? data.country.name : '');
        if (cc) parts.push(cc);
        var org = (data.as && (data.as.info || data.as.name)) ? (data.as.info || data.as.name) : '';
        if (org) {
            var asn = (data.as && data.as.number) ? 'AS' + data.as.number + ' ' : '';
            parts.push(asn + org);
        } else if (data.isp) {
            parts.push(data.isp);
        }
    } else {
        var cn = (data.country && data.country.name) ? data.country.name : '';
        if (cn) parts.push(cn);
        if (data.regions_short && data.regions_short.length) parts.push(data.regions_short.join(' '));
        var isp = data.isp || (data.as && (data.as.name || data.as.info)) || '';
        if (isp) parts.push(isp);
    }
    return parts.join(' ') || data.location || '未知';
}

/** 生成出口探测单条 HTML */
function buildEgressRow(label, kind, ip, info, latency) {
    var latencyVal = latency || '—';
    var latencyClass = kind === 'foreign' ? 'is-bad' : 'is-good';
    return '<div class="ip-entry ip-probe-row">' +
        '<span class="ip-tag ip-tag-' + kind + '">' + escapeHtml(label) + '</span>' +
        '<span class="ip-text ip-probe-ip">' + escapeHtml(ip) + '</span>' +
        '<span class="ip-probe-info">' + escapeHtml(info) + '</span>' +
        '<span class="ip-probe-latency ' + latencyClass + '">' + escapeHtml(latencyVal) + '</span>' +
        '</div>';
}

/** 渲染出口探测（国内 + 国外双视图） */
function renderEgressProbe(container, localData, localLatency, publicIpData) {
    var rows = [];
    var local = (localData && localData.status === 0 && localData.data) ? localData.data : null;

    // 国内：优先用服务端本机视角；若本机为内网则回退到公网 IP
    var domData = (local && !local.private) ? local : publicIpData;
    var domIP = domData && domData.ip ? domData.ip : null;
    if (domIP && domData) {
        var domInfo = buildEgressInfo(domData, 'domestic');
        var domLatency = formatLatency(localLatency) || (publicIpData && publicIpData._latency ? formatLatency(publicIpData._latency) : null);
        rows.push(buildEgressRow('国内', 'domestic', domIP, domInfo, domLatency));
    }

    // 国外：公网出口视角
    if (publicIpData && publicIpData.ip) {
        var foreignInfo = buildEgressInfo(publicIpData, 'foreign');
        var foreignLatency = formatLatency(publicIpData._latency);
        rows.push(buildEgressRow('国外', 'foreign', publicIpData.ip, foreignInfo, foreignLatency));
    }

    if (!rows.length) {
        container.innerHTML = '<div class="ip-loading" style="color:#999;">暂无 IP 数据</div>';
        return;
    }
    container.innerHTML = rows.join('');
}

// 当前选中的 IP 数据源（'' = 跟随后台生效源，走缓存）
var currentIpSource = '';
var ipSourceActiveDefault = '';

/** 加载可用 IP 数据源并填充首页下拉框 */
async function loadIpSources() {
    var sel = $('ipSourceSelect');
    if (!sel) return;
    try {
        var resp = await fetch(CONFIG.API_BASE + 'ip.php?action=registry', { referrerPolicy: 'no-referrer' });
        var data = await resp.json();
        if (data.status !== 0 || !data.data || !Array.isArray(data.data.sources)) return;
        var sources = data.data.sources;
        var active = (typeof data.data.active === 'string') ? data.data.active : '';
        ipSourceActiveDefault = active;
        sel.innerHTML = '';
        sources.forEach(function (s) {
            var opt = document.createElement('option');
            opt.value = s.key;
            var label = s.name || s.key;
            if (s.needs_token) label += '（需 Token）';
            if (s.active) label += ' ✓';
            opt.textContent = label;
            sel.appendChild(opt);
        });
        sel.value = active;
        currentIpSource = ''; // 默认不覆盖，走缓存 + 后台生效源
    } catch (e) {
        // 网络异常时保留占位项，不阻断其它功能
    }
}

/** 绑定 IP 数据源下拉切换：选中后自动刷新首页动态 IP 内容 */
function bindIpSourceSelector() {
    var sel = $('ipSourceSelect');
    if (!sel) return;
    sel.addEventListener('change', function () {
        var v = sel.value || '';
        // 与默认生效源一致时不覆盖，避免无谓跳过缓存
        currentIpSource = (v && v !== ipSourceActiveDefault) ? v : '';
        fetchIPInfo();
    });
}

async function fetchIPInfo() {
    var container = $('ipInfoContent');
    if (!container) return;

    var localData = null;
    var localLatency = null;
    var publicIpData = null;

    // 1. 获取服务端本机出口（国内视角）并计时（可带 source 覆盖）
    try {
        var srcParam = currentIpSource ? ('?source=' + encodeURIComponent(currentIpSource)) : '';
        var t0 = Date.now();
        var localResp = await fetch(CONFIG.API_BASE + 'ip.php' + srcParam, { referrerPolicy: 'no-referrer' });
        localLatency = Date.now() - t0;
        localData = await localResp.json();
    } catch (e) {}

    // 2. 获取公网出口 IP（国外视角）并计时
    var publicIP = null;
    try {
        publicIP = await fetchPublicIP();
    } catch (e) {}

    if (publicIP && publicIP.ip) {
        try {
            var pubUrl = CONFIG.API_BASE + 'ip.php?ip=' + encodeURIComponent(publicIP.ip) +
                (currentIpSource ? ('&source=' + encodeURIComponent(currentIpSource)) : '');
            var ipResp = await fetch(pubUrl);
            var ipRespJson = await ipResp.json();
            if (ipRespJson.status === 0 && ipRespJson.data) {
                publicIpData = ipRespJson.data;
                publicIpData._latency = publicIP.latency;
            }
        } catch (e) {}
    }

    // 3. 渲染顶部 IP 信息卡（优先展示服务端 request_ip() 解析出的真实访客 IP）
    if (localData && localData.status === 0 && localData.data) {
        renderIpInfoCard(localData.data, 'ok', { latency: localLatency });
    } else if (publicIpData) {
        renderIpInfoCard(publicIpData, 'ok', { latency: publicIpData._latency });
    } else {
        renderIpInfoCard(null, 'empty');
    }

    // 4. 渲染出口探测（国内 + 国外双视图）
    renderEgressProbe(container, localData, localLatency, publicIpData);

    // 5. 同步更新顶部 IP 显示
    _updateCurrentIP();
}

/**
 * 更新信息面板中的当前IP显示（含连接状态心跳）。
 * 优先展示服务端 request_ip() 解析出的「真实访客 IP」（最权威）；
 * 仅在服务端不可达时，回退到浏览器侧公共出口 IP（Cloudflare / ipify）作为补充。
 */
async function _updateCurrentIP() {
    var el = $('displayCurrentIp');
    var icon = $('heartbeatIcon');
    if (!el) return;

    // 心跳动画
    if (icon) { icon.classList.add('hb-pulse'); }

    var done = false;

    // 优先：服务端真实访客 IP（由 request_ip() 解析，最权威）
    try {
        var sUrl = CONFIG.API_BASE + 'ip.php' + (currentIpSource ? ('?source=' + encodeURIComponent(currentIpSource)) : '');
        var resp = await fetch(sUrl, { referrerPolicy: 'no-referrer' });
        var data = await resp.json();
        if (data.status === 0 && data.data && data.data.ip) {
            var regions = data.data.regions_short || [];
            el.textContent = data.data.ip + (regions.length ? ' (' + regions.join(' ') + ')' : '');
            if (icon) { icon.classList.remove('hb-error'); icon.classList.add('hb-ok'); }
            done = true;
        }
    } catch (e) {}

    // 回退：浏览器侧公共出口 IP
    if (!done) {
        try {
            var publicIP = await fetchPublicIP();
            if (publicIP && publicIP.ip) {
                var fUrl = CONFIG.API_BASE + 'ip.php?ip=' + encodeURIComponent(publicIP.ip) +
                    (currentIpSource ? ('&source=' + encodeURIComponent(currentIpSource)) : '');
                var ipResp = await fetch(fUrl);
                var ipData = await ipResp.json();
                if (ipData.status === 0 && ipData.data && ipData.data.ip) {
                    var regions2 = ipData.data.regions_short || [];
                    el.textContent = ipData.data.ip + (regions2.length ? ' (' + regions2.join(' ') + ')' : '');
                    if (icon) { icon.classList.remove('hb-error'); icon.classList.add('hb-ok'); }
                    done = true;
                }
            }
        } catch (e) {}
    }

    if (!done) {
        el.textContent = '已连接到云中心';
        if (icon) { icon.classList.remove('hb-error'); icon.classList.add('hb-ok'); }
    }

    // 停止心跳动画
    if (icon) setTimeout(function(){ icon.classList.remove('hb-pulse'); }, 600);
}

// ============================================================
// 第十五层：认证系统
// ============================================================

function bindAuthEvents() {
    // 顶部导航 登录按钮现在是<a>标签，直接跳转到 ./user/login.php，无需JS事件

    // 信息面板区域 登录/注册按钮现在是<a>标签，直接跳转

    // 会员中心链接点击 -> 跳转到用户中心页面
    var memberLinkEl = $('memberLink');
    if (memberLinkEl) memberLinkEl.addEventListener('click', function(e) {
        e.preventDefault();
        window.open('./user/center.php', '_blank');
    });

    // Auth Tab切换
    var authTabs = $qa('.auth-tab');
    for (var i = 0; i < authTabs.length; i++) {
        (function(tab) {
            tab.addEventListener('click', function() {
                var tabs = $qa('.auth-tab');
                var panels = $qa('.auth-tab-panel');
                for (var t = 0; t < tabs.length; t++) tabs[t].classList.remove('active');
                this.classList.add('active');
                for (var p = 0; p < panels.length; p++) panels[p].style.display = 'none';
                var target = $(this.dataset.authTab);
                if (target) target.style.display = '';
            });
        })(authTabs[i]);
    }

    // 登录提交
    var authLoginSubmit = $('btnAuthLogin');
    if (authLoginSubmit) authLoginSubmit.addEventListener('click', handleAuthLogin);

    // 注册提交
    var authRegSubmit = $('btnAuthRegister');
    if (authRegSubmit) authRegSubmit.addEventListener('click', handleAuthRegister);
}

async function checkAuthStatus() {
    try {
        var resp = await fetch(AUTH_API + '?action=profile', { credentials: 'same-origin' });
        var data = await resp.json();
        if (data.status === 0 && data.data) {
            currentUser = data.data;
            updateAuthUI(data.data);
            if (data.data.access_token) {
                localStorage.setItem('AccessToken', data.data.access_token);
            }
        } else {
            updateAuthUI(null);
        }
    } catch(e) {
        updateAuthUI(null);
    }
}

// 账号被禁用时显示的网页内弹窗
function showDisabledAccountModal() {
    // 如果已有弹窗则不重复创建
    if ($('disabledAccountModal')) return;
    var modal = document.createElement('dialog');
    modal.id = 'disabledAccountModal';
    modal.style.cssText = 'margin:auto;max-width:400px;border:none;border-radius:16px;padding:0;box-shadow:0 10px 40px rgba(0,0,0,.25);';
    modal.innerHTML = '<div style="padding:24px;text-align:center;">' +
        '<div style="font-size:48px;color:#f56c6c;margin-bottom:12px;">&#9888;</div>' +
        '<h3 style="font-size:18px;color:#303133;margin-bottom:8px;">账号已被禁用</h3>' +
        '<p style="font-size:14px;color:#909399;margin-bottom:20px;">您的账号已被管理员禁用，无法使用测速功能。<br>请联系管理员解禁。</p>' +
        '<button onclick="document.getElementById(\'disabledAccountModal\').close();this.closest(\'dialog\').remove();" ' +
        'style="padding:10px 36px;border-radius:10px;background:#5668EE;color:#fff;border:none;font-size:14px;cursor:pointer;font-weight:600;">我知道了</button>' +
        '</div>';
    document.body.appendChild(modal);
    modal.showModal();
}

function updateAuthUI(user) {
    var loginBtn = $('btnLogin');
    var registerBtn = $('btnRegister');
    var userCenterBtn = $('btnUserCenter');
    var adminLink = $('btnAdminLink');

    if (user) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (registerBtn) registerBtn.style.display = 'none';
        if (userCenterBtn) {
            userCenterBtn.style.display = '';
            userCenterBtn.textContent = user.username || '个人中心';
        }

        if (user.role === 'admin' && adminLink) adminLink.style.display = '';
    } else {
        if (loginBtn) loginBtn.style.display = '';
        if (registerBtn) registerBtn.style.display = '';
        if (userCenterBtn) userCenterBtn.style.display = 'none';
        if (adminLink) adminLink.style.display = 'none';
    }

    updateAuthStatusDot();
}

function updateAuthStatusDot() {
    var btnGroup = $('authBtnGroup');
    var loggedName = $('loggedUserName');
    var memberLink = $('memberLink');

    if (currentUser) {
        if (btnGroup) btnGroup.style.display = 'none';
        if (loggedName) { loggedName.style.display = ''; loggedName.textContent = '在线'; }
        if (memberLink) { memberLink.style.display = ''; memberLink.textContent = '已登录'; }
    } else {
        if (btnGroup) btnGroup.style.display = '';
        if (loggedName) loggedName.style.display = 'none';
        if (memberLink) memberLink.style.display = 'none';
    }
}

async function handleAuthLogin() {
    var username = ($('authUser') || {}).value || '';
    var password = ($('authPass') || {}).value || '';
    var msgEl = $('authLoginMsg');

    if (!username || !password) { _showAuthMsg(msgEl, '请填写账号和密码', 'error'); return; }

    try {
        _setBtnLoading('btnAuthLogin', true);
        var resp = await fetch(AUTH_API, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'login', username: username, password: password })
        });
        var data = await resp.json();

        if (data.status === 0) {
            _showAuthMsg(msgEl, '登录成功！', 'success');
            localStorage.setItem('AccessToken', data.data.access_token);
            currentUser = data.data;
            updateAuthUI(data.data);
            setTimeout(function() { closeModal('#modalAuth'); }, 800);
        } else {
            _showAuthMsg(msgEl, data.message || '登录失败', 'error');
        }
    } catch(e) {
        _showAuthMsg(msgEl, '网络错误', 'error');
    }
    _setBtnLoading('btnAuthLogin', false);
}

async function handleAuthRegister() {
    var username = ($('regUserInput') || {}).value || '';
    var email = ($('regEmailInput') || {}).value || '';
    var password = ($('regPassInput') || {}).value || '';
    var confirm = ($('regPassConfirm') || {}).value || '';
    var msgEl = $('authRegMsg');

    if (password !== confirm) { _showAuthMsg(msgEl, '两次密码不一致', 'error'); return; }
    if (!username || password.length < 6) { _showAuthMsg(msgEl, '请正确填写信息', 'error'); return; }

    try {
        _setBtnLoading('btnAuthRegister', true);
        var resp = await fetch(AUTH_API, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'register', username: username, email: email, password: password })
        });
        var data = await resp.json();

        if (data.status === 0) {
            _showAuthMsg(msgEl, '注册成功！', 'success');
            localStorage.setItem('AccessToken', data.data.access_token);
            currentUser = data.data;
            updateAuthUI(data.data);
            setTimeout(function() { closeModal('#modalAuth'); }, 1200);
        } else {
            _showAuthMsg(msgEl, data.message || '注册失败', 'error');
        }
    } catch(e) {
        _showAuthMsg(msgEl, '网络错误', 'error');
    }
    _setBtnLoading('btnAuthRegister', false);
}

function _showAuthMsg(el, text, type) {
    if (!el) return;
    el.textContent = text;
    el.className = 'auth-msg msg-' + (type || '');
    if (type !== 'success') setTimeout(function() { el.className = 'auth-msg'; }, 4000);
}

async function handleSendReset() {
    var email = ($('resetEmailInput') || {}).value || '';
    var msgEl = $('resetMsg');

    if (!email || !email.includes('@')) {
        _showAuthMsg(msgEl, '请输入有效的邮箱地址', 'error');
        return;
    }

    try {
        _setBtnLoading('btnSendReset', true);
        var resp = await fetch(AUTH_API, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'reset_password', email: email })
        });
        var data = await resp.json();

        if (data.status === 0) {
            _showAuthMsg(msgEl, '重置邮件已发送，请查收！', 'success');
            setTimeout(function() { closeModal('#modalResetPwd'); }, 2000);
        } else {
            _showAuthMsg(msgEl, data.message || '发送失败，请检查邮箱是否正确', 'error');
        }
    } catch(e) {
        _showAuthMsg(msgEl, '网络错误，请稍后重试', 'error');
    }
    _setBtnLoading('btnSendReset', false);
}

function _setBtnLoading(sel, loading) {
    var btn = $(sel);
    if (!btn) return;
    if (loading) {
        btn.dataset.origText = btn.textContent;
        btn.textContent = '处理中...';
        btn.disabled = true;
        btn.style.opacity = '0.7';
    } else {
        btn.textContent = btn.dataset.origText || '确定';
        btn.disabled = false;
        btn.style.opacity = '';
    }
}

// ============================================================
// 第十六层：信息面板（浏览器/系统/设备/CPU/内存）
// ============================================================

function initInfoPanel() {
    detectBrowserOS();
}

function detectBrowserOS() {
    var ua = navigator.userAgent;
    var browser = { name: '-', icon: '\u{1F50D}' };   // 🔍
    var os = { name: '-', icon: '\u{1F4BB}' };         // 💻
    var device = { name: '桌面端', icon: '\u{1F5A5}' }; // 🖥

    // 浏览器检测
    if (/Edge|Edg\//i.test(ua)) browser = { name: 'Microsoft Edge', icon: '\u{1F30D}' };
    else if (/Firefox/i.test(ua)) browser = { name: 'Mozilla Firefox', icon: '\u{1F525}' };
    else if (/Chrome/i.test(ua) && !/Edg\//i.test(ua)) browser = { name: 'Google Chrome', icon: '\u{1F4A6}' };
    else if (/Safari/i.test(ua)) browser = { name: 'Apple Safari', icon: '\u{1F4F1}' };
    else if (/Opera|OPR\//i.test(ua)) browser = { name: 'Opera', icon: '\u{1F3B5}' };

    // 操作系统
    if (/Windows NT 10/.test(ua)) os = { name: 'Windows 10/11', icon: '\u{1F5A5}' };
    else if (/Windows NT 6\.3/.test(ua)) os = { name: 'Windows 8.1', icon: '\u{1F5A5}' };
    else if (/Windows NT 6\.2/.test(ua)) os = { name: 'Windows 8', icon: '\u{1F5A5}' };
    else if (/Windows NT 6\.1/.test(ua)) os = { name: 'Windows 7', icon: '\u{1F5A5}' };
    else if (/Mac OS X/.test(ua)) {
        var verMatch = ua.match(/Mac OS X (\d+[._]\d+)/);
        os = { name: 'macOS ' + (verMatch ? verMatch[1].replace('.', '.') : ''), icon: '\u{1F4F1}' };
    } else if (/Android/.test(ua)) {
        var androidVer = ua.match(/Android (\d+\.?\d*)/);
        os = { name: 'Android ' + (androidVer ? androidVer[1] : ''), icon: '\u{1F4EB}' };
    } else if (/iPhone|iPad/.test(ua)) os = { name: 'iOS', icon: '\u{1F4F1}' };
    else if (/Linux/.test(ua)) os = { name: 'Linux', icon: '\u{1F426}' };
    else os = { name: '未知系统', icon: '\u{1F914}' };

    // 设备类型
    if (/Mobi|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua)) {
        var isTablet = /iPad/.test(ua) || (/Mac/.test(ua) && navigator.maxTouchPoints > 1);
        device = isTablet ? { name: '平板', icon: '\u{1F4FA}' } : { name: '手机', icon: '\u{1F4F1}' };
    } else {
        device = { name: '桌面端', icon: '\u{1F5A5}' };
    }

    // 渲染
    var bEl = $('infoBrowser');
    var oEl = $('infoOs');
    var dEl = $('infoDevice');

    if (bEl) bEl.innerHTML = '<span class="browser-icon">' + browser.icon + '</span><span>' + browser.name + '</span>';
    if (oEl) oEl.innerHTML = '<span class="os-icon">' + os.icon + '</span><span>' + os.name + '</span>';
    if (dEl) dEl.innerHTML = '<span class="device-icon">' + device.icon + '</span><span>' + device.name + '</span>';
}

// ============================================================
// 第十七层：公告/广告位
// ============================================================

async function loadNotice() {
    try {
        var resp = await fetch(CONFIG.API_BASE + 'footer_settings.php');
        var data = await resp.json();
        var notices = (data.data && data.data.notices) || [];
        if (notices.length > 0) {
            startNoticeScroll(notices);
            return;
        }
    } catch(e) {}

    // 尝试从localStorage恢复
    try {
        var saved = localStorage.getItem('customNotices');
        if (saved) {
            var arr = JSON.parse(saved);
            if (arr && arr.length) startNoticeScroll(arr);
        }
    } catch(e) {}
}

function startNoticeScroll(items) {
    var bar = $('noticeBar');
    var inner = $('noticeScrollInner');
    if (!bar || !inner) return;

    var filtered = [];
    for (var i = 0; i < items.length; i++) {
        if (items[i] && String(items[i]).trim()) filtered.push(items[i]);
    }
    if (!filtered.length) { bar.style.display = 'none'; return; }

    inner.innerHTML = filtered.map(function(item) {
        return '<div class="notice-item">' + item + '</div>';
    }).join('');

    bar.style.display = '';
    inner.style.transform = 'translateY(0)';

    if (filtered.length <= 1) return;

    var noticeIdx = 0;
    if (_noticeTimer) clearInterval(_noticeTimer);
    _noticeTimer = setInterval(function() {
        noticeIdx = (noticeIdx + 1) % filtered.length;
        inner.style.transform = 'translateY(-' + (noticeIdx * 22) + 'px)';
    }, 5000);

    try { localStorage.setItem('customNotices', JSON.stringify(filtered)); } catch(e) {}
}

// ============================================================
// 第十七层B：公告弹窗（后台公告管理）
// ============================================================

async function loadAnnouncements() {
    try {
        var resp = await fetch(CONFIG.API_BASE + 'footer_settings.php?action=announcements');
        var data = await resp.json();
        if (data.status === 0 && data.data && data.data.length > 0) {
            showAnnouncementPopup(data.data);
        }
    } catch(e) {
        console.error('加载公告失败', e);
    }
}

function showAnnouncementPopup(announcements) {
    var today = new Date().toISOString().slice(0, 10);
    var hideKey = 'announcement_hide_' + today;
    try {
        if (localStorage.getItem(hideKey) === '1') return;
    } catch(e) {}

    var popupItems = announcements.filter(function(a) { return a.show_popup == 1; });
    if (!popupItems.length) return;

    var modal = document.getElementById('modalAnnouncement');
    var titleEl = document.getElementById('announcementModalTitle');
    var bodyEl = document.getElementById('announcementModalBody');
    var dontShowEl = document.getElementById('announcementDontShow');
    if (!modal || !bodyEl) return;

    if (popupItems.length === 1) {
        titleEl.textContent = popupItems[0].title || '公告';
        bodyEl.innerHTML = popupItems[0].content;
    } else {
        titleEl.textContent = '公告';
        var html = '';
        popupItems.forEach(function(item) {
            html += '<div class="announcement-item">';
            html += '<h4 class="announcement-item-title">' + (item.title || '公告') + '</h4>';
            html += '<div class="announcement-item-content">' + item.content + '</div>';
            html += '</div>';
        });
        bodyEl.innerHTML = html;
    }

    if (dontShowEl) dontShowEl.checked = false;

    try { modal.showModal(); } catch(e) {
        if (modal.show) modal.show();
    }
}

function initAnnouncementPopup() {
    var okBtn = document.getElementById('btnAnnouncementOk');
    var modal = document.getElementById('modalAnnouncement');
    var dontShowEl = document.getElementById('announcementDontShow');

    if (okBtn) {
        okBtn.addEventListener('click', function() {
            if (dontShowEl && dontShowEl.checked) {
                var today = new Date().toISOString().slice(0, 10);
                try { localStorage.setItem('announcement_hide_' + today, '1'); } catch(e) {}
            }
            try { modal.close(); } catch(e) {
                if (modal.hide) modal.hide();
            }
        });
    }

    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                try { modal.close(); } catch(e2) {}
            }
        });
    }

    loadAnnouncements();
}

// ============================================================
// 第十七层C：广告区块
// ============================================================

async function loadAds() {
    try {
        var resp = await fetch(CONFIG.API_BASE + 'footer_settings.php?action=ads');
        var data = await resp.json();
        if (data.status !== 0 || !data.data || !data.data.length) {
            var panel = document.getElementById('adsPanel');
            if (panel) panel.style.display = 'none';
            return;
        }
        var list = document.getElementById('adsList');
        if (!list) return;
        var html = '';
        data.data.forEach(function(ad) {
            var color = ad.color ? 'color:' + ad.color + ';' : '';
            var url = 'redirect.php?url=' + encodeURIComponent(ad.url);
            html += '<a class="ad-item" href="' + url + '" target="_blank" rel="noopener">';
            html += '<span class="ad-text" style="' + color + '">' + ad.title + '</span>';
            html += '<span class="ad-tag">广告</span>';
            html += '</a>';
        });
        list.innerHTML = html;
    } catch(e) {
        console.error('加载广告失败', e);
        var panel = document.getElementById('adsPanel');
        if (panel) panel.style.display = 'none';
    }
}

// ============================================================
// 第十八层：排行榜
// ============================================================

async function refreshRank() {
    var sortByRadio = $qa('[name="sortBy"]:checked');
    var sortBy = sortByRadio.length ? sortByRadio[0].value : 'allUsed';

    var gradeRadio = $qa('[name="grade"]:checked');
    var grade = gradeRadio.length ? gradeRadio[0].value : '3';

    var isPastCb = $('isPast');
    var isPast = isPastCb ? isPastCb.checked : false;

    var tbody = $('rankBody');
    if (tbody) tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:30px;">加载中...</td></tr>';

    try {
        var params = new URLSearchParams({ grade: grade, sorted_by: sortBy, isPast: isPast ? 'true' : 'false' });
        var resp = await fetch(CONFIG.API_BASE + 'rank.php?' + params.toString(), {
            mode: 'cors', redirect: 'follow', referrerPolicy: 'no-referrer'
        });
        var result = await resp.json();

        if (result.status !== 0 || !result.data || !result.data.length) {
            if (tbody) tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:30px;">没有数据</td></tr>';
            return;
        }

        var colNames = { allUsed: '总流量', averageSpeed: '平均速度', onlineTime: '在线时长' };
        var colHeader = $q('th[data-col]');
        if (colHeader) colHeader.textContent = colNames[sortBy] || '';

        var html = '';
        for (var i = 0; i < result.data.length; i++) {
            var row = result.data[i];
            var formattedValue;
            if (sortBy === 'allUsed') formattedValue = formatBytes(row.data, [0,0,0,0,1,1]);
            else if (sortBy === 'averageSpeed') formattedValue = formatBits(row.data * 8, [0,0,0,1,1,1]);
            else formattedValue = formatDuration(row.data);

            var ispClass = _getISPClass(row.isp || '');
            var avatar = row.headimg
                ? '<img src="' + escapeAttr(row.headimg) + '" class="rank-avatar">'
                : '<span style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#5668EE,#6576ff);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;">' + (row.user||'?')[0].toUpperCase() + '</span>';
            var shortStr = Array.isArray(row.short) ? row.short.join(' ') : (row.short || '');

            html += '<tr>' +
                '<td>' + (i+1) + '</td>' +
                '<td><div class="rank-user-cell">' + avatar + '<span>' + escapeHtml(row.user) + '</span></div></td>' +
                '<td>' + formattedValue + '</td>' +
                '<td><span class="tag-isp ' + ispClass + '">' + shortStr + '</span></td>' +
                '</tr>';
        }
        if (tbody) tbody.innerHTML = html;
    } catch(e) {
        console.error('Rank query failed:', e);
        if (tbody) tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:red;padding:30px;">获取榜单失败</td></tr>';
    }
}

function _getISPClass(text) {
    if (text.indexOf('移动') !== -1) return 'isp-mobile';
    if (text.indexOf('联通') !== -1) return 'isp-unicom';
    if (text.indexOf('电信') !== -1) return 'isp-telecom';
    if (text.indexOf('广电') !== -1) return 'isp-broadband';
    return 'isp-other';
}

// ============================================================
// 第十九层：今日排行（可选功能）
// ============================================================

async function loadTodayRank() {
    var container = $('todayRankList');
    if (!container) return;

    try {
        var resp = await fetch(CONFIG.API_BASE + 'rank_today.php?limit=10');
        var result = await resp.json();

        if (result.status !== 0 || !result.data || !result.data.length) {
            container.innerHTML = '<div style="text-align:center;padding:24px;color:#bbb;font-size:14px;">暂无排行数据</div>';
            return;
        }

        var html = '';
        for (var i = 0; i < result.data.length; i++) {
            var row = result.data[i];
            var medalHtml;
            if (row.rank === 1) medalHtml = '<span style="font-style:normal;">&#129351;</span>'; // 🥇
            else if (row.rank === 2) medalHtml = '<span style="font-style:normal;">&#129352;</span>'; // 🥈
            else if (row.rank === 3) medalHtml = '<span style="font-style:normal;">&#129353;</span>'; // 🥉
            else medalHtml = '<span class="rank-medal medal-num">' + row.rank + '</span>';

            var avatarHtml = row.headimg
                ? '<img src="' + escapeAttr(row.headimg) + '" class="rank-avatar-sm">'
                : '<span class="rank-noavatar">' + ((row.username||'?')[0]).toUpperCase() + '</span>';

            html += '<div class="rank-today-item">' +
                medalHtml + avatarHtml +
                '<div class="rank-user-name"><span>' + escapeHtml(row.username) + '</span></div>' +
                '<div class="rank-bytes-val">' + formatBytes(row.bytes, 0) + '</div>' +
                '</div>';
        }
        container.innerHTML = html;
    } catch(e) {
        container.innerHTML = '<div style="text-align:center;padding:20px;color:#f56c6c;font-size:13px;">加载失败</div>';
    }
}

// ============================================================
// 第二十层：友情链接
// ============================================================

async function loadFriendLinks() {
    try {
        var resp = await fetch(CONFIG.API_BASE + 'footer_settings.php');
        var data = await resp.json();

        if (data.status !== 0 || !data.data || !data.data.friend_links) {
            var card = $('.friend-links-card');
            if (card) card.style.display = 'none';
            return;
        }

        var links = [];
        try { links = JSON.parse(data.data.friend_links); } catch(e) {}

        if (!links.length) {
            var fc = $('.friend-links-card');
            if (fc) fc.style.display = 'none';
            return;
        }

        var body = $('friendLinksBody');
        if (body) {
            var html = '';
            for (var i = 0; i < links.length; i++) {
                html += '<a href="' + escapeAttr(links[i].url) + '" target="_blank" rel="noopener" class="friend-link-item">' + escapeHtml(links[i].name) + '</a>';
                if (i < links.length - 1) html += '<span class="fl-sep">/</span>';
            }
            body.innerHTML = html;
        }
    } catch(e) {}
}

// ============================================================
// 第十一层b：顶部动态导航
// ============================================================

/**
 * 默认导航配置（后台未设置时的兜底）
 *
 * 主导航（首页/工具箱/IP 查询/流量计算器/字节转换/IP 进阶/排行榜）
 * 已在 HTML 中固定，此处仅用于「自定义附加项」兜底。默认空数组，
 * 避免在 topNavContainer 里重复渲染主导航项。
 */
var _defaultTopNav = [];

async function loadTopNav() {
    var container = $('topNavContainer');
    if (!container) return;

    try {
        // 尝试从后台获取导航配置（footer_settings API 扩展）
        var resp = await fetch(CONFIG.API_BASE + 'footer_settings.php');
        var data = await resp.json();

        if (data.status === 0 && data.data && data.data.nav_links) {
            var links;
            try { links = JSON.parse(data.data.nav_links); } catch(e) {}
            if (links && links.length > 0) {
                _renderTopNav(links);
                return;
            }
        }
    } catch(e) {}

    // 兜底：使用默认导航
    _renderTopNav(_defaultTopNav);
}

function _renderTopNav(links) {
    var container = $('topNavContainer');
    if (!container || !links) return;

    var html = '';
    for (var i = 0; i < links.length; i++) {
        var item = links[i];
        // 主导航与右上角入口已在 HTML 中固定，避免后台配置误填导致重复
        var primaryNavNames = ['首页','工具箱','IP 查询','IP查询','流量计算器','字节转换','字节转换器','IP 进阶','排行榜','个人中心','登录','注册','管理后台'];
        if (primaryNavNames.indexOf(item.name) !== -1) continue;

        var url = item.url || '#';
        var name = escapeHtml(item.name || '链接');
        var activeClass = item.active ? ' active' : '';

        if (url.indexOf('#') === 0 && url !== '#') {
            // 页内锚点跳转
            html += '<a href="' + url + '" class="nav-link nav-btn' + activeClass + '" onclick="document.querySelector(\'' + url + '\').scrollIntoView({behavior:\'smooth\'});return false;">' + name + '</a>';
        } else {
            // 外部/新标签页链接
            var target = (item.target === '_self') ? '' : ' target="_blank" rel="noopener"';
            html += '<a href="' + url + '" class="nav-link nav-btn' + activeClass + '"' + target + '>' + name + '</a>';
        }
    }
    container.innerHTML = html;
}

// ============================================================
// 第二十一层：底部设置
// ============================================================

async function loadFooterSettings() {
    try {
        var resp = await fetch(CONFIG.API_BASE + 'footer_settings.php');
        var data = await resp.json();

        if (data.status !== 0 || !data.data) return;
        var s = data.data;

        // 自定义文字
        if (s.custom_text) {
            var el = $('footerCustomText');
            if (el) el.innerHTML = s.custom_text;
        }

        // 版权
        if (s.copyright) {
            var cpEl = $('footerCopyright');
            if (cpEl) cpEl.textContent = s.copyright;
        }

        // ICP备案
        if (s.icp) {
            var icpEl = $('footerIcp');
            var divEl = $('footerDivider');
            if (icpEl) { icpEl.textContent = s.icp; icpEl.href = s.icp_url || '#'; icpEl.style.display = ''; }
        } else {
            var icpEl2 = $('footerIcp');
            var divEl2 = $('footerDivider');
            if (icpEl2) icpEl2.style.display = 'none';
            if (divEl2) divEl2.style.display = 'none';
        }

        // 自定义HTML
        if (s.custom_html) {
            var htmlEl = $('footerHtmlArea');
            if (htmlEl) htmlEl.innerHTML = s.custom_html;
        }

        // 公告栏
        if (s.notices && s.notices.length) {
            startNoticeScroll(s.notices);
        }

        // 底部友情链接
        if (s.friend_links) {
            var fLinks = [];
            try { fLinks = JSON.parse(s.friend_links); } catch(e) {}
            if (fLinks.length) {
                var ffl = $('footerFriendLinks');
                if (ffl) {
                    var h = '<span style="font-size:12px;color:#999;margin-right:6px;">友情链接:</span>';
                    for (var fi = 0; fi < fLinks.length; fi++) {
                        h += '<a href="' + escapeAttr(fLinks[fi].url) + '" target="_blank" rel="noopener" style="color:var(--text-info);text-decoration:none;font-size:12px;margin:0 4px;">' + escapeHtml(fLinks[fi].name) + '</a>';
                    }
                    ffl.innerHTML = h;
                }
            }
        }

        // 隐藏空区域
        if (!s.custom_text) { var ct = $('footerCustomText'); if (ct) ct.style.display = 'none'; }
    } catch(e) {}
}

// ============================================================
// 结束
// ============================================================
console.log('[NetworkPanel] v2.0 loaded successfully');
