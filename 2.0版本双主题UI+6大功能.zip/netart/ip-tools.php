<?php
/**
 * IP 进阶工具
 *
 * 在基础 IP 归属查询之上，提供四类进阶诊断能力：
 *  1. 多地 IP 一致性对比 —— 多源归属交叉验证（识别代理 / VPN / Anycast）
 *  2. CDN / 云厂商识别 —— 基于 ASN 推断 CDN 加速、云厂商或运营商
 *  3. 延迟探测（Ping）—— 基于 TCP 连接的端口可达性与耗时
 *  4. 多解析器 DNS 对比 —— 多公共 DoH 解析结果差异（DNS 泄漏 / 分地区解析）
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/layout.php';

render_page_header([
    'title' => 'IP 进阶工具',
    'subtitle' => '多地一致性 · CDN 识别 · 延迟探测 · 多解析器 DNS 对比',
    'description' => 'IP 进阶诊断工具集：多地归属一致性对比、CDN/云厂商识别、TCP 延迟探测（Ping）、多解析器 DNS 对比，识别代理/VPN/Anycast/CDN 调度。',
    'active' => 'tools',
]);
?>

<!-- 1. 多地 IP 一致性对比 -->
<div class="np-card">
    <h2 class="np-card-title">🌐 多地 IP 一致性对比</h2>
    <p class="np-card-desc">同时查询多个数据源的归属信息，对比国家 / 地区 / ASN 是否一致。出现差异通常意味着代理、VPN、Anycast 或多出口。</p>

    <form class="np-input-group" id="consistencyForm" autocomplete="off">
        <input class="np-input" type="text" id="consistencyInput" name="target"
               placeholder="IP 或域名，例如 8.8.8.8 / example.com（留空查本机）"
               maxlength="253" spellcheck="false">
        <button class="np-btn np-btn-primary" type="submit">对比</button>
    </form>

    <div class="np-result" id="consistencyResult" hidden>
        <div class="np-badge-row" id="consistencyBadge"></div>
        <div class="np-table-wrap">
            <table class="np-table">
                <thead>
                    <tr><th>数据源</th><th>国家</th><th>地区</th><th>ASN</th><th>运营商</th></tr>
                </thead>
                <tbody id="consistencyBody"></tbody>
            </table>
        </div>
        <p class="np-note" id="consistencyNote"></p>
    </div>
</div>

<!-- 2. CDN / 云厂商识别 -->
<div class="np-card">
    <h2 class="np-card-title">🛰️ CDN / 云厂商识别</h2>
    <p class="np-card-desc">输入 IP 或域名，根据 ASN 与归属信息推断其是否部署在 CDN、云厂商或骨干运营商网络。</p>

    <form class="np-input-group" id="cdnForm" autocomplete="off">
        <input class="np-input" type="text" id="cdnInput" name="target"
               placeholder="IP 或域名，例如 1.1.1.1 / cloudflare.com"
               maxlength="253" spellcheck="false">
        <button class="np-btn np-btn-primary" type="submit">识别</button>
    </form>

    <div class="np-result" id="cdnResult" hidden></div>
</div>

<!-- 3. 延迟探测 -->
<div class="np-card">
    <h2 class="np-card-title">📶 延迟探测（Ping）</h2>
    <p class="np-card-desc">通过 TCP 连接探测目标端口的可达性与往返耗时（ICMP 通常被禁，故用 TCP 近似）。默认探测 80 / 443 / 53 / 22。</p>

    <form class="np-input-group" id="latencyForm" autocomplete="off">
        <input class="np-input" type="text" id="latencyInput" name="target"
               placeholder="域名或 IP，例如 example.com / 8.8.8.8"
               maxlength="253" spellcheck="false">
        <input class="np-input np-input-sm" type="text" id="latencyPorts" name="ports"
               value="80,443,53,22" maxlength="40" spellcheck="false" title="自定义端口，逗号分隔">
        <button class="np-btn np-btn-primary" type="submit">探测</button>
    </form>

    <div class="np-result" id="latencyResult" hidden></div>
</div>

<!-- 4. 多解析器 DNS 对比 -->
<div class="np-card">
    <h2 class="np-card-title">🔎 多解析器 DNS 对比</h2>
    <p class="np-card-desc">通过 Cloudflare / Google / Aliyun 三个公共 DoH 解析器查询同一域名的 A 记录，对比差异（可识别分地区解析、CDN 调度或 DNS 泄漏）。</p>

    <form class="np-input-group" id="dnsForm" autocomplete="off">
        <input class="np-input" type="text" id="dnsInput" name="target"
               placeholder="域名，例如 example.com"
               maxlength="253" spellcheck="false">
        <button class="np-btn np-btn-primary" type="submit">对比</button>
    </form>

    <div class="np-result" id="dnsResult" hidden>
        <div class="np-badge-row" id="dnsBadge"></div>
        <div class="np-table-wrap">
            <table class="np-table">
                <thead>
                    <tr><th>解析器</th><th>A 记录</th><th>状态</th></tr>
                </thead>
                <tbody id="dnsBody"></tbody>
            </table>
        </div>
        <p class="np-note" id="dnsNs"></p>
        <p class="np-note" id="dnsNote"></p>
    </div>
</div>

<?php
render_page_footer(['scripts' => ['./js/ip-tools.js']]);
