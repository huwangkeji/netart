<?php
/**
 * 字节单位转换工具
 *
 * 支持 B / KB / MB / GB / TB / PB 互转（1024 进制），
 * 同时给出全部单位下的换算结果。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/units.php';

$units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
$unitLabels = [
    'B' => '字节 (B)',
    'KB' => '千字节 (KB)',
    'MB' => '兆字节 (MB)',
    'GB' => '吉字节 (GB)',
    'TB' => '太字节 (TB)',
    'PB' => '拍字节 (PB)',
];

render_page_header([
    'title' => '字节转换工具',
    'subtitle' => 'B / KB / MB / GB / TB / PB 单位互转，1024 进制',
    'description' => '在线字节单位换算工具，支持 B、KB、MB、GB、TB、PB 互转，并一次性给出全部单位结果。',
    'active' => 'tools',
]);
?>

<div class="np-card">
    <h2 class="np-card-title">🔄 双向转换</h2>
    <p class="np-card-desc">输入数值后自动换算，可点击「⇄」交换源单位与目标单位。</p>

    <div class="np-grid np-grid-3">
        <div class="np-field" style="margin-bottom:0;">
            <label class="np-label" for="fromValue">输入值</label>
            <input class="np-input" type="number" id="fromValue" value="1" min="0" step="any" inputmode="decimal">
        </div>
        <div class="np-field" style="margin-bottom:0;">
            <label class="np-label" for="fromUnit">源单位</label>
            <select class="np-select" id="fromUnit">
                <?php foreach ($units as $unit): ?>
                    <option value="<?= e($unit) ?>"<?= $unit === 'MB' ? ' selected' : '' ?>><?= e($unitLabels[$unit]) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="np-field" style="margin-bottom:0;">
            <label class="np-label" for="toUnit">目标单位</label>
            <div class="np-input-group">
                <select class="np-select" id="toUnit">
                    <?php foreach ($units as $unit): ?>
                        <option value="<?= e($unit) ?>"<?= $unit === 'GB' ? ' selected' : '' ?>><?= e($unitLabels[$unit]) ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="np-btn" type="button" id="swapBtn" title="交换单位" aria-label="交换单位">⇄</button>
            </div>
        </div>
    </div>

    <div class="np-field" style="margin-top:16px;margin-bottom:0;">
        <label class="np-label" for="toValue">换算结果</label>
        <div class="np-input-group">
            <input class="np-input" type="text" id="toValue" readonly value="-">
            <button class="np-btn" type="button" id="btnCopyResult">复制</button>
        </div>
        <p class="np-hint" id="convertHint">1 MB = 0.0009765625 GB</p>
    </div>
</div>

<div class="np-card">
    <h2 class="np-card-title">📊 全部单位结果</h2>
    <p class="np-card-desc">同一数值在 6 种单位下的精确值（最多保留 6 位小数）。</p>

    <div class="np-grid np-grid-6">
        <?php foreach ($units as $unit): ?>
            <div class="np-stat">
                <div class="np-stat-label"><?= e($unit) ?></div>
                <div class="np-stat-value" id="result-<?= e($unit) ?>">-</div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="np-alert np-alert-danger" id="convertError" hidden style="margin-top:14px;"></div>
</div>

<div class="np-card">
    <h2 class="np-card-title">ℹ️ 换算说明</h2>
    <ul style="margin:0;padding-left:22px;color:var(--np-text-secondary);font-size:14px;line-height:1.9;">
        <li>存储单位按 <strong>1024 进制</strong>：1 KB = 1024 B，1 MB = 1024 KB，依此类推。</li>
        <li>硬盘厂商常用 1000 进制标注容量，因此标称 1 TB 硬盘在系统中约显示为 931 GB。</li>
        <li>数值过大或过小时自动使用科学计数法，避免精度丢失。</li>
    </ul>
</div>

<?php
render_page_footer(['scripts' => ['./js/byte.js']]);
