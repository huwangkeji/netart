<?php
/**
 * NAT 类型在线检测（专业版报告）
 *
 * 检测原理：WebRTC / ICE 借助公共 STUN 节点观测「公网映射行为」，
 * 在【同一条连接、同一个本地 UDP 端口】上向多个探测目标发起请求，
 * 比较各目标返回的映射端点是否一致，据此判定映射行为（EIM / ADM / APDM），
 * 再结合服务端出口 IP（api/nat.php）做交叉校验。
 *
 * 诚实边界：浏览器无法发送 RFC 3489/5780 的 CHANGE-REQUEST，也无法让外部
 * 主机主动向映射端口回连，因此「过滤行为（Filtering）」「Hairpinning」
 * 「TCP 映射行为」在本页一律标注为未知，不做推测性结论。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/layout.php';

render_page_header([
    'title'    => 'NAT 类型在线检测',
    'subtitle' => '同端口多目标映射采样 + 出口交叉校验，输出带原始数据与判定依据的 NAT 行为报告',
    'active'   => 'nat',
    'css'      => ['./css/nat.css'],
]);
?>
<!-- ==================== 顶部：标题与操作 ==================== -->
<section class="np-card nat-hero">
    <div class="nat-hero-text">
        <h2 class="nat-hero-title">NAT 类型在线检测</h2>
        <p class="nat-hero-desc">
            在<strong>同一条 WebRTC 连接、同一个本地 UDP 端口</strong>上，向多个独立 STUN 目标发起请求，
            比较各目标观测到的公网映射端点是否一致，据此判定映射行为（EIM / ADM / APDM）并推定 NAT 类型；
            再与服务端出口 IP 交叉校验以识别 CGNAT、多出口等情况。
        </p>
        <div class="nat-hero-actions">
            <button class="np-btn np-btn-primary" id="btnStartNat" type="button">开始检测</button>
            <span class="nat-pill" id="natStatusPill">未开始</span>
            <span class="nat-pill nat-pill-muted" id="natConfidence">可信度：—</span>
        </div>
        <p class="nat-note">
            检测全程在浏览器本地完成，HTTP 回显仅用于校验当前访问出口 IP，
            <strong>不上传任何 ICE candidate</strong>。
        </p>
    </div>
    <div class="nat-hero-art" aria-hidden="true">
        <svg viewBox="0 0 220 160" width="100%" height="100%">
            <defs>
                <linearGradient id="natGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#5668EE"/>
                    <stop offset="1" stop-color="#7b8bff"/>
                </linearGradient>
            </defs>
            <rect x="10" y="62" width="52" height="36" rx="8" fill="url(#natGrad)" opacity="0.92"/>
            <text x="36" y="85" fill="#fff" font-size="12" text-anchor="middle" font-family="sans-serif">LAN</text>
            <rect x="70" y="58" width="54" height="44" rx="8" fill="#dde2ff"/>
            <text x="97" y="76" fill="#3c4bbf" font-size="11" text-anchor="middle" font-family="sans-serif">NAT</text>
            <text x="97" y="92" fill="#5b66c9" font-size="9" text-anchor="middle" font-family="sans-serif">:51652</text>
            <g font-family="sans-serif" font-size="9" fill="#5b6270">
                <rect x="152" y="8"  width="60" height="26" rx="7" fill="#eef0f4"/><text x="182" y="25" text-anchor="middle">STUN A</text>
                <rect x="152" y="48" width="60" height="26" rx="7" fill="#eef0f4"/><text x="182" y="65" text-anchor="middle">STUN B</text>
                <rect x="152" y="88" width="60" height="26" rx="7" fill="#eef0f4"/><text x="182" y="105" text-anchor="middle">STUN C</text>
                <rect x="152" y="128" width="60" height="26" rx="7" fill="#eef0f4"/><text x="182" y="145" text-anchor="middle">STUN D</text>
            </g>
            <g stroke="#5668EE" stroke-width="2" fill="none">
                <path d="M124 74 C140 60 142 26 152 21"/>
                <path d="M124 78 C140 70 142 61 152 61"/>
                <path d="M124 82 C140 90 142 99 152 101"/>
                <path d="M124 86 C140 100 142 138 152 141"/>
            </g>
            <g fill="#f5a623">
                <circle cx="152" cy="21" r="3.2"/><circle cx="152" cy="61" r="3.2"/>
                <circle cx="152" cy="101" r="3.2"/><circle cx="152" cy="141" r="3.2"/>
            </g>
        </svg>
    </div>
</section>

<!-- ==================== 检测结果总览 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#128202; 检测结果</h2>

    <div class="nat-verdict">
        <div class="nat-verdict-main">
            <div class="nat-result-type nat-result-wait" id="natResultType">等待检测</div>
            <div class="nat-result-sub" id="natResultSub">
                点击「开始检测」后，浏览器会在同一连接内以同一本地端口向多个 STUN 目标发起探测，
                并据此给出映射行为判定与原始数据。
            </div>
            <div class="nat-verdict-meta">
                <span class="nat-chip nat-chip-info" id="natResultTag">—</span>
                <span class="nat-chip nat-chip-info" id="natResultName">未判定</span>
                <span class="nat-chip nat-chip-muted" id="natMappingLabel">映射行为：待检测</span>
            </div>
        </div>
        <div class="nat-verdict-side">
            <div class="nat-kv-row"><span class="nat-kv-label">状态</span><span class="nat-kv-value" id="statStatus">未开始</span></div>
            <div class="nat-kv-row"><span class="nat-kv-label">可信度</span><span class="nat-kv-value" id="statConfidence">—</span></div>
            <div class="nat-kv-row"><span class="nat-kv-label">总耗时</span><span class="nat-kv-value nat-mono" id="statElapsed">--</span></div>
            <div class="nat-kv-row"><span class="nat-kv-label">成功轮次</span><span class="nat-kv-value nat-mono" id="statRounds">0/0</span></div>
        </div>
    </div>

    <h3 class="nat-subtitle">判定依据</h3>
    <div class="nat-chips" id="natBasisList">
        <span class="nat-chip nat-chip-muted">尚未采样</span>
    </div>
    <p class="nat-note" id="confReason">可信度依据：尚未开始检测。</p>

    <h3 class="nat-subtitle">映射采样统计</h3>
    <div class="np-grid np-grid-4 nat-stats">
        <div class="np-stat"><div class="np-stat-label">公网映射端点</div><div class="np-stat-value nat-mono" id="statEndpoints">0</div></div>
        <div class="np-stat"><div class="np-stat-label">公网映射地址</div><div class="np-stat-value nat-mono" id="statMappedIps">0</div></div>
        <div class="np-stat"><div class="np-stat-label">STUN 映射候选</div><div class="np-stat-value nat-mono" id="statSrflxCands">0</div></div>
        <div class="np-stat"><div class="np-stat-label">本地候选</div><div class="np-stat-value nat-mono" id="statLocalCands">0</div></div>
        <div class="np-stat"><div class="np-stat-label">TCP 候选</div><div class="np-stat-value nat-mono" id="statTcpCands">0</div></div>
    </div>
</section>

<!-- ==================== 公网出口与映射行为 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#128268; 公网出口与映射行为（交叉校验）</h2>
    <div class="np-grid np-grid-3 nat-cross">
        <div class="np-stat">
            <div class="np-stat-label">HTTP 出口 IP（服务端观测）</div>
            <div class="np-stat-value nat-mono" id="crossHttpIp">--</div>
        </div>
        <div class="np-stat">
            <div class="np-stat-label">STUN 公网映射地址</div>
            <div class="np-stat-value nat-mono" id="crossStunIp">--</div>
        </div>
        <div class="np-stat">
            <div class="np-stat-label">上游网络线索</div>
            <div class="np-stat-value nat-clue" id="crossClue">--</div>
        </div>
    </div>
    <p class="nat-note" id="crossEnv">运行环境：待检测。</p>
    <p class="nat-note">
        说明：HTTP 出口 IP 为服务端在传输层观测到的客户端地址，可能已被反向代理改写；
        STUN 映射地址为 UDP 出口侧 NAT 分配的公网端点。二者不一致通常指向多层 NAT、CGNAT 地址池或多出口负载均衡。
    </p>
</section>

<!-- ==================== 映射行为分析 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#128209; 映射行为分析</h2>
    <p class="nat-note">
        每一轮采样都在<strong>同一条连接</strong>内完成，因此轮内所有探测共用同一个本地 UDP 端口；
        「本地端口相同、映射端点却不同」只能由「映射取决于目标」解释。
    </p>
    <div class="nat-table-wrap" id="natMappingTable">
        <div class="nat-empty">暂无检测数据</div>
    </div>
    <div class="nat-note-block" id="natMappingNote">
        <p class="nat-note-line">· 等待检测。</p>
    </div>
</section>

<!-- ==================== NAT 类型速览 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#128225; NAT 类型速览</h2>
    <p class="nat-note">NAT1/2/3 的映射行为相同，差异仅在过滤行为；浏览器端只能确认「锥形族」。</p>
    <div class="np-grid np-grid-3 nat-types">
        <div class="nat-type nat-type-open" id="natCard-open">
            <div class="nat-type-head"><span class="nat-type-tag">NAT0</span><span class="nat-type-rating">极佳</span></div>
            <div class="nat-type-name">开放网络 / 无 NAT</div>
            <div class="nat-type-desc">本机直接持有公网地址，未经过地址转换。外部主机可直接访问，P2P、联机、语音视频均为最佳状态。</div>
            <div class="nat-type-meta"><b>影响：</b>无连接限制</div>
            <div class="nat-type-meta"><b>建议：</b>注意主机防火墙与暴露面，只开放必要端口</div>
        </div>
        <div class="nat-type nat-type-1" id="natCard-cone">
            <div class="nat-type-head"><span class="nat-type-tag">NAT1</span><span class="nat-type-rating">极佳</span></div>
            <div class="nat-type-name">全锥（Full Cone）</div>
            <div class="nat-type-desc">同一内网端点映射到固定公网端点，且外部任意主机均可向该映射端点发包。</div>
            <div class="nat-type-meta"><b>影响：</b>P2P 下载、联机、语音通话均直连</div>
            <div class="nat-type-meta"><b>建议：</b>连接能力最强，同时暴露面也最大，建议配合主机防火墙使用</div>
        </div>
        <div class="nat-type nat-type-2" id="natCard-restricted">
            <div class="nat-type-head"><span class="nat-type-tag">NAT2</span><span class="nat-type-rating">良好</span></div>
            <div class="nat-type-name">受限锥（Restricted Cone）</div>
            <div class="nat-type-desc">映射固定；仅当内网主机先前向某外部地址发送过数据后，该地址才能回连（按 IP 限制）。</div>
            <div class="nat-type-meta"><b>影响：</b>多数应用可直连，部分联机需打洞</div>
            <div class="nat-type-meta"><b>建议：</b>一般无需处理；若个别应用失败，可开启 UPnP 或端口转发</div>
        </div>
        <div class="nat-type nat-type-3" id="natCard-port-restricted">
            <div class="nat-type-head"><span class="nat-type-tag">NAT3</span><span class="nat-type-rating">一般</span></div>
            <div class="nat-type-name">端口受限锥（Port Restricted Cone）</div>
            <div class="nat-type-desc">映射固定；回连同时受外部 IP 与端口限制（按 IP+端口过滤）。</div>
            <div class="nat-type-meta"><b>影响：</b>游戏联机与 P2P 易受影响，失败时依赖中继</div>
            <div class="nat-type-meta"><b>建议：</b>检查光猫桥接、路由器 UPnP、或申请公网 IPv4</div>
        </div>
        <div class="nat-type nat-type-4" id="natCard-symmetric">
            <div class="nat-type-head"><span class="nat-type-tag">NAT4</span><span class="nat-type-rating">较差</span></div>
            <div class="nat-type-name">对称型（Symmetric）</div>
            <div class="nat-type-desc">映射随目标地址（乃至端口）变化，同一内网端点访问不同目标会得到不同的公网端点。</div>
            <div class="nat-type-meta"><b>影响：</b>P2P 打洞最困难，联机与通话多需 TURN 中继</div>
            <div class="nat-type-meta"><b>建议：</b>优先改善为公网 IPv4 / IPv6，或使用中继与内网穿透方案</div>
        </div>
    </div>
</section>

<!-- ==================== 未测项（明确标注未知） ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#10067; 未能确认的检测项</h2>
    <p class="nat-note">
        以下项目需要服务端配合或非浏览器协议能力，纯前端检测<strong>无法给出结论</strong>，
        为避免误导，一律标注为未知，不做推测。
    </p>
    <div class="np-grid np-grid-3 nat-unknowns">
        <div class="nat-unknown">
            <div class="nat-unknown-head">
                <span class="nat-unknown-title">过滤行为（Filtering Behavior）</span>
                <span class="nat-badge nat-badge-unknown" id="filterVerdict">未知</span>
            </div>
            <p class="nat-unknown-desc">
                判定「是否接受未经请求的外来数据包」需要 STUN 服务端从<strong>另一个 IP / 端口</strong>主动回连映射端点
                （RFC 3489 Test II / III，RFC 5780 CHANGE-REQUEST）。浏览器 WebRTC 不允许构造这类请求。
            </p>
            <p class="nat-unknown-desc">
                <b>因此：</b>全锥 / 受限锥 / 端口受限锥 三条子类型在本页只做「族」级判定，不细分。
            </p>
        </div>
        <div class="nat-unknown">
            <div class="nat-unknown-head">
                <span class="nat-unknown-title">Hairpinning（回环穿透）</span>
                <span class="nat-badge nat-badge-unknown" id="hairpinVerdict">未知</span>
            </div>
            <p class="nat-unknown-desc">
                需在 NAT <strong>同一侧</strong>部署 STUN 服务端并观察内网主机能否访问本网络的公网映射地址
                （RFC 5780 Test V）。公共 STUN 节点均位于外部网络，无法用于该测试。
            </p>
            <p class="nat-unknown-desc"><b>影响：</b>决定同一 NAT 后的两台设备能否直连，影响局域网内联机与内网穿透。</p>
        </div>
        <div class="nat-unknown">
            <div class="nat-unknown-head">
                <span class="nat-unknown-title">TCP 映射与过滤行为</span>
                <span class="nat-badge nat-badge-unknown" id="tcpVerdict">未知</span>
            </div>
            <p class="nat-unknown-desc">
                浏览器仅在配置 TURN over TCP 时才会发起 TCP 中继连接，无法对任意目标发起 TCP 的 STUN 探测，
                因此本页只报告<strong>是否观察到 TCP host 候选</strong>，不对 TCP 映射行为下结论。
            </p>
            <p class="nat-unknown-desc"><b>影响：</b>部分企业网络屏蔽 UDP 后，仅 TCP 可用的场景需要单独评估。</p>
        </div>
    </div>
</section>

<!-- ==================== 原始探测数据 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#128300; 原始探测数据</h2>
    <p class="nat-note">
        每条记录对应一次 STUN Binding 请求：<code>探测目标 → 观测到的公网映射端点</code>。
        候选地址仅在浏览器本地分析，不会上传后端。
    </p>
    <div class="nat-raw" id="natRaw">
        <div class="nat-empty">暂无探测数据</div>
    </div>
</section>

<!-- ==================== 连接体验评估 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#127918; 连接体验评估</h2>
    <p class="nat-note">依据本次映射行为判定给出，仅供参考。</p>
    <div class="np-grid np-grid-4 nat-scenarios">
        <div class="nat-scenario" id="scGame">
            <div class="nat-scenario-icon">🎮</div>
            <div class="nat-scenario-name">游戏联机</div>
            <div class="nat-scenario-status" data-default="待测">待测</div>
        </div>
        <div class="nat-scenario" id="scP2p">
            <div class="nat-scenario-icon">📡</div>
            <div class="nat-scenario-name">P2P 下载</div>
            <div class="nat-scenario-status" data-default="待测">待测</div>
        </div>
        <div class="nat-scenario" id="scVideo">
            <div class="nat-scenario-icon">📹</div>
            <div class="nat-scenario-name">视频通话</div>
            <div class="nat-scenario-status" data-default="待测">待测</div>
        </div>
        <div class="nat-scenario" id="scRemote">
            <div class="nat-scenario-icon">🔧</div>
            <div class="nat-scenario-name">远程访问</div>
            <div class="nat-scenario-status" data-default="待测">待测</div>
        </div>
    </div>
</section>

<!-- ==================== 检测流程与判定规则 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#9881; 检测流程与判定规则</h2>

    <h3 class="nat-subtitle">检测流程</h3>
    <div class="nat-table-wrap">
        <table class="nat-table">
            <thead><tr><th>阶段</th><th>动作</th><th>采集到的数据</th></tr></thead>
            <tbody>
                <tr>
                    <td class="nat-mono">S0</td>
                    <td>环境检查</td>
                    <td>RTCPeerConnection 可用性、安全上下文（HTTPS / localhost）</td>
                </tr>
                <tr>
                    <td class="nat-mono">S1</td>
                    <td>本地候选枚举</td>
                    <td>host 候选 → 内网 IP / 端口；浏览器启用 mDNS 时地址被混淆为 <code>*.local</code></td>
                </tr>
                <tr>
                    <td class="nat-mono">S2</td>
                    <td><b>映射行为采样（核心）</b>：单条连接挂载全部 STUN，以同一本地端口向多个目标发 Binding 请求，重复多轮</td>
                    <td>每个目标返回的公网映射端点（IP:端口）、归属目标、协议、单轮耗时</td>
                </tr>
                <tr>
                    <td class="nat-mono">S3</td>
                    <td>出口交叉校验</td>
                    <td>服务端观测到的 HTTP 出口 IP，与 STUN 映射地址集合比对</td>
                </tr>
                <tr>
                    <td class="nat-mono">S4</td>
                    <td>判定引擎</td>
                    <td>映射行为（EIM / ADM / APDM）、端口保持、映射地址数量 → NAT 类型</td>
                </tr>
                <tr>
                    <td class="nat-mono">S5</td>
                    <td>未测项标注</td>
                    <td>过滤行为、Hairpinning、TCP 映射 → 统一标注「未知」并说明原因</td>
                </tr>
            </tbody>
        </table>
    </div>

    <h3 class="nat-subtitle">判定规则</h3>
    <div class="nat-table-wrap">
        <table class="nat-table">
            <thead><tr><th>观察到的现象（同一本地端口，多个探测目标）</th><th>映射行为</th><th>结论</th></tr></thead>
            <tbody>
                <tr><td>未收到任何 srflx 映射，且 host 候选本身是公网地址</td><td>无转换</td><td class="is-info">开放网络 / 无 NAT</td></tr>
                <tr><td>未收到任何 srflx 映射，host 候选为内网地址</td><td>未知</td><td class="is-muted">无法判定（UDP 受阻或 STUN 不可达）</td></tr>
                <tr><td>各目标返回的公网映射端点<b>完全相同</b></td><td>EIM</td><td class="is-ok">锥形族（NAT1/2/3，子类型未知）</td></tr>
                <tr><td>各目标返回的映射地址不同</td><td>ADM / APDM</td><td class="is-danger">对称型（NAT4）</td></tr>
                <tr><td>映射地址相同、但映射端口不同</td><td>APDM</td><td class="is-danger">对称型（NAT4）</td></tr>
                <tr><td>单轮内仅 1 个目标响应（样本不足）</td><td>未知</td><td class="is-muted">无法判定，需重试</td></tr>
            </tbody>
        </table>
    </div>
</section>

<!-- ==================== 边界情况与限制 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#9888; 边界情况与限制</h2>
    <div class="nat-limits">
        <div class="nat-limit">
            <div class="nat-limit-title">多层 NAT（Multi-layer NAT）</div>
            <p>光猫 + 路由器 + 代理叠加时，浏览器只能观测到<strong>最外层</strong>的映射结果。内层 NAT 的类型无法单独测量，
                因此结论代表「整条路径的等效行为」。内层为对称型、外层为锥形时，整体表现为对称型。</p>
        </div>
        <div class="nat-limit">
            <div class="nat-limit-title">运营商级 NAT / CGNAT</div>
            <p>IPv4 地址紧张，宽带、校园网、企业网与移动网络的出口普遍使用 CGNAT。
                典型特征是<strong>映射地址存在多个</strong>（地址池）或与 HTTP 出口 IP 不一致，
                往往直接表现为对称型（NAT4）或接近 NAT4 的严格环境。</p>
        </div>
        <div class="nat-limit">
            <div class="nat-limit-title">防火墙与企业策略</div>
            <p>UDP 被完全屏蔽时采集不到任何 srflx，此时<strong>无法区分「没有 NAT」与「无法探测」</strong>，本页会标注为未知。
                企业代理、SSL 检查设备也可能改写或拦截 STUN 流量，导致映射地址与真实出口不一致。</p>
        </div>
        <div class="nat-limit">
            <div class="nat-limit-title">映射地址随线路变化</div>
            <p>多 WAN、ECMP、负载均衡或 VPN 环境下，不同目标可能走不同出口，映射地址自然不同。
                这会与对称型 NAT 的现象重合，本页只能给出「映射随目标变化」的事实，无法区分是 NAT 分配策略还是路由策略所致。</p>
        </div>
        <div class="nat-limit">
            <div class="nat-limit-title">mDNS 与 IPv6 双栈</div>
            <p>现代浏览器默认用 mDNS（<code>*.local</code>）隐藏内网 IP，导致「内网 IP/端口」不可见，属于隐私保护而非故障。
                双栈环境下 host 候选可能包含公网 IPv6，此时即便 IPv4 侧存在 NAT，IPv6 侧也可能是直连。</p>
        </div>
        <div class="nat-limit">
            <div class="nat-limit-title">浏览器实现差异</div>
            <p>不同浏览器对 STUN 节点的选取、候选去重与统计字段（如映射端点的归属目标 <code>url</code>）支持程度不同。
                当归属信息缺失时，本页仍可使用「同轮端点是否一致」做判定，但无法指出是哪个目标返回了哪个端点。</p>
        </div>
    </div>
</section>

<!-- ==================== 常见问题 ==================== -->
<section class="np-card">
    <h2 class="np-card-title">&#10067; 常见问题</h2>
    <div class="nat-faq">
        <details class="nat-faq-item">
            <summary>为什么不能给出「全锥 / 受限锥 / 端口受限锥」的精确结论？</summary>
            <p>三者的<b>映射行为完全相同</b>（都是端点无关映射），差异只在<b>过滤行为</b>：
                全锥允许任意外部主机回连，受限锥只允许曾被访问过的 IP，端口受限锥还额外限制端口。
                测量过滤行为必须让服务端从另一个地址主动向映射端口发起连接，这在浏览器 WebRTC 中无法做到。
                因此本页只能确认「属于锥形族」，并明确标注子类型未知。</p>
        </details>
        <details class="nat-faq-item">
            <summary>为什么每轮采样要用同一条连接？</summary>
            <p>因为 ICE 会为每条连接分配<b>不同的本地 UDP 端口</b>。如果每个 STUN 目标各建一条连接，本地端口不同，
                映射端口自然可能不同，此时比较端口毫无意义。只有在同一连接（同一本地端口）内比较，
                「映射是否随目标变化」才是有效结论。</p>
        </details>
        <details class="nat-faq-item">
            <summary>「映射地址变化」一定是对称型 NAT 吗？</summary>
            <p>不一定。对称型 NAT 会造成映射随目标变化，但多出口路由、ECMP、VPN 或代理也会造成同样的现象。
                本页会在「上游网络线索」中标注映射地址数量与 HTTP 出口是否一致，帮助你区分，
                但最终归属仍需结合网络拓扑判断。</p>
        </details>
        <details class="nat-faq-item">
            <summary>为什么结果和某些「NAT 检测工具」不一致？</summary>
            <p>不少工具由客户端直接向自建 STUN 服务端发起 RFC 3489 全套测试（含 CHANGE-REQUEST），可以给出精细子类型；
                浏览器端受安全策略限制无法复现。若需要精确到 NAT1/2/3，建议使用本地客户端工具或自建 STUN 服务端。</p>
        </details>
        <details class="nat-faq-item">
            <summary>这个检测会收集我的数据吗？</summary>
            <p>不会。候选地址与映射结果只在浏览器本地计算与展示，不会上传；<code>api/nat.php</code> 仅回显服务端观察到的连接来源 IP，
                用于交叉校验。STUN 节点只会看到探测来源地址，这是 STUN 协议的固有行为。</p>
        </details>
    </div>
</section>

<p class="nat-disclaimer">
    说明：本页通过单个连接内的多目标 STUN 采样观测 NAT <b>映射行为</b>，并辅以 HTTP 出口交叉校验。
    浏览器无法执行完整的 STUN 变更请求或让远端主动回连，因此<b>过滤行为、Hairpinning 与 TCP 映射行为</b>均标注为未知，
    结论属于「映射行为推定」，不等同于客户端级 NAT 类型测试。
</p>

<?php
render_page_footer(['scripts' => ['./js/nat.js']]);
