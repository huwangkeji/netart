<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/site_settings.php';
require_once __DIR__ . '/includes/layout.php';

$siteName = getSiteSetting('site_name', 'NetArt 流量消耗');

// 首页「重要合规提示」与「公告提示」配置（后台可开关、自定义内容）
$hmConfig = [];
if (getSiteSetting('home_compliance_enabled', '0') === '1') {
    $text = getSiteSetting('home_compliance_text', '');
    if ($text !== '') {
        $hmConfig[] = [
            'type' => 'cs',
            'html' => base64_encode($text),
            'bg'   => getSiteSetting('home_compliance_bg', '#fff9e6'),
        ];
    }
}
if (getSiteSetting('home_notice_enabled', '0') === '1') {
    $text = getSiteSetting('home_notice_text', '');
    if ($text !== '') {
        $hmConfig[] = [
            'type' => 'nt',
            'html' => base64_encode($text),
            'bg'   => '#f0f5ff',
        ];
    }
}

render_page_header([
    'active' => 'home',
    'wide' => true,
    'body_class' => 'np-console',
    'css' => ['./css/style.css', './css/console.css', './css/aod.css'],
]);
?>
<script>
window.__HM = <?php echo json_encode($hmConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
</script>
<?php
?>

    <!-- 会话信息条：连接状态 / 出口 IP / 运行环境 / 账号 -->
    <section class="fl-card cn-session">
        <div class="cn-session-left">
            <span class="cn-status" title="与服务器连接状态"><span class="fl-pulse-dot" id="heartbeatIcon" aria-hidden="true"></span></span>
            <span class="cn-session-ip" id="displayCurrentIp">与服务器通信中</span>
            <button class="fl-btn-ghost" id="btnSearchIp" type="button" title="搜索 IP 信息" aria-label="搜索 IP 信息">
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.5-3.5"></path></svg>
            </button>
        </div>
        <div class="cn-session-mid">
            <span class="fl-chip">浏览器&nbsp;<b id="infoBrowser">-</b></span>
            <span class="fl-chip">系统&nbsp;<b id="infoOs">-</b></span>
            <span class="fl-chip">设备&nbsp;<b id="infoDevice">-</b></span>
        </div>
        <!-- 登录/注册统一入口在顶部导航（#btnLogin / #btnRegister），此处不再重复渲染；
             仅保留登录后的状态展示，避免桌面端与移动端出现重复入口。 -->
        <div class="cn-session-right" id="userStatusArea">
            <span class="cn-user-online" id="loggedUserName" style="display:none;">在线</span>
            <a class="fl-btn-ghost" href="./user/center.php" id="memberLink" style="display:none;">已登录</a>
            <a class="fl-btn-ghost" href="#" id="btnApp" style="display:none;">下载 APP</a>
        </div>
    </section>

    <!-- 公告滚动位（后台可自定义多行，5 秒滚动） -->
    <div class="notice-bar" id="noticeBar" style="display:none;">
        <span class="notice-icon">&#128227;</span>
        <div class="notice-scroll-wrap">
            <div class="notice-scroll-inner" id="noticeScrollInner"></div>
        </div>
    </div>

    <!-- 首页动态模块挂载点（重要合规提示 / 公告提示，抗拦截） -->
    <div id="hm" style="display:none;" aria-live="polite"></div>

    <!-- 推广（广告位，后台可配置） -->
    <section class="np-card ads-panel" id="adsPanel">
        <div class="ads-panel-header">
            <span class="ads-panel-icon">&#128227;</span>
            <span class="ads-panel-title">推广</span>
        </div>
        <div class="ads-list" id="adsList">
            <div class="ads-loading">加载中...</div>
        </div>
    </section>

    <!-- 主内容区：控制台 -->
    <section class="fl-card cn-console" id="mainPanel">
        <div class="cn-card-head">
            <h2 class="cn-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12h4l3 8 4-16 3 8h4"/></svg>
                控制台
            </h2>
            <div class="cn-card-tools">
                <button class="fl-btn-ghost" type="button" id="btnEditNodes" title="自定义测速地址">自定义地址</button>
                <button class="fl-btn-ghost" type="button" id="btnCopyUrl" title="复制当前测速地址">复制链接</button>
            </div>
        </div>

        <div class="cn-field">
            <label class="cn-label" for="urlSelect">测速节点</label>
            <select class="cn-select" id="urlSelect"></select>
        </div>

        <div class="cn-field">
            <div class="cn-label-row">
                <label class="cn-label" for="threadSlider">并发线程</label>
                <span class="cn-ov-hint"><strong id="threadNumLabel">2</strong> 线程</span>
            </div>
            <input type="range" class="cn-range" id="threadSlider" min="1" max="16" value="2">
        </div>

        <div class="cn-actions">
            <button class="fl-btn-primary cn-play" id="btnPlay" type="button">开始测速</button>
            <button class="fl-btn-danger cn-play" id="btnStop" type="button" style="display:none;">停止测速</button>
            <span class="fl-spin" id="loadingSpinner" style="display:none;" aria-hidden="true"></span>
        </div>

        <div class="cn-tools">
            <button class="cn-tool-btn" id="btnToolRank" type="button" title="查看今日排行榜">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><rect x="7" y="11" width="3" height="6"/><rect x="13" y="7" width="3" height="10"/><rect x="18.5" y="13" width="0" height="0"/></svg>
                排行榜
            </button>
            <button class="cn-tool-btn" id="btnToolAod" type="button" title="进入熄屏显示（AOD）">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1111.2 3 7 7 0 0021 12.8z"/></svg>
                息屏
            </button>
            <a class="cn-tool-btn" id="btnToolUser" href="./user/center.php" title="用户中心">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>
                用户
            </a>
            <a class="cn-tool-btn" id="btnToolSettings" href="./settings.php" title="面板设置">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.6 1.6 0 00-2.7 1.1V21a2 2 0 11-4 0v-.1A1.6 1.6 0 007 19.4a1.6 1.6 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1A1.6 1.6 0 004.6 15H4.5a2 2 0 110-4h.1A1.6 1.6 0 006 9.4a1.6 1.6 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1A1.6 1.6 0 0011 4.6V4.5a2 2 0 114 0v.1A1.6 1.6 0 0017 6a1.6 1.6 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1A1.6 1.6 0 0019.4 11h.1a2 2 0 010 4z"/></svg>
                设置
            </a>
        </div>
    </section>

    <!-- 运行概览 -->
    <h3 class="cn-block-title">运行概览</h3>
    <div class="cn-overview">
        <div class="fl-stat cn-ov" id="btnPredict" role="button" tabindex="0" title="查看用量预测">
            <div class="cn-ov-label">用量预测</div>
            <div class="cn-ov-value">查看</div>
            <div class="cn-ov-hint">按当前速度估算</div>
        </div>
        <div class="fl-stat cn-ov" id="btnEditMax" role="button" tabindex="0" title="点击设置总流量上限">
            <div class="cn-ov-label">总流量上限</div>
            <div class="cn-ov-value" id="maxUseDisplay">未设置</div>
            <div class="cn-ov-hint">点击修改</div>
        </div>
        <div class="fl-stat cn-ov" id="btnEditSpeed" role="button" tabindex="0" title="点击设置带宽上限">
            <div class="cn-ov-label">带宽上限</div>
            <div class="cn-ov-value" id="maxSpeedDisplay">未设置</div>
            <div class="cn-ov-hint">点击修改</div>
        </div>
        <div class="fl-stat cn-ov">
            <div class="cn-ov-label">限额管理</div>
            <div class="limit-input-group">
                <input type="number" id="trafficLimitInput" class="limit-input" min="0" step="1" placeholder="0=不限" value="">
                <select id="trafficLimitUnit" class="limit-unit-select">
                    <option value="MB">MB</option>
                    <option value="GB" selected>GB</option>
                    <option value="TB">TB</option>
                </select>
            </div>
            <div class="cn-ov-hint" id="limitHint"></div>
        </div>
        <div class="fl-stat cn-ov has-switch">
            <div class="cn-ov-label">自动运行</div>
            <label class="cn-mini-switch"><input type="checkbox" id="switchAutoStart"><span class="track"></span></label>
        </div>
        <div class="fl-stat cn-ov has-switch">
            <div class="cn-ov-label" title="切换标签页/最小化时继续测速，不中断">后台保活</div>
            <label class="cn-mini-switch"><input type="checkbox" id="switchKeepAlive"><span class="track"></span></label>
        </div>
    </div>

    <!-- 数据统计 -->
    <h3 class="cn-block-title">数据统计</h3>
    <div class="cn-stats">
        <div class="fl-stat cn-stat">
            <div class="cn-stat-head">
                <span class="cn-stat-label">总流量</span>
            </div>
            <div class="cn-stat-value" id="allUsedValue">-</div>
        </div>
        <div class="fl-stat cn-stat">
            <div class="cn-stat-head">
                <span class="cn-stat-label" id="speedLabel">平均速度</span>
            </div>
            <div class="cn-stat-value" id="speedValue">-</div>
        </div>
        <div class="fl-stat cn-stat">
            <div class="cn-stat-head">
                <span class="cn-stat-label">实时带宽</span>
            </div>
            <div class="cn-stat-value" id="speedBitValue">-</div>
        </div>
    </div>

    <!-- IP 信息：结构化字段（IP / 归属地 / 运营商 / 连接状态）+ 多出口探测列表 -->
    <section class="fl-card cn-egress" id="ipPanel">
        <div class="cn-card-head">
            <h2 class="cn-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s7-5.6 7-11a7 7 0 10-14 0c0 5.4 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>
                IP 信息
            </h2>
            <div class="cn-card-tools">
                <select id="ipSourceSelect" class="np-ip-src-select" title="切换 IP 数据源（实时刷新归属地/运营商）">
                    <option value="">加载数据源…</option>
                </select>
                <span class="fl-chip" id="ipStateChip"><span class="cn-dot" id="ipStateDot"></span><b id="ipStateText">检测中</b></span>
                <button class="fl-btn-ghost" type="button" id="btnRefreshIp" title="重新检测 IP 信息">重新检测</button>
            </div>
        </div>

        <dl class="cn-ip-grid">
            <div class="cn-ip-item">
                <dt>IP 地址</dt>
                <dd id="ipAddr" class="cn-ip-mono">-</dd>
            </div>
            <div class="cn-ip-item">
                <dt>归属地</dt>
                <dd id="ipRegion">-</dd>
            </div>
            <div class="cn-ip-item">
                <dt>运营商</dt>
                <dd id="ipIsp">-</dd>
            </div>
            <div class="cn-ip-item">
                <dt>连接状态</dt>
                <dd id="ipStatus">检测中…</dd>
            </div>
        </dl>

        <div class="cn-sub-title">出口探测</div>
        <div class="cn-egress-list" id="ipInfoContent">
            <div class="ip-loading">正在加载...</div>
        </div>
    </section>

    <!-- 实时图表 -->
    <section class="fl-card cn-chart">
        <div class="cn-card-head">
            <h2 class="cn-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/></svg>
                实时图表
            </h2>
            <div class="cn-card-tools">
                <span class="fl-chip" id="chartChip"><span class="cn-dot" id="chartChipDot"></span><b id="chartChipText">等待数据</b></span>
            </div>
        </div>
        <div class="chart-container" id="chartContainer"></div>
        <div class="cn-chart-state" id="chartState">暂无数据，点击上方「开始测速」后显示实时速度曲线</div>
    </section>

    <!-- 今日排行榜 -->
    <section class="fl-card cn-rank">
        <div class="cn-card-head">
            <h2 class="cn-card-title">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0V4z"/><path d="M17 5h3v2a3 3 0 01-3 3M7 5H4v2a3 3 0 003 3"/></svg>
                今日排行榜
            </h2>
            <div class="cn-card-tools">
                <a class="fl-btn-ghost" href="./rank.php">完整榜单</a>
            </div>
        </div>
        <div id="todayRankList"></div>
    </section>

    <!-- 底部区域：友情链接 -->
    <section class="fl-card cn-links friend-links-card">
        <h2 class="cn-card-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.5-1.5"/></svg>
            友情链接
        </h2>
        <div class="friend-links-body" id="friendLinksBody">
            <a href="#" target="_blank" rel="noopener" class="friend-link-item" data-fl>示例链接1</a>
            <span class="fl-sep">/</span>
            <a href="#" target="_blank" rel="noopener" class="friend-link-item" data-fl>示例链接2</a>
        </div>
    </section>

    <!-- 页脚由 render_page_footer() 统一输出 -->

    <!-- 弹窗：自定义地址 -->
    <dialog class="modal" id="modalCustomNodes">
        <div class="modal-header">
            <h3>自定义地址</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <div id="customNodesList"></div>
            <button class="btn-primary full-width" id="btnAddNode">添加地址</button>
        </div>
    </dialog>

    <!-- 弹窗：添加链接 -->
    <dialog class="modal" id="modalAddNode">
        <div class="modal-header">
            <h3>添加链接</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <form id="addNodeForm">
                <div class="form-group">
                    <label>名称:</label>
                    <input type="text" id="nodeName" placeholder="输入节点名称" required>
                </div>
                <div class="form-group">
                    <label>URL:</label>
                    <input type="text" id="nodeUrl" placeholder="https://..." required pattern="https?://.+">
                </div>
            </form>
            <div class="alert alert-warning">
                <strong>注意：</strong><br>
                以下情况你将无法正常使用链接<br>
                1. 你使用https协议打开本站，但是url是http协议<br>
                2. 目标服务器返回的Access-Control-Allow-Origin响应头没有允许本站
            </div>
            <div class="alert alert-error">
                <strong>免责声明：</strong><br>
                请勿用于非法用途，使用本功能造成的一切后果由用户承担
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-default" data-close>取消</button>
            <button class="btn-primary" id="btnConfirmAdd">确认</button>
        </div>
    </dialog>

    <!-- 弹窗：设置流量上限 -->
    <dialog class="modal modal-sm" id="modalMaxUse">
        <div class="modal-header">
            <h3>设置上限自动停止</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <div class="input-group">
                <input type="number" id="maxUseInput" min="1" placeholder="留空则无上限">
                <select id="maxUseUnit">
                    <option value="MB">MB</option>
                    <option value="GB" selected>GB</option>
                    <option value="TB">TB</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-default" data-close>取消</button>
            <button class="btn-primary" id="btnConfirmMaxUse">确定</button>
        </div>
    </dialog>

    <!-- 弹窗：设置带宽上限 -->
    <dialog class="modal modal-sm" id="modalMaxSpeed">
        <div class="modal-header">
            <h3>设置带宽上限</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <div class="input-group">
                <input type="number" id="maxSpeedInput" min="1" placeholder="留空则无上限">
                <select id="maxSpeedUnit">
                    <option value="Mbps" selected>Mbps</option>
                    <option value="Gbps">Gbps</option>
                </select>
            </div>
            <div class="alert alert-warning">
                注意：<br>浏览器会使用缓存策略<br>只能限制平均速度，无法限制峰值速度!
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-default" data-close>取消</button>
            <button class="btn-primary" id="btnConfirmMaxSpeed">确定</button>
        </div>
    </dialog>

    <!-- 用量预测弹窗 -->
    <dialog class="modal modal-sm" id="modalPredict">
        <div class="modal-header">
            <h3>用量预测</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body predict-body">
            <p>每分钟&nbsp;&nbsp;<span id="predictMin">-</span></p>
            <p>每小时&nbsp;&nbsp;<span id="predictHour">-</span></p>
            <p>每天&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="predictDay">-</span></p>
            <p>每月&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span id="predictMon">-</span></p>
            <div class="predict-tip" id="predictTip">暂无采样数据。用量预测基于实时测速速度推算，请先点击「开始测速」。</div>
        </div>
    </dialog>

    <!-- 排行榜弹窗 -->
    <dialog class="modal modal-lg" id="modalRank">
        <div class="modal-header">
            <h3>排行榜</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body rank-body">
            <div class="rank-filters">
                <div class="filter-group">
                    <label><input type="radio" name="sortBy" value="allUsed" checked> 总流量</label>
                    <label><input type="radio" name="sortBy" value="averageSpeed"> 平均速度</label>
                    <label><input type="radio" name="sortBy" value="onlineTime"> 在线时长</label>
                </div>
                <div class="filter-group">
                    <label><input type="radio" name="grade" value="3" checked> 小时</label>
                    <label><input type="radio" name="grade" value="2"> 天</label>
                    <label><input type="radio" name="grade" value="1"> 月</label>
                    <label><input type="radio" name="grade" value="0"> 年</label>
                    <label><input type="checkbox" id="isPast"> 上个统计周期</label>
                </div>
            </div>
            <table class="rank-table" id="rankTable">
                <thead><tr><th>#</th><th>用户</th><th data-col></th><th>属地</th></tr></thead>
                <tbody id="rankBody"><tr><td colspan="4">加载中...</td></tr></tbody>
            </table>
            <a class="fl-btn-primary full-width" href="./user/center.php" style="margin-top:14px;">用户中心</a>
        </div>
    </dialog>

    <!-- 登录/注册弹窗 -->
    <dialog class="modal modal-sm" id="modalAuth">
        <div class="modal-header">
            <h3 id="authTitle">登录</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <!-- Tab切换栏 -->
            <div class="auth-tab-bar">
                <button class="auth-tab active" data-auth-tab="loginTab" id="authLoginTab">登录</button>
                <button class="auth-tab" data-auth-tab="registerTab" id="authRegTab">注册</button>
            </div>

            <!-- 登录表单 -->
            <div id="loginTab" class="auth-tab-panel">
                <form onsubmit="return false;">
                    <div class="form-group"><label>用户名 / 邮箱</label><input type="text" id="authUser" placeholder="输入用户名或邮箱" required></div>
                    <div class="form-group"><label>密码</label><input type="password" id="authPass" placeholder="输入密码" required></div>
                    <button class="btn-primary full-width" id="btnAuthLogin">登 录</button>
                    <p class="auth-msg" id="authLoginMsg"></p>
                </form>
                <div class="auth-foot">
                    <a class="auth-link" href="./user/forgot.php">忘记密码？</a>
                    <span class="auth-tip">还没有账号？<a class="auth-link" href="./user/register.php">立即注册</a></span>
                </div>
            </div>

            <!-- 注册表单 -->
            <div id="registerTab" class="auth-tab-panel" style="display:none;">
                <form onsubmit="return false;">
                    <div class="form-group"><label>用户名 (2~20位)</label><input type="text" id="regUserInput" placeholder="支持中英文数字下划线" required pattern="[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}"></div>
                    <div class="form-group"><label>邮箱 (可选)</label><input type="email" id="regEmailInput"></div>
                    <div class="form-group"><label>密码 (&ge;6位)</label><input type="password" id="regPassInput" placeholder="至少6位" required minlength="6"></div>
                    <div class="form-group"><label>确认密码</label><input type="password" id="regPassConfirm" required minlength="6"></div>
                    <button class="btn-primary full-width" id="btnAuthRegister">注 册</button>
                    <p class="auth-msg" id="authRegMsg"></p>
                </form>
            </div>
        </div>
    </dialog>

    <!-- 找回密码弹窗 -->
    <dialog class="modal modal-sm" id="modalResetPwd">
        <div class="modal-header">
            <h3>找回密码</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <form onsubmit="return false;">
                <div class="form-group"><label>注册邮箱</label><input type="email" id="resetEmailInput" placeholder="请输入注册时使用的邮箱"></div>
                <button class="btn-primary full-width" id="btnSendReset">发送重置邮件</button>
                <p class="auth-msg" id="resetMsg"></p>
            </form>
        </div>
    </dialog>

    <!-- 公告弹窗 -->
    <dialog class="modal announcement-modal" id="modalAnnouncement">
        <div class="modal-header">
            <h3 id="announcementModalTitle">公告</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body announcement-body" id="announcementModalBody"></div>
        <div class="modal-footer announcement-footer">
            <label class="announcement-dont-show">
                <input type="checkbox" id="announcementDontShow">
                <span>今天不再显示</span>
            </label>
            <button class="btn-primary" id="btnAnnouncementOk">知道了</button>
        </div>
    </dialog>

    <!-- 关于弹窗 -->
    <dialog class="modal modal-sm" id="modalAbout">
        <div class="modal-header">
            <h3>关于</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body about-body">
            <h2>网络面板</h2>
            <p>作者：<a href="https://netart.cn/" target="_blank">Whoami</a></p>
            <p>开源地址：
                <a href="https://github.com/ljxi/NetworkPanel" target="_blank">NetworkPanel</a>
                <a href="https://github.com/ljxi/GeoCN" target="_blank">GeoCN</a>
            </p>
            <hr>
            <h3>疑问解答</h3>
            <div class="qa-item">
                <p class="ask">问：能否添加xxx功能？</p>
                <p class="answer">答：有合理的建议请联系作者</p>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-primary" data-close>关闭</button>
        </div>
    </dialog>

    <!-- 全屏模式覆盖层 -->
    <div class="fullscreen-overlay" id="fullscreenOverlay" style="display:none;">
        <div class="fullscreen-content">
            <div class="fs-left">
                <div class="fs-title">NetworkPanel</div>
                <div class="fs-time" id="fsTime">00:00</div>
                <div class="fs-date" id="fsDate">2024-01-01 周一</div>
            </div>
            <div class="fs-right">
                <div class="fs-state">
                    <span class="fs-des">总流量</span><br>
                    <span class="fs-value" id="fsAllUsed">-</span><br><br>
                    <span class="fs-des" id="fsSpeedLabel">平均速度</span><br>
                    <span class="fs-value" id="fsSpeed">-</span><br><br>
                    <span class="fs-des" id="fsBandwidthLabel">平均带宽</span><br>
                    <span class="fs-value" id="fsSpeedBit">-</span>
                </div>
            </div>
        </div>
    </div>

    <!-- AOD 熄屏显示叠层（结构由 js/aod.js 复用，与设置页共用） -->
    <div id="npAod" aria-hidden="true">
        <div class="aod-container">
            <div class="aod-left">
                <div class="aod-brand" id="aodBrand">网络面板</div>
                <div class="aod-time" id="aodTime">--:--</div>
                <div class="aod-date" id="aodDate"></div>
                <div class="aod-device">
                    <span id="aodBattery">电量 --%</span>
                    <span id="aodRuntime">运行 00s</span>
                </div>
            </div>
            <div class="aod-right">
                <div class="aod-stat"><span>总流量</span><strong id="aodTraffic">—</strong></div>
                <div class="aod-stat"><span>平均速度</span><strong id="aodSpeed">—</strong></div>
                <div class="aod-stat"><span>平均带宽</span><strong id="aodBandwidth">—</strong></div>
            </div>
        </div>
        <div class="aod-custom" id="aodCustom" style="display:none;"></div>
        <div class="aod-hint">点击任意处或按 Esc 退出</div>
    </div>

    <?php
    // 注意：echarts 必须排在 app.js 之前（app.js 的 initChart() 依赖全局 echarts）
    render_page_footer(['scripts' => [
        './public/echarts.min.js',
        './js/home-modules.js',
        './js/aod.js',
        './js/app.js',
    ]]);
    ?>
