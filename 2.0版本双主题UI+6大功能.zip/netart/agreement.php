<?php
/**
 * 用户协议
 *
 * 页面内容可在后台「系统设置 → 页面管理」中自定义修改。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/page_view.php';

render_document_page('agreement');
