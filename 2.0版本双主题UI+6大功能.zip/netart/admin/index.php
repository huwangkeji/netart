<?php
require_once __DIR__ . '/../config/config.php';
function _adminGetSiteSetting($key, $default = '') {
    try { $db = getDB(); $stmt = $db->prepare("SELECT setting_value FROM site_settings WHERE setting_key=?"); $stmt->execute([$key]); return $stmt->fetchColumn() ?: $default; } catch (Exception $e) { return $default; }
}
$_adminSiteName = _adminGetSiteSetting('site_name', '网络面板');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台 - <?php echo htmlspecialchars($_adminSiteName); ?></title>
    <link rel="icon" type="image/svg+xml" href="../public/favicon.svg">
    <link rel="icon" type="image/png" sizes="144x144" href="../public/icon.png">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <!-- 登录页 -->
    <div class="login-wrapper" id="loginPage" style="display:none;">
        <div class="login-card">
            <div class="login-logo">
                <svg viewBox="0 0 1024 1024"><path d="M568.96 459.242667l144-189.205334A382.208 382.208 0 0 0 512 213.333333c-212.074667 0-384 171.925333-384 384a382.293333 382.293333 0 0 0 93.397333 251.008l-64.554666 55.808A467.584 467.584 0 0 1 42.666667 597.333333C42.666667 338.133333 252.8 128 512 128c93.098667 0 179.861333 27.093333 252.842667 73.856l75.882666-99.690667 67.541334 51.413334-273.28 359.04a149.333333 149.333333 0 1 1-66.048-53.376z m266.453333-69.056l54.357334-71.424A467.242667 467.242667 0 0 1 981.333333 597.333333c0 113.706667-40.64 221.226667-113.237333 305.728l-64.725333-55.616A382.272 382.272 0 0 0 896 597.333333c0-76.288-22.250667-147.370667-60.586667-207.146666zM512 661.333333a64 64 0 1 0 0-128 64 64 0 0 0 0 128z" fill="#5668EE"/></svg>
            </div>
            <h2>后台管理系统</h2>
            <form id="loginForm" onsubmit="return false;">
                <div class="form-group">
                    <input type="text" name="username" placeholder="管理员账号" required autocomplete="username">
                </div>
                <div class="form-group">
                    <input type="password" name="password" placeholder="密码" required autocomplete="current-password">
                </div>
                <button type="submit" class="btn-primary btn-block" id="btnLogin">登 录</button>
                <p class="login-error" id="loginError"></p>
            </form>
            <a href="../index.php" class="back-link">← 返回首页</a>
        </div>
    </div>

    <!-- 管理主界面 -->
    <div class="admin-layout" id="adminLayout" style="display:none;">
        <!-- 侧边栏 -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo-mini">NP</div>
                <span class="sidebar-title">管理后台</span>
            </div>
            <nav class="nav-menu">
                <a href="#" class="nav-item active" data-page="dashboard">
                    <span class="nav-icon">&#127968;</span><span>仪表盘</span></a>
                <a href="#" class="nav-item" data-page="nodes">
                    <span class="nav-icon">&#128267;</span><span>节点管理</span></a>
                <a href="#" class="nav-item" data-page="users">
                    <span class="nav-icon">&#128101;</span><span>会员管理</span></a>
                <a href="#" class="nav-item" data-page="settings">
                    <span class="nav-icon">&#9881;</span><span>系统设置</span></a>
                <a href="#" class="nav-item" data-page="homemodules">
                    <span class="nav-icon">&#128221;</span><span>首页模块</span></a>
                <a href="#" class="nav-item" data-page="integrations">
                    <span class="nav-icon">&#128273;</span><span>登录集成</span></a>
                <a href="#" class="nav-item" data-page="announcements">
                    <span class="nav-icon">&#128227;</span><span>公告管理</span></a>
                <a href="#" class="nav-item" data-page="ads">
                    <span class="nav-icon">&#127881;</span><span>广告管理</span></a>
                <a href="#" class="nav-item" data-page="logs">
                    <span class="nav-icon">&#128196;</span><span>操作日志</span></a>
                <a href="#" class="nav-item" data-page="speedlogs">
                    <span class="nav-icon">&#9203;</span><span>测速记录</span></a>
                <a href="#" class="nav-item" data-page="feedback">
                    <span class="nav-icon">&#128172;</span><span>用户反馈</span>
                    <span class="nav-badge" id="feedbackNavBadge" style="display:none;">0</span></a>
                <a href="#" class="nav-item" data-page="pages">
                    <span class="nav-icon">&#128220;</span><span>页面管理</span></a>
                <a href="#" class="nav-item" data-page="querylogs">
                    <span class="nav-icon">&#128270;</span><span>查询记录</span></a>
            </nav>
            <div class="sidebar-footer">
                <div class="admin-info" id="adminInfo">
                    <span class="admin-avatar">A</span>
                    <span class="admin-name">Admin</span>
                </div>
                <a href="#" class="nav-item nav-exit" id="btnLogout">
                    <span class="nav-icon">&#10140;</span><span>退出登录</span></a>
            </div>
        </aside>

        <!-- 主内容区 -->
        <main class="admin-main">
            <header class="topbar">
                <button class="menu-toggle" id="menuToggle">&#9776;</button>
                <h1 class="page-title" id="pageTitle">仪表盘</h1>
                <div class="topbar-right">
                    <span class="time-display" id="clockDisplay"></span>
                </div>
            </header>

            <!-- 仪表盘页面 -->
            <section class="page-content active" id="page-dashboard">
                <div class="stat-cards">
                    <div class="stat-card stat-blue">
                        <div class="stat-icon">&#128101;</div>
                        <div class="stat-body">
                            <div class="stat-num" id="statUsers">-</div>
                            <div class="stat-label">总用户数</div>
                        </div>
                        <div class="stat-trend" id="todayUsers"></div>
                    </div>
                    <div class="stat-card stat-green">
                        <div class="stat-icon">&#128225;</div>
                        <div class="stat-body">
                            <div class="stat-num" id="statTraffic">-</div>
                            <div class="stat-label">总流量</div>
                        </div>
                    </div>
                    <div class="stat-card stat-orange">
                        <div class="stat-icon">&#128267;</div>
                        <div class="stat-body">
                            <div class="stat-num" id="statNodes">-</div>
                            <div class="stat-label">节点数</div>
                        </div>
                    </div>
                    <div class="stat-card stat-purple">
                        <div class="stat-icon">&#128202;</div>
                        <div class="stat-body">
                            <div class="stat-num" id="statTodayTraffic">-</div>
                            <div class="stat-label">今日流量</div>
                        </div>
                    </div>
                </div>
                <div class="grid-row">
                    <div class="card-panel">
                        <h3 class="panel-title">最近注册用户</h3>
                        <table class="data-table" id="recentUsersTable">
                            <thead><tr><th>用户名</th><th>邮箱</th><th>角色</th><th>注册时间</th></tr></thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="card-panel">
                        <h3 class="panel-title">最近操作日志</h3>
                        <div class="log-list" id="logList"></div>
                    </div>
                </div>
            </section>

            <!-- 节点管理页面 -->
            <section class="page-content" id="page-nodes">
                <div class="toolbar-bar">
                    <button class="btn-primary" id="btnAddNode">+ 添加节点</button>
                </div>
                <div class="card-panel">
                    <table class="data-table" id="nodeTable">
                        <thead><tr><th>ID</th><th>分组</th><th>名称</th><th>URL</th><th>类型</th><th>状态</th><th>排序</th><th>操作</th></tr></thead>
                        <tbody><tr><td colspan="8">加载中...</td></tr></tbody>
                    </table>
                </div>
            </section>

            <!-- 会员管理页面 -->
            <section class="page-content" id="page-users">
                <div class="toolbar-bar">
                    <input type="text" class="search-input" id="userSearch" placeholder="搜索用户名/邮箱...">
                    <select class="filter-select" id="userRoleFilter">
                        <option value="">全部角色</option>
                        <option value="user">普通用户</option>
                        <option value="vip">VIP会员</option>
                        <option value="admin">管理员</option>
                    </select>
                    <button class="btn-primary" id="btnSearchUser">搜索</button>
                </div>
                <div class="card-panel">
                    <table class="data-table" id="userTable">
                        <thead><tr><th>ID</th><th>用户名</th><th>邮箱</th><th>角色</th><th>状态</th><th>累计流量</th><th>注册时间</th><th>操作</th></tr></thead>
                        <tbody><tr><td colspan="8">加载中...</td></tr></tbody>
                    </table>
                    <div class="pagination" id="userPagination"></div>
                </div>
            </section>

            <!-- 系统设置页面 -->
            <section class="page-content" id="page-settings">
                <div class="settings-groups">
                    <div class="card-panel settings-group" id="settingsBasic">
                        <h3 class="panel-title">基本设置</h3>
                        <div class="setting-form" id="settingsFormBasic"></div>
                    </div>
                    <div class="card-panel settings-group" id="settingsIpSource">
                        <h3 class="panel-title">&#127760; IP 设置</h3>
                        <p style="font-size:12px;color:var(--text-secondary);margin-bottom:14px;">
                            选择本站 IP 归属查询使用的生效数据源，可手动切换至以下任意一家：uapis.cn、ip9.com.cn（快速接入）、xxapi.cn/doc/ip。切换后 IP 缓存自动刷新，立即生效。
                        </p>
                        <div class="setting-form" id="settingsFormIpSource"></div>
                        <button class="btn-primary btn-lg" id="btnSaveIpSource" style="margin-top:20px;">保存 IP 设置</button>
                    </div>
                    <div class="card-panel settings-group" id="settingsNav">
                        <h3 class="panel-title">&#128279; 顶部导航</h3>
                        <p style="font-size:12px;color:var(--text-secondary);margin-bottom:14px;">自定义首页顶部导航按钮，可增删改排序。JSON格式数组。</p>
                        <div class="setting-form" id="settingsFormNav"></div>
                    </div>
                    <div class="card-panel settings-group" id="settingsSystem">
                        <h3 class="panel-title">系统配置</h3>
                        <div class="setting-form" id="settingsFormSystem"></div>
                    </div>
                    <div class="card-panel settings-group" id="settingsFooter">
                        <h3 class="panel-title">&#127970; 底部设置</h3>
                        <p style="font-size:12px;color:var(--text-secondary);margin-bottom:14px;">自定义网站底部展示的文字、ICP备案号、友情链接和HTML代码</p>
                        <div class="setting-form" id="settingsFormFooter"></div>
                    </div>
                </div>
                <button class="btn-primary btn-lg" id="btnSaveAllSettings" style="margin-top:20px;">保存所有设置</button>
            </section>

            <!-- 首页模块设置页面 -->
            <section class="page-content" id="page-homemodules">
                <div class="card-panel settings-group" id="settingsHomepage">
                    <h3 class="panel-title">&#128221; 首页动态模块</h3>
                    <p style="font-size:12px;color:var(--text-secondary);margin-bottom:14px;">
                        配置首页展示的「重要合规提示」与「公告提示」模块。两者均可在后台一键开关、自定义内容，
                        并通过前端动态注入的方式尽量规避广告/内容过滤插件的误拦截。
                    </p>
                    <div class="setting-form" id="settingsFormHomepage"></div>
                </div>
                <button class="btn-primary btn-lg" id="btnSaveHomepageSettings" style="margin-top:20px;">保存首页模块设置</button>
            </section>

            <!-- 操作日志页面 -->
            <section class="page-content" id="page-logs">
                <div class="card-panel">
                    <table class="data-table" id="logTable">
                        <thead><tr><th>ID</th><th>管理员</th><th>操作</th><th>目标</th><th>详情</th><th>IP</th><th>时间</th></tr></thead>
                        <tbody><tr><td colspan="7">加载中...</td></td></tbody>
                    </table>
                    <div class="pagination" id="logPagination"></div>
                </div>
            </section>

            <!-- 测速记录页面 -->
            <section class="page-content" id="page-speedlogs">
                <div class="toolbar-bar">
                    <input type="text" class="search-input" id="speedLogSearch" placeholder="搜索URL/用户名/浏览器...">
                    <button class="btn-primary" id="btnSearchSpeedLog">搜索</button>
                    <span style="margin-left:auto;font-size:13px;color:var(--text-secondary);" id="speedLogTotal"></span>
                </div>
                <div class="card-panel">
                    <table class="data-table" id="speedLogTable">
                        <thead><tr><th>ID</th><th>用户</th><th>测速节点</th><th>流量消耗</th><th>时长(秒)</th><th>速度(B/s)</th><th>IP地址</th><th>浏览器</th><th>开始时间</th></tr></thead>
                        <tbody><tr><td colspan="9">加载中...</td></td></tbody>
                    </table>
                    <div class="pagination" id="speedLogPagination"></div>
                </div>
            </section>

            <!-- 用户反馈页面 -->
            <section class="page-content" id="page-feedback">
                <div class="toolbar-bar">
                    <select class="filter-select" id="feedbackStatusFilter">
                        <option value="">全部状态</option>
                        <option value="0">未读</option>
                        <option value="1">已读</option>
                        <option value="2">已处理</option>
                    </select>
                    <button class="btn-primary" id="btnSearchFeedback">筛选</button>
                    <span style="margin-left:auto;font-size:13px;color:var(--text-secondary);" id="feedbackTotal"></span>
                    <button class="btn-default" style="color:var(--danger);border-color:var(--danger);" id="btnClearFeedback" title="清空所有反馈数据">&#128465; 清空</button>
                </div>
                <div class="card-panel">
                    <table class="data-table" id="feedbackTable">
                        <thead><tr><th>ID</th><th>用户</th><th>反馈内容</th><th>状态</th><th>提交时间</th><th>操作</th></tr></thead>
                        <tbody><tr><td colspan="6">加载中...</td></tr></tbody>
                    </table>
                    <div class="pagination" id="feedbackPagination"></div>
                </div>
            </section>

            <!-- 公告管理页面 -->
            <section class="page-content" id="page-announcements">
                <div class="toolbar-bar">
                    <button class="btn-primary" id="btnAddAnnouncement">+ 添加公告</button>
                </div>
                <div class="card-panel">
                    <table class="data-table" id="announcementTable">
                        <thead><tr><th>ID</th><th>标题</th><th>内容预览</th><th>状态</th><th>弹窗展示</th><th>排序</th><th>更新时间</th><th>操作</th></tr></thead>
                        <tbody><tr><td colspan="8">加载中...</td></tr></tbody>
                    </table>
                </div>
            </section>

            <!-- 广告管理页面 -->
            <section class="page-content" id="page-ads">
                <div class="toolbar-bar">
                    <button class="btn-primary" id="btnAddAd">+ 添加广告</button>
                    <button class="btn-default" id="btnRedirectSettings" style="margin-left:8px;">跳转页配置</button>
                </div>
                <div class="card-panel">
                    <table class="data-table" id="adTable">
                        <thead><tr><th>ID</th><th>广告文字</th><th>跳转链接</th><th>文字颜色</th><th>状态</th><th>排序</th><th>更新时间</th><th>操作</th></tr></thead>
                        <tbody><tr><td colspan="8">加载中...</td></tr></tbody>
                    </table>
                </div>
            </section>

            <!-- 页面管理（用户协议 / 隐私政策） -->
            <section class="page-content" id="page-pages">
                <div class="card-panel">
                    <h3 class="panel-title">&#128220; 页面内容管理</h3>
                    <p class="editor-hint">
                        编辑《用户协议》《隐私政策》《关于我们》正文内容，保存后前台页面即时生效。支持 HTML 标签
                        （h2/h3、p、ul/li、strong、a、img 等），不安全标签与脚本会被自动过滤。
                    </p>

                    <div class="form-group">
                        <label for="pageSlugSelect">选择页面</label>
                        <select id="pageSlugSelect">
                            <option value="agreement">用户协议</option>
                            <option value="privacy">隐私政策</option>
                            <option value="about">关于我们</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="pageContentInput">页面内容（HTML）</label>
                        <textarea id="pageContentInput" rows="18" placeholder="请输入页面正文内容"></textarea>
                        <small class="editor-tip">
                            提示：使用 &lt;h2&gt; 标题可自动生成前台目录；不填写则显示系统默认模板。
                        </small>
                    </div>

                    <div class="form-group">
                        <label>前台预览</label>
                        <div id="pagePreview" class="page-editor-preview"></div>
                    </div>

                    <div class="editor-actions">
                        <button class="btn-primary" id="btnSavePage">保存内容</button>
                        <button class="btn-default" id="btnResetPage">恢复默认</button>
                        <a class="btn-default" id="btnViewPage" href="../agreement.php" target="_blank" rel="noopener">前台查看</a>
                        <span id="pageMeta" class="editor-meta"></span>
                    </div>
                </div>
            </section>

            <!-- 登录集成（第三方登录 / UCenter） -->
            <section class="page-content" id="page-integrations">
                <div class="card-panel settings-group">
                    <h3 class="panel-title">&#128273; 第三方登录（QQ / 微信扫码）</h3>
                    <p style="font-size:12px;color:var(--text-secondary);margin-bottom:14px;">
                        配置 QQ 互联与微信开放平台的 AppID / 密钥，并填写回调地址（指向 <code>user/oauth.php?action=callback&amp;provider=qq|wx</code>）。
                        开启后登录页自动显示对应扫码入口。
                    </p>
                    <div class="setting-form" id="settingsFormOAuth"></div>
                </div>

                <div class="card-panel settings-group">
                    <h3 class="panel-title">&#128279; Discuz UCenter 账号互通</h3>
                    <p style="font-size:12px;color:var(--text-secondary);margin-bottom:14px;">
                        配置 UCenter 通信地址、通信密钥与应用 ID，实现本站用户体系与 Discuz UCenter 的注册 / 登录 / 改密 / 同步互通。下方「同步策略」可逐项独立开关每一项同步行为。
                    </p>
                    <div class="setting-form" id="settingsFormUCenter"></div>
                </div>

                <button class="btn-primary btn-lg" id="btnSaveIntegrations" style="margin-top:20px;">保存登录集成设置</button>
            </section>

            <!-- 查询记录管理页面 -->
            <section class="page-content" id="page-querylogs">
                <div class="toolbar-bar">
                    <input type="text" class="search-input" id="queryLogSearch" placeholder="搜索 用户名 / IP / 查询内容...">
                    <select class="filter-select" id="queryLogTypeFilter">
                        <option value="">全部类型</option>
                        <option value="ip">IP 查询</option>
                        <option value="ip_advanced">IP 进阶</option>
                        <option value="traffic">流量计算</option>
                        <option value="byte">字节转换</option>
                        <option value="speedtest">测速</option>
                    </select>
                    <button class="btn-primary" id="btnSearchQueryLog">搜索</button>
                    <span style="margin-left:auto;font-size:13px;color:var(--text-secondary);" id="queryLogTotal"></span>
                    <button class="btn-default" style="color:var(--danger);border-color:var(--danger);" id="btnClearQueryLogs" title="清空所有查询记录">&#128465; 清空</button>
                </div>
                <div class="card-panel">
                    <table class="data-table" id="queryLogTable">
                        <thead><tr><th>ID</th><th>用户</th><th>类型</th><th>查询输入</th><th>结果摘要</th><th>IP 地址</th><th>查询时间</th><th>操作</th></tr></thead>
                        <tbody><tr><td colspan="8">加载中...</td></tr></tbody>
                    </table>
                    <div class="pagination" id="queryLogPagination"></div>
                </div>
            </section>
        </main>
    </div>

    <!-- 节点编辑弹窗 -->
    <dialog class="modal" id="modalNodeEdit">
        <div class="modal-header"><h3 id="nodeModalTitle">添加节点</h3><button class="close-btn" data-close>&times;</button></div>
        <div class="modal-body">
            <input type="hidden" id="editNodeId">
            <div class="form-group"><label>分组名称</label><input type="text" id="nodeGroup" value="默认"></div>
            <div class="form-group"><label>节点名称 *</label><input type="text" id="nodeNameInput" placeholder="如: 咪咕视频"></div>
            <div class="form-group"><label>URL *</label><textarea id="nodeUrlInput" rows="2" placeholder="https://... 或 NetworkPanelApi://..."></textarea></div>
            <div class="form-row">
                <div class="form-group flex-1"><label>URL类型</label>
                    <select id="nodeUrlType"><option value="http">HTTP直链</option><option value="api">API协议</option></select>
                </div>
                <div class="form-group flex-1"><label>排序权重</label><input type="number" id="nodeSortOrder" value="0" min="0" max="9999"></div>
            </div>
            <div class="form-group"><label>备注说明</label><input type="text" id="nodeDesc" placeholder="可选"></div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="btnCancelNode">取消</button>
            <button class="btn-primary" id="btnSaveNode">保存</button>
        </div>
    </dialog>

    <!-- 用户编辑弹窗 -->
    <dialog class="modal modal-sm" id="modalUserEdit">
        <div class="modal-header"><h3>编辑会员</h3><button class="close-btn" data-close>&times;</button></div>
        <div class="modal-body">
            <input type="hidden" id="editUserId">
            <div class="form-group"><label>用户名</label><input type="text" id="editUsername"></div>
            <div class="form-group"><label>邮箱</label><input type="email" id="editEmail" placeholder="选填"></div>
            <div class="form-group"><label>新密码</label><input type="password" id="editPassword" placeholder="不填则不修改"></div>
            <div class="form-group"><label>角色</label>
                <select id="editUserRole"><option value="user">普通用户</option><option value="vip">VIP会员</option><option value="admin">管理员</option></select>
            </div>
            <div class="form-group"><label>状态</label>
                <select id="editUserStatus"><option value="1">正常</option><option value="0">禁用</option></select>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" data-close>取消</button>
            <button class="btn-primary" id="btnSaveUser">保存</button>
        </div>
    </dialog>

    <!-- 用户详情弹窗 -->
    <dialog class="modal" id="modalUserDetail" style="max-width:700px;">
        <div class="modal-header"><h3>用户详情</h3><button class="close-btn" data-close>&times;</button></div>
        <div class="modal-body">
            <!-- 基本信息 -->
            <div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid var(--border);">
                <div style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#5668EE,#6576ff);display:flex;align-items:center;justify-content:center;color:#fff;font-size:22px;font-weight:bold;flex-shrink:0;" id="detailAvatar">U</div>
                <div>
                    <h3 style="margin:0 0 4px;font-size:20px;" id="detailUsername">-</h3>
                    <span class="tag tag-info" id="detailRoleTag">普通用户</span>
                    <span class="tag" id="detailStatusTag" style="margin-left:6px;">正常</span>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;">
                <!-- 左列：注册信息 + 账号信息 -->
                <div>
                    <h4 style="font-size:15px;margin:0 0 12px;color:var(--primary);">&#128196; 注册信息</h4>
                    <table style="width:100%;font-size:13px;">
                        <tr><td style="color:#999;padding:5px 0;width:90px;">注册时间</td><td style="padding:5px 0;" id="detailRegTime">-</td></tr>
                        <tr><td style="color:#999;padding:5px 0;">最后更新</td><td style="padding:5px 0;" id="detailUpdateTime">-</td></tr>
                        <tr><td style="color:#999;padding:5px 0;">邮箱</td><td style="padding:5px 0;" id="detailEmail">-</td></tr>
                    </table>

                    <h4 style="font-size:15px;margin:18px 0 12px;color:var(--primary);">&#128272; 账号信息</h4>
                    <table style="width:100%;font-size:13px;">
                        <tr><td style="color:#999;padding:5px 0;width:90px;">访问令牌</td><td style="padding:5px 0;"><code style="background:#f5f5f5;padding:2px 6px;border-radius:4px;font-size:11px;word-break:break-all;display:inline-block;max-width:220px;" id="detailToken">-</code> <button class="btn-default btn-sm" onclick="copyDetailToken()" style="padding:2px 8px;font-size:11px;margin-left:4px;">复制</button></td></tr>
                        <tr><td style="color:#999;padding:5px 0;">累计流量</td><td style="padding:5px 0;font-weight:600;color:var(--primary);" id="detailTotalBytes">-</td></tr>
                        <tr><td style="color:#999;padding:5px 0;">累计时长</td><td style="padding:5px 0;font-weight:600;color:var(--primary);" id="detailTotalTime">-</td></tr>
                        <tr><td style="color:#999;padding:5px 0;">最后活跃</td><td style="padding:5px 0;" id="detailLastActive">-</td></tr>
                        <tr><td style="color:#999;padding:5px 0;">登录次数</td><td style="padding:5px 0;" id="detailLoginCount">-</td></tr>
                    </table>
                </div>

                <!-- 右列：登录记录 -->
                <div>
                    <h4 style="font-size:15px;margin:0 0 12px;color:var(--primary);">&#128246; 最近登录记录</h4>
                    <div id="detailLoginLogs" style="max-height:320px;overflow-y:auto;">
                        <p style="color:#999;font-size:13px;text-align:center;padding:30px 0;">加载中...</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" data-close>关闭</button>
        </div>
    </dialog>

    <!-- 公告编辑弹窗 -->
    <dialog class="modal" id="modalAnnouncementEdit">
        <div class="modal-header"><h3 id="announcementModalTitle">添加公告</h3><button class="close-btn" data-close>&times;</button></div>
        <div class="modal-body">
            <input type="hidden" id="editAnnouncementId">
            <div class="form-group"><label>公告标题</label><input type="text" id="announcementTitle" value="公告" placeholder="留空则使用默认标题'公告'"></div>
            <div class="form-group">
                <label>公告内容（支持HTML）</label>
                <textarea id="announcementContent" rows="6" style="font-family:monospace;font-size:13px;" placeholder="输入公告内容，支持HTML标签"></textarea>
                <small style="color:var(--text-secondary);display:block;margin-top:4px">支持HTML标签，如 &lt;p style="color:#00d4ff;"&gt;蓝色文字&lt;/p&gt;</small>
            </div>
            <div class="form-row">
                <div class="form-group flex-1"><label>状态</label>
                    <select id="announcementStatus"><option value="1">启用</option><option value="0">禁用</option></select>
                </div>
                <div class="form-group flex-1"><label>弹窗展示</label>
                    <select id="announcementShowPopup"><option value="1">是</option><option value="0">否</option></select>
                </div>
                <div class="form-group flex-1"><label>排序权重</label><input type="number" id="announcementSortOrder" value="0" min="0" max="9999"></div>
            </div>
            <div class="form-group">
                <label style="color:var(--primary);font-weight:600;">内容预览</label>
                <div id="announcementPreview" style="padding:12px 16px;background:var(--bg);border-radius:8px;border:1px solid var(--border);min-height:40px;font-size:14px;line-height:1.6;"></div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" id="btnCancelAnnouncement">取消</button>
            <button class="btn-primary" id="btnSaveAnnouncement">保存</button>
        </div>
    </dialog>

    <!-- 广告编辑弹窗 -->
    <dialog class="modal" id="modalAdEdit">
        <div class="modal-header">
            <h3 id="adModalTitle">添加广告</h3>
            <button class="close-btn" data-close>&times;</button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="editAdId" value="">
            <div class="form-group">
                <label>广告文字</label>
                <input type="text" id="adTitle" placeholder="输入广告展示文字">
            </div>
            <div class="form-group">
                <label>跳转链接</label>
                <input type="text" id="adUrl" placeholder="https://example.com">
            </div>
            <div class="form-row">
                <div class="form-group flex-1">
                    <label>文字颜色</label>
                    <input type="color" id="adColor" value="#5668EE" style="height:36px;padding:2px 4px;cursor:pointer;">
                </div>
                <div class="form-group flex-1">
                    <label>状态</label>
                    <select id="adStatus">
                        <option value="1">启用</option>
                        <option value="0">禁用</option>
                    </select>
                </div>
                <div class="form-group flex-1">
                    <label>排序权重</label>
                    <input type="number" id="adSortOrder" value="0" min="0" max="9999">
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" data-close>取消</button>
            <button class="btn-primary" id="btnSaveAd">保存</button>
        </div>
    </dialog>

    <!-- 跳转页配置弹窗 -->
    <dialog class="modal" id="modalRedirectSettings">
        <div class="modal-header"><h3>跳转页配置</h3><button class="close-btn" data-close>&times;</button></div>
        <div class="modal-body">
            <div class="form-group"><label>页面标题</label><input type="text" id="redirectTitle" value="广告跳转提示"></div>
            <div class="form-group"><label>加载提示文字</label><input type="text" id="redirectLoadingText" value="广告加载中，请稍后..."></div>
            <div class="form-group">
                <label>免责声明</label>
                <textarea id="redirectDisclaimer" rows="3">本站不担保任何广告内容，网络交易请谨慎自行甄别。如遇欺诈或纠纷，请联系管理员投诉下架该广告。</textarea>
            </div>
            <div class="form-group"><label>倒计时秒数</label><input type="number" id="redirectCountdown" value="5" min="1" max="30"></div>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" data-close>取消</button>
            <button class="btn-primary" id="btnSaveRedirectSettings">保存</button>
        </div>
    </dialog>

    <!--
        自包含后台引导脚本。
        原 admin SPA 框架（js/utils.js|core.js|modules.js|content.js）在本仓库中缺失，
        导致后台（含「页面管理」编辑器、登录/布局显隐）完全无法运行。
        此处以内联方式补齐「登录态判断 / 侧边栏导航切换 / 页面内容编辑器」三块核心功能，
        不改动任何既有 HTML 结构与 CSS，仅附加行为；若后续补齐框架脚本，本段以 __NP_ADMIN_BOOT__ 幂等保底。
    -->
    <script>
    (function () {
        if (window.__NP_ADMIN_BOOT__) return;
        window.__NP_ADMIN_BOOT__ = true;

        var $ = function (id) { return document.getElementById(id); };
        var loginPage = $('loginPage'), adminLayout = $('adminLayout');

        function api(method, url, body) {
            var opts = { method: method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' } };
            if (body) opts.body = JSON.stringify(body);
            return fetch(url, opts).then(function (r) { return r.json(); });
        }
        function showLogin() { if (loginPage) loginPage.style.display = ''; if (adminLayout) adminLayout.style.display = 'none'; }
        function showAdmin() { if (loginPage) loginPage.style.display = 'none'; if (adminLayout) adminLayout.style.display = ''; }

        // 1) 登录态初始化
        api('GET', '../api/admin_auth.php?action=check')
            .then(function (d) { (d && d.status === 0) ? showAdmin() : showLogin(); })
            .catch(function () { showLogin(); });

        // 2) 登录
        var loginForm = $('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var btn = $('btnLogin'), err = $('loginError');
                if (err) err.textContent = '';
                if (btn) btn.disabled = true;
                api('POST', '../api/admin_auth.php?action=login', {
                    username: this.username.value, password: this.password.value
                }).then(function (d) {
                    if (d && d.status === 0) { showAdmin(); loadPageEditor(); }
                    else { if (err) err.textContent = (d && d.message) || '登录失败'; }
                }).catch(function () { if (err) err.textContent = '网络错误'; })
                  .then(function () { if (btn) btn.disabled = false; });
            });
        }

        // 3) 退出登录
        var btnLogout = $('btnLogout');
        if (btnLogout) btnLogout.addEventListener('click', function (e) {
            e.preventDefault();
            api('POST', '../api/admin_auth.php?action=logout').finally(showLogin);
        });

        // 4) 侧边栏导航切换
        var navItems = document.querySelectorAll('.nav-item[data-page]');
        function switchPage(page) {
            var target = $('page-' + page);
            if (!target) return;
            document.querySelectorAll('.page-content').forEach(function (s) { s.classList.remove('active'); });
            target.classList.add('active');
            navItems.forEach(function (n) { n.classList.toggle('active', n.getAttribute('data-page') === page); });
            var title = $('pageTitle');
            if (title) { var t = target.querySelector('.panel-title, h1, h2, h3'); title.textContent = t ? t.textContent : page; }
            if (page === 'pages') loadPageEditor();
        }
        navItems.forEach(function (n) {
            n.addEventListener('click', function (e) { e.preventDefault(); switchPage(n.getAttribute('data-page')); });
        });
        var menuToggle = $('menuToggle');
        if (menuToggle) menuToggle.addEventListener('click', function () {
            var sb = $('sidebar'); if (sb) sb.classList.toggle('open');
        });

        // 5) 页面内容编辑器（页面管理模块）
        var slugSelect = $('pageSlugSelect'),
            contentInput = $('pageContentInput'),
            previewEl = $('pagePreview'),
            metaEl = $('pageMeta'),
            saveBtn = $('btnSavePage'),
            resetBtn = $('btnResetPage'),
            viewLink = $('btnViewPage');
        var currentSlug = '';

        function setMeta(text, ok) {
            if (!metaEl) return;
            metaEl.textContent = text || '';
            metaEl.style.color = ok ? 'var(--success, #047857)' : 'var(--danger, #b91c1c)';
        }
        function renderPreview(html) { if (previewEl) previewEl.innerHTML = html || ''; }

        function loadPage(slug) {
            currentSlug = slug;
            setMeta('加载中…', true);
            api('GET', '../api/admin.php?action=page_get&slug=' + encodeURIComponent(slug))
                .then(function (d) {
                    if (!d || d.status !== 0 || !d.data) { setMeta('加载失败：' + ((d && d.message) || ''), false); return; }
                    if (contentInput) contentInput.value = d.data.content || '';
                    renderPreview(d.data.content || '');
                    var info = [];
                    info.push(d.data.is_custom ? '已自定义' : '默认模板');
                    if (d.data.updated_at) info.push('更新于 ' + d.data.updated_at);
                    setMeta(info.join(' · '), true);
                    if (viewLink) viewLink.href = '../' + slug + '.php';
                })
                .catch(function () { setMeta('请求异常，请重试', false); });
        }

        function loadPageEditor() {
            if (!slugSelect) return;
            if (!currentSlug) currentSlug = slugSelect.value || 'agreement';
            loadPage(currentSlug);
        }

        if (slugSelect) slugSelect.addEventListener('change', function () { loadPage(this.value); });
        if (contentInput) contentInput.addEventListener('input', function () { renderPreview(this.value); });

        if (saveBtn) saveBtn.addEventListener('click', function () {
            if (!currentSlug) { setMeta('请先选择页面', false); return; }
            setMeta('保存中…', true);
            saveBtn.disabled = true;
            api('POST', '../api/admin.php?action=page_save', { slug: currentSlug, content: contentInput ? contentInput.value : '' })
                .then(function (d) {
                    if (d && d.status === 0) { setMeta((d.message || '保存成功') + ' · 已更新', true); }
                    else { setMeta('保存失败：' + ((d && d.message) || ''), false); }
                })
                .catch(function () { setMeta('网络错误，保存失败', false); })
                .then(function () { saveBtn.disabled = false; });
        });

        if (resetBtn) resetBtn.addEventListener('click', function () {
            if (!currentSlug) return;
            if (!window.confirm('确定恢复为默认内容？当前自定义内容将被清除。')) return;
            setMeta('恢复中…', true);
            api('POST', '../api/admin.php?action=page_reset', { slug: currentSlug })
                .then(function (d) {
                    if (d && d.status === 0) { setMeta(d.message || '已恢复默认', true); loadPage(currentSlug); }
                    else { setMeta('恢复失败：' + ((d && d.message) || ''), false); }
                })
                .catch(function () { setMeta('网络错误', false); });
        });

        // 若页面管理为初始激活页则直接加载
        var pagesSection = $('page-pages');
        if (pagesSection && pagesSection.classList.contains('active')) loadPageEditor();
    })();
    </script>

    <!-- 后台功能补齐脚本（自包含，幂等保底）：设置表单渲染 / 仪表盘 / 数据表格 / 增删改 / 弹窗开关 -->
    <script>
    (function () {
        if (window.__NP_ADMIN_EXT__) return;
        window.__NP_ADMIN_EXT__ = true;

        var $ = function (id) { return document.getElementById(id); };
        function api(method, url, body) {
            var opts = { method: method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' } };
            if (body) opts.body = JSON.stringify(body);
            return fetch(url, opts).then(function (r) { return r.json(); });
        }
        function esc(s) {
            if (s === null || s === undefined) return '';
            return String(s).replace(/[&<>"']/g, function (c) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
            });
        }
        function toast(msg, type) {
            var t = $('npToast');
            if (!t) {
                t = document.createElement('div');
                t.id = 'npToast';
                t.style.cssText = 'position:fixed;top:18px;left:50%;transform:translateX(-50%);z-index:99999;padding:10px 18px;border-radius:8px;font-size:14px;box-shadow:0 6px 24px rgba(0,0,0,.2);max-width:80%;';
                document.body.appendChild(t);
            }
            t.textContent = msg;
            t.style.background = (type === 'error') ? '#ef4444' : '#10b981';
            t.style.color = '#fff';
            t.style.display = 'block';
            clearTimeout(t._t);
            t._t = setTimeout(function () { t.style.display = 'none'; }, 2600);
        }
        function formatBytes(b) {
            b = Number(b) || 0;
            if (b <= 0) return '0 B';
            if (b < 1024) return b + ' B';
            var u = ['KB', 'MB', 'GB', 'TB', 'PB']; var i = -1;
            do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
            return b.toFixed(2) + ' ' + u[i];
        }
        function roleName(r) { return (r === 'admin') ? '管理员' : (r === 'vip') ? 'VIP会员' : '普通用户'; }
        function statusName(s) { return (s == 1 || s === '1') ? '正常' : '禁用'; }
        function val(id, def) { var el = $(id); return el ? el.value : (def || ''); }
        function setVal(id, v) { var el = $(id); if (el) el.value = (v == null ? '' : v); }
        function tbodyEl(id) { var t = $(id); return t ? t.querySelector('tbody') : null; }
        function setLoading(tb, cs) { if (tb) tb.innerHTML = '<tr><td colspan="' + cs + '">加载中...</td></tr>'; }
        function setEmpty(tb, cs, msg) { if (tb) tb.innerHTML = '<tr><td colspan="' + cs + '">' + esc(msg || '暂无数据') + '</td></tr>'; }
        function errRow(tb, cs, msg) { if (tb) tb.innerHTML = '<tr><td colspan="' + cs + '">' + esc(msg || '加载失败') + '</td></tr>'; }

        // ===== Dialog helpers =====
        function openDialog(id) { var d = $(id); if (!d) return; if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else { d.setAttribute('open', ''); } }
        function closeDialog(id) { var d = $(id); if (!d) return; if (typeof d.close === 'function') d.close(); else d.removeAttribute('open'); }
        document.addEventListener('click', function (e) {
            var cl = e.target.closest ? e.target.closest('[data-close]') : null;
            if (cl) { var dlg = cl.closest('dialog'); if (dlg) closeDialog(dlg.id); }
        });

        // ===== Settings =====
        var SETTINGS_GROUPS = {
            basic: 'settingsFormBasic', header: 'settingsFormNav', system: 'settingsFormSystem',
            footer: 'settingsFormFooter', homepage: 'settingsFormHomepage', oauth: 'settingsFormOAuth',
            ucenter: 'settingsFormUCenter', advanced: 'settingsFormSystem'
        };
        function settingFieldHtml(row) {
            var key = row.setting_key;
            // IP 源由专用「IP 设置」模块管理，不在基本设置里重复渲染
            if (key === 'ip_source_active' || key === 'ip_source_uapis_token') return '';
            var val2 = row.setting_value == null ? '' : String(row.setting_value);
            var type = row.setting_type || 'string';
            var title = row.title || key;
            var desc = row.description || '';
            var label = '<label title="' + esc(desc) + '">' + esc(title) + '</label>';
            var input;
            if (type === 'bool') {
                var checked = (val2 === '1' || val2 === 'true') ? 'checked' : '';
                input = '<input type="checkbox" data-skey="' + esc(key) + '" data-stype="bool" ' + checked + '>';
            } else if (type === 'int') {
                input = '<input type="number" data-skey="' + esc(key) + '" data-stype="int" value="' + esc(val2) + '">';
            } else if (type === 'json' || type === 'text') {
                input = '<textarea data-skey="' + esc(key) + '" data-stype="' + esc(type) + '">' + esc(val2) + '</textarea>';
            } else {
                input = '<input type="text" data-skey="' + esc(key) + '" data-stype="string" value="' + esc(val2) + '">';
            }
            return '<div class="form-group">' + label + input + '</div>';
        }
        function loadAllSettings() {
            api('GET', '../api/admin.php?action=settings').then(function (d) {
                if (!d || d.status !== 0 || !d.data) return;
                var map = {};
                d.data.forEach(function (row) {
                    var cid = SETTINGS_GROUPS[row.group_name];
                    if (!cid) return;
                    (map[cid] = map[cid] || []).push(row);
                });
                Object.keys(map).forEach(function (cid) {
                    var c = $(cid); if (!c) return;
                    c.innerHTML = map[cid].map(settingFieldHtml).join('');
                });
            }).catch(function () {});
        }
        function gatherValues(containerId) {
            var c = $(containerId); if (!c) return [];
            var arr = [];
            c.querySelectorAll('[data-skey]').forEach(function (el) {
                var type = el.getAttribute('data-stype');
                var v = (type === 'bool') ? (el.checked ? '1' : '0') : el.value;
                arr.push({ key: el.getAttribute('data-skey'), value: v });
            });
            return arr;
        }
        function saveSettingsFromContainers(ids, btn) {
            var items = [];
            ids.forEach(function (id) { items = items.concat(gatherValues(id)); });
            if (!items.length) { toast('没有可保存的设置'); return; }
            if (btn) { btn.disabled = true; var old = btn.textContent; btn.textContent = '保存中...'; }
            var done = 0, errors = [];
            items.forEach(function (it) {
                api('POST', '../api/admin.php?action=setting_save', { key: it.key, value: it.value })
                    .then(function (r) { if (!r || r.status !== 0) errors.push(it.key + ':' + ((r && r.message) || '失败')); })
                    .catch(function () { errors.push(it.key + ':网络错误'); })
                    .then(function () { done++; if (done === items.length) finish(); });
            });
            function finish() {
                if (btn) { btn.disabled = false; btn.textContent = old; }
                if (errors.length) toast('部分保存失败：' + errors.join('；'), 'error');
                else toast('保存成功');
            }
        }
        function bindSaveButtons() {
            var s1 = $('btnSaveAllSettings'); if (s1) s1.addEventListener('click', function () { saveSettingsFromContainers(['settingsFormBasic', 'settingsFormNav', 'settingsFormSystem', 'settingsFormFooter'], s1); });
            var s2 = $('btnSaveHomepageSettings'); if (s2) s2.addEventListener('click', function () { saveSettingsFromContainers(['settingsFormHomepage'], s2); });
            var s3 = $('btnSaveIntegrations'); if (s3) s3.addEventListener('click', function () { saveSettingsFromContainers(['settingsFormOAuth', 'settingsFormUCenter'], s3); });
        }

        // IP 设置（基本设置 → IP 设置模块）：三家提供商下拉 + Token + 保存
        var IP_SRC_OPTIONS = [
            { key: 'uapis', label: 'UAPIS（uapis.cn）' },
            { key: 'ip9',   label: 'IP9（ip9.com.cn，快速接入）' },
            { key: 'xxapi', label: 'XXAPI（xxapi.cn/doc/ip）' }
        ];
        function loadIpSourceSettings() {
            var c = $('settingsFormIpSource'); if (!c) return;
            var opts = IP_SRC_OPTIONS.map(function (o) {
                return '<option value="' + esc(o.key) + '">' + esc(o.label) + '</option>';
            }).join('');
            c.innerHTML =
                '<div class="form-group"><label>生效 IP 数据源</label>' +
                '<select id="ipSourceSelectAdmin" class="ipsrc-select">' + opts + '</select>' +
                '<small class="editor-tip">选择本站 IP 归属查询使用的生效源，可手动切换至以上任意一家。</small></div>' +
                '<div class="form-group"><label>UAPIS Token（uapis.cn，可选）</label>' +
                '<input type="text" id="ipSourceTokenAdmin" autocomplete="off" placeholder="在 uapis.cn 后台获取的 API Token，留空则不使用该源（若已保存则保留）">' +
                '</div>';

            // 拉取当前配置回填
            api('GET', '../api/admin.php?action=settings').then(function (d) {
                if (!d || d.status !== 0 || !d.data) return;
                var map = {};
                d.data.forEach(function (r) { map[r.setting_key] = r.setting_value; });
                var sel = $('ipSourceSelectAdmin');
                if (sel && map['ip_source_active']) sel.value = map['ip_source_active'];
                var tok = $('ipSourceTokenAdmin');
                if (tok && map['ip_source_uapis_token'] != null) tok.value = map['ip_source_uapis_token'];
            }).catch(function () {});

            var btn = $('btnSaveIpSource');
            if (btn && !btn.dataset.bound) {
                btn.dataset.bound = '1';
                btn.addEventListener('click', function () {
                    var sel = $('ipSourceSelectAdmin');
                    var tok = $('ipSourceTokenAdmin');
                    if (!sel) return;
                    btn.disabled = true;
                    var old = btn.textContent;
                    btn.textContent = '保存中...';
                    var fd = new FormData();
                    fd.append('action', 'save');
                    fd.append('format', 'json');
                    fd.append('ip_source_active', sel.value);
                    fd.append('ip_source_uapis_token', tok ? tok.value : '');
                    fetch('../admin/ip_source.php', { method: 'POST', body: fd, credentials: 'same-origin' })
                        .then(function (r) { return r.json(); })
                        .then(function (j) {
                            if (j && j.status === 0) toast(j.message || 'IP 设置已保存');
                            else toast((j && j.message) || '保存失败', 'error');
                        })
                        .catch(function () { toast('保存失败，请重试', 'error'); })
                        .then(function () { btn.disabled = false; btn.textContent = old; });
                });
            }
        }

        // ===== Dashboard =====
        function loadDashboard() {
            api('GET', '../api/admin.php?action=dashboard').then(function (d) {
                if (!d || d.status !== 0 || !d.data) return;
                var s = d.data.stats || {};
                if ($('statUsers')) $('statUsers').textContent = (s.total_users != null) ? s.total_users : '-';
                if ($('statTraffic')) $('statTraffic').textContent = formatBytes(s.total_traffic || 0);
                if ($('statNodes')) $('statNodes').textContent = (s.total_nodes != null) ? s.total_nodes : '-';
                if ($('statTodayTraffic')) $('statTodayTraffic').textContent = formatBytes(s.today_traffic || 0);
                if ($('todayUsers')) $('todayUsers').textContent = ((s.today_users || 0)) + ' 今日新增';
                var tb = tbodyEl('recentUsersTable');
                if (tb) {
                    if (d.data.recent_users && d.data.recent_users.length) {
                        tb.innerHTML = d.data.recent_users.map(function (u) {
                            return '<tr><td>' + esc(u.username) + '</td><td>' + esc(u.email) + '</td><td>' + esc(roleName(u.role)) + '</td><td>' + esc(u.created_at) + '</td></tr>';
                        }).join('');
                    } else setEmpty(tb, 4, '暂无用户');
                }
                var ll = $('logList');
                if (ll) {
                    if (d.data.recent_logs && d.data.recent_logs.length) {
                        ll.innerHTML = d.data.recent_logs.map(function (l) {
                            return '<div class="log-item"><span class="log-time">' + esc(l.created_at) + '</span><span class="log-action">' + esc(l.action) + '</span><span class="log-detail">' + esc(l.detail) + '</span></div>';
                        }).join('');
                    } else ll.innerHTML = '<p class="np-empty">暂无日志</p>';
                }
            }).catch(function () {});
        }

        // ===== Generic list loader with pagination =====
        var PAGERS = {};
        function makePager(key, tbodyId, cs, loader) { PAGERS[key] = { page: 1, total: 0, limit: 20, tbodyId: tbodyId, cs: cs, loader: loader }; return PAGERS[key]; }
        function renderPager(key) {
            var p = PAGERS[key]; if (!p) return;
            var box = $(key + 'Pagination'); if (!box) return;
            var pages = Math.max(1, Math.ceil(p.total / p.limit));
            var html = '<button data-pg="prev"' + (p.page <= 1 ? ' disabled' : '') + '>上一页</button>';
            html += '<span class="page-info">第 ' + p.page + ' / ' + pages + ' 页（共 ' + p.total + ' 条）</span>';
            html += '<button data-pg="next"' + (p.page >= pages ? ' disabled' : '') + '>下一页</button>';
            box.innerHTML = html;
        }
        function fetchList(key, action, buildRow, opts) {
            opts = opts || {};
            var p = PAGERS[key]; if (!p) return;
            var tb = tbodyEl(p.tbodyId); if (!tb) return;
            setLoading(tb, p.cs);
            var url = '../api/admin.php?action=' + action + '&page=' + p.page + '&limit=' + p.limit;
            if (opts.qs) url += '&' + opts.qs();
            api('GET', url).then(function (d) {
                if (!d || d.status !== 0) { errRow(tb, p.cs, (d && d.message) || '加载失败'); return; }
                var payload = d.data || {};
                var list = payload.list || (Array.isArray(payload) ? payload : []);
                p.total = payload.total != null ? payload.total : list.length;
                if (!list.length) setEmpty(tb, p.cs, opts.empty || '暂无数据');
                else tb.innerHTML = list.map(buildRow).join('');
                renderPager(key);
                if (opts.onData) opts.onData(payload, list);
            }).catch(function () { errRow(tb, p.cs, '网络错误'); });
        }

        function loadNodes() {
            var tb = tbodyEl('nodeTable'); if (!tb) return;
            setLoading(tb, 8);
            api('GET', '../api/admin.php?action=nodes').then(function (d) {
                if (!d || d.status !== 0) { errRow(tb, 8, (d && d.message) || '加载失败'); return; }
                var list = d.data || [];
                if (!list.length) { setEmpty(tb, 8, '暂无节点'); return; }
                tb.innerHTML = list.map(function (n) {
                    return '<tr><td>' + esc(n.id) + '</td><td>' + esc(n.group_name) + '</td><td>' + esc(n.label) + '</td>' +
                        '<td class="np-url">' + esc(n.url) + '</td><td>' + esc(n.url_type) + '</td>' +
                        '<td>' + (n.status == 1 ? '启用' : '禁用') + '</td><td>' + esc(n.sort_order) + '</td>' +
                        '<td><button class="np-btn-sm" data-act="edit-node" data-id="' + esc(n.id) + '">编辑</button> ' +
                        '<button class="np-btn-sm np-danger" data-act="del-node" data-id="' + esc(n.id) + '">删除</button></td></tr>';
                }).join('');
            }).catch(function () { errRow(tb, 8, '网络错误'); });
        }
        function loadUsers() {
            fetchList('user', 'users', function (u) {
                return '<tr><td>' + esc(u.id) + '</td><td>' + esc(u.username) + '</td><td>' + esc(u.email) + '</td>' +
                    '<td>' + esc(roleName(u.role)) + '</td><td>' + esc(statusName(u.status)) + '</td>' +
                    '<td>' + formatBytes(u.total_bytes) + '</td><td>' + esc(u.created_at) + '</td>' +
                    '<td><button class="np-btn-sm" data-act="view-user" data-id="' + esc(u.id) + '">详情</button> ' +
                    '<button class="np-btn-sm" data-act="edit-user" data-id="' + esc(u.id) + '">编辑</button> ' +
                    '<button class="np-btn-sm np-danger" data-act="del-user" data-id="' + esc(u.id) + '">禁用</button></td></tr>';
            }, { cs: 8, qs: function () {
                var q = ''; var s = $('userSearch'); if (s && s.value) q += 'search=' + encodeURIComponent(s.value) + '&';
                var r = $('userRoleFilter'); if (r && r.value) q += 'role=' + encodeURIComponent(r.value) + '&'; return q;
            } });
        }
        function loadLogs() {
            fetchList('log', 'logs', function (l) {
                return '<tr><td>' + esc(l.id) + '</td><td>' + esc(l.admin_name || l.admin_id) + '</td><td>' + esc(l.action) + '</td>' +
                    '<td>' + esc(l.target_type) + (l.target_id ? ' #' + l.target_id : '') + '</td><td class="np-url">' + esc(l.detail) + '</td>' +
                    '<td>' + esc(l.ip) + '</td><td>' + esc(l.created_at) + '</td></tr>';
            }, { cs: 7 });
        }
        function loadSpeedLogs() {
            fetchList('speedLog', 'speed_logs', function (r) {
                return '<tr><td>' + esc(r.id) + '</td><td>' + esc(r.username) + '</td><td class="np-url">' + esc(r.url) + '</td>' +
                    '<td>' + formatBytes(r.bytes_used) + '</td><td>' + esc(r.duration) + 's</td><td>' + formatBytes(r.speed) + '/s</td>' +
                    '<td>' + esc(r.ip) + '</td><td class="np-url">' + esc(r.user_agent) + '</td><td>' + esc(r.created_at) + '</td></tr>';
            }, { cs: 9, qs: function () { var s = $('speedLogSearch'); return s && s.value ? 'keyword=' + encodeURIComponent(s.value) : ''; },
                onData: function (p, list) { var t = $('speedLogTotal'); if (t) t.textContent = '共 ' + (p.total || list.length) + ' 条记录'; } });
        }
        function loadFeedback() {
            fetchList('feedback', 'feedback_list', function (f) {
                var st = (f.status == 2) ? '已处理' : (f.status == 1) ? '已读' : '未读';
                return '<tr><td>' + esc(f.id) + '</td><td>' + esc(f.username) + '</td><td class="np-url">' + esc(f.content) + '</td>' +
                    '<td>' + st + '</td><td>' + esc(f.created_at) + '</td>' +
                    '<td><button class="np-btn-sm" data-act="fb-read" data-id="' + esc(f.id) + '">已读</button> ' +
                    '<button class="np-btn-sm" data-act="fb-done" data-id="' + esc(f.id) + '">已处理</button></td></tr>';
            }, { cs: 6, qs: function () { var s = $('feedbackStatusFilter'); return s && s.value !== '' ? 'status=' + encodeURIComponent(s.value) : ''; },
                onData: function (p, list) { var t = $('feedbackTotal'); if (t) t.textContent = '共 ' + (p.total || list.length) + ' 条反馈'; } });
        }
        function loadAnnouncements() {
            var tb = tbodyEl('announcementTable'); if (!tb) return;
            setLoading(tb, 8);
            api('GET', '../api/admin.php?action=announcements').then(function (d) {
                if (!d || d.status !== 0) { errRow(tb, 8, (d && d.message) || '加载失败'); return; }
                var list = d.data || [];
                if (!list.length) { setEmpty(tb, 8, '暂无公告'); return; }
                tb.innerHTML = list.map(function (a) {
                    var content = (a.content || '').replace(/<[^>]+>/g, '');
                    return '<tr><td>' + esc(a.id) + '</td><td>' + esc(a.title) + '</td><td class="np-url">' + esc(content.substring(0, 50)) + '</td>' +
                        '<td>' + (a.status == 1 ? '启用' : '禁用') + '</td><td>' + (a.show_popup == 1 ? '是' : '否') + '</td>' +
                        '<td>' + esc(a.sort_order) + '</td><td>' + esc(a.updated_at) + '</td>' +
                        '<td><button class="np-btn-sm" data-act="edit-ann" data-id="' + esc(a.id) + '">编辑</button> ' +
                        '<button class="np-btn-sm np-danger" data-act="del-ann" data-id="' + esc(a.id) + '">删除</button></td></tr>';
                }).join('');
            }).catch(function () { errRow(tb, 8, '网络错误'); });
        }
        function loadAds() {
            var tb = tbodyEl('adTable'); if (!tb) return;
            setLoading(tb, 8);
            api('GET', '../api/admin.php?action=ads').then(function (d) {
                if (!d || d.status !== 0) { errRow(tb, 8, (d && d.message) || '加载失败'); return; }
                var list = d.data || [];
                if (!list.length) { setEmpty(tb, 8, '暂无广告'); return; }
                tb.innerHTML = list.map(function (a) {
                    return '<tr><td>' + esc(a.id) + '</td><td>' + esc(a.title) + '</td><td class="np-url">' + esc(a.url) + '</td>' +
                        '<td><span style="color:' + esc(a.color || '#000') + '">●</span> ' + esc(a.color) + '</td>' +
                        '<td>' + (a.status == 1 ? '启用' : '禁用') + '</td><td>' + esc(a.sort_order) + '</td><td>' + esc(a.updated_at) + '</td>' +
                        '<td><button class="np-btn-sm" data-act="edit-ad" data-id="' + esc(a.id) + '">编辑</button> ' +
                        '<button class="np-btn-sm np-danger" data-act="del-ad" data-id="' + esc(a.id) + '">删除</button></td></tr>';
                }).join('');
            }).catch(function () { errRow(tb, 8, '网络错误'); });
        }
        function loadQueryLogs() {
            fetchList('queryLog', 'query_log_list', function (q) {
                return '<tr><td>' + esc(q.id) + '</td><td>' + esc(q.username) + '</td><td>' + esc(q.query_type) + '</td>' +
                    '<td class="np-url">' + esc(q.query_input) + '</td><td class="np-url">' + esc(q.result_summary) + '</td>' +
                    '<td>' + esc(q.ip) + '</td><td>' + esc(q.created_at) + '</td>' +
                    '<td><button class="np-btn-sm np-danger" data-act="del-ql" data-id="' + esc(q.id) + '">删除</button></td></tr>';
            }, { cs: 8, qs: function () {
                var q = ''; var s = $('queryLogSearch'); if (s && s.value) q += 'keyword=' + encodeURIComponent(s.value) + '&';
                var t = $('queryLogTypeFilter'); if (t && t.value) q += 'type=' + encodeURIComponent(t.value) + '&'; return q;
            }, onData: function (p, list) { var t = $('queryLogTotal'); if (t) t.textContent = '共 ' + (p.total || list.length) + ' 条记录'; } });
        }

        makePager('user', 'userTable', 8, loadUsers);
        makePager('log', 'logTable', 7, loadLogs);
        makePager('speedLog', 'speedLogTable', 9, loadSpeedLogs);
        makePager('feedback', 'feedbackTable', 6, loadFeedback);
        makePager('queryLog', 'queryLogTable', 8, loadQueryLogs);

        var PAGE_LOADERS = {
            nodes: loadNodes, users: loadUsers, logs: loadLogs, speedlogs: loadSpeedLogs,
            feedback: loadFeedback, announcements: loadAnnouncements, ads: loadAds, querylogs: loadQueryLogs
        };

        // ===== CRUD =====
        function handleTableAction(act, id) {
            id = parseInt(id, 10);
            switch (act) {
                case 'edit-node': editNode(id); break;
                case 'del-node': delNode(id); break;
                case 'view-user': viewUser(id); break;
                case 'edit-user': editUser(id); break;
                case 'del-user': delUser(id); break;
                case 'fb-read': setFeedback(id, 1); break;
                case 'fb-done': setFeedback(id, 2); break;
                case 'edit-ann': editAnnouncement(id); break;
                case 'del-ann': delAnnouncement(id); break;
                case 'edit-ad': editAd(id); break;
                case 'del-ad': delAd(id); break;
                case 'del-ql': delQueryLog(id); break;
            }
        }
        function bindTableActions() {
            ['nodeTable','userTable','logTable','speedLogTable','feedbackTable','announcementTable','adTable','queryLogTable'].forEach(function (tid) {
                var t = $(tid); if (!t) return;
                t.addEventListener('click', function (e) {
                    var btn = e.target.closest ? e.target.closest('[data-act]') : null;
                    if (btn) handleTableAction(btn.getAttribute('data-act'), btn.getAttribute('data-id'));
                });
            });
            ['user','log','speedLog','feedback','queryLog'].forEach(function (key) {
                var box = $(key + 'Pagination'); if (!box) return;
                box.addEventListener('click', function (e) {
                    var b = e.target.closest ? e.target.closest('[data-pg]') : null;
                    if (!b) return;
                    var p = PAGERS[key]; if (!p) return;
                    var dir = b.getAttribute('data-pg');
                    if (dir === 'prev' && p.page > 1) p.page--;
                    else if (dir === 'next') p.page++;
                    p.loader();
                });
            });
        }

        // Nodes
        function resetNodeForm() { ['editNodeId','nodeGroup','nodeNameInput','nodeUrlInput','nodeSortOrder','nodeDesc'].forEach(function (i) { setVal(i, ''); }); setVal('nodeGroup', '默认'); setVal('nodeUrlType', 'http'); setVal('nodeSortOrder', '0'); var ti = $('nodeModalTitle'); if (ti) ti.textContent = '添加节点'; }
        function editNode(id) {
            api('GET', '../api/admin.php?action=nodes&id=' + id).then(function (d) {
                if (!d || d.status !== 0 || !d.data) { toast('加载节点失败', 'error'); return; }
                var n = d.data; setVal('editNodeId', n.id); setVal('nodeGroup', n.group_name); setVal('nodeNameInput', n.label);
                setVal('nodeUrlInput', n.url); setVal('nodeUrlType', n.url_type); setVal('nodeSortOrder', n.sort_order); setVal('nodeDesc', n.description);
                var ti = $('nodeModalTitle'); if (ti) ti.textContent = '编辑节点 #' + n.id; openDialog('modalNodeEdit');
            }).catch(function () { toast('加载节点失败', 'error'); });
        }
        function delNode(id) { if (!confirm('确定删除该节点？')) return; api('POST', '../api/admin.php?action=node_delete', { id: id }).then(function (d) { toast(d && d.status === 0 ? '已删除' : ((d && d.message) || '删除失败'), d && d.status === 0 ? '' : 'error'); loadNodes(); }).catch(function () { toast('删除失败', 'error'); }); }
        function bindNodeModal() {
            var add = $('btnAddNode'); if (add) add.addEventListener('click', function () { resetNodeForm(); openDialog('modalNodeEdit'); });
            var save = $('btnSaveNode'); if (save) save.addEventListener('click', function () {
                var id = parseInt(val('editNodeId'), 10) || 0;
                var payload = { group_name: val('nodeGroup', '默认'), label: val('nodeNameInput'), url: val('nodeUrlInput'), url_type: val('nodeUrlType', 'http'), sort_order: parseInt(val('nodeSortOrder', '0'), 10) || 0, description: val('nodeDesc') };
                if (!payload.label || !payload.url) { toast('节点名称和URL不能为空', 'error'); return; }
                if (id) payload.id = id;
                save.disabled = true;
                api('POST', '../api/admin.php?action=' + (id ? 'node_edit' : 'node_add'), payload).then(function (d) {
                    toast(d && d.status === 0 ? (id ? '更新成功' : '添加成功') : ((d && d.message) || '操作失败'), d && d.status === 0 ? '' : 'error');
                    if (d && d.status === 0) { closeDialog('modalNodeEdit'); loadNodes(); }
                }).catch(function () { toast('操作失败', 'error'); }).then(function () { save.disabled = false; });
            });
        }

        // Users
        function viewUser(id) {
            api('GET', '../api/admin.php?action=user_detail&id=' + id).then(function (d) {
                if (!d || d.status !== 0 || !d.data) { toast('加载详情失败', 'error'); return; }
                var u = d.data.user || {};
                setVal('detailUsername', u.username); setVal('detailRegTime', u.created_at); setVal('detailUpdateTime', u.updated_at);
                setVal('detailEmail', u.email); setVal('detailToken', d.data.access_token); setVal('detailTotalBytes', formatBytes(u.total_bytes));
                setVal('detailTotalTime', (u.total_time || 0) + ' 秒'); setVal('detailLastActive', u.last_active); setVal('detailLoginCount', d.data.login_count);
                var rt = $('detailRoleTag'); if (rt) rt.textContent = roleName(u.role);
                var st = $('detailStatusTag'); if (st) { st.textContent = statusName(u.status); st.style.background = (u.status == 1) ? '#10b981' : '#ef4444'; st.style.color = '#fff'; }
                var av = $('detailAvatar'); if (av) av.textContent = (u.username || 'U').substring(0, 1).toUpperCase();
                var logs = $('detailLoginLogs');
                if (logs) { if (d.data.login_logs && d.data.login_logs.length) { logs.innerHTML = d.data.login_logs.map(function (l) { return '<div class="log-item"><span class="log-time">' + esc(l.time) + '</span><span>' + esc(l.ip) + '</span><span>' + esc(l.browser) + ' / ' + esc(l.os) + '</span></div>'; }).join(''); } else logs.innerHTML = '<p class="np-empty">暂无登录记录</p>'; }
                openDialog('modalUserDetail');
            }).catch(function () { toast('加载详情失败', 'error'); });
        }
        function editUser(id) {
            api('GET', '../api/admin.php?action=user_detail&id=' + id).then(function (d) {
                if (!d || d.status !== 0 || !d.data) { toast('加载用户失败', 'error'); return; }
                var u = d.data.user || {}; setVal('editUserId', u.id); setVal('editUsername', u.username); setVal('editEmail', u.email); setVal('editUserRole', u.role); setVal('editUserStatus', u.status); setVal('editPassword', '');
                openDialog('modalUserEdit');
            }).catch(function () { toast('加载用户失败', 'error'); });
        }
        function delUser(id) { if (!confirm('确定禁用该用户？')) return; api('POST', '../api/admin.php?action=user_delete', { id: id }).then(function (d) { toast(d && d.status === 0 ? '已禁用' : '操作失败', d && d.status === 0 ? '' : 'error'); loadUsers(); }).catch(function () { toast('操作失败', 'error'); }); }
        function bindUserModal() {
            var save = $('btnSaveUser'); if (save) save.addEventListener('click', function () {
                var id = parseInt(val('editUserId'), 10); if (!id) { toast('缺少用户ID', 'error'); return; }
                var payload = { id: id, username: val('editUsername'), role: val('editUserRole'), status: parseInt(val('editUserStatus'), 10) };
                var pw = val('editPassword'); if (pw) payload.password = pw;
                save.disabled = true;
                api('POST', '../api/admin.php?action=user_update', payload).then(function (d) { toast(d && d.status === 0 ? '保存成功' : '保存失败', d && d.status === 0 ? '' : 'error'); if (d && d.status === 0) { closeDialog('modalUserEdit'); loadUsers(); } }).catch(function () { toast('保存失败', 'error'); }).then(function () { save.disabled = false; });
            });
        }
        function bindUserSearch() { var b = $('btnSearchUser'); if (b) b.addEventListener('click', function () { if (PAGERS.user) PAGERS.user.page = 1; loadUsers(); }); }

        // Feedback
        function setFeedback(id, st) { api('POST', '../api/admin.php?action=feedback_set_status', { id: id, status: st }).then(function (d) { toast(d && d.status === 0 ? '状态已更新' : '操作失败', d && d.status === 0 ? '' : 'error'); loadFeedback(); }).catch(function () { toast('操作失败', 'error'); }); }
        function bindFeedback() {
            var f = $('btnSearchFeedback'); if (f) f.addEventListener('click', function () { if (PAGERS.feedback) PAGERS.feedback.page = 1; loadFeedback(); });
            var c = $('btnClearFeedback'); if (c) c.addEventListener('click', function () { if (!confirm('确定清空所有反馈？')) return; api('POST', '../api/admin.php?action=feedback_clear', {}).then(function (d) { toast(d && d.status === 0 ? '已清空' : '清空失败', d && d.status === 0 ? '' : 'error'); loadFeedback(); }).catch(function () { toast('清空失败', 'error'); }); });
        }

        // Announcements
        function resetAnnForm() { ['editAnnouncementId','announcementTitle','announcementContent','announcementSortOrder'].forEach(function (i) { setVal(i, ''); }); setVal('announcementStatus', '1'); setVal('announcementShowPopup', '1'); var ti = $('announcementModalTitle'); if (ti) ti.textContent = '添加公告'; var pv = $('announcementPreview'); if (pv) pv.innerHTML = ''; }
        function editAnnouncement(id) {
            api('GET', '../api/admin.php?action=announcements&id=' + id).then(function (d) { if (!d || d.status !== 0 || !d.data) { toast('加载失败', 'error'); return; } var a = d.data; setVal('editAnnouncementId', a.id); setVal('announcementTitle', a.title); setVal('announcementContent', a.content); setVal('announcementStatus', a.status); setVal('announcementShowPopup', a.show_popup); setVal('announcementSortOrder', a.sort_order); var ti = $('announcementModalTitle'); if (ti) ti.textContent = '编辑公告 #' + a.id; var pv = $('announcementPreview'); if (pv) pv.innerHTML = a.content || ''; openDialog('modalAnnouncementEdit'); }).catch(function () { toast('加载失败', 'error'); });
        }
        function delAnnouncement(id) { if (!confirm('确定删除该公告？')) return; api('POST', '../api/admin.php?action=announcement_delete', { id: id }).then(function (d) { toast(d && d.status === 0 ? '已删除' : '删除失败', d && d.status === 0 ? '' : 'error'); loadAnnouncements(); }).catch(function () { toast('删除失败', 'error'); }); }
        function bindAnnouncementModal() {
            var add = $('btnAddAnnouncement'); if (add) add.addEventListener('click', function () { resetAnnForm(); openDialog('modalAnnouncementEdit'); });
            var ct = $('announcementContent'); if (ct) ct.addEventListener('input', function () { var pv = $('announcementPreview'); if (pv) pv.innerHTML = ct.value; });
            var save = $('btnSaveAnnouncement'); if (save) save.addEventListener('click', function () {
                var id = parseInt(val('editAnnouncementId'), 10) || 0;
                var payload = { title: val('announcementTitle', '公告'), content: val('announcementContent'), status: parseInt(val('announcementStatus'), 10), sort_order: parseInt(val('announcementSortOrder'), 10) || 0, show_popup: parseInt(val('announcementShowPopup'), 10) };
                if (!payload.content) { toast('公告内容不能为空', 'error'); return; }
                if (id) payload.id = id; save.disabled = true;
                api('POST', '../api/admin.php?action=' + (id ? 'announcement_edit' : 'announcement_add'), payload).then(function (d) { toast(d && d.status === 0 ? (id ? '更新成功' : '添加成功') : '操作失败', d && d.status === 0 ? '' : 'error'); if (d && d.status === 0) { closeDialog('modalAnnouncementEdit'); loadAnnouncements(); } }).catch(function () { toast('操作失败', 'error'); }).then(function () { save.disabled = false; });
            });
        }

        // Ads
        function resetAdForm() { ['editAdId','adTitle','adUrl','adSortOrder'].forEach(function (i) { setVal(i, ''); }); setVal('adColor', '#5668EE'); setVal('adStatus', '1'); var ti = $('adModalTitle'); if (ti) ti.textContent = '添加广告'; }
        function editAd(id) {
            api('GET', '../api/admin.php?action=ads&id=' + id).then(function (d) { if (!d || d.status !== 0 || !d.data) { toast('加载失败', 'error'); return; } var a = d.data; setVal('editAdId', a.id); setVal('adTitle', a.title); setVal('adUrl', a.url); setVal('adColor', a.color); setVal('adStatus', a.status); setVal('adSortOrder', a.sort_order); var ti = $('adModalTitle'); if (ti) ti.textContent = '编辑广告 #' + a.id; openDialog('modalAdEdit'); }).catch(function () { toast('加载失败', 'error'); });
        }
        function delAd(id) { if (!confirm('确定删除该广告？')) return; api('POST', '../api/admin.php?action=ad_delete', { id: id }).then(function (d) { toast(d && d.status === 0 ? '已删除' : '删除失败', d && d.status === 0 ? '' : 'error'); loadAds(); }).catch(function () { toast('删除失败', 'error'); }); }
        function bindAdModal() {
            var add = $('btnAddAd'); if (add) add.addEventListener('click', function () { resetAdForm(); openDialog('modalAdEdit'); });
            var save = $('btnSaveAd'); if (save) save.addEventListener('click', function () {
                var id = parseInt(val('editAdId'), 10) || 0;
                var payload = { title: val('adTitle'), url: val('adUrl'), color: val('adColor'), status: parseInt(val('adStatus'), 10), sort_order: parseInt(val('adSortOrder'), 10) || 0 };
                if (!payload.title || !payload.url) { toast('广告文字和链接不能为空', 'error'); return; }
                if (id) payload.id = id; save.disabled = true;
                api('POST', '../api/admin.php?action=' + (id ? 'ad_edit' : 'ad_add'), payload).then(function (d) { toast(d && d.status === 0 ? (id ? '更新成功' : '添加成功') : '操作失败', d && d.status === 0 ? '' : 'error'); if (d && d.status === 0) { closeDialog('modalAdEdit'); loadAds(); } }).catch(function () { toast('操作失败', 'error'); }).then(function () { save.disabled = false; });
            });
        }

        // Query logs
        function delQueryLog(id) { if (!confirm('确定删除该记录？')) return; api('POST', '../api/admin.php?action=query_log_delete', { id: id }).then(function (d) { toast(d && d.status === 0 ? '已删除' : '删除失败', d && d.status === 0 ? '' : 'error'); loadQueryLogs(); }).catch(function () { toast('删除失败', 'error'); }); }
        function bindQueryLogs() {
            var s = $('btnSearchQueryLog'); if (s) s.addEventListener('click', function () { if (PAGERS.queryLog) PAGERS.queryLog.page = 1; loadQueryLogs(); });
            var c = $('btnClearQueryLogs'); if (c) c.addEventListener('click', function () { if (!confirm('确定清空所有查询记录？')) return; api('POST', '../api/admin.php?action=query_log_clear', {}).then(function (d) { toast(d && d.status === 0 ? '已清空' : '清空失败', d && d.status === 0 ? '' : 'error'); loadQueryLogs(); }).catch(function () { toast('清空失败', 'error'); }); });
        }

        // Redirect settings
        function bindRedirectSettings() {
            var btn = $('btnRedirectSettings'); if (btn) btn.addEventListener('click', function () {
                api('GET', '../api/admin.php?action=redirect_settings').then(function (d) { if (d && d.status === 0 && d.data) { setVal('redirectTitle', d.data.redirect_title); setVal('redirectLoadingText', d.data.redirect_loading_text); setVal('redirectDisclaimer', d.data.redirect_disclaimer); setVal('redirectCountdown', d.data.redirect_countdown); } openDialog('modalRedirectSettings'); }).catch(function () { openDialog('modalRedirectSettings'); });
            });
            var save = $('btnSaveRedirectSettings'); if (save) save.addEventListener('click', function () {
                var payload = { redirect_title: val('redirectTitle'), redirect_loading_text: val('redirectLoadingText'), redirect_disclaimer: val('redirectDisclaimer'), redirect_countdown: val('redirectCountdown') };
                save.disabled = true;
                api('POST', '../api/admin.php?action=redirect_settings_save', payload).then(function (d) { toast(d && d.status === 0 ? '保存成功' : '保存失败', d && d.status === 0 ? '' : 'error'); if (d && d.status === 0) closeDialog('modalRedirectSettings'); }).catch(function () { toast('保存失败', 'error'); }).then(function () { save.disabled = false; });
            });
        }

        // ===== Nav loaders =====
        function bindNavLoaders() {
            document.querySelectorAll('.nav-item[data-page]').forEach(function (n) {
                n.addEventListener('click', function () { var p = n.getAttribute('data-page'); if (PAGE_LOADERS[p]) PAGE_LOADERS[p](); });
            });
        }

        // ===== Boot (runs once admin layout becomes visible) =====
        function boot() {
            loadAllSettings();
            loadIpSourceSettings();
            loadDashboard();
            bindNavLoaders();
            bindSaveButtons();
            bindTableActions();
            bindNodeModal();
            bindUserModal();
            bindUserSearch();
            bindFeedback();
            bindAnnouncementModal();
            bindAdModal();
            bindQueryLogs();
            bindRedirectSettings();
        }
        function tryInit() {
            if (window.__NP_ADMIN_INITED__) return;
            var al = $('adminLayout');
            if (!al || al.style.display === 'none') return;
            window.__NP_ADMIN_INITED__ = true;
            boot();
        }
        function kickInit() {
            var n = 0;
            var iv = setInterval(function () { n++; tryInit(); if (window.__NP_ADMIN_INITED__ || n > 40) clearInterval(iv); }, 300);
        }
        var lb = $('btnLogin'); if (lb) lb.addEventListener('click', kickInit);
        kickInit();
    })();
    </script>
</body>
</html>
