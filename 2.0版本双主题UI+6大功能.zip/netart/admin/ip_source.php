<?php
/**
 * 后台 · IP 归属数据源管理
 *
 * 功能：
 *   1. 自由切换当前生效的 IP 源（ip9 / ipapi / ip-api.com / uapis / xxapi）；
 *   2. 配置各供应商接入参数（如 uapis.cn 的 Bearer Token，统一由后台管理，不硬编码）；
 *   3. 对任一供应商做连通性测试（测试时可直接传入 Token，无需先保存）。
 *
 * 说明：本页面为独立管理页面，不依赖后台 SPA 框架；仅管理员可访问。
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/ip_service.php';

session_start();

// 当前登录态
$loggedIn = !empty($_SESSION['admin_id']);

// 连通性测试（AJAX，必须早于任何 HTML 输出）
$action = (string) ($_GET['action'] ?? $_POST['action'] ?? '');
if ($action === 'test') {
    header('Content-Type: application/json; charset=utf-8');
    if (empty($_SESSION['admin_id'])) {
        echo json_encode(['ok' => false, 'msg' => '未登录或会话已过期']);
        exit;
    }
    $provider = (string) ($_GET['provider'] ?? $_POST['provider'] ?? '');
    $testIp = (string) ($_GET['ip'] ?? $_POST['ip'] ?? '8.8.8.8');
    $token = trim((string) ($_GET['token'] ?? $_POST['token'] ?? ''));
    $registry = ip_source_registry();
    if (!isset($registry[$provider])) {
        echo json_encode(['ok' => false, 'msg' => '未知的供应商']);
        exit;
    }
    $fn = $registry[$provider]['fn'];
    if (!function_exists($fn)) {
        echo json_encode(['ok' => false, 'msg' => '数据源函数不存在']);
        exit;
    }
    try {
        $r = ($provider === 'uapis') ? $fn($testIp, $token !== '' ? $token : null) : $fn($testIp);
    } catch (Throwable $e) {
        echo json_encode(['ok' => false, 'msg' => '调用异常：' . $e->getMessage()]);
        exit;
    }
    if (is_array($r)) {
        echo json_encode(['ok' => true, 'data' => $r]);
    } else {
        $msg = ($provider === 'uapis' && $token === '')
            ? '未返回有效数据：请先填写并保存 Token，或在测试中提供 Token'
            : '未返回有效数据（接口不可用或返回结构不符）';
        echo json_encode(['ok' => false, 'msg' => $msg]);
    }
    exit;
}

// 保存配置
$saveMsg = '';
$saveOk = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save' && $loggedIn) {
    $active = (string) ($_POST['ip_source_active'] ?? 'ip9');
    $registry = ip_source_registry();
    if (!isset($registry[$active])) {
        $saveMsg = '未知的 IP 源，保存失败';
    } else {
        $prevActive = (string) app_setting('ip_source_active', 'ip9');
        $prevToken = (string) app_setting('ip_source_uapis_token', '');

        app_setting_set('ip_source_active', $active);
        // Token：提交为空且当前生效源非 uapis 时，保留已有 Token 不被空值覆盖；
        // 否则（填写了新值，或切到 uapis）写入提交值。
        $tok = trim((string) ($_POST['ip_source_uapis_token'] ?? ''));
        if ($tok !== '' || $active === 'uapis') {
            app_setting_set('ip_source_uapis_token', $tok);
        }

        // 生效源或 Token 变化 → 刷新 IP 缓存，使新源立即生效（缓存按 IP 维度，不区分源）
        if ($active !== $prevActive || $tok !== $prevToken) {
            try {
                getDB()->exec('TRUNCATE TABLE ip_cache');
                $saveMsg = 'IP 源配置已保存，IP 缓存已刷新（新源立即生效）';
            } catch (Throwable $e) {
                $saveMsg = 'IP 源配置已保存（缓存刷新失败：' . $e->getMessage() . '）';
            }
        } else {
            $saveMsg = 'IP 源配置已保存';
        }
        $saveOk = true;
    }

    // AJAX / JSON 请求（后台 SPA 调用）：直接返回 JSON，跳过 HTML 重渲染
    if (!empty($_POST['format']) && $_POST['format'] === 'json') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status'  => $saveOk ? 0 : 1,
            'message' => $saveMsg ?: ($saveOk ? '保存成功' : '保存失败'),
        ]);
        exit;
    }
}

// 当前配置
$active = (string) app_setting('ip_source_active', 'ip9');
$uapisToken = (string) app_setting('ip_source_uapis_token', '');
$registry = ip_source_registry();
$siteName = (string) app_setting('site_name', '网络面板');

// 简单转义
function _h($v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP 源管理 - <?php echo _h($siteName); ?></title>
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .ipsrc-wrap { max-width: 920px; margin: 24px auto; padding: 0 16px 60px; }
        .ipsrc-card { background: var(--card-bg, #fff); border: 1px solid var(--border, #eaeaea); border-radius: 10px; padding: 20px 22px; margin-bottom: 18px; }
        .ipsrc-card h3 { margin: 0 0 4px; font-size: 16px; }
        .ipsrc-card .sub { color: var(--text-secondary, #888); font-size: 13px; margin-bottom: 16px; }
        .ipsrc-select-wrap { margin: 6px 0 4px; }
        .ipsrc-select { width: 100%; box-sizing: border-box; padding: 10px 12px; border: 1.5px solid var(--border, #eaeaea); border-radius: 8px; font-size: 14px; background: var(--bg, #fafafa); color: var(--text, #222); cursor: pointer; }
        .ipsrc-select:focus { outline: none; border-color: var(--primary, #5668EE); box-shadow: 0 0 0 3px rgba(86,104,238,.12); }
        .ipsrc-token-box { margin-top: 14px; }
        .ipsrc-token-box label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; }
        .ipsrc-token-box input { width: 100%; box-sizing: border-box; padding: 9px 12px; border: 1px solid var(--border, #eaeaea); border-radius: 8px; font-family: var(--np-font-mono, monospace); font-size: 13px; }
        .ipsrc-actions { display: flex; gap: 12px; align-items: center; margin-top: 8px; flex-wrap: wrap; }
        .ipsrc-msg { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; }
        .ipsrc-msg.ok { background: #ecfdf5; color: #047857; border: 1px solid #a7f3d0; }
        .ipsrc-msg.err { background: #fef2f2; color: #b91c1c; border: 1px solid #fecaca; }
        .ipsrc-test-result { margin-top: 14px; font-size: 13px; }
        .ipsrc-test-result pre { background: var(--bg, #f6f6f8); border: 1px solid var(--border, #eaeaea); border-radius: 8px; padding: 12px; overflow: auto; max-height: 240px; font-size: 12px; line-height: 1.5; margin: 0; }
        .ipsrc-hint { font-size: 12px; color: var(--text-secondary, #888); line-height: 1.7; }
        .ipsrc-hint code { background: #f1f1f4; padding: 1px 5px; border-radius: 4px; }
        .btn-sm { padding: 6px 14px; font-size: 13px; }
        /* 登录态 */
        .login-wrapper { max-width: 360px; margin: 80px auto; padding: 28px; border: 1px solid var(--border, #eaeaea); border-radius: 12px; background: var(--card-bg, #fff); }
        .login-wrapper h2 { margin: 0 0 18px; text-align: center; font-size: 18px; }
        .login-wrapper .form-group { margin-bottom: 14px; }
        .login-wrapper input { width: 100%; box-sizing: border-box; padding: 10px 12px; border: 1px solid var(--border, #eaeaea); border-radius: 8px; }
        .login-error { color: #b91c1c; font-size: 13px; min-height: 18px; margin: 8px 0 0; }
    </style>
</head>
<body>
<?php if (!$loggedIn): ?>
    <div class="login-wrapper">
        <h2>管理员登录</h2>
        <form id="loginForm" onsubmit="return false;">
            <div class="form-group">
                <input type="text" name="username" placeholder="管理员账号" required autocomplete="username">
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="密码" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn-primary btn-block" style="width:100%;">登 录</button>
            <p class="login-error" id="loginError"></p>
        </form>
        <p style="text-align:center;margin-top:14px;"><a href="../index.php">← 返回首页</a></p>
    </div>
    <script>
    document.getElementById('loginForm').addEventListener('submit', function () {
        var f = this, err = document.getElementById('loginError');
        err.textContent = '';
        fetch('../api/admin_auth.php?action=login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: f.username.value,
                password: f.password.value
            })
        }).then(function (r) { return r.json(); }).then(function (d) {
            if (d.status === 0) { location.href = 'ip_source.php'; }
            else { err.textContent = d.message || '登录失败'; }
        }).catch(function () { err.textContent = '网络错误'; });
    });
    </script>
<?php else: ?>
    <div class="ipsrc-wrap">
        <h2 style="margin:0 0 4px;">IP 归属数据源管理</h2>
        <p class="ipsrc-hint" style="margin-top:0;">
            选择当前生效的 IP 查询源；新增供应商不影响既有数据源（任一源失败会自动回退到其他源）。
            点击「保存」后首页与所有 IP 查询接口将使用所选数据源。
        </p>

        <?php if ($saveMsg !== ''): ?>
            <div class="ipsrc-msg <?php echo $saveOk ? 'ok' : 'err'; ?>"><?php echo _h($saveMsg); ?></div>
        <?php endif; ?>

        <form method="post" action="ip_source.php">
            <input type="hidden" name="action" value="save">
            <div class="ipsrc-card">
                <h3>生效 IP 源</h3>
                <div class="sub">选择当前生效的 IP 查询源；当前生效：<strong><?php echo _h($registry[$active]['name'] ?? $active); ?></strong></div>
                <div class="ipsrc-select-wrap">
                    <select id="ipSourceActive" name="ip_source_active" class="ipsrc-select">
                        <?php foreach ($registry as $id => $meta): ?>
                        <option value="<?php echo _h($id); ?>" <?php echo $id === $active ? 'selected' : ''; ?>>
                            <?php echo _h($meta['name'] . ' — ' . $meta['endpoint']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="ipsrc-hint" style="margin-top:6px;">
                        <?php echo _h($registry[$active]['desc'] ?? ''); ?>
                    </p>
                </div>

                <div class="ipsrc-token-box">
                    <label for="tok">UAPIS（uapis.cn）Bearer Token</label>
                    <input type="text" id="tok" name="ip_source_uapis_token" value="<?php echo _h($uapisToken); ?>" placeholder="在 uapis.cn 后台获取的 API Token，留空则不使用该源" autocomplete="off">
                    <p class="ipsrc-hint" style="margin-top:6px;">
                        Token 仅存储于本站数据库（<code>site_settings</code> 表），代码中<strong>不硬编码</strong>，可随时在后台修改或清除。
                    </p>
                </div>
            </div>

            <div class="ipsrc-actions">
                <button type="submit" class="btn-primary">保存配置</button>
                <button type="button" class="btn-default btn-sm" id="btnTest">测试选中源连通性</button>
                <a class="btn-default btn-sm" href="../index.php" target="_blank" rel="noopener">打开首页</a>
            </div>
        </form>

        <div class="ipsrc-card">
            <h3>连通性测试</h3>
            <div class="sub">对当前「选中」的源发起一次真实查询（测试 IP 8.8.8.8）。uapis 测试会临时使用上方 Token 输入框的值。</div>
            <div class="ipsrc-test-result" id="testResult" style="display:none;">
                <pre id="testJson"></pre>
            </div>
            <p class="ipsrc-hint" id="testHint">点击「测试选中源连通性」开始。</p>
        </div>

        <p class="ipsrc-hint">
            数据源说明：<br>
            · <strong>IP9 / XXAPI</strong>：国内免费接口，开箱即用，无需配置；<br>
            · <strong>ipapi.co / ip-api.com</strong>：海外免费接口（后者仅 HTTP）；<br>
            · <strong>UAPIS</strong>：需 Bearer Token，请在上方填写后保存，并确认服务器可访问 <code>uapis.cn</code>。
        </p>
    </div>

    <script>
    (function () {
        var form = document.querySelector('form');
        var resultBox = document.getElementById('testResult');
        var jsonEl = document.getElementById('testJson');
        var hintEl = document.getElementById('testHint');

        document.getElementById('btnTest').addEventListener('click', function () {
            var sel = document.getElementById('ipSourceActive');
            if (!sel) { hintEl.textContent = '请先选择一个 IP 源'; return; }
            var provider = sel.value;
            var token = document.getElementById('tok').value.trim();
            hintEl.textContent = '正在测试 ' + provider + ' …';
            resultBox.style.display = 'block';
            jsonEl.textContent = '请求中…';
            var url = 'ip_source.php?action=test&provider=' + encodeURIComponent(provider)
                + '&ip=8.8.8.8&token=' + encodeURIComponent(token);
            fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (d.ok) {
                        hintEl.textContent = '✅ 连通成功（' + provider + '）';
                        jsonEl.textContent = JSON.stringify(d.data, null, 2);
                    } else {
                        hintEl.textContent = '❌ 测试失败：' + (d.msg || '未知错误');
                        jsonEl.textContent = '';
                    }
                })
                .catch(function (e) { hintEl.textContent = '❌ 请求异常：' + e.message; jsonEl.textContent = ''; });
        });
    })();
    </script>
<?php endif; ?>
</body>
</html>
