/**
 * NetworkPanel - 后台管理系统前端逻辑
 */

const API = '../api/';
const ADMIN_API = API + 'admin.php';
const AUTH_API = API + 'admin_auth.php';

// ========== 角色映射（全局唯一） ==========
const ROLE_MAP  = {user:'普通用户', vip:'VIP会员', admin:'管理员'};

// ========== 工具函数 ==========
function $(s){return document.querySelector(s);}
function $$(s){return document.querySelectorAll(s);}
function esc(s){ const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }

function formatBytes(bytes) {
    if (!bytes) return '0 B';
    const units = ['B','KB','MB','GB','TB'];
    let i = 0; let v = bytes;
    while(v >= 1024 && i<units.length-1){v/=1024;i++;}
    return v.toFixed(i>1?1:0)+' '+units[i];
}

function fmtTime(t){
    if(!t)return '-';
    const d=new Date(t);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

function startClock(){
    setInterval(()=>{
        const d=new Date();
        $('#clockDisplay').textContent=`${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
    },1000);
}
function escAttr(s) {
    return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function parseBrowserUA(ua) {
    if (!ua) return '-';
    // Chrome
    if (/Chrome\//.test(ua)) {
        const m = ua.match(/Chrome\/([\d.]+)/);
        return 'Chrome ' + (m ? m[1] : '');
    }
    // Firefox
    if (/Firefox\//.test(ua)) {
        const m = ua.match(/Firefox\/([\d.]+)/);
        return 'Firefox ' + (m ? m[1] : '');
    }
    // Edge
    if (/Edg\//.test(ua)) {
        const m = ua.match(/Edg\/([\d.]+)/);
        return 'Edge ' + (m ? m[1] : '');
    }
    // Safari
    if (/Safari/.test(ua) && !/Chrome/.test(ua)) {
        return 'Safari';
    }
    // fallback
    if (/MSIE|Trident/.test(ua)) return 'IE';
    if (ua.length > 40) return ua.substring(0, 38) + '...';
    return ua;
}
function formatBps(bps) {
    if (!bps || bps <= 0) return '-';
    if (bps >= 1073741824) return (bps / 1073741824).toFixed(1) + ' GB/s';
    if (bps >= 1048576) return (bps / 1048576).toFixed(1) + ' MB/s';
    if (bps >= 1024) return (bps / 1024).toFixed(1) + ' KB/s';
    return bps.toFixed(0) + ' B/s';
}
function renderPagination(container, total, current, perPage, onPageChange) {
    const totalPages = Math.ceil(total / perPage);
    if (totalPages <= 1) { container.innerHTML = ''; return; }

    let html = `<button ${current<=1?'disabled':''} onclick="this.parentElement._cb(${current-1})">&laquo;</button>`;
    const maxShow = 5; 
    let start = Math.max(1, current - Math.floor(maxShow/2));
    let end = Math.min(totalPages, start + maxShow - 1);
    if (end - start < maxShow - 1) { start = Math.max(1, end - maxShow + 1); }

    if (start > 1) { html+=`<button onclick="this.parentElement._cb(1)">1</button>`; if(start>2)html+=`<span>...</span>`; }
    for(let i=start;i<=end;i++) { html+=`<button class="${i===current?'active':''}" onclick="this.parentElement._cb(${i})">${i}</button>`; }
    if (end < totalPages) { if(end<totalPages-1)html+=`<span>...</span>`; html+=`<button onclick="this.parentElement._cb(${totalPages})">${totalPages}</button>`; }
    html += `<button ${current>=totalPages?'disabled':''} onclick="this.parentElement._cb(${current+1})">&raquo;</button>`;
    html += `<span class="page-info">${total}条 / 第${current}/${totalPages}页</span>`;

    container.innerHTML = html;
    container._cb = onPageChange;
}
let _confirmResolve = null;
function showConfirm(title, message) {
    return new Promise(resolve => {
        // 移除旧弹窗
        const old = document.getElementById('customConfirmModal');
        if (old) { old.remove(); }

        const modal = document.createElement('dialog');
        modal.id = 'customConfirmModal';
        modal.style.cssText = 'margin:auto;max-width:380px;border:none;border-radius:14px;padding:0;box-shadow:0 10px 40px rgba(0,0,0,.25);';
        modal.innerHTML = `
            <div style="padding:20px 24px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;">
                <h3 style="font-size:16px;margin:0;color:#303133;">${esc(title)}</h3>
                <button data-close style="background:none;border:none;font-size:20px;cursor:pointer;color:#999;line-height:1;">&times;</button>
            </div>
            <div style="padding:24px;font-size:14px;line-height:1.6;color:#606266;">${message}</div>
            <div style="display:flex;justify-content:center;gap:16px;padding:16px 24px;">
                <button id="confirmCancel" style="padding:10px 30px;border-radius:10px;background:#5668EE;color:#fff;border:none;font-size:14px;cursor:pointer;font-weight:600;">取消</button>
                <button id="confirmOk" style="padding:10px 30px;border-radius:10px;background:#f56c6c;color:#fff;border:none;font-size:14px;cursor:pointer;font-weight:600;">确定</button>
            </div>`;
        document.body.appendChild(modal);
        modal.showModal();

        const doClose = (val) => () => { modal.close(); modal.remove(); resolve(val); };
        modal.querySelector('#confirmOk').onclick = doClose(true);
        modal.querySelector('#confirmCancel').onclick = doClose(false);
        modal.querySelector('[data-close]').onclick = doClose(false);
        modal.oncancel = () => { modal.remove(); resolve(false); };
    });
}
// CSS动画注入
const style = document.createElement('style');
style.textContent = `@keyframes fadeInOut{0%{opacity:0;transform:translateX(-50%) translateY(-10px)}20%{opacity:1;transform:translateX(-50%) translateY(0)}80%{opacity:1;transform:translateX(-50%) translateY(0)}100%{opacity:0;transform:translateX(-50%) translateY(-10px)}}`
+ `.action-btns .action-btn.active{font-weight:600;color:#fff!important;}
.btn-status-pending.active{background:#f56c6c;border-color:#f56c6c;}
.btn-status-read.active{background:#e6a23c;border-color:#e6a23c;color:#fff;}
.btn-status-done.active{background:#67c23a;border-color:#67c23a;color:#fff;}`;
document.head.appendChild(style);

