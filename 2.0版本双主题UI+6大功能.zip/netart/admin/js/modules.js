// ========== 仪表盘 ==========
async function loadDashboard() {
    try {
        const resp = await fetch(ADMIN_API + '?action=dashboard');
        // 安全解析：防止后端返回HTML导致JSON解析崩溃
        if (!resp.ok) {
            let errText = '';
            try { errText = await resp.text(); } catch(e2) {}
            console.error('Dashboard HTTP错误:', resp.status, errText.substring(0,200));
            return;
        }
        let data;
        try { data = await resp.json(); } catch(parseErr) {
            let rawText = '';
            try { rawText = await resp.text(); } catch(_) {}
            console.error('Dashboard非JSON响应:', parseErr.message, rawText.substring(0,300));
            return;
        }
        if (data.status !== 0) return;

        const s = data.data.stats;
        $('#statUsers').textContent = s.total_users;
        $('#todayUsers').textContent = '+今日 ' + s.today_users;
        $('#statTraffic').textContent = formatBytes(s.total_traffic);
        $('#statNodes').textContent = s.active_nodes + '/' + s.total_nodes;
        $('#statTodayTraffic').textContent = formatBytes(s.today_traffic);
        // 未读反馈提示
        const fbBadge = $('#feedbackNavBadge');
        if (fbBadge) {
            fbBadge.style.display = s.unread_feedback > 0 ? '' : 'none';
            fbBadge.textContent = s.unread_feedback;
        }

        // 最近用户
        let html = '';
        (data.data.recent_users || []).forEach(u => {
            const roleTag = `<span class="tag ${u.role==='vip'?'tag-warning':u.role==='admin'?'tag-danger':'tag-info'}">${ROLE_MAP[u.role]||u.role}</span>`;
            html += `<tr><td>${u.id}</td><td>${esc(u.username)}</td><td>${u.email||'-'}</td><td>${roleTag}</td><td>${fmtTime(u.created_at)}</td></tr>`;
        });
        $('#recentUsersTable tbody').innerHTML = html || '<tr><td colspan="4">暂无数据</td></tr>';

        // 日志
        let lh = '';
        (data.data.recent_logs || []).forEach(l => {
            lh += `<div class="log-item"><span class="log-time">${fmtTime(l.created_at)}</span>
                <span class="log-action">${l.action}</span><span class="log-detail">${esc(l.detail||'-')} by ${esc(l.admin_name)}</span></div>`;
        });
        $('#logList').innerHTML = lh || '<p style="color:var(--text-secondary)">暂无日志</p>';
    } catch(e) { console.error(e); }
}

// ========== 节点管理 ==========
async function loadNodes() {
    try {
        const resp = await fetch(ADMIN_API + '?action=nodes');
        if (!resp.ok) { console.error('Nodes HTTP错误:', resp.status); return; }
        let data;
        try { data = await resp.json(); } catch(e) { console.error('Nodes非JSON响应:', e.message); return; }
        if (data.status !== 0) return;
        
        let html = '';
        (data.data || []).forEach(n => {
            const statusTag = n.status ? '<span class="tag tag-success">启用</span>' : '<span class="tag tag-danger">隐藏</span>';
            const typeTag = n.url_type === 'api' ? '<span class="tag tag-primary">API</span>' : '<span class="tag tag-info">HTTP</span>';
            const toggleBtn = n.status
                ? `<button class="action-btn warning" onclick="toggleNodeStatus(${n.id}, 0)">禁用</button>`
                : `<button class="action-btn success" onclick="toggleNodeStatus(${n.id}, 1)">启用</button>`;
            html += `<tr><td>${n.id}</td><td>${esc(n.group_name)}</td><td>${esc(n.label)}</td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis">${esc(n.url)}</td>
                <td>${typeTag}</td><td>${statusTag}</td><td>${n.sort_order}</td>
                <td><div class="action-btns">
                    ${toggleBtn}
                    <button class="action-btn" onclick="openNodeModal(${n.id})">编辑</button>
                    <button class="action-btn danger" onclick="deleteNode(${n.id})">删除</button>
                </div></td></tr>`;
        });
        $('#nodeTable tbody').innerHTML = html || '<tr><td colspan="8">暂无节点数据，点击"添加节点"</td></tr>';
    } catch(e) { console.error(e); }
}

let editingNodeId = null;
async function openNodeModal(id = null) {
    editingNodeId = id;
    $('#nodeModalTitle').textContent = id ? '编辑节点' : '添加节点';
    $('#editNodeId').value = id || '';

    if (id) {
        // 从API获取节点详情并回填表单
        try {
            const resp = await fetch(`${ADMIN_API}?action=nodes&id=${id}`);
            let data;
            try { data = await resp.json(); } catch(e) { console.error('节点详情解析失败:', e.message); return; }
            if (data.status === 0 && data.data) {
                const n = data.data;
                $('#nodeGroup').value = n.group_name || '默认';
                $('#nodeNameInput').value = n.label || '';
                $('#nodeUrlInput').value = n.url || '';
                $('#nodeUrlType').value = n.url_type || 'http';
                $('#nodeSortOrder').value = n.sort_order ?? 0;
                $('#nodeDesc').value = n.description || '';
            }
        } catch(e) { console.error('获取节点详情失败', e); }
    } else {
        $('#nodeGroup').value = '默认';
        $('#nodeNameInput').value = '';
        $('#nodeUrlInput').value = '';
        $('#nodeUrlType').value = 'http';
        $('#nodeSortOrder').value = '0';
        $('#nodeDesc').value = '';
    }
    $('#modalNodeEdit').showModal();
}

async function saveNode() {
    const payload = {
        action: editingNodeId ? 'node_edit' : 'node_add',
        id: editingNodeId,
        group_name: $('#nodeGroup').value,
        label: $('#nodeNameInput').value.trim(),
        url: $('#nodeUrlInput').value.trim(),
        url_type: $('#nodeUrlType').value,
        sort_order: parseInt($('#nodeSortOrder').value)||0,
        description: $('#nodeDesc').value.trim()
    };
    if (!payload.label || !payload.url) { toast('名称和URL不能为空'); return; }

    try {
        const resp = await fetch(ADMIN_API, {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload)
        });
        let d;
        try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
        if (d.status === 0) {
            toast(d.message || '保存成功');
            $('#modalNodeEdit').close();
            loadNodes();
        } else { toast(d.message || '保存失败'); }
    } catch(e) { toast('网络错误'); }
}

async function deleteNode(id) {
    if (!await showConfirm('删除节点', '确定删除此节点？此操作不可恢复。')) return;
    const resp = await fetch(ADMIN_API, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ action:'node_delete', id })
    });
    let d;
    try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
    toast(d.status===0?'删除成功':d.message);
    loadNodes();
}

async function toggleNodeStatus(id, newStatus) {
    const resp = await fetch(ADMIN_API, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ action:'node_edit', id, status: newStatus })
    });
    let d;
    try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
    toast(d.status===0 ? (newStatus ? '已启用' : '已禁用') : d.message);
    loadNodes();
}

// ========== 会员管理 ==========
async function loadUsers() {
    const search = $('#userSearch').value.trim();
    const role = $('#userRoleFilter').value;
    let url = `${ADMIN_API}?action=users&page=${userPage}&limit=15`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (role) url += `&role=${role}`;

    try {
        const resp = await fetch(url);
        if (!resp.ok) { console.error('Users HTTP错误:', resp.status); return; }
        let data;
        try { data = await resp.json(); } catch(e) { console.error('Users非JSON响应:', e.message); return; }
        if (data.status !== 0) return;

        const list = data.data.list;
        let html = '';
        list.forEach(u => {
            const roleClass = u.role==='vip'?'tag-warning': u.role==='admin'?'tag-danger':'tag-info';
            const statusTag = u.status==1? '<span class="tag tag-success">正常</span>':'<span class="tag tag-danger">禁用</span>';
            html += `<tr><td>${u.id}</td><td>${esc(u.username)}</td><td>${u.email||'-'}</td>
                <td><span class="tag ${roleClass}">${ROLE_MAP[u.role]||u.role}</span></td>
                <td>${statusTag}</td><td>${formatBytes(u.total_bytes||0)}</td><td>${fmtTime(u.created_at)}</td>
                <td><div class="action-btns">
                    <button class="action-btn" data-action="detail" data-id="${u.id}">详情</button>
                    <button class="action-btn" data-action="edit" data-id="${u.id}" data-username="${escAttr(u.username)}" data-email="${escAttr(u.email||'')}" data-role="${u.role}" data-status="${u.status}">编辑</button>
                    <button class="action-btn ${u.status==1?'danger':'success'}" data-action="toggle" data-id="${u.id}" data-status="${u.status}">${u.status==1?'禁用':'启用'}</button>
                </div></td></tr>`;
        });
        $('#userTable tbody').innerHTML = html || '<tr><td colspan="8">无数据</td></tr>';

        // 操作列按钮 - 事件委托（避免onclick中特殊字符导致JS报错）
        $('#userTable tbody').addEventListener('click', e => {
            const btn = e.target.closest('[data-action]');
            if (!btn) return;
            const id = parseInt(btn.dataset.id);
            switch (btn.dataset.action) {
                case 'detail': openUserDetail(id); break;
                case 'edit': openUserModal(id, btn.dataset.username, btn.dataset.email, btn.dataset.role, btn.dataset.status); break;
                case 'toggle': toggleUserStatus(id, btn.dataset.status); break;
            }
        });

        renderPagination($('#userPagination'), data.data.total, userPage, 15, p=>{userPage=p;loadUsers()});
    } catch(e) { console.error(e); }
}

let editUserId = null;
function openUserModal(id, username, email, role, status) {
    editUserId = id;
    $('#editUserId').value = id;
    $('#editUsername').value = username;
    $('#editEmail').value = email || '';
    $('#editPassword').value = '';
    $('#editUserRole').value = role;
    $('#editUserStatus').value = status;
    $('#modalUserEdit').showModal();
}

async function saveUser() {
    const username = $('#editUsername').value.trim();
    if (!username) { toast('用户名不能为空'); return; }
    const payload = {
        action:'user_update',
        id: parseInt($('#editUserId').value),
        username: username,
        email: $('#editEmail').value.trim(),
        password: $('#editPassword').value,
        role: $('#editUserRole').value,
        status: parseInt($('#editUserStatus').value)
    };
    const resp = await fetch(ADMIN_API, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload)
    });
    let d;
    try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
    toast(d.status===0?'更新成功':d.message);
    $('#modalUserEdit').close();
    loadUsers();
}

async function toggleUserStatus(id, currentStatus) {
    const newStatus = currentStatus == 1 ? 0 : 1;
    const actionText = newStatus == 0 ? '禁用' : '启用';
    if (!await showConfirm(actionText + '用户', '确定要' + actionText + '该用户？')) return;
    await fetch(ADMIN_API, {method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({action:'user_update', id, status:newStatus})});
    toast('已' + actionText); loadUsers();
}

// ========== 用户详情 ==========
async function openUserDetail(id) {
    const modal = document.getElementById('modalUserDetail');
    if (!modal) return;
    modal.showModal();

    // 先清空/显示加载
    const logsEl = document.getElementById('detailLoginLogs');
    logsEl.innerHTML = '<p style="color:#999;font-size:13px;text-align:center;padding:30px 0;">加载中...</p>';

    try {
        const resp = await fetch(ADMIN_API + '?action=user_detail&id=' + id);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        let data;
        try { data = await resp.json(); } catch(e) { throw new Error('非JSON响应'); }
        if (data.status !== 0) throw new Error(data.message || '加载失败');

        const u = data.data.user;
        const ts = data.data.traffic_summary;
        const logs = (data.data.login_logs || []).slice(0, 5);

        // 基本信息
        document.getElementById('detailAvatar').textContent = (u.username || 'U')[0].toUpperCase();
        document.getElementById('detailUsername').textContent = u.username;

        const roleClass = {user:'tag-info', vip:'tag-warning', admin:'tag-danger'};
        const roleTag = document.getElementById('detailRoleTag');
        roleTag.textContent = ROLE_MAP[u.role] || u.role;
        roleTag.className = 'tag ' + (roleClass[u.role] || 'tag-info');

        const statusTag = document.getElementById('detailStatusTag');
        statusTag.textContent = u.status == 1 ? '正常' : '禁用';
        statusTag.style.cssText = u.status == 1 ? '' : 'background:var(--danger);color:#fff;';

        // 注册信息
        document.getElementById('detailRegTime').textContent = fmtTime(u.created_at);
        document.getElementById('detailUpdateTime').textContent = fmtTime(u.updated_at);
        document.getElementById('detailEmail').textContent = u.email || '-';

        // 账号信息
        document.getElementById('detailToken').textContent = data.data.access_token || '-';
        document.getElementById('detailTotalBytes').textContent = formatBytes(ts.total_bytes || 0);
        document.getElementById('detailTotalTime').textContent = formatDur(ts.total_time || 0);
        document.getElementById('detailLastActive').textContent = fmtTime(u.last_active);
        document.getElementById('detailLoginCount').textContent = String(data.data.login_count || 0);

        // 登录记录
        if (logs.length > 0) {
            let lh = '';
            logs.forEach((log, i) => {
                lh += `<div style="padding:10px 12px;border-radius:8px;margin-bottom:6px;background:${i % 2 === 0 ? '#f8f9ff' : '#fafafa'};font-size:12px;line-height:1.8;">`;
                lh += `<div style="display:flex;justify-content:space-between;color:#666;"><span>&#128100; ${esc(log.ip)}</span><span>${fmtTime(log.time)}</span></div>`;
                lh += `<div><span class="tag tag-primary" style="font-size:11px;padding:1px 6px;margin-right:4px;">${esc(log.browser)}</span>`;
                lh += `<span class="tag tag-success" style="font-size:11px;padding:1px 6px;">${esc(log.os)}</span></div>`;
                lh += `</div>`;
            });
            logsEl.innerHTML = lh;
        } else {
            logsEl.innerHTML = '<p style="color:#999;font-size:13px;text-align:center;padding:30px 0;">暂无登录记录</p>';
        }
    } catch(e) {
        logsEl.innerHTML = `<p style="color:#f56c6c;font-size:13px;text-align:center;padding:30px 0;">&#9888; ${esc(e.message)}</p>`;
    }
}

function copyDetailToken() {
    const t = document.getElementById('detailToken')?.textContent;
    if (!t || t === '-') { toast('无可复制的令牌'); return; }
    navigator.clipboard?.writeText(t).then(() => toast('令牌已复制')).catch(() => {
        const ta = document.createElement('textarea'); ta.value = t;
        ta.style.position = 'fixed'; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); document.body.removeChild(ta); toast('令牌已复制');
    });
}

function formatDur(s) {
    if (!s) return '-';
    s = Number(s);
    if (s < 60) return s.toFixed(0) + '秒';
    s /= 60; if (s < 60) return s.toFixed(0) + '分';
    s /= 60; if (s < 24) return s.toFixed(0) + '时';
    return (s / 24).toFixed(0) + '天';
}

// ========== 系统设置 ==========
async function loadSettings() {
    try {
        const [basicResp, navResp, systemResp, footerResp] = await Promise.all([
            fetch(`${ADMIN_API}?action=settings&group=basic`),
            fetch(`${ADMIN_API}?action=settings&group=header`),
            fetch(`${ADMIN_API}?action=settings&group=system`),
            fetch(`${ADMIN_API}?action=settings&group=footer`),
        ]);
        // 安全解析，每个请求独立容错
        const safeJson = async (r, label) => {
            if (!r.ok) { console.error(label+' HTTP错误:', r.status); return {data:[]}; }
            try { return await r.json(); } catch(e) { console.error(label+'非JSON:', e.message); return {data:[]}; }
        };
        const basic = (await safeJson(basicResp,'Settings-basic')).data||[];
        const nav = (await safeJson(navResp,'Settings-nav')).data||[];
        const system = (await safeJson(systemResp,'Settings-system')).data||[];
        const footer = (await safeJson(footerResp,'Settings-footer')).data||[];

        renderSettingForm('#settingsFormBasic', basic);
        renderNavSettingForm('#settingsFormNav', nav);
        renderSettingForm('#settingsFormSystem', system);

        // 底部设置 - 使用特殊渲染
        renderFooterSettingForm('#settingsFormFooter', footer);
    } catch(e) { console.error(e); }
}

/** 渲染底部专用表单（含友情链接JSON编辑、HTML代码区域） */
function renderFooterSettingForm(containerSel, items) {
    const container = $(containerSel);
    if (!container) return;

    // 确保所有底部设置项都存在，缺少的用默认值填充
    const requiredKeys = {
        'footer_custom_text': { title: '自定义底部文字', value: '', type: 'textarea', rows: 2, hint: '' },
        'footer_copyright': { title: '版权信息', value: '© 2026 NetArt 网络测速系统', type: 'input', hint: '' },
        'footer_icp': { title: 'ICP备案号', value: '', type: 'input', hint: '' },
        'footer_icp_url': { title: 'ICP备案链接', value: '#', type: 'input', hint: '' },
        'friend_links': { title: '友情链接', value: '[{"name":"示例链接","url":"#"}]', type: 'json', rows: 4, hint: 'JSON格式 [{"name":"名","url":"地址"}]' },
        'notices': { title: '公告/广告内容', value: '', type: 'json', rows: 5, hint: '每行一条公告，支持HTML标签，5秒自动滚动' },
        'footer_html': { title: '自定义HTML代码', value: '', type: 'json', rows: 5, hint: '支持完整HTML/JS/CSS' }
    };

    // 将数据库中的值合并到默认项中
    const mergedItems = [];
    const itemsMap = {};
    if (items && items.length > 0) {
        items.forEach(item => { itemsMap[item.setting_key] = item; });
    }
    for (const [key, def] of Object.entries(requiredKeys)) {
        const existing = itemsMap[key];
        mergedItems.push({
            setting_key: key,
            setting_value: existing ? (existing.setting_value ?? '') : def.value,
            title: existing ? (existing.title || key) : def.title,
            _type: def.type,
            _rows: def.rows || 3,
            _hint: def.hint || ''
        });
    }

    let html = '';
    mergedItems.forEach(item => {
        const key = esc(item.setting_key);
        const val = item.setting_value ?? '';  // 不转义，textarea/input会自动处理
        const title = esc(item.title || item.setting_key);
        
        let inputHtml;
        if (key === 'friend_links' || key === 'footer_html' || key === 'notices') {
            const rows = item._rows || 5;
            const hint = item._hint || '';
            inputHtml = `<textarea name="${key}" rows="${rows}" style="font-family:monospace;font-size:13px;">${esc(val)}</textarea>`
                + (hint ? `<small style="color:var(--text-secondary);display:block;margin-top:4px">${hint}</small>` : '');
        } else if (key === 'footer_custom_text') {
            inputHtml = `<textarea name="${key}" rows="2">${esc(val)}</textarea>`;
        } else {
            inputHtml = `<input type="text" name="${key}" value="${esc(val)}">`;
        }
        html += `<div class="form-group"><label>${title}</label>${inputHtml}</div>`;
    });
    container.innerHTML = html;
}

function renderSettingForm(containerSel, items) {
    let html = '';
    items.forEach(item => {
        const key = esc(item.setting_key);
        const val = esc(item.setting_value ?? '');
        const title = esc(item.title || item.setting_key);
        const desc = item.description ? `<small style="display:block;color:var(--text-secondary);margin-top:2px">${esc(item.description)}</small>` : '';

        let inputHtml;
        if (item.setting_type === 'bool') {
            inputHtml = `<select name="${key}"><option value="1" ${val==='1'?'selected':''}>是</option><option value="0" ${val!=='1'?'selected':''}>否</option></select>`;
        } else if (item.setting_type === 'int') {
            inputHtml = `<input type="number" name="${key}" value="${val}" placeholder="${title}">`;
        } else if (item.setting_type === 'text') {
            inputHtml = `<textarea name="${key}" rows="3" placeholder="${title}">${val}</textarea>`;
        } else {
            inputHtml = `<input type="text" name="${key}" value="${val}" placeholder="${title}">`;
        }
        html += `<div class="form-group"><label>${title}${desc}</label>${inputHtml}</div>`;
    });
    $(containerSel).innerHTML = html || '<p style="color:var(--text-secondary);padding:20px;text-align:center">暂无配置项</p>';
}

/** 渲染顶部导航专用表单（含可视化编辑） */
function renderNavSettingForm(containerSel, items) {
    const container = $(containerSel);
    if (!container) return;

    // 找到 nav_links 配置项
    let navValue = '';
    if (items && items.length > 0) {
        const navItem = items.find(i => i.setting_key === 'nav_links');
        if (navItem) navValue = navItem.setting_value || '';
    }

    // 默认：空数组。主导航（首页/工具箱/IP 查询/流量计算器/字节转换/IP 进阶/排行榜）
    // 已在页面 HTML 中固定；此处仅用于配置「附加自定义导航项」，避免重复。
    if (!navValue) {
        navValue = JSON.stringify([], null, 2);
    }

    // 尝试格式化JSON
    try { navValue = JSON.stringify(JSON.parse(navValue), null, 2); } catch(e) {}

    container.innerHTML = `
        <div class="form-group">
            <label>附加导航链接（JSON数组）</label>
            <textarea name="nav_links" rows="8" style="font-family:monospace;font-size:13px;">${esc(navValue)}</textarea>
            <small style="color:var(--text-secondary);display:block;margin-top:4px">
                主导航已固定，此处仅用于配置额外自定义链接（如 API 文档、博客、外部资源）。<br>
                重复名称（首页/工具箱/IP 查询/排行榜 等）将被自动过滤，避免导航重复。<br>
                JSON格式: [{"name":"显示名","url":"地址","target":"_blank","active":true}]<br>
                name=按钮文字, url=跳转地址, target=_blank(新窗口)/_self(当前窗口), active=是否高亮<br>
                首页、排行榜、个人中心按钮已固定在导航栏中，无需重复添加
            </small>
        </div>`;
}

async function saveAllSettings() {
    const forms = ['#settingsFormBasic', '#settingsFormNav', '#settingsFormSystem', '#settingsFormFooter'];
    const promises = [];

    forms.forEach(sel => {
        $(sel).querySelectorAll('[name]').forEach(input => {
            promises.push(
                fetch(ADMIN_API, {
                    method:'POST', headers:{'Content-Type':'application/json'},
                    body: JSON.stringify({ action:'setting_save', key:input.name, value:input.value })
                }).then(async r => { try { return await r.json(); } catch(e) { return {status:1, message:'响应异常'}; } })
            );
        });
    });

    // 同时保存导航链接
    if (typeof saveNavLinks === 'function') {
        saveNavLinks();
    }

    const results = await Promise.all(promises);
    const failCount = results.filter(r=>r.status!==0).length;
    toast(failCount > 0 ? `${results.length-failCount}/${results.length} 保存成功` : '全部保存成功');
}

// ========== 首页动态模块（重要合规提示 / 公告提示） ==========
async function loadHomeModules() {
    const container = $('#settingsFormHomepage');
    if (!container) return;
    container.innerHTML = '<p style="color:var(--text-secondary);padding:20px;text-align:center">加载中...</p>';
    try {
        const resp = await fetch(`${ADMIN_API}?action=settings&group=homepage`);
        if (!resp.ok) { console.error('Homepage settings HTTP 错误:', resp.status); container.innerHTML = '<p style="color:var(--danger)">加载失败</p>'; return; }
        let data;
        try { data = await resp.json(); } catch(e) { console.error('Homepage settings 非 JSON:', e.message); container.innerHTML = '<p style="color:var(--danger)">返回数据异常</p>'; return; }
        const items = data.data || [];
        const map = {};
        items.forEach(i => { map[i.setting_key] = i; });

        // 表单定义（key / 标题 / 类型 / 描述）
        const defs = [
            { key:'home_compliance_enabled', title:'启用「重要合规提示」', type:'bool', desc:'开启后首页顶部展示合规/未成年人保护提示模块' },
            { key:'home_compliance_text', title:'重要合规提示内容（支持 HTML）', type:'html', rows:5, desc:'如：未成年人保护、合规使用说明、免责声明等' },
            { key:'home_compliance_bg', title:'合规提示背景色', type:'color', desc:'默认浅黄 #fff9e6' },
            { key:'home_notice_enabled', title:'启用「公告提示」', type:'bool', desc:'开启后首页展示公告/活动通知模块' },
            { key:'home_notice_text', title:'公告提示内容（支持 HTML）', type:'html', rows:5, desc:'活动通知、维护公告、推广信息等' },
        ];

        const html = defs.map(d => {
            const v = map[d.key] ? (map[d.key].setting_value ?? '') : '';
            const desc = d.desc ? `<small style="display:block;color:var(--text-secondary);margin-top:2px">${esc(d.desc)}</small>` : '';
            let inputHtml;
            if (d.type === 'bool') {
                inputHtml = `<select name="${d.key}"><option value="1" ${v==='1'?'selected':''}>是</option><option value="0" ${v!=='1'?'selected':''}>否</option></select>`;
            } else if (d.type === 'color') {
                inputHtml = `<input type="color" name="${d.key}" value="${esc(v || '#fff9e6')}" style="height:36px;padding:2px 4px;cursor:pointer;">`;
            } else {
                inputHtml = `<textarea name="${d.key}" rows="${d.rows||4}" style="font-family:monospace;font-size:13px;">${esc(v)}</textarea>`;
            }
            return `<div class="form-group"><label>${esc(d.title)}${desc}</label>${inputHtml}</div>`;
        }).join('');

        container.innerHTML = html;
    } catch(e) { console.error(e); container.innerHTML = '<p style="color:var(--danger)">加载异常</p>'; }
}

async function saveHomepageSettings() {
    const container = $('#settingsFormHomepage');
    if (!container) return;
    const inputs = container.querySelectorAll('[name]');
    if (!inputs.length) { toast('暂无可保存项'); return; }

    const promises = [];
    inputs.forEach(input => {
        promises.push(
            fetch(ADMIN_API, {
                method:'POST', headers:{'Content-Type':'application/json'},
                body: JSON.stringify({ action:'setting_save', key:input.name, value:input.value })
            }).then(async r => { try { return await r.json(); } catch(e){ return {status:1, message:'响应异常'}; } })
        );
    });

    const results = await Promise.all(promises);
    const fail = results.filter(r=>r.status!==0).length;
    toast(fail > 0 ? `${results.length - fail}/${results.length} 项保存成功` : '首页模块设置已保存');
}

// ========== 登录集成（第三方登录 / UCenter） ==========
const OAUTH_DEFS = [
    { key:'oauth_qq_enabled', title:'QQ 登录-启用', type:'bool' },
    { key:'oauth_qq_appid', title:'QQ 互联 AppID', type:'text' },
    { key:'oauth_qq_appkey', title:'QQ 互联 AppKey/Secret', type:'text' },
    { key:'oauth_qq_callback', title:'QQ 回调地址', type:'text', placeholder:'http://域名/user/oauth.php?action=callback&provider=qq' },
    { key:'oauth_wx_enabled', title:'微信登录-启用', type:'bool' },
    { key:'oauth_wx_appid', title:'微信开放平台 AppID', type:'text' },
    { key:'oauth_wx_appsecret', title:'微信开放平台 AppSecret', type:'text' },
    { key:'oauth_wx_callback', title:'微信 回调地址', type:'text', placeholder:'http://域名/user/oauth.php?action=callback&provider=wx' },
];

const UCENTER_DEFS = [
    { key:'uc_enabled', title:'UCenter 同步-启用', type:'bool' },
    { key:'uc_api', title:'UCenter 通信地址', type:'text', placeholder:'http://bbs.example.com/uc_server' },
    { key:'uc_key', title:'UCenter 通信密钥', type:'text' },
    { key:'uc_appid', title:'当前应用 ID', type:'text' },
    { key:'uc_ip', title:'UCenter 服务器 IP（可选）', type:'text' },
    { key:'uc_charset', title:'字符集', type:'text' },
    { key:'uc_connect', title:'数据库连接方式', type:'text', placeholder:'mysql 或 default' },
    { key:'uc_dbhost', title:'UCenter 数据库主机', type:'text' },
    { key:'uc_dbuser', title:'UCenter 数据库用户', type:'text' },
    { key:'uc_dbpw', title:'UCenter 数据库密码', type:'text' },
    { key:'uc_dbname', title:'UCenter 数据库名', type:'text' },
    { key:'uc_dbtablepre', title:'UCenter 表前缀', type:'text', placeholder:'uc_' },
    // ---- 同步策略（独立开关，默认开启）----
    { key:'uc_sync_register', title:'本站注册 → 写入 UCenter', type:'bool', section:'同步策略（可逐项独立开关）', desc:'开启后，本站新注册用户会同步创建到 UCenter 统一用户中心。' },
    { key:'uc_sync_login', title:'本站登录 → 广播同步登录', type:'bool', desc:'开启后，在本站登录会向 UCenter 体系广播同步登录（跨应用免登）。' },
    { key:'uc_sync_password', title:'本站改密 → 同步 UCenter', type:'bool', desc:'开启后，本站修改密码会同步更新到 UCenter。' },
    { key:'uc_sync_email', title:'本站改资料 → 同步邮箱', type:'bool', desc:'开启后，本站修改邮箱会同步更新到 UCenter。' },
    { key:'uc_allow_uc_login', title:'允许 UCenter 用户登录本站', type:'bool', desc:'开启后，可使用 UCenter 账号（统一用户中心）登录本站。' },
    { key:'uc_auto_create', title:'UCenter 用户自动建号', type:'bool', desc:'开启后，用 UCenter 账号登录本站时若本地无账号会自动建档并绑定。' },
];

async function loadIntegrations() {
    const oauthBox = $('#settingsFormOAuth');
    const ucBox = $('#settingsFormUCenter');
    if (!oauthBox) return;
    oauthBox.innerHTML = '<p style="color:var(--text-secondary);padding:12px;">加载中...</p>';
    if (ucBox) ucBox.innerHTML = '<p style="color:var(--text-secondary);padding:12px;">加载中...</p>';
    try {
        const [oR, uR] = await Promise.all([
            fetch(`${ADMIN_API}?action=settings&group=oauth`),
            fetch(`${ADMIN_API}?action=settings&group=ucenter`),
        ]);
        const oData = oR.ok ? (await oR.json()) : { data: [] };
        const uData = uR.ok ? (await uR.json()) : { data: [] };
        renderIntegrationForm(oauthBox, OAUTH_DEFS, oData.data || []);
        if (ucBox) renderIntegrationForm(ucBox, UCENTER_DEFS, uData.data || []);
    } catch (e) {
        console.error(e);
        if (oauthBox) oauthBox.innerHTML = '<p style="color:var(--danger)">加载失败</p>';
    }
}

function renderIntegrationForm(container, defs, items) {
    const map = {};
    items.forEach(i => { map[i.setting_key] = i; });
    let lastSection = null;
    const html = defs.map(d => {
        let sectionHtml = '';
        if (d.section && d.section !== lastSection) {
            lastSection = d.section;
            sectionHtml = `<h4 class="form-section" style="margin:18px 0 10px;font-size:13px;font-weight:600;color:#8b5cf6;border-left:3px solid #8b5cf6;padding-left:8px;">${esc(d.section)}</h4>`;
        }
        const v = map[d.key] ? (map[d.key].setting_value ?? '') : '';
        const desc = d.desc ? `<small style="display:block;color:var(--text-secondary);margin-top:2px">${esc(d.desc)}</small>` : '';
        let inputHtml;
        if (d.type === 'bool') {
            inputHtml = `<select name="${d.key}"><option value="1" ${v==='1'?'selected':''}>是</option><option value="0" ${v!=='1'?'selected':''}>否</option></select>`;
        } else {
            const ph = d.placeholder ? ` placeholder="${esc(d.placeholder)}"` : '';
            inputHtml = `<input type="text" name="${d.key}" value="${esc(v)}"${ph}>`;
        }
        return sectionHtml + `<div class="form-group"><label>${esc(d.title)}${desc}</label>${inputHtml}</div>`;
    }).join('');
    container.innerHTML = html;
}

async function saveIntegrationsSettings() {
    const containers = ['#settingsFormOAuth', '#settingsFormUCenter'];
    const promises = [];
    containers.forEach(sel => {
        const c = $(sel);
        if (!c) return;
        c.querySelectorAll('[name]').forEach(input => {
            promises.push(
                fetch(ADMIN_API, {
                    method:'POST', headers:{'Content-Type':'application/json'},
                    body: JSON.stringify({ action:'setting_save', key:input.name, value:input.value })
                }).then(async r => { try { return await r.json(); } catch(e){ return {status:1, message:'响应异常'}; } })
            );
        });
    });
    if (!promises.length) { toast('暂无可保存项'); return; }
    const results = await Promise.all(promises);
    const fail = results.filter(r=>r.status!==0).length;
    toast(fail > 0 ? `${results.length - fail}/${results.length} 保存成功` : '登录集成设置已保存');
}

async function loadLogs() {
    try {
        const resp = await fetch(`${ADMIN_API}?action=logs&page=${logPage}&limit=20`);
        if (!resp.ok) { console.error('Logs HTTP错误:', resp.status); return; }
        let data;
        try { data = await resp.json(); } catch(e) { console.error('Logs非JSON响应:', e.message); return; }
        if (data.status !== 0) return;

        let html = '';
        (data.data.list||[]).forEach(l => {
            html += `<tr><td>${l.id}</td><td>${esc(l.admin_name||'')}</td><td>${esc(l.action)}</td>
                <td>${esc(l.target_type||'-')}:${l.target_id||''}</td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis">${esc(l.detail||'-')}</td>
                <td>${esc(l.ip)}</td><td>${fmtTime(l.created_at)}</td></tr>`;
        });
        $('#logTable tbody').innerHTML = html || '<tr><td colspan="7">暂无日志</td></tr>';
        renderPagination($('#logPagination'), data.data.total, logPage, 20, p=>{logPage=p;loadLogs()});
    } catch(e) { console.error(e); }
}

// ========== 测速记录管理 ==========
let speedLogPage = 1;

async function loadSpeedLogs() {
    const keyword = $('#speedLogSearch') ? $('#speedLogSearch').value.trim() : '';
    let url = `${ADMIN_API}?action=speed_logs&page=${speedLogPage}&limit=20`;
    if (keyword) url += `&keyword=${encodeURIComponent(keyword)}`;

    const tbody = $('#speedLogTable tbody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:20px;color:#999;">加载中...</td></tr>';

    try {
        const resp = await fetch(url);
        if (!resp.ok) {
            let errText = '';
            try { errText = await resp.text(); } catch(e2) {}
            console.error('SpeedLogs HTTP错误:', resp.status, errText.substring(0, 300));
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:20px;color:#f56c6c;font-size:13px;">
                &#9888; 请求失败 (HTTP ${resp.status})，请检查网络或刷新重试</td></tr>`;
            return;
        }
        let data;
        try { data = await resp.json(); } catch(parseErr) {
            let rawText = '';
            try { rawText = await resp.text(); } catch(_) {}
            console.error('SpeedLogs非JSON响应:', rawText.substring(0, 300));
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:20px;color:#f56c6c;font-size:13px;">
                &#9888; 服务器响应异常，请刷新页面重试</td></tr>`;
            return;
        }

        // API 返回错误
        if (data.status !== 0 || !data.data) {
            const errMsg = data.message || '未知错误';
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:24px;color:#e6a23c;font-size:14px;">
                <div>&#9888; ${esc(errMsg)}</div>
                <div style="color:#999;font-size:12px;margin-top:6px;">请检查 traffic_logs 表是否存在，或联系管理员执行建表SQL</div>
                </td></tr>`;
            if ($('#speedLogTotal')) $('#speedLogTotal').textContent = '';
            return;
        }

        const { list, total, diag } = data.data;
        if ($('#speedLogTotal')) $('#speedLogTotal').textContent = `共 ${total} 条`;

        // 诊断：如果表存在但没数据
        if (!list || list.length === 0 && total === 0) {
            tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:36px 20px;">
                <div style="color:#909399;font-size:40px;margin-bottom:8px;">&#128202;</div>
                <div style="color:#909399;font-size:14px;">暂无测速记录</div>
                <div style="color:#c0c4cc;font-size:12px;margin-top:4px;">前台用户测速后数据会自动记录在此处</div>
                ${diag && !diag.has_url ? '<div style="color:#e6a23c;font-size:12px;margin-top:8px;">[诊断] traffic_logs 表缺少 url 列</div>' : ''}
                </td></tr>`;
            renderPagination($('#speedLogPagination'), 0, speedLogPage, 20, p => { speedLogPage = p; loadSpeedLogs(); });
            return;
        }

        let html = '';
        list.forEach(row => {
            const bytes = formatBytes(row.bytes_used);
            const urlShort = row.url ? (row.url.length > 40 ? row.url.substring(0, 40) + '...' : row.url) : '-';
            const uaShort = parseBrowserUA(row.user_agent);
            html += `<tr>
                <td>${row.id}</td>
                <td><span class="${row.user_id > 0 ? 'tag tag-info' : ''}" style="font-size:12px;">${esc(row.username)}</span></td>
                <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;" title="${esc(row.url)}">${urlShort}</td>
                <td><strong style="color:var(--primary);">${bytes}</strong></td>
                <td>${row.duration}s</td>
                <td>${formatBps(row.speed)}</td>
                <td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;font-size:12px;">${esc(row.ip)}</td>
                <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;font-size:12px;" title="${esc(row.user_agent)}">${uaShort}</td>
                <td style="white-space:nowrap;font-size:12px;">${fmtTime(row.created_at)}</td>
            </tr>`;
        });
        tbody.innerHTML = html || '<tr><td colspan="9" style="text-align:center;padding:20px;color:#999;">暂无数据</td></tr>';
        renderPagination($('#speedLogPagination'), total, speedLogPage, 20, p => { speedLogPage = p; loadSpeedLogs(); });
    } catch(e) {
        console.error('Speed logs load error:', e);
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:20px;color:#f56c6c;font-size:13px;">
            &#9888; 加载异常：${esc(e.message || '未知错误')}<br><span style="color:#999;font-size:11px;margin-top:4px;display:inline-block;">请按 F12 打开控制台查看详细错误</span></td></tr>`;
    }
}
// ========== 用户反馈管理 ==========
async function loadFeedback() {
    const status = $('#feedbackStatusFilter').value;
    let url = `${ADMIN_API}?action=feedback_list&page=${feedbackPage}&limit=15`;
    if (status !== '') url += `&status=${status}`;

    // 先显示加载中，确保任何异常都能恢复显示
    const tbody = $('#feedbackTable tbody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:20px;color:#999;">加载中...</td></tr>';

    try {
        const resp = await fetch(url);
        // 先检查 HTTP 状态
        if (!resp.ok) {
            let errText = '';
            try { errText = await resp.text(); } catch(e2) {}
            throw new Error('HTTP ' + resp.status + ': ' + (errText || '').substring(0, 200));
        }
        const data = await resp.json();
        if (data.status !== 0) {
            tbody.innerHTML = `<tr><td colspan="6" style="color:#f56c6c;text-align:center;padding:20px;font-size:13px;">&#9888; ${esc(data.message || '服务器返回错误')}</td></tr>`;
            return;
        }

        const list = data.data.list;
        const statusMap = { 0: ['未读', 'tag-danger'], 1: ['已读', 'tag-warning'], 2: ['已处理', 'tag-success'] };

        let html = '';
        if (list && list.length > 0) {
            list.forEach(f => {
                const [stext, sclass] = statusMap[f.status] || ['未知', ''];
                const fcontent = f.content || '';
                const contentPreview = esc(fcontent.length > 60 ? fcontent.substring(0, 60) + '...' : fcontent);
                html += `<tr>
                    <td>${f.id}</td>
                    <td><strong>${esc(f.username)}</strong><br><small style="color:#999;">ID:${f.user_id}</small></td>
                    <td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:normal;line-height:1.5;font-size:13px;" title="${esc(fcontent)}">${contentPreview || '<span style="color:#ccc">（空）</span>'}</td>
                    <td><span class="tag ${sclass}">${stext}</span></td>
                    <td>${fmtTime(f.created_at)}</td>
                    <td><div class="action-btns">
                        <button class="action-btn btn-status-pending${f.status===0?' active':''}" onclick="setFeedbackStatus(${f.id},0)">待处理</button>
                        <button class="action-btn btn-status-read${f.status===1?' active':''}" onclick="setFeedbackStatus(${f.id},1)">已读</button>
                        <button class="action-btn btn-status-done${f.status===2?' active':''}" onclick="setFeedbackStatus(${f.id},2)">已处理</button>
                    </div></td></tr>`;
            });
        }
        const totalCount = data.data.total || 0;
        if (!html && totalCount === 0) {
            html = `<tr><td colspan="6" style="text-align:center;padding:36px 20px;">
                <div style="color:#c0c4cc;font-size:40px;margin-bottom:8px;">&#128172;</div>
                <div style="color:#909399;font-size:14px;">暂无反馈数据</div>
                <div style="color:#c0c4cc;font-size:12px;margin-top:4px;">用户提交的反馈将显示在此处</div>
            </td></tr>`;
        } else if (!html) {
            html = '<tr><td colspan="6" style="text-align:center;padding:24px;color:#e6a23c;font-size:14px;">当前筛选条件下无数据</td></tr>';
        }
        tbody.innerHTML = html;
        renderPagination($('#feedbackPagination'), totalCount, feedbackPage, 15, p => { feedbackPage = p; loadFeedback(); });
        $('#feedbackTotal').textContent = `共 ${totalCount} 条`;
    } catch (e) {
        tbody.innerHTML = `<tr><td colspan="6" style="color:#f56c6c;text-align:center;padding:20px;font-size:13px;">&#9888; 请求失败：${esc(e.message || '网络错误')}</td></tr>`;
    }
}

// ========== 设置反馈状态（快捷操作） ==========
async function setFeedbackStatus(id, status) {
    const statusNames = { 0: '待处理', 1: '已读', 2: '已处理' };
    try {
        const resp = await fetch(ADMIN_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'feedback_set_status', id, status })
        });
        let d;
        try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
        if (d.status === 0) {
            toast('已标记为' + (statusNames[status] || status));
            loadFeedback();
            if (currentPage === 'dashboard') loadDashboard();
        } else {
            toast(d.message || '操作失败');
        }
    } catch(e) { toast('网络错误'); }
}

// ========== 清空所有反馈 ==========
async function clearAllFeedback() {
    if (!await showConfirm('清空反馈', '确定要清空所有反馈数据吗？<br><br><span style="color:#f56c6c;font-weight:600;">此操作不可恢复！</span>')) return;
    if (!await showConfirm('再次确认', '真的要清空全部用户反馈吗？')) return;

    try {
        const resp = await fetch(ADMIN_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'feedback_clear', hard_reset: true })
        });
        let d;
        try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }

        if (d.status === 0) {
            toast(d.message || '已清空');
            feedbackPage = 1;
            loadFeedback();
            // 刷新仪表盘未读数
            if (currentPage === 'dashboard') loadDashboard();
        } else {
            toast(d.message || '清空失败');
        }
    } catch(e) { toast('网络错误'); }
}

// ========== 查询记录管理 ==========
async function loadQueryLogs() {
    const keyword = $('#queryLogSearch') ? $('#queryLogSearch').value.trim() : '';
    const type = $('#queryLogTypeFilter') ? $('#queryLogTypeFilter').value : '';
    let url = `${ADMIN_API}?action=query_log_list&page=${queryLogPage}&limit=20`;
    if (keyword) url += `&keyword=${encodeURIComponent(keyword)}`;
    if (type) url += `&type=${encodeURIComponent(type)}`;

    const tbody = $('#queryLogTable tbody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:20px;color:#999;">加载中...</td></tr>';

    try {
        const resp = await fetch(url);
        let data;
        try { data = await resp.json(); } catch(e) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:20px;color:#f56c6c;font-size:13px;">&#9888; 服务器响应异常，请刷新重试</td></tr>';
            return;
        }

        if (data.status !== 0 || !data.data) {
            const errMsg = data.message || '未知错误';
            tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:24px;color:#e6a23c;font-size:14px;">
                <div>&#9888; ${esc(errMsg)}</div>
                <div style="color:#999;font-size:12px;margin-top:6px;">请检查 query_logs 表是否存在，或联系管理员执行建表 SQL</div></td></tr>`;
            if ($('#queryLogTotal')) $('#queryLogTotal').textContent = '';
            return;
        }

        const { list, total } = data.data;
        if ($('#queryLogTotal')) $('#queryLogTotal').textContent = `共 ${total} 条`;

        if (!list || list.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:36px 20px;">
                <div style="color:#909399;font-size:40px;margin-bottom:8px;">&#128270;</div>
                <div style="color:#909399;font-size:14px;">暂无查询记录</div>
                <div style="color:#c0c4cc;font-size:12px;margin-top:4px;">前台用户/游客的查询行为会自动记录在此处</div></td></tr>`;
            renderPagination($('#queryLogPagination'), 0, queryLogPage, 20, p => { queryLogPage = p; loadQueryLogs(); });
            return;
        }

        const TYPE_LABELS = { ip:'IP查询', ip_advanced:'IP进阶', traffic:'流量计算', byte:'字节转换', speedtest:'测速', ip_tools:'IP工具', other:'其他' };
        let html = '';
        list.forEach(row => {
            const isGuest = !row.user_id || row.user_id === 0;
            const userTag = isGuest
                ? '<span style="color:#909399;font-size:12px;">游客</span>'
                : `<span class="tag tag-info" style="font-size:12px;">${esc(row.username)}</span>`;
            const typeLabel = TYPE_LABELS[row.query_type] || row.query_type || '-';
            const inputShort = row.query_input ? (row.query_input.length > 40 ? row.query_input.substring(0, 40) + '...' : row.query_input) : '-';
            const summaryShort = row.result_summary ? (row.result_summary.length > 40 ? row.result_summary.substring(0, 40) + '...' : row.result_summary) : '-';
            html += `<tr>
                <td>${row.id}</td>
                <td>${userTag}</td>
                <td><span class="tag" style="font-size:12px;">${typeLabel}</span></td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;" title="${esc(row.query_input)}">${esc(inputShort)}</td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;" title="${esc(row.result_summary)}">${esc(summaryShort)}</td>
                <td style="font-size:12px;">${esc(row.ip)}</td>
                <td style="white-space:nowrap;font-size:12px;">${fmtTime(row.created_at)}</td>
                <td><button class="btn-danger btn-sm" onclick="deleteQueryLog(${row.id})">删除</button></td>
            </tr>`;
        });
        tbody.innerHTML = html;
        renderPagination($('#queryLogPagination'), total, queryLogPage, 20, p => { queryLogPage = p; loadQueryLogs(); });
    } catch(e) {
        console.error('Query logs load error:', e);
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:20px;color:#f56c6c;font-size:13px;">
            &#9888; 加载异常：${esc(e.message || '未知错误')}</td></tr>`;
    }
}

async function deleteQueryLog(id) {
    if (!confirm('确定删除这条查询记录吗？')) return;
    try {
        const resp = await fetch(ADMIN_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'query_log_delete', id })
        });
        let d; try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
        if (d.status === 0) { toast('已删除'); loadQueryLogs(); }
        else { toast(d.message || '删除失败'); }
    } catch(e) { toast('网络错误'); }
}

async function clearQueryLogs() {
    if (!confirm('确定清空所有查询记录吗？此操作不可恢复！')) return;
    try {
        const resp = await fetch(ADMIN_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'query_log_clear' })
        });
        let d; try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
        if (d.status === 0) { toast(d.message || '已清空'); queryLogPage = 1; loadQueryLogs(); }
        else { toast(d.message || '清空失败'); }
    } catch(e) { toast('网络错误'); }
}

