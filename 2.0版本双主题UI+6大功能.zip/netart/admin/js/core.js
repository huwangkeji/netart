// ========== 状态 ==========
let currentPage = 'dashboard';
let userPage = 1, logPage = 1, feedbackPage = 1, queryLogPage = 1;

// ========== 初始化 ==========
document.addEventListener('DOMContentLoaded', () => {
    checkAdminAuth();
    bindEvents();
    startClock();
});

function checkAdminAuth() {
    fetch(AUTH_API + '?action=check', { credentials: 'same-origin' })
        .then(async r => { try { return await r.json(); } catch(e) { return {status:-1}; } })
        .then(data => {
            if (data.status === 0) {
                showAdmin(data.data);
            } else {
                showLogin();
            }
        })
        .catch(() => showLogin());
}

function showLogin() {
    $('#loginPage').style.display = '';
    $('#adminLayout').style.display = 'none';
}

function showAdmin(admin) {
    $('#loginPage').style.display = 'none';
    $('#adminLayout').style.display = 'flex';
    $('.admin-name').textContent = admin.nickname || admin.username;
    loadDashboard();
}

// ========== 登录 ==========
$('#btnLogin').addEventListener('click', async () => {
    const form = new FormData($('#loginForm'));
    const username = form.get('username');
    const password = form.get('password');

    if (!username || !password) return showError('请输入账号和密码');
    
    $('#loginError').textContent = '';
    $('#btnLogin').disabled = true;
    $('#btnLogin').textContent = '登录中...';

    try {
        const resp = await fetch(AUTH_API, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ action:'login', username, password })
        });
        let data;
        try { data = await resp.json(); } catch(parseErr) { showError('服务器响应异常'); return; }

        if (data.status === 0) {
            showAdmin(data.data);
        } else {
            showError(data.message || '登录失败');
        }
    } catch(e) {
        showError('网络错误');
    }
    $('#btnLogin').disabled = false;
    $('#btnLogin').textContent = '登 录';
});

function showError(msg) { $('#loginError').textContent = msg; }

function showToast(msg) {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = msg;
    Object.assign(el.style,{position:'fixed',top:'20px',left:'50%',transform:'translateX(-50%)',
        background:'rgba(86,104,238,.9)',color:'#fff',padding:'10px 24px',borderRadius:'8px',
        zIndex:99999,animation:'fadeInOut 2.5s forwards'});
    document.body.appendChild(el); setTimeout(()=>el.remove(),2500);
}
const toast = showToast;

// ========== 事件绑定 ==========
function bindEvents() {
    // 导航
    $$('.nav-item[data-page]').forEach(item => {
        item.addEventListener('click', e => {
            e.preventDefault();
            switchPage(item.dataset.page);
        });
    });

    // 侧边栏折叠
    $('#menuToggle').addEventListener('click', () => {
        $('#sidebar').classList.toggle('collapsed');
    });

    // 退出
    $('#btnLogout').addEventListener('click', async (e) => {
        e.preventDefault();
        await fetch(AUTH_API, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'logout'})});
        location.reload();
    });

    // 节点管理
    if ($('#btnAddNode')) $('#btnAddNode').addEventListener('click', () => openNodeModal());
    if ($('#btnSaveNode')) $('#btnSaveNode').addEventListener('click', saveNode);
    if ($('#btnCancelNode')) $('#btnCancelNode').addEventListener('click', () => {
        const modal = document.getElementById('modalNodeEdit');
        if (modal) modal.close();
    });

    // 用户搜索
    if ($('#btnSearchUser')) $('#btnSearchUser').addEventListener('click', () => { userPage=1; loadUsers(); });
    $('#userSearch').addEventListener('keyup', e => { if(e.key==='Enter'){ if($('#btnSearchUser'))$('#btnSearchUser').click();} });
    if ($('#userRoleFilter')) $('#userRoleFilter').addEventListener('change', () => { userPage=1; loadUsers(); });

    // 保存所有设置
    if ($('#btnSaveAllSettings')) $('#btnSaveAllSettings').addEventListener('click', saveAllSettings);

    // 用户编辑保存
    if ($('#btnSaveUser')) $('#btnSaveUser').addEventListener('click', saveUser);

    // 反馈筛选
    if ($('#btnSearchFeedback')) $('#btnSearchFeedback').addEventListener('click', () => { feedbackPage=1; loadFeedback(); });
    if ($('#btnSearchSpeedLog')) $('#btnSearchSpeedLog').addEventListener('click', () => { speedLogPage=1; loadSpeedLogs(); });
    if ($('#speedLogSearch')) $('#speedLogSearch').addEventListener('keyup', e => { if (e.key === 'Enter') { if ($('#btnSearchSpeedLog')) $('#btnSearchSpeedLog').click(); } });
    if ($('#feedbackStatusFilter')) $('#feedbackStatusFilter').addEventListener('change', () => { feedbackPage=1; loadFeedback(); });
    // 反馈清空
    if ($('#btnClearFeedback')) $('#btnClearFeedback').addEventListener('click', clearAllFeedback);

    // 公告管理
    if ($('#btnAddAnnouncement')) $('#btnAddAnnouncement').addEventListener('click', () => openAnnouncementModal());
    if ($('#btnSaveAnnouncement')) $('#btnSaveAnnouncement').addEventListener('click', saveAnnouncement);
    if ($('#btnCancelAnnouncement')) $('#btnCancelAnnouncement').addEventListener('click', () => {
        const modal = document.getElementById('modalAnnouncementEdit');
        if (modal) modal.close();
    });
    if ($('#announcementContent')) $('#announcementContent').addEventListener('input', updateAnnouncementPreview);

    // 广告管理
    if ($('#btnAddAd')) $('#btnAddAd').addEventListener('click', () => openAdModal());
    if ($('#btnSaveAd')) $('#btnSaveAd').addEventListener('click', saveAd);
    if ($('#btnRedirectSettings')) $('#btnRedirectSettings').addEventListener('click', openRedirectSettings);
    if ($('#btnSaveRedirectSettings')) $('#btnSaveRedirectSettings').addEventListener('click', saveRedirectSettings);

    // 页面管理（用户协议 / 隐私政策）
    if ($('#pageSlugSelect')) $('#pageSlugSelect').addEventListener('change', () => loadPageEditor());
    if ($('#pageContentInput')) $('#pageContentInput').addEventListener('input', renderPagePreview);
    if ($('#btnSavePage')) $('#btnSavePage').addEventListener('click', savePageContent);
    if ($('#btnResetPage')) $('#btnResetPage').addEventListener('click', resetPageContent);

    // 首页动态模块设置
    if ($('#btnSaveHomepageSettings')) $('#btnSaveHomepageSettings').addEventListener('click', saveHomepageSettings);

    // 登录集成设置
    if ($('#btnSaveIntegrations')) $('#btnSaveIntegrations').addEventListener('click', saveIntegrationsSettings);

    // 查询记录管理
    if ($('#btnSearchQueryLog')) $('#btnSearchQueryLog').addEventListener('click', () => { queryLogPage = 1; loadQueryLogs(); });
    if ($('#queryLogSearch')) $('#queryLogSearch').addEventListener('keyup', e => { if (e.key === 'Enter') { if ($('#btnSearchQueryLog')) $('#btnSearchQueryLog').click(); } });
    if ($('#queryLogTypeFilter')) $('#queryLogTypeFilter').addEventListener('change', () => { queryLogPage = 1; loadQueryLogs(); });
    if ($('#btnClearQueryLogs')) $('#btnClearQueryLogs').addEventListener('click', clearQueryLogs);

    // 弹窗关闭
    $$('[data-close]').forEach(btn => btn.addEventListener('click', function(){
        this.closest('.modal')?.close?.();
    }));
}

// ========== 页面切换 ==========
function switchPage(page) {
    currentPage = page;
    // 更新导航
    $$('.nav-item[data-page]').forEach(i => i.classList.toggle('active', i.dataset.page === page));
    // 更新页面
    $$('.page-content').forEach(p => p.classList.toggle('active', p.id === 'page-'+page));
    // 标题
    const titles = { dashboard:'仪表盘', nodes:'节点管理', users:'会员管理', settings:'系统设置', homemodules:'首页模块', integrations:'登录集成', announcements:'公告管理', ads:'广告管理', logs:'操作日志', speedlogs:'测速记录', feedback:'用户反馈', pages:'页面管理', querylogs:'查询记录' };
    $('#pageTitle').textContent = titles[page] || page;

    // 加载数据
    switch(page) {
        case 'dashboard': loadDashboard(); break;
        case 'nodes': loadNodes(); break;
        case 'users': loadUsers(); break;
        case 'settings': loadSettings(); break;
        case 'announcements': loadAnnouncements(); break;
        case 'ads': loadAds(); break;
        case 'logs': logPage=1; loadLogs(); break;
        case 'speedlogs': speedLogPage=1; loadSpeedLogs(); break;
        case 'feedback': feedbackPage=1; loadFeedback(); break;
        case 'pages': loadPageEditor(); break;
        case 'homemodules': loadHomeModules(); break;
        case 'integrations': loadIntegrations(); break;
        case 'querylogs': queryLogPage=1; loadQueryLogs(); break;
    }
}

