// ========== 公告管理 ==========
async function loadAnnouncements() {
    try {
        const resp = await fetch(ADMIN_API + '?action=announcements');
        if (!resp.ok) { console.error('Announcements HTTP错误:', resp.status); return; }
        let data;
        try { data = await resp.json(); } catch(e) { console.error('Announcements非JSON响应:', e.message); return; }
        if (data.status !== 0) return;

        let html = '';
        (data.data || []).forEach(a => {
            const statusTag = a.status ? '<span class="tag tag-success">启用</span>' : '<span class="tag tag-danger">禁用</span>';
            const popupTag = a.show_popup ? '<span class="tag tag-primary">弹窗</span>' : '<span class="tag tag-info">不弹窗</span>';
            const toggleBtn = a.status
                ? `<button class="action-btn warning" onclick="toggleAnnouncementStatus(${a.id}, 0)">禁用</button>`
                : `<button class="action-btn success" onclick="toggleAnnouncementStatus(${a.id}, 1)">启用</button>`;
            const contentPreview = esc(a.content ? (a.content.length > 60 ? a.content.substring(0, 60) + '...' : a.content) : '');
            html += `<tr><td>${a.id}</td><td>${esc(a.title || '公告')}</td>
                <td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;" title="${esc(a.content||'')}">${contentPreview}</td>
                <td>${statusTag}</td><td>${popupTag}</td><td>${a.sort_order}</td><td>${fmtTime(a.updated_at)}</td>
                <td><div class="action-btns">
                    ${toggleBtn}
                    <button class="action-btn" onclick="openAnnouncementModal(${a.id})">编辑</button>
                    <button class="action-btn danger" onclick="deleteAnnouncement(${a.id})">删除</button>
                </div></td></tr>`;
        });
        $('#announcementTable tbody').innerHTML = html || '<tr><td colspan="8">暂无公告，点击"添加公告"创建</td></tr>';
    } catch(e) { console.error(e); }
}

let editingAnnouncementId = null;
function openAnnouncementModal(id = null) {
    editingAnnouncementId = id;
    $('#announcementModalTitle').textContent = id ? '编辑公告' : '添加公告';
    $('#editAnnouncementId').value = id || '';
    if (id) {
        fetch(`${ADMIN_API}?action=announcements&id=${id}`)
            .then(r => r.json())
            .then(data => {
                if (data.status === 0 && data.data) {
                    const a = data.data;
                    $('#announcementTitle').value = a.title || '公告';
                    $('#announcementContent').value = a.content || '';
                    $('#announcementStatus').value = a.status ?? 1;
                    $('#announcementShowPopup').value = a.show_popup ?? 1;
                    $('#announcementSortOrder').value = a.sort_order ?? 0;
                    updateAnnouncementPreview();
                }
            }).catch(e => console.error('获取公告详情失败', e));
    } else {
        $('#announcementTitle').value = '公告';
        $('#announcementContent').value = '';
        $('#announcementStatus').value = '1';
        $('#announcementShowPopup').value = '1';
        $('#announcementSortOrder').value = '0';
        updateAnnouncementPreview();
    }
    $('#modalAnnouncementEdit').showModal();
}

function updateAnnouncementPreview() {
    const content = $('#announcementContent').value;
    const preview = $('#announcementPreview');
    if (preview) preview.innerHTML = content || '<span style="color:var(--text-secondary)">暂无内容</span>';
}

async function saveAnnouncement() {
    const payload = {
        action: editingAnnouncementId ? 'announcement_edit' : 'announcement_add',
        id: editingAnnouncementId,
        title: $('#announcementTitle').value.trim() || '公告',
        content: $('#announcementContent').value.trim(),
        status: parseInt($('#announcementStatus').value),
        show_popup: parseInt($('#announcementShowPopup').value),
        sort_order: parseInt($('#announcementSortOrder').value) || 0
    };
    if (!payload.content) { toast('公告内容不能为空'); return; }

    try {
        const resp = await fetch(ADMIN_API, {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload)
        });
        let d;
        try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
        if (d.status === 0) {
            toast(d.message || '保存成功');
            $('#modalAnnouncementEdit').close();
            loadAnnouncements();
        } else { toast(d.message || '保存失败'); }
    } catch(e) { toast('网络错误'); }
}

async function deleteAnnouncement(id) {
    if (!await showConfirm('删除公告', '确定删除此公告？此操作不可恢复。')) return;
    const resp = await fetch(ADMIN_API, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ action:'announcement_delete', id })
    });
    let d;
    try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
    toast(d.status===0?'删除成功':d.message);
    loadAnnouncements();
}

async function toggleAnnouncementStatus(id, newStatus) {
    const resp = await fetch(ADMIN_API, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ action:'announcement_edit', id, status: newStatus })
    });
    let d;
    try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
    toast(d.status===0 ? (newStatus ? '已启用' : '已禁用') : d.message);
    loadAnnouncements();
}
// ========== 广告管理 ==========
async function loadAds() {
    try {
        const resp = await fetch(ADMIN_API + '?action=ads');
        if (!resp.ok) return;
        let data;
        try { data = await resp.json(); } catch(e) { return; }
        if (data.status !== 0) return;
        let html = '';
        (data.data || []).forEach(a => {
            const statusTag = a.status ? '<span class="tag tag-success">启用</span>' : '<span class="tag tag-danger">禁用</span>';
            const toggleBtn = a.status
                ? `<button class="action-btn warning" onclick="toggleAdStatus(${a.id}, 0)">禁用</button>`
                : `<button class="action-btn success" onclick="toggleAdStatus(${a.id}, 1)">启用</button>`;
            const colorPreview = a.color ? `<span style="display:inline-block;width:14px;height:14px;border-radius:3px;background:${esc(a.color)};vertical-align:middle;margin-right:4px;"></span>${esc(a.color)}` : '默认';
            const urlShort = a.url ? (a.url.length > 40 ? a.url.substring(0, 40) + '...' : a.url) : '-';
            html += `<tr><td>${a.id}</td><td>${esc(a.title)}</td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;" title="${esc(a.url||'')}">${esc(urlShort)}</td>
                <td>${colorPreview}</td><td>${statusTag}</td><td>${a.sort_order}</td><td>${fmtTime(a.updated_at)}</td>
                <td><div class="action-btns">
                    ${toggleBtn}
                    <button class="action-btn" onclick="openAdModal(${a.id})">编辑</button>
                    <button class="action-btn danger" onclick="deleteAd(${a.id})">删除</button>
                </div></td></tr>`;
        });
        $('#adTable tbody').innerHTML = html || '<tr><td colspan="8">暂无广告，点击"添加广告"创建</td></tr>';
    } catch(e) { console.error(e); }
}

let editingAdId = null;
function openAdModal(id = null) {
    editingAdId = id;
    var modal = document.getElementById('modalAdEdit');
    if (!modal) return;
    
    // 动态重建modal-body内容，确保所有输入框存在
    var body = modal.querySelector('.modal-body');
    if (body) {
        body.innerHTML = '';
        var hidden = document.createElement('input');
        hidden.type = 'hidden'; hidden.id = 'editAdId'; hidden.value = id || '';
        body.appendChild(hidden);
        
        var fg1 = document.createElement('div');
        fg1.className = 'form-group';
        var lb1 = document.createElement('label'); lb1.textContent = '广告文字';
        var inp1 = document.createElement('input');
        inp1.type = 'text'; inp1.id = 'adTitle'; inp1.placeholder = '输入广告展示文字';
        fg1.appendChild(lb1); fg1.appendChild(inp1);
        body.appendChild(fg1);
        
        var fg2 = document.createElement('div');
        fg2.className = 'form-group';
        var lb2 = document.createElement('label'); lb2.textContent = '跳转链接';
        var inp2 = document.createElement('input');
        inp2.type = 'text'; inp2.id = 'adUrl'; inp2.placeholder = 'https://example.com';
        fg2.appendChild(lb2); fg2.appendChild(inp2);
        body.appendChild(fg2);
        
        var row = document.createElement('div');
        row.className = 'form-row';
        
        var fg3 = document.createElement('div');
        fg3.className = 'form-group flex-1';
        var lb3 = document.createElement('label'); lb3.textContent = '文字颜色';
        var inp3 = document.createElement('input');
        inp3.type = 'color'; inp3.id = 'adColor'; inp3.value = '#5668EE';
        inp3.style.cssText = 'height:36px;padding:2px 4px;cursor:pointer;';
        fg3.appendChild(lb3); fg3.appendChild(inp3);
        row.appendChild(fg3);
        
        var fg4 = document.createElement('div');
        fg4.className = 'form-group flex-1';
        var lb4 = document.createElement('label'); lb4.textContent = '状态';
        var sel4 = document.createElement('select');
        sel4.id = 'adStatus';
        var opt1 = document.createElement('option'); opt1.value = '1'; opt1.textContent = '启用';
        var opt2 = document.createElement('option'); opt2.value = '0'; opt2.textContent = '禁用';
        sel4.appendChild(opt1); sel4.appendChild(opt2);
        fg4.appendChild(lb4); fg4.appendChild(sel4);
        row.appendChild(fg4);
        
        var fg5 = document.createElement('div');
        fg5.className = 'form-group flex-1';
        var lb5 = document.createElement('label'); lb5.textContent = '排序权重';
        var inp5 = document.createElement('input');
        inp5.type = 'number'; inp5.id = 'adSortOrder'; inp5.value = '0';
        inp5.min = '0'; inp5.max = '9999';
        fg5.appendChild(lb5); fg5.appendChild(inp5);
        row.appendChild(fg5);
        
        body.appendChild(row);
    }
    
    $('#adModalTitle').textContent = id ? '编辑广告' : '添加广告';
    if (id) {
        fetch(`${ADMIN_API}?action=ads&id=${id}`)
            .then(r => r.json())
            .then(data => {
                if (data.status === 0 && data.data) {
                    const a = data.data;
                    $('#adTitle').value = a.title || '';
                    $('#adUrl').value = a.url || '';
                    $('#adColor').value = a.color || '#5668EE';
                    $('#adStatus').value = a.status ?? 1;
                    $('#adSortOrder').value = a.sort_order ?? 0;
                }
            }).catch(e => console.error('获取广告详情失败', e));
    } else {
        $('#adTitle').value = '';
        $('#adUrl').value = '';
        $('#adColor').value = '#5668EE';
        $('#adStatus').value = '1';
        $('#adSortOrder').value = '0';
    }
    $('#modalAdEdit').showModal();
}

async function saveAd() {
    const payload = {
        action: editingAdId ? 'ad_edit' : 'ad_add',
        id: editingAdId,
        title: $('#adTitle').value.trim(),
        url: $('#adUrl').value.trim(),
        color: $('#adColor').value,
        status: parseInt($('#adStatus').value),
        sort_order: parseInt($('#adSortOrder').value) || 0
    };
    if (!payload.title || !payload.url) { toast('广告文字和链接不能为空'); return; }
    try {
        const resp = await fetch(ADMIN_API, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        let d;
        try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
        if (d.status === 0) { toast(d.message || '保存成功'); $('#modalAdEdit').close(); loadAds(); }
        else { toast(d.message || '保存失败'); }
    } catch(e) { toast('网络错误'); }
}

async function deleteAd(id) {
    if (!await showConfirm('删除广告', '确定删除此广告？')) return;
    const resp = await fetch(ADMIN_API, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ action:'ad_delete', id }) });
    let d;
    try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
    toast(d.status===0?'删除成功':d.message);
    loadAds();
}

async function toggleAdStatus(id, newStatus) {
    const resp = await fetch(ADMIN_API, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ action:'ad_edit', id, status: newStatus }) });
    let d;
    try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
    toast(d.status===0 ? (newStatus ? '已启用' : '已禁用') : d.message);
    loadAds();
}

async function openRedirectSettings() {
    try {
        const resp = await fetch(ADMIN_API + '?action=redirect_settings');
        const data = await resp.json();
        if (data.status === 0 && data.data) {
            const s = data.data;
            $('#redirectTitle').value = s.redirect_title || '广告跳转提示';
            $('#redirectLoadingText').value = s.redirect_loading_text || '广告加载中，请稍后...';
            $('#redirectDisclaimer').value = s.redirect_disclaimer || '';
            $('#redirectCountdown').value = s.redirect_countdown || '5';
        }
    } catch(e) { console.error(e); }
    $('#modalRedirectSettings').showModal();
}

async function saveRedirectSettings() {
    const payload = {
        action: 'redirect_settings_save',
        redirect_title: $('#redirectTitle').value.trim(),
        redirect_loading_text: $('#redirectLoadingText').value.trim(),
        redirect_disclaimer: $('#redirectDisclaimer').value.trim(),
        redirect_countdown: $('#redirectCountdown').value
    };
    try {
        const resp = await fetch(ADMIN_API, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        let d;
        try { d = await resp.json(); } catch(e) { toast('服务器响应异常'); return; }
        if (d.status === 0) { toast('保存成功'); $('#modalRedirectSettings').close(); }
        else { toast(d.message || '保存失败'); }
    } catch(e) { toast('网络错误'); }
}
// ========== 页面管理（用户协议 / 隐私政策） ==========
async function loadPageEditor() {
    const select = $('#pageSlugSelect');
    const input = $('#pageContentInput');
    const meta = $('#pageMeta');
    if (!select || !input) return;

    const slug = select.value || 'agreement';
    if ($('#btnViewPage')) $('#btnViewPage').href = '../' + slug + '.php';

    input.disabled = true;
    try {
        const resp = await fetch(`${ADMIN_API}?action=page_get&slug=${encodeURIComponent(slug)}`, { credentials: 'same-origin' });
        let data = null;
        try { data = await resp.json(); } catch (e) { toast('服务器响应异常'); return; }

        if (!data || data.status !== 0) { toast((data && data.message) || '加载失败'); input.value = ''; return; }

        input.value = data.data.content || '';
        if (meta) {
            meta.textContent = data.data.is_custom
                ? '当前为自定义内容，最后更新：' + (fmtTime(data.data.updated_at) || '-')
                : '当前为系统默认模板，保存后将覆盖默认内容';
        }
        renderPagePreview();
    } catch (e) {
        toast('网络错误');
    } finally {
        input.disabled = false;
    }
}

function renderPagePreview() {
    const box = $('#pagePreview');
    const input = $('#pageContentInput');
    if (!box || !input) return;
    box.innerHTML = input.value.trim()
        ? input.value
        : '<span style="color:var(--text-secondary)">暂无内容，前台将显示系统默认模板</span>';
}

async function savePageContent() {
    const select = $('#pageSlugSelect');
    const input = $('#pageContentInput');
    if (!select || !input) return;

    if (!input.value.trim()) { toast('内容不能为空'); return; }

    try {
        const resp = await fetch(ADMIN_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'page_save', slug: select.value, content: input.value })
        });
        let d = null;
        try { d = await resp.json(); } catch (e) { toast('服务器响应异常'); return; }

        if (d.status === 0) { toast('保存成功'); loadPageEditor(); }
        else { toast(d.message || '保存失败'); }
    } catch (e) { toast('网络错误'); }
}

async function resetPageContent() {
    const select = $('#pageSlugSelect');
    if (!select) return;
    if (!confirm('确定要恢复为系统默认内容吗？自定义内容将被删除且不可恢复。')) return;

    try {
        const resp = await fetch(ADMIN_API, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'page_reset', slug: select.value })
        });
        let d = null;
        try { d = await resp.json(); } catch (e) { toast('服务器响应异常'); return; }

        if (d.status === 0) { toast('已恢复默认内容'); loadPageEditor(); }
        else { toast(d.message || '恢复失败'); }
    } catch (e) { toast('网络错误'); }
}

