<?php
/**
 * 新版首页（落地页）
 *
 * 参考 https://net.arsn.cn 首页视觉层次：Hero 主视觉 → 核心工具网格 → 能力亮点 → NAT 检测专区 → 行动号召。
 * 与全站统一的 np-card / np-grid 组件体系保持一致，深色模式自适应。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/layout.php';

$siteName = app_site_name();

$tools = [
    [
        'icon' => '🚀',
        'name' => '实时测速',
        'url'  => './index.php',
        'desc' => '多线程采样实时呈现网速、流量消耗、带宽与峰值吞吐，支持限额与定时任务。',
        'primary' => true,
    ],
    [
        'icon' => '🌐',
        'name' => 'IP 归属查询',
        'url'  => './ip.php',
        'desc' => '支持 IPv4 / IPv6 / 域名，查看归属地、运营商与 ASN，结果缓存 24 小时。',
    ],
    [
        'icon' => '📈',
        'name' => '流量计算器',
        'url'  => './traffic.php',
        'desc' => '按速率与单价估算每小时 / 每天 / 每月 / 每年的流量消耗与费用。',
    ],
    [
        'icon' => '🔢',
        'name' => '字节转换',
        'url'  => './byte.php',
        'desc' => 'B / KB / MB / GB / TB / PB 互转，一次性给出全部单位结果。',
    ],
    [
        'icon' => '🛰️',
        'name' => 'IP 进阶工具',
        'url'  => './ip-tools.php',
        'desc' => '多地归属一致性对比、CDN/云厂商识别、TCP 延迟探测、多解析器 DNS 对比。',
    ],
    [
        'icon' => '🔌',
        'name' => 'NAT 类型检测',
        'url'  => './nat.php',
        'desc' => '多 STUN 节点采样公网映射，估算全锥 / 受限锥 / 端口受限锥 / 对称型 NAT。',
        'accent' => true,
    ],
];

$features = [
    ['icon' => '⚡', 'title' => '多节点实时测速', 'desc' => '并发多线程采样，直观反映当前网络真实吞吐与稳定性。'],
    ['icon' => '🔒', 'title' => '本地计算·隐私优先', 'desc' => '流量、字节换算均在浏览器完成，IP 查询仅提交待查地址本身。'],
    ['icon' => '🌍', 'title' => '全球归属识别', 'desc' => '覆盖国内外 IP 库，返回归属地、运营商与 ASN 线路信息。'],
    ['icon' => '🔌', 'title' => 'NAT 与连通性', 'desc' => '在线估算 NAT 类型，辅助判断游戏联机、P2P 与远程访问体验。'],
];

render_page_header([
    'title'    => '',
    'active'   => 'overview',
    'css'      => ['./css/home.css'],
    'description' => '青鸟云网络质量监测：实时测速、IP 归属查询、流量计算、字节转换、IP 进阶与 NAT 类型检测，一站式网络工具集合。',
]);
?>
<section class="home-hero">
    <div class="home-hero-glow" aria-hidden="true"></div>
    <div class="home-hero-inner">
        <span class="home-hero-badge">网络质量监测 · 一站式工具</span>
        <h1 class="home-hero-title">实时感知网络质量<br>精准定位连接异常</h1>
        <p class="home-hero-sub">从网速、流量到 IP 归属与 NAT 类型，用一套干净统一的界面，看清你当前的网络状况。</p>
        <div class="home-hero-actions">
            <a class="np-btn np-btn-primary home-cta" href="./index.php">开始测速</a>
            <a class="np-btn home-cta-ghost" href="#tools">浏览全部工具</a>
        </div>
        <div class="home-hero-stats">
            <div class="home-hero-stat"><span class="home-hero-stat-num">6+</span><span class="home-hero-stat-label">在线工具</span></div>
            <div class="home-hero-stat"><span class="home-hero-stat-num">IPv4/IPv6</span><span class="home-hero-stat-label">双栈支持</span></div>
            <div class="home-hero-stat"><span class="home-hero-stat-num">24h</span><span class="home-hero-stat-label">IP 缓存</span></div>
        </div>
    </div>
</section>

<section class="home-section" id="tools">
    <div class="home-section-head">
        <h2 class="home-section-title">核心工具</h2>
        <p class="home-section-desc">无需安装，打开即用。全部工具免费、轻量、跨平台。</p>
    </div>
    <div class="np-grid np-grid-3 home-tools">
        <?php foreach ($tools as $tool): ?>
            <a class="np-tool-card<?= !empty($tool['primary']) ? ' is-primary' : '' ?><?= !empty($tool['accent']) ? ' is-accent' : '' ?>" href="<?= e($tool['url']) ?>">
                <div class="np-tool-icon"><?= e($tool['icon']) ?></div>
                <div class="np-tool-name"><?= e($tool['name']) ?></div>
                <div class="np-tool-desc"><?= e($tool['desc']) ?></div>
                <span class="np-tool-arrow" aria-hidden="true">→</span>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<section class="home-section">
    <div class="home-section-head">
        <h2 class="home-section-title">为什么选择我们</h2>
        <p class="home-section-desc">把复杂的网络指标，变成一眼能懂的结果。</p>
    </div>
    <div class="np-grid np-grid-4 home-features">
        <?php foreach ($features as $f): ?>
            <div class="home-feature">
                <div class="home-feature-icon"><?= e($f['icon']) ?></div>
                <div class="home-feature-title"><?= e($f['title']) ?></div>
                <div class="home-feature-desc"><?= e($f['desc']) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="home-section">
    <div class="home-nat-band">
        <div class="home-nat-band-text">
            <h3 class="home-nat-band-title">🔌 你的 NAT 类型，决定了联机体验</h3>
            <p class="home-nat-band-desc">对称型 NAT 会让游戏联机、P2P 与远程访问变得困难。立即检测，了解你的网络处于哪一种。</p>
        </div>
        <a class="np-btn np-btn-primary" href="./nat.php">立即检测 NAT 类型</a>
    </div>
</section>

<section class="home-section home-cta-section">
    <div class="home-cta-card">
        <h2 class="home-cta-title">准备好看清你的网络了吗？</h2>
        <p class="home-cta-sub">一次点击，开始你的第一次测速。</p>
        <a class="np-btn np-btn-primary home-cta" href="./index.php">开始测速</a>
    </div>
</section>

<?php
render_page_footer(['scripts' => ['./js/home.js']]);
