<?php
/**
 * 网络流量计算器
 *
 * 计算指定速率在每小时 / 每天 / 每月 / 每年产生的流量及对应费用。
 * 换算口径：1 Mbps = 0.125 MB/s，1 GB = 1024 MB。
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/units.php';

$defaultPrice = app_default_price();
$defaultSpeed = (string) app_setting('traffic_default_speed', '2');

render_page_header([
    'title' => '网络流量计算器',
    'subtitle' => '按网络速率与流量单价，估算不同时间周期产生的流量与费用',
    'description' => '在线流量计算器：输入网络速率与单价，快速算出每小时、每天、每月、每年的流量消耗与费用，支持 Kbps / Mbps / Gbps。',
    'active' => 'tools',
]);
?>

<div class="np-card">
    <h2 class="np-card-title">⚙️ 计算参数</h2>
    <p class="np-card-desc">修改任意参数后结果自动刷新；速率支持 Kbps / Mbps / Gbps 三种单位。</p>

    <div class="np-field">
        <label class="np-label" for="speedInput">网络速率</label>
        <div class="np-input-group">
            <input class="np-input" type="number" id="speedInput" min="0" step="0.01"
                   value="<?= e($defaultSpeed) ?>" inputmode="decimal">
            <div class="np-stepper">
                <button class="np-btn" type="button" data-step="-1" data-target="speedInput" aria-label="减少">−</button>
                <button class="np-btn" type="button" data-step="1" data-target="speedInput" aria-label="增加">+</button>
            </div>
            <select class="np-select" id="speedUnit" aria-label="速率单位">
                <option value="Kbps">Kbps</option>
                <option value="Mbps" selected>Mbps</option>
                <option value="Gbps">Gbps</option>
            </select>
        </div>
        <p class="np-hint">宽带运营商标称的 100M 宽带即 100 Mbps，理论下载速度约 12.5 MB/s。</p>
    </div>

    <div class="np-field">
        <label class="np-label" for="priceInput">流量单价（元 / GB）</label>
        <div class="np-input-group">
            <input class="np-input" type="number" id="priceInput" min="0" step="0.01"
                   value="<?= e($defaultPrice) ?>" inputmode="decimal">
            <div class="np-stepper">
                <button class="np-btn" type="button" data-step="-0.1" data-target="priceInput" aria-label="减少">−</button>
                <button class="np-btn" type="button" data-step="0.1" data-target="priceInput" aria-label="增加">+</button>
            </div>
            <div class="np-select" style="display:flex;align-items:center;justify-content:center;min-width:96px;background:var(--np-subtle);">
                元 / GB
            </div>
        </div>
        <p class="np-hint">单价填 0 时只统计流量；默认值可在后台配置中修改。</p>
    </div>
</div>

<div class="np-card">
    <h2 class="np-card-title">📊 计算结果</h2>
    <p class="np-card-desc" id="calcSummary">按 1024 进制换算（1 GB = 1024 MB）。</p>

    <div class="np-table-wrap">
        <table class="np-table">
            <thead>
                <tr>
                    <th>时间周期</th>
                    <th>产生流量</th>
                    <th>折算 GB</th>
                    <th>预计费用</th>
                </tr>
            </thead>
            <tbody id="resultBody">
                <tr><td colspan="4" style="text-align:center;color:var(--np-text-muted);">计算中…</td></tr>
            </tbody>
        </table>
    </div>

    <div class="np-alert np-alert-danger" id="calcError" hidden style="margin-top:14px;"></div>
</div>

<div class="np-card">
    <h2 class="np-card-title">ℹ️ 计算说明</h2>
    <ul style="margin:0;padding-left:22px;color:var(--np-text-secondary);font-size:14px;line-height:1.9;">
        <li>速率单位换算：1 Gbps = 1000 Mbps = 1,000,000 Kbps（比特，按 1000 进制）。</li>
        <li>字节换算：1 Mbps = 0.125 MB/s，1 MB = 1024 KB，1 GB = 1024 MB。</li>
        <li>流量 = 速率 × 时间；费用 = 流量（GB） × 单价（元/GB）。</li>
        <li>每月按 30 天、每年按 365 天计算；结果为理论满速值，实际流量受网络波动、协议开销等影响。</li>
    </ul>
</div>

<?php
render_page_footer(['scripts' => ['./js/traffic.js']]);
