<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/site_settings.php';
$_siteName = getSiteSetting('site_name', '网络面板');
$_siteDesc = getSiteSetting('site_description', '');
$pageTitle = '会员中心 - ' . $_siteName;
$siteDesc  = $_siteDesc;
$extraHead = <<<HTML
    <style>
        .user-center { max-width: 800px; margin: 20px auto; padding: 0 15px; position: relative; }
        .uc-header { display:flex; align-items:center; gap:16px; margin-bottom:24px; background:var(--card-bg); border-radius:16px; padding:24px; box-shadow:var(--shadow); }
        .uc-avatar { width:72px; height:72px; border-radius:50%; background:linear-gradient(135deg,#5668EE,#6576ff); display:flex; align-items:center; justify-content:center; color:#fff; font-size:28px; font-weight:bold; flex-shrink:0; }
        .uc-info h2 { font-size:22px; color:var(--text-primary); margin-bottom:4px; }
        .uc-info .role-tag { display:inline-block; padding:3px 12px; border-radius:10px; font-size:12px; margin-top:4px; }
        .role-user { background:rgba(144,147,153,.1); color:#909399; }
        .role-vip { background:rgba(230,162,60,.1); color:#e6a23c; }
        .role-admin { background:rgba(245,108,108,.1); color:#f56c6c; }
        .uc-meta { font-size:13px; color:var(--text-secondary); margin-top:4px; }

        .uc-grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(200px,1fr)); gap:16px; margin-bottom:24px; }
        .stat-box { background:var(--card-bg); border-radius:14px; padding:22px; text-align:center; box-shadow:var(--shadow); }
        .stat-box .num { font-size:28px; font-weight:700; color:var(--primary); }
        .stat-box .label { font-size:13px; color:var(--text-secondary); margin-top:4px; }

        .uc-section { background:var(--card-bg); border-radius:14px; padding:22px; box-shadow:var(--shadow); margin-bottom:16px; }
        .uc-section h3 { font-size:17px; margin-bottom:16px; padding-bottom:12px; border-bottom:1px solid var(--border); }
        .form-row { display:flex; gap:12px; align-items:flex-end; flex-wrap:wrap; }
        .form-group { flex:1; min-width:180px; margin-bottom:0; }
        .form-group label { display:block; font-size:13px; color:var(--text-secondary); margin-bottom:5px; }
        .form-group input, .form-group select {
            width:100%; padding:9px 14px; border:1px solid var(--border); border-radius:8px;
            font-size:14px; background:var(--card-bg); color:var(--text-primary); outline:none;
        }
        .form-group input:focus { border-color:var(--primary); }

        .btn-row { display:flex; gap:10px; justify-content:flex-end; margin-top:16px; }
        .btn-primary { background:var(--primary); color:#fff; border:none; border-radius:8px; padding:9px 22px; cursor:pointer; font-size:14px; }
        .btn-default { background:var(--card-bg); color:var(--text-primary); border:1px solid var(--border); border-radius:8px; padding:9px 22px; cursor:pointer; font-size:14px; }

        .back-home{display:inline-flex;align-items:center;justify-content:center;padding:8px 18px;border:1.5px solid var(--border);border-radius:10px;background:var(--card-bg);color:var(--text-secondary);text-decoration:none;font-size:14px;font-weight:500;box-shadow:0 2px 8px rgba(0,0,0,.06);transition:all .25s;width:110px;height:38px;box-sizing:border-box;}
        .back-home:hover{color:var(--primary);border-color:var(--primary);box-shadow:0 4px 16px rgba(86,104,238,.15);transform:translateY(-1px);}
        .top-right-actions { position:absolute; top:20px; right:20px; display:flex; flex-direction:column; gap:10px; align-items:center; }
        .btn-logout-top { padding:7px 20px; border:1.5px solid var(--danger); border-radius:10px; background:#fff5f5; color:var(--danger); font-size:14px; font-weight:600; cursor:pointer; transition:all .2s; width:110px;height:38px;box-sizing:border-box; }
        .btn-logout-top:hover { background:var(--danger); color:#fff; }

        .msg-tip { padding:10px 14px; border-radius:8px; font-size:13px; margin-top:10px; display:none; }
        .msg-success { background:rgba(103,194,58,.08); color:#67c23a; display:block; }
        .msg-error { background:rgba(245,108,108,.08); color:#f56c6c; display:block; }

        /* 统计卡片重置按钮 */
        .btn-reset-stat { display:block; width:100%; margin-top:10px; padding:6px 0; border:1.5px solid var(--border); border-radius:6px; background:var(--card-bg); color:var(--text-secondary); font-size:12px; font-weight:500; cursor:pointer; text-align:center; transition:all .2s; }
        .btn-reset-stat:hover { background:#fff5f5; color:var(--danger); border-color:var(--danger); }

        /* 确认弹窗 */
        #confirmModal { margin:auto;max-width:380px;border-radius:14px;border:none;padding:0;box-shadow:0 10px 40px rgba(0,0,0,.25); }
        #confirmModal .modal-header { padding:16px 20px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center; }
        #confirmModal .modal-header h3 { font-size:16px;margin:0;color:var(--text-primary); }
        #confirmModal .modal-body { font-size:14px;line-height:1.6;color:var(--text-primary);padding:24px 24px; }
        #confirmModal::backdrop { background:rgba(0,0,0,.45); }
        #confirmModal:not([open]) { display:none !important; }
        #confirmModal[open] { display:flex !important; flex-direction:column; }

        /* Token 按钮悬停 */
        #btnCopyToken:hover { background:#67c23a;color:#fff;box-shadow:0 3px 10px rgba(103,194,58,.35);transform:translateY(-1px); }
        #btnRefreshToken:hover { background:#e6a23c;color:#fff;box-shadow:0 3px 10px rgba(230,162,60,.35);transform:translateY(-1px); }

        /* 会员中心自定义卡片 */
        .uc-custom-card { background:linear-gradient(135deg, #f0f4ff, #e8edff); border:2px solid #5668EE30; color:var(--primary); transition:all .25s; }
        .uc-custom-card:hover { transform:translateY(-3px); box-shadow:0 8px 24px rgba(86,104,238,.2); border-color:#5668EE80; }
    </style>
HTML;
require_once __DIR__ . '/../includes/user_head.php';
?>
<div class="header" style="position:relative;">
    <div class="header-inner">
        <div class="logo-section"><div class="logo-icon"><svg viewBox="0 0 1024 1024"><path d="M568.96 459.242667l144-189.205334A382.208 382.208 0 0 0 512 213.333333c-212.074667 0-384 171.925333-384 384a382.293333 382.293333 0 0 0 93.397333 251.008l-64.554666 55.808A467.584 467.584 0 0 1 42.666667 597.333333C42.666667 338.133333 252.8 128 512 128c93.098667 0 179.861333 27.093333 252.842667 73.856l75.882666-99.690667 67.541334 51.413334-273.28 359.04a149.333333 149.333333 0 1 1-66.048-53.376z m266.453333-69.056l54.357334-71.424A467.242667 467.242 0 0 1 981.333333 597.333333c0 113.706667-40.64 221.226667-113.237333 305.728l-64.725333-55.616A382.272 382.272 0 0 0 896 597.333333c0-76.288-22.250667-147.370667-60.586667-207.146666zM512 661.333333a64 64 0 1 0 0-128 64 64 0 0 0 0 128z" fill="#ffffff"/></svg></div><span class="title">会员中心</span></div>
    </div>
</div>

<div class="user-center">
    <div class="top-right-actions">
        <button class="btn-logout-top" id="btnLogoutTop" style="display:none;" onclick="doLogout()">退出登录</button>
        <a href="../index.php" class="back-home">返回首页</a>
    </div>

    <!-- 未登录提示 -->
    <div id="notLoggedIn">
        <section class="uc-section" style="text-align:center;padding:40px;">
            <p style="font-size:18px;margin-bottom:16px;" id="loginTip">请先登录以查看会员中心</p>
            <button class="btn-primary" onclick="showLoginModal()">登录 / 注册</button>
        </section>
    </div>

    <!-- 错误提示 -->
    <div id="errorArea" style="display:none;">
        <section class="uc-section" style="text-align:center;padding:40px;">
            <p style="font-size:16px;color:var(--danger);margin-bottom:12px;" id="errorMsg">加载失败，请稍后重试</p>
            <button class="btn-default" onclick="location.reload()">刷新页面</button>
        </section>
    </div>

    <!-- 已登录内容 -->
    <div id="loggedInContent" style="display:none;">
        <!-- 用户信息卡片 -->
        <div class="uc-header">
            <div class="uc-avatar" id="ucAvatar">U</div>
            <div class="uc-info">
                <h2 id="ucUsername">-</h2>
                <span class="role-tag role-user" id="ucRoleTag">普通用户</span>
                <p class="uc-meta" id="ucMeta"></p>
            </div>
        </div>

        <!-- 统计数据 -->
        <div class="uc-grid">
            <div class="stat-box">
                <div class="num" id="ucTotalBytes">-</div>
                <div class="label">累计使用流量</div>
                <button class="btn-reset-stat" onclick="resetStat('total_bytes')">重置归零</button>
            </div>
            <div class="stat-box">
                <div class="num" id="ucTotalTime">-</div>
                <div class="label">累计在线时长</div>
                <button class="btn-reset-stat" onclick="resetStat('total_time')">重置归零</button>
            </div>
            <div class="stat-box"><div class="num" id="ucRegDate">-</div><div class="label">注册时间</div></div>
            <div class="stat-box"><div class="num" id="ucActiveDate">-</div><div class="label">最后活跃</div></div>
            <div class="stat-box" id="ucStatusBox"><div class="num" id="ucStatus">-</div><div class="label">账号状态</div></div>
            <div class="stat-box uc-custom-card" id="ucCustomCardBox" style="display:none;cursor:pointer;position:relative;overflow:hidden;">
                <a href="#" id="ucCustomCardLink" target="_blank" style="text-decoration:none;color:inherit;position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;">
                <span style="font-size:28px;font-weight:700;" id="ucCustomCardText"></span>
                </a>
                <span class="label" style="position:absolute;bottom:12px;left:50%;transform:translateX(-50%);margin-top:0;">点击查看</span>
                <svg style="position:absolute;top:-18px;right:-12px;width:56px;height:56px;opacity:.08;transform:rotate(-15deg);" viewBox="0 0 1024 1024"><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm192 472c0 4.4-3.6 8-8 8H544v152c0 4.4-3.6 8-8 8h-56c-4.4 0-8-3.6-8-8V544H320c-4.4 0-8-3.6-8-8v-56c0-4.4 3.6-8 8-8h152V320c0-4.4 3.6-8 8-8h56c4.4 0 8 3.6 8 8v152h152c4.4 0 8 3.6 8 8v56z" fill="#5668EE"/></svg>
            </div>
        </div>

        <!-- 个人信息编辑 -->
        <div class="uc-section">
            <h3>个人信息</h3>
            <form id="profileForm" onsubmit="return false;">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:18px;">
                    <div class="form-group" style="margin-bottom:0;"><label>用户名</label><input type="text" id="pUsername" placeholder="输入用户名" style="padding:12px 14px;font-size:14px;border:2px solid var(--primary);border-radius:10px;background:#f8f9ff;"></div>
                    <div class="form-group" style="margin-bottom:0;"><label>邮箱</label><input type="email" id="pEmail" placeholder="选填" style="padding:12px 14px;font-size:14px;border:2px solid var(--border);border-radius:10px;background:#f8f9ff;"></div>
                </div>
                <div style="display:flex;justify-content:center;">
                    <button type="submit" class="btn-primary" id="btnSaveProfile" style="padding:11px 48px;font-size:15px;border-radius:10px;background:linear-gradient(135deg,#5668EE,#6576ff);box-shadow:0 4px 14px rgba(86,104,238,.35);">确认修改</button>
                </div>
                <div class="msg-tip" id="profileMsg"></div>
            </form>
        </div>

        <!-- 修改密码 -->
        <div class="uc-section">
            <h3>修改密码</h3>
            <form id="pwdForm" onsubmit="return false;">
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:18px;">
                    <div class="form-group" style="margin-bottom:0;">
                        <label style="font-weight:600;color:var(--primary);font-size:14px;">当前密码</label>
                        <input type="password" id="oldPwd" required placeholder="输入当前密码" style="padding:12px 14px;font-size:14px;border:2px solid var(--border);border-radius:10px;background:#f8f9ff;">
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                        <label style="font-weight:600;color:#e6a23c;font-size:14px;">新密码 (≥6位)</label>
                        <input type="password" id="newPwd" required minlength="6" placeholder="输入新密码" style="padding:12px 14px;font-size:14px;border:2px solid #e6a23c40;border-radius:10px;background:#fffef5;">
                    </div>
                    <div class="form-group" style="margin-bottom:0;">
                        <label style="font-weight:600;color:#67c23a;font-size:14px;">确认新密码</label>
                        <input type="password" id="confirmPwd" required minlength="6" placeholder="再次输入新密码" style="padding:12px 14px;font-size:14px;border:2px solid #67c23a40;border-radius:10px;background:#f0ffeb;">
                    </div>
                </div>
                <div style="display:flex;justify-content:center;gap:12px;">
                    <button type="submit" class="btn-primary" id="btnChangePwd" style="padding:12px 52px;font-size:15px;border-radius:10px;background:linear-gradient(135deg,#5668EE,#6576ff);box-shadow:0 4px 14px rgba(86,104,238,.35);">确认修改</button>
                </div>
                <div class="msg-tip" id="pwdMsg"></div>
            </form>
        </div>

        <!-- Access Token -->
        <div class="uc-section">
            <h3>访问令牌 (AccessToken)</h3>
            <p style="font-size:13px;color:var(--text-secondary);margin-bottom:10px;">用于API调用和流量日志关联，请妥善保管</p>
            <div style="display:flex;gap:10px;align-items:center;">
                <input type="text" id="tokenDisplay" readonly style="flex:1;padding:10px 14px;border:2px solid var(--border);border-radius:8px;font-family:monospace;font-size:12px;background:#f8f9ff;">
                <button class="btn-default" id="btnCopyToken" style="padding:9px 22px;border:2px solid #67c23a;border-radius:8px;background:#f0ffeb;color:#67c23a;font-weight:600;cursor:pointer;transition:all .2s;">复制</button>
                <button class="btn-default" id="btnRefreshToken" style="padding:9px 22px;border:2px solid #e6a23c;border-radius:8px;background:#fffef5;color:#e6a23c;font-weight:600;cursor:pointer;transition:all .2s;">刷新令牌</button>
            </div>
        </div>

        <!-- 消息反馈 -->
        <div class="uc-section">
            <h3>消息反馈</h3>
            <p style="font-size:13px;color:var(--text-secondary);margin-bottom:12px;">遇到问题或有建议？欢迎反馈，我们会尽快处理（仅支持文字，最多200字）</p>
            <form id="feedbackForm" onsubmit="return false;">
                <textarea id="fbContent" maxlength="200" placeholder="请输入您的反馈内容..." style="width:100%;min-height:120px;padding:14px 16px;border:2px solid var(--border);border-radius:10px;background:#f8f9ff;font-size:14px;line-height:1.7;resize:vertical;box-sizing:border-box;font-family:inherit;"></textarea>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px;">
                    <span style="font-size:13px;color:#999;" id="fbCharCount">0/200</span>
                    <button type="submit" class="btn-primary" id="btnSubmitFeedback" style="padding:10px 40px;font-size:15px;border-radius:10px;background:linear-gradient(135deg,#5668EE,#6576ff);box-shadow:0 4px 14px rgba(86,104,238,.35);cursor:pointer;">提交反馈</button>
                </div>
                <div class="msg-tip" id="feedbackMsg"></div>
            </form>
        </div>


    </div>
</div>

<!-- 登录/注册弹窗 -->
<dialog class="modal modal-sm" id="authModal">
    <div class="modal-header"><h3 id="authTitle">登录</h3><button class="close-btn" data-close>&times;</button></div>
    <div class="modal-body">
        <div class="tab-bar" style="display:flex;border-bottom:1px solid var(--border);margin-bottom:18px;">
            <button class="tab-btn active" data-tab="loginTab" style="flex:1;padding:10px;background:none;border:none;cursor:pointer;font-weight:600;color:var(--primary);">登录</button>
            <button class="tab-btn" data-tab="registerTab" style="flex:1;padding:10px;background:none;border:none;cursor:pointer;color:var(--text-secondary);">注册</button>
        </div>
        <!-- 登录表单 -->
        <div id="loginTab" class="tab-panel">
            <form onsubmit="return false;">
                <div class="form-group" style="margin-bottom:14px;"><label>用户名/邮箱</label><input type="text" id="loginUser" required autocomplete="username"></div>
                <div class="form-group" style="margin-bottom:14px;"><label>密码</label><input type="password" id="loginPass" required autocomplete="current-password"></div>
                <button class="btn-primary btn-block" id="btnDoLogin" style="padding:11px;">登 录</button>
                <div class="msg-tip" id="loginMsg"></div>
            </form>
        </div>
        <!-- 注册表单 -->
        <div id="registerTab" class="tab-panel" style="display:none;">
            <form onsubmit="return false;">
                <div class="form-group" style="margin-bottom:12px;"><label>用户名 (2~20位)</label><input type="text" id="regUser" required pattern="[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}"></div>
                <div class="form-group" style="margin-bottom:12px;"><label>邮箱 (可选)</label><input type="email" id="regEmail"></div>
                <div class="form-group" style="margin-bottom:12px;"><label>密码 (≥6位)</label><input type="password" id="regPass" required minlength="6" autocomplete="new-password"></div>
                <div class="form-group" style="margin-bottom:14px;"><label>确认密码</label><input type="password" id="regPassConfirm" required minlength="6"></div>
                <button class="btn-primary btn-block" id="btnDoRegister" style="padding:11px;">注 册</button>
                <div class="msg-tip" id="regMsg"></div>
            </form>
        </div>
    </div>
</dialog>

<!-- 自定义确认弹窗 -->
<dialog class="modal" id="confirmModal" style="z-index:99999;">
    <div class="modal-header"><h3 id="confirmTitle">确认操作</h3><button class="close-btn" data-close>&times;</button></div>
    <div class="modal-body" id="confirmBody"></div>
    <div class="modal-footer" style="display:flex;justify-content:center;gap:16px;padding:18px 24px;">
        <button id="confirmCancel" style="padding:10px 30px;border-radius:10px;background:#5668EE;color:#fff;border:none;font-size:14px;cursor:pointer;font-weight:600;">取消</button>
        <button id="confirmOk" style="padding:10px 30px;border-radius:10px;background:#f56c6c;color:#fff;border:none;font-size:14px;cursor:pointer;font-weight:600;">确定</button>
    </div>
</dialog>

<script src="../js/app.js"></script>
<script src="../js/user-center.js"></script>
</body>
</html>
