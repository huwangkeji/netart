<?php
/**
 * 第三方登录（QQ / 微信扫码登录）处理
 *
 * 流程：
 *  1) 登录页点击 QQ/微信 → 本文件 action=qq_auth / wx_qr 生成 state 并 302 到厂商授权页；
 *  2) 用户在厂商页扫码/授权 → 厂商带 code + state 跳回 action=callback；
 *  3) 校验 state → 用 code 换取 access_token → 取 openid/unionid/昵称/头像；
 *  4) 在 user_social 中查找绑定用户，没有则自动注册；
 *  5) 写入本地 session 并跳转回目标页（默认会员中心）。
 *
 * 后台通过 site_settings 中的 oauth_* 配置项控制开关与参数。
 */

session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/site_settings.php';

// 统一 JSON 输出兜底
set_exception_handler(function (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 1, 'message' => '服务器错误：' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
});

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

switch ($action) {
    case 'qq_auth':
    case 'wx_auth':
        beginProviderAuth($action === 'qq_auth' ? 'qq' : 'wx');
        break;
    case 'wx_qr':
        // 直接 302 到微信二维码登录页（供登录页弹窗 iframe 使用）
        redirectToProvider('wx');
        break;
    case 'callback':
        handleCallback();
        break;
    default:
        http_response_code(404);
        echo '未知操作';
}

// ==================== 开始授权（生成 state + 跳转） ====================
function beginProviderAuth(string $provider): void
{
    $enabled = (int) getSiteSetting('oauth_' . $provider . '_enabled', '0');
    if ($enabled !== 1) {
        failPage('当前未开启' . providerName($provider) . '登录');
    }
    // 保存跳转目标
    $redirect = $_GET['redirect'] ?? ($_POST['redirect'] ?? '../index.php');
    $_SESSION['oauth_redirect'] = $redirect;
    // 生成并保存 state（防 CSRF）
    $state = bin2hex(random_bytes(16));
    $_SESSION['oauth_state'] = $state;
    $_SESSION['oauth_provider'] = $provider;

    redirectToProvider($provider, $state);
}

function redirectToProvider(string $provider, ?string $state = null): void
{
    $appid = getSiteSetting('oauth_' . $provider . '_appid', '');
    $callback = getSiteSetting('oauth_' . $provider . '_callback', '');
    if ($appid === '' || $callback === '') {
        failPage(providerName($provider) . '登录未配置 AppID / 回调地址');
    }
    $callback = urlencode($callback);
    $state = $state ?? ($_SESSION['oauth_state'] ?? bin2hex(random_bytes(16)));

    if ($provider === 'qq') {
        // display=mobile 让 PC 端也展示二维码，实现“扫码登录”
        $url = 'https://graph.qq.com/oauth2.0/authorize?response_type=code'
            . '&client_id=' . urlencode($appid)
            . '&redirect_uri=' . $callback
            . '&state=' . $state
            . '&scope=get_user_info&display=mobile';
    } else {
        $url = 'https://open.weixin.qq.com/connect/qrconnect?appid=' . urlencode($appid)
            . '&redirect_uri=' . $callback
            . '&response_type=code&scope=snsapi_login&state=' . $state
            . '#wechat_redirect';
    }
    header('Location: ' . $url);
    exit;
}

// ==================== 回调处理 ====================
function handleCallback(): void
{
    $provider = $_GET['provider'] ?? ($_SESSION['oauth_provider'] ?? '');
    if (!in_array($provider, ['qq', 'wx'], true)) {
        failPage('非法的登录来源');
    }
    $code = $_GET['code'] ?? '';
    $state = $_GET['state'] ?? '';
    if ($code === '' || !hash_equals((string)($_SESSION['oauth_state'] ?? ''), (string)$state)) {
        failPage('登录校验失败（state 不匹配或缺少 code）');
    }
    // 一次性消费 state
    unset($_SESSION['oauth_state']);

    $appid = getSiteSetting('oauth_' . $provider . '_appid', '');
    $secret = getSiteSetting('oauth_' . $provider . '_appkey', '');
    if ($provider === 'wx') {
        $secret = getSiteSetting('oauth_wx_appsecret', '');
    }
    $callback = getSiteSetting('oauth_' . $provider . '_callback', '');

    // 1) 换取 access_token
    if ($provider === 'qq') {
        $tokenUrl = 'https://graph.qq.com/oauth2.0/token?grant_type=authorization_code'
            . '&client_id=' . urlencode($appid)
            . '&client_secret=' . urlencode($secret)
            . '&code=' . urlencode($code)
            . '&redirect_uri=' . urlencode($callback)
            . '&fmt=json';
        $tokenResp = http_get_json($tokenUrl);
        if (!$tokenResp || empty($tokenResp['access_token'])) {
            failPage('获取 QQ access_token 失败');
        }
        $accessToken = $tokenResp['access_token'];
        // 2) 取 openid
        $meResp = http_get_json('https://graph.qq.com/oauth2.0/me?access_token=' . urlencode($accessToken) . '&fmt=json');
        if (!$meResp || empty($meResp['openid'])) {
            failPage('获取 QQ openid 失败');
        }
        $openid = $meResp['openid'];
        $unionid = '';
        // 3) 取用户信息
        $infoResp = http_get_json('https://graph.qq.com/user/get_user_info?access_token=' . urlencode($accessToken)
            . '&oauth_consumer_key=' . urlencode($appid) . '&openid=' . urlencode($openid));
        $nickname = $infoResp['nickname'] ?? ('qq_' . substr(md5($openid), 0, 6));
        $avatar = $infoResp['figureurl_qq_2'] ?? ($infoResp['figureurl_qq_1'] ?? ($infoResp['figureurl'] ?? ''));
    } else {
        $tokenUrl = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . urlencode($appid)
            . '&secret=' . urlencode($secret)
            . '&code=' . urlencode($code) . '&grant_type=authorization_code';
        $tokenResp = http_get_json($tokenUrl);
        if (!$tokenResp || empty($tokenResp['access_token'])) {
            failPage('获取微信 access_token 失败');
        }
        $accessToken = $tokenResp['access_token'];
        $openid = $tokenResp['openid'] ?? '';
        $unionid = $tokenResp['unionid'] ?? '';
        if ($openid === '') {
            failPage('获取微信 openid 失败');
        }
        // 3) 取用户信息
        $infoResp = http_get_json('https://api.weixin.qq.com/sns/userinfo?access_token=' . urlencode($accessToken) . '&openid=' . urlencode($openid));
        $nickname = $infoResp['nickname'] ?? ('wx_' . substr(md5($openid), 0, 6));
        $avatar = $infoResp['headimgurl'] ?? '';
    }

    try {
        $db = getDB();
        $user = findOrCreateSocialUser($db, $provider, $openid, $unionid, $nickname, $avatar, $accessToken);
    } catch (Throwable $e) {
        failPage('登录失败：' . $e->getMessage());
    }

    setAuthSession($user['id'], $user['username'], $user['access_token'], $user['role']);

    // 与 UCenter 建立绑定（若在 UCenter 已存在同名用户则绑定；新建用户由本地注册流程同步）
    if (uc_is_enabled()) {
        $existing = uc_find_ucuid($user['id']);
        if ($existing === null) {
            $u = uc_get_user($user['username']);
            if (is_array($u) && isset($u[0]) && (int)$u[0] > 0) {
                uc_bind_user($user['id'], (int)$u[0], $user['username'], $user['email'] ?? '');
            }
        }
    }

    $redirect = $_SESSION['oauth_redirect'] ?? 'center.php';
    unset($_SESSION['oauth_redirect'], $_SESSION['oauth_provider']);

    // 若处于 iframe（微信弹窗）中，跳出到顶层窗口
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>登录成功</title></head><body>'
        . '<script>window.top.location.href=' . json_encode($redirect) . ';</script>'
        . '<p style="font-family:sans-serif;text-align:center;padding:40px;">登录成功，正在跳转…</p>'
        . '</body></html>';
    exit;
}

// ==================== 查找/创建用户 ====================
function findOrCreateSocialUser(PDO $db, string $provider, string $openid, string $unionid, string $nickname, string $avatar, string $accessToken): array
{
    // 已绑定
    $stmt = $db->prepare(
        "SELECT u.id,u.username,u.access_token,u.role FROM user_social s "
        . "JOIN users u ON u.id=s.user_id WHERE s.provider=? AND s.openid=? LIMIT 1"
    );
    $stmt->execute([$provider, $openid]);
    $row = $stmt->fetch();
    if ($row) {
        $db->prepare("UPDATE user_social SET access_token=?, nickname=?, avatar=?, updated_at=NOW() WHERE provider=? AND openid=?")
            ->execute([$accessToken, $nickname, $avatar, $provider, $openid]);
        $db->prepare("UPDATE users SET last_active=NOW() WHERE id=?")->execute([$row['id']]);
        return $row;
    }

    // 新用户：生成唯一用户名
    $base = strtolower($provider) . '_' . substr(md5($openid), 0, 8);
    $username = $base;
    $i = 0;
    while (usernameExists($db, $username)) {
        $username = $base . '_' . (++$i);
    }
    $accessTokenLocal = bin2hex(random_bytes(32));
    $passwordHash = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);

    $ins = $db->prepare(
        "INSERT INTO users (username,email,password_hash,access_token,headimg,ip,role,status,last_active) "
        . "VALUES (?,?,?,?,?,?, 'user', 1, NOW())"
    );
    $ins->execute([$username, '', $passwordHash, $accessTokenLocal, $avatar, getClientIP()]);
    $userId = (int)$db->lastInsertId();

    $db->prepare(
        "INSERT INTO user_social (user_id,provider,openid,unionid,nickname,avatar,access_token,expires_in) "
        . "VALUES (?,?,?,?,?,?,?,0)"
    )->execute([$userId, $provider, $openid, $unionid, $nickname, $avatar, $accessToken]);

    return [
        'id' => $userId,
        'username' => $username,
        'access_token' => $accessTokenLocal,
        'role' => 'user',
    ];
}

function usernameExists(PDO $db, string $username): bool
{
    $s = $db->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
    $s->execute([$username]);
    return (bool)$s->fetch();
}

// ==================== 登录态写入（与 api/auth.php 保持一致） ====================
function setAuthSession(int $id, string $username, string $token, string $role): void
{
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['user_id'] = $id;
    $_SESSION['username'] = $username;
    $_SESSION['access_token'] = $token;
    $_SESSION['role'] = $role;
    $_SESSION['login_time'] = time();
}

function providerName(string $provider): string
{
    return $provider === 'qq' ? 'QQ' : '微信';
}

function failPage(string $msg): void
{
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>登录失败</title></head><body>'
        . '<p style="font-family:sans-serif;text-align:center;padding:40px;color:#e74c3c;">'
        . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . ' <a href="login.php">返回登录</a></p>'
        . '</body></html>';
    exit;
}
