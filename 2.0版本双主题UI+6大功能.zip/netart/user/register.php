<?php
/**
 * 会员注册页 - NetworkPanel
 */
session_start();
if (!empty($_SESSION['user_id'])) {
    header('Location: center.php');
    exit;
}
$redirect = isset($_GET['redirect']) ? htmlspecialchars($_GET['redirect']) : '../index.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/site_settings.php';
$_regSiteName = getSiteSetting('site_name', '网络面板');
$pageTitle = '注册 - ' . $_regSiteName;
$extraHead = '<style>
    .auth-card{padding:36px 32px 24px;}
    .form-group{margin-bottom:18px;}
    .form-group label{margin-bottom:7px;}
    .msg-tip{padding:10px 14px;margin-top:14px;}
    .auth-logo{background:linear-gradient(135deg,#67c23a,#4caf50);box-shadow:0 8px 32px rgba(103,194,58,.35);}
</style>';
require_once __DIR__ . '/../includes/auth_head.php';
?>
<a href="<?php echo $redirect; ?>" class="back-home">&larr; 返回首页</a>

<div class="auth-page">
    <div class="auth-header">
        <div class="auth-logo">
            <svg viewBox="0 0 1024 1024"><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm192 472c0 4.4-3.6 8-8 8H544v152c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V544H328c-4.4 0-8-3.6-8-8v-48c0-4.4 3.6-8 8-8h152V328c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v152h152c4.4 0 8 3.6 8 8v48z" fill="#ffffff"/></svg>
        </div>
        <h1>创建账号</h1>
        <p>加入网络面板，开始监测您的网络状况</p>
    </div>

    <div class="auth-card">
        <form id="regForm" onsubmit="return false;">
            <div class="form-group">
                <label for="username">用户名 <span style="color:var(--danger)">*</span></label>
                <input class="form-input" id="username" type="text" placeholder="支持中英文数字下划线，2~20位" required pattern="[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}" autocomplete="username">
                <p class="input-hint">注册后不可修改</p>
            </div>

            <div class="form-group">
                <label for="email">邮箱（选填）</label>
                <input class="form-input" id="email" type="email" placeholder="用于找回密码" autocomplete="email">
            </div>

            <div class="form-group">
                <label for="password">密码 <span style="color:var(--danger)">*</span></label>
                <input class="form-input" id="password" type="password" placeholder="至少6位字符" required minlength="6" autocomplete="new-password" oninput="checkPwdStrength()">
                <div class="pwd-strength" id="pwdStrength"><span></span><span></span><span></span><span></span></div>
            </div>

            <div class="form-group">
                <label for="confirmPwd">确认密码 <span style="color:var(--danger)">*</span></label>
                <input class="form-input" id="confirmPwd" type="password" placeholder="再次输入密码" required minlength="6" autocomplete="new-password">
            </div>

            <label class="agree-row" style="display:flex;align-items:flex-start;gap:8px;font-size:13px;color:var(--text-info);line-height:1.6;margin-bottom:14px;cursor:pointer;">
                <input type="checkbox" id="agreeTerms" style="margin-top:3px;">
                <span>我已阅读并同意 <a href="../agreement.php" target="_blank" rel="noopener">《用户协议》</a> 与 <a href="../privacy.php" target="_blank" rel="noopener">《隐私政策》</a></span>
            </label>

            <button class="btn-submit" id="btnSubmit" onclick="doRegister()">注 册</button>

            <div class="msg-tip" id="msgTip"></div>
        </form>

        <div class="divider"><span>或</span></div>

        <div class="auth-footer">
            已有账号？<a href="login.php?redirect=<?php echo urlencode($redirect); ?>">立即登录</a>
        </div>
    </div>
</div>

<script>window.__REDIRECT__ = <?php echo json_encode($redirect); ?>;</script>
<script src="../js/auth-common.js"></script>
<script src="../js/auth-register.js"></script>
</body>
</html>
