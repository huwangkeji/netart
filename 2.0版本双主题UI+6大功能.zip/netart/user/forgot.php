<?php
/**
 * 忘记密码页 - NetworkPanel
 */
session_start();
$redirect = isset($_GET['redirect']) ? htmlspecialchars($_GET['redirect']) : '../index.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/site_settings.php';
$_forgotSiteName = getSiteSetting('site_name', '网络面板');
$pageTitle = '找回密码 - ' . $_forgotSiteName;
$extraHead = '<style>
    .auth-logo{background:linear-gradient(135deg,var(--warning),#f5a623);box-shadow:0 8px 32px rgba(230,162,60,.35);}
    .btn-submit{background:linear-gradient(135deg,var(--warning),#f5a623);}
    .btn-submit:hover{box-shadow:0 6px 24px rgba(230,162,60,.4);}
    .auth-card{padding:36px 32px 24px;}
    .form-group{margin-bottom:20px;}
    .msg-tip{line-height:1.5;}
</style>';
require_once __DIR__ . '/../includes/auth_head.php';
?>
<a href="<?php echo $redirect; ?>" class="back-home">&larr; 返回首页</a>

<div class="auth-page">
    <div class="auth-header">
        <div class="auth-logo">
            <svg viewBox="0 0 1024 1024"><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372zm0-592c-121.3 0-220 98.7-220 220s98.7 220 220 220 220-98.7 220-220-98.7-220-220-220zm0 360c-77.2 0-140-62.8-140-140s62.8-140 140-140 140 62.8 140 140-62.8 140-140 140zm0-192c-28.7 0-52 23.3-52 52s23.3 52 52 52 52-23.3 52-52-23.3-52-52-52z" fill="#ffffff"/></svg>
        </div>
        <h1>找回密码</h1>
        <p>通过邮箱重置您的账号密码</p>
    </div>

    <div class="auth-card">
        <div class="info-block">
            <strong>找回密码</strong><br>
            如需找回密码，请在<strong>首页联系客服</strong>处理。
        </div>

        <form id="resetForm" onsubmit="return false;">
            <div class="form-group">
                <label for="email">注册邮箱</label>
                <input class="form-input" id="email" type="email" placeholder="请输入您注册时使用的邮箱地址" required autocomplete="email" autofocus disabled>
            </div>

            <button class="btn-submit" disabled style="opacity:0.6;cursor:not-allowed;">该功能不可用</button>

            <div class="msg-tip" id="msgTip"></div>
        </form>

        <div class="divider"><span>其他操作</span></div>

        <div class="auth-footer">
            想起密码了？<a href="login.php?redirect=<?php echo urlencode($redirect); ?>">返回登录</a> &nbsp;|&nbsp; <a href="register.php?redirect=<?php echo urlencode($redirect); ?>">注册新账号</a>
        </div>
    </div>
</div>

<script>
<script src="../js/auth-common.js"></script>
<script src="../js/auth-forgot.js"></script>
</body>
</html>
