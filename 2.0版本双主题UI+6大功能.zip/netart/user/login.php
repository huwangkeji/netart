<?php
/**
 * 会员登录页 - NetworkPanel
 */
session_start();
// 已登录则跳转到会员中心
if (!empty($_SESSION['user_id'])) {
    header('Location: center.php');
    exit;
}
$redirect = isset($_GET['redirect']) ? htmlspecialchars($_GET['redirect']) : '../index.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/site_settings.php';
$_loginSiteName = getSiteSetting('site_name', '网络面板');
$pageTitle = '登录 - ' . $_loginSiteName;
require_once __DIR__ . '/../includes/auth_head.php';
?>
<a href="<?php echo $redirect; ?>" class="back-home">&larr; 返回首页</a>

<div class="auth-page">
    <div class="auth-header">
        <div class="auth-logo">
            <svg viewBox="0 0 1024 1024"><path d="M568.96 459.242667l144-189.205334A382.208 382.208 0 0 0 512 213.333333c-212.074667 0-384 171.925333-384 384a382.293333 382.293333 0 0 0 93.397333 251.008l-64.554666 55.808A467.584 467.584 0 0 1 42.666667 597.333333C42.666667 338.133333 252.8 128 512 128c93.098667 0 179.861333 27.093333 252.842673 73.856l75.882667-99.690667 67.541333 51.413334-273.28 359.04a149.333333 149.333333 0 1 1-66.048-53.376z m266.453333-69.056l54.357334-71.424A467.242667 467.242 0 0 1 981.333333 597.333333c0 113.706667-40.64 221.226667-113.237333 305.728l-64.725334-55.616A382.272 382.272 0 0 0 896 597.333333c0-76.288-22.250667-147.370667-60.586667-207.146666zM512 661.333333a64 64 0 1 0 0-128 64 64 0 0 0 0 128z" fill="#ffffff"/></svg>
        </div>
        <h1>欢迎回来</h1>
        <p>登录您的网络面板账号</p>
    </div>

    <div class="auth-card">
        <form id="loginForm" onsubmit="return false;">
            <div class="form-group">
                <label for="username">用户名 / 邮箱</label>
                <input class="form-input" id="username" type="text" placeholder="输入用户名或邮箱" required autocomplete="username" autofocus>
            </div>
            <div class="form-group">
                <label for="password">密码</label>
                <input class="form-input" id="password" type="password" placeholder="输入您的密码" required autocomplete="current-password" minlength="1">
            </div>

            <div class="form-options">
                <label class="remember-me"><input type="checkbox" id="rememberMe"> 记住我</label>
                <a href="forgot.php?redirect=<?php echo urlencode($redirect); ?>" class="forgot-link">忘记密码？</a>
            </div>

            <button class="btn-submit" id="btnSubmit" onclick="doLogin()">登 录</button>

            <div class="msg-tip" id="msgTip"></div>
        </form>

        <div class="divider"><span>或</span></div>

        <?php
        $oauthOn = (getSiteSetting('oauth_qq_enabled', '0') === '1' || getSiteSetting('oauth_wx_enabled', '0') === '1');
        ?>
        <div class="social-login<?php echo $oauthOn ? '' : ' is-hidden'; ?>" id="socialLogin">
            <button type="button" class="btn-social btn-social-qq" id="btnQQLogin" onclick="doQQLogin()">QQ 登录</button>
            <button type="button" class="btn-social btn-social-wx" id="btnWXLogin" onclick="openWechatModal()">微信扫码登录</button>
        </div>

        <div class="auth-footer">
            还没有账号？<a href="register.php?redirect=<?php echo urlencode($redirect); ?>">立即注册</a>
        </div>

        <?php if (getSiteSetting('uc_enabled', '0') === '1'): ?>
        <div class="divider"><span>UCenter</span></div>
        <button type="button" class="btn-submit" id="btnUcLogin"
                style="background:linear-gradient(135deg,#7b5cff,#5b8def);box-shadow:0 8px 24px rgba(123,92,255,.35);"
                onclick="doLogin('uc')">UCenter 账号登录</button>
        <p style="text-align:center;font-size:12px;color:var(--text-secondary);margin-top:10px;">
            使用 UCenter 统一用户中心账号直接登录（自动同步到本站）
        </p>
        <?php endif; ?>
    </div>
</div>

<!-- 微信扫码登录弹窗 -->
<div class="modal-mask" id="wxLoginModal" onclick="if(event.target===this)closeWechatModal()">
    <div class="modal-box">
        <div class="modal-title">微信扫码登录 <button type="button" class="modal-close" onclick="closeWechatModal()">&times;</button></div>
        <iframe id="wxQrFrame" class="wx-qr-frame" frameborder="0" scrolling="no"></iframe>
        <p class="modal-tip">请使用微信扫一扫，扫描上方二维码完成登录</p>
    </div>
</div>

<script>window.__REDIRECT__ = <?php echo json_encode($redirect); ?>;</script>
<script src="../js/auth-common.js"></script>
<script src="../js/auth-login.js"></script>
<script src="../js/auth-oauth.js"></script>
</body>
</html>
