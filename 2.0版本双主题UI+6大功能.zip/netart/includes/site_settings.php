<?php
/**
 * 站点设置读取（公共页与用户页共用）
 * 提供 getSiteSetting()：带异常降级，DB 不可用时回退默认值。
 */

if (!function_exists('getSiteSetting')) {
    function getSiteSetting($key, $default = '') {
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT setting_value FROM site_settings WHERE setting_key=?");
            $stmt->execute([$key]);
            $val = $stmt->fetchColumn();
            // 严格判断「未找到」：存储值为 '0' / '' 时应当原样返回，不能误用默认值
            if ($val === false) {
                return $default;
            }
            return (string) $val;
        } catch (Exception $e) {
            return $default;
        }
    }
}
