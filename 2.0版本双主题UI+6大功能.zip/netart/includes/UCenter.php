<?php
/**
 * Discuz UCenter 客户端封装（网络面板侧）
 *
 * 职责：
 *  1) 作为「应用」对接 Discuz 的 UCenter 服务端（uc_server），实现账号互通；
 *  2) 在本地注册 / 登录 / 改密 / 删除时，双向同步到 UCenter；
 *  3) 提供同步登录 / 同步登出所需的 JS 脚本（uc_user_synlogin / uc_user_synlogout）；
 *  4) 提供接收端辅助函数，供 api/ucenter.php 解析 UCenter 下发的通知。
 *
 * 配置项（在后台「登录集成」中设置，存储于 site_settings）：
 *  uc_enabled / uc_api / uc_key / uc_appid / uc_ip / uc_charset
 *  / uc_connect / uc_dbhost / uc_dbuser / uc_dbpw / uc_dbname / uc_dbtablepre
 *
 * 全部调用均做「未启用 / 配置缺失」降级，不会因 UCenter 不可用而中断主流程。
 */

require_once __DIR__ . '/site_settings.php';

if (!function_exists('uc_is_enabled')) {

    /** UCenter 客户端版本号（与 Discuz UCenter 协定，非致命项） */
    if (!defined('UC_RELEASE')) {
        define('UC_RELEASE', '20080429');
    }

    /** 客户端 UA（必须同时用于 curl 请求头与加密 payload 的 agent 字段，二者需一致） */
    if (!defined('UC_CLIENT_UA')) {
        define('UC_CLIENT_UA', 'UCenter Client/1.6');
    }

    /** 是否启用 UCenter 同步 */
    function uc_is_enabled(): bool
    {
        $on = (string) getSiteSetting('uc_enabled', '0') === '1'
            && trim((string) getSiteSetting('uc_api', '')) !== ''
            && trim((string) getSiteSetting('uc_key', '')) !== '';
        // 启用状态下补齐同步策略开关的默认值，避免后台表单与后端判断不一致
        if ($on) {
            uc_ensure_defaults();
        }
        return $on;
    }

    /**
     * 同步策略单项开关。
     * 默认开启（保持向后兼容：未配置时视为开启），需 UCenter 已启用。
     * 配置键:
     *  uc_sync_register   本站注册 → 写入 UCenter
     *  uc_sync_login      本站登录 → 广播同步登录
     *  uc_sync_password   本站改密 → 同步 UCenter
     *  uc_sync_email      本站改资料 → 同步邮箱
     *  uc_allow_uc_login  允许 UCenter 用户登录本站
     *  uc_auto_create     UCenter 用户自动建号
     */
    function uc_strategy(string $key): bool
    {
        return uc_is_enabled() && (string) getSiteSetting($key, '1') === '1';
    }

    /**
     * 补齐 6 个同步策略开关的默认值（默认开启）。
     * 仅插入尚不存在的键（INSERT IGNORE + setting_key 唯一约束），幂等、安全。
     */
    function uc_ensure_defaults(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        $defaults = [
            'uc_sync_register'   => ['title' => '本站注册写入 UCenter',       'desc' => '开启后，本站新注册用户会同步创建到 UCenter 统一用户中心。'],
            'uc_sync_login'      => ['title' => '本站登录广播同步登录',       'desc' => '开启后，在本站登录会向 UCenter 体系广播同步登录（跨应用免登）。'],
            'uc_sync_password'   => ['title' => '本站改密同步 UCenter',       'desc' => '开启后，本站修改密码会同步更新到 UCenter。'],
            'uc_sync_email'      => ['title' => '本站改资料同步邮箱',         'desc' => '开启后，本站修改邮箱会同步更新到 UCenter。'],
            'uc_allow_uc_login'  => ['title' => '允许 UCenter 用户登录本站',  'desc' => '开启后，可使用 UCenter 账号（统一用户中心）登录本站。'],
            'uc_auto_create'     => ['title' => 'UCenter 用户自动建号',       'desc' => '开启后，用 UCenter 账号登录本站时若本地无账号会自动建档并绑定。'],
        ];
        try {
            $db = getDB();
            $ins = $db->prepare(
                "INSERT IGNORE INTO site_settings "
                . "(setting_key,setting_value,setting_type,title,description,group_name,sort_order) "
                . "VALUES (?,?,?,?,?,?,?)"
            );
            $i = 0;
            foreach ($defaults as $k => $meta) {
                $ins->execute([$k, '1', 'bool', $meta['title'], $meta['desc'], 'ucenter', 100 + ($i++)]);
            }
        } catch (Throwable $e) {
            // 忽略：DB 不可用时不影响主流程
        }
    }

    /** 读取 UCenter 配置 */
    function uc_cfg(): array
    {
        return [
            'api'      => rtrim(trim(getSiteSetting('uc_api', '')), '/'),
            'key'      => trim(getSiteSetting('uc_key', '')),
            'appid'    => (int) getSiteSetting('uc_appid', '0'),
            'ip'       => trim(getSiteSetting('uc_ip', '')),
            'charset'  => trim(getSiteSetting('uc_charset', 'utf-8')) ?: 'utf-8',
            'connect'  => trim(getSiteSetting('uc_connect', 'mysql')),
            'dbhost'   => trim(getSiteSetting('uc_dbhost', '')),
            'dbuser'   => trim(getSiteSetting('uc_dbuser', '')),
            'dbpw'     => getSiteSetting('uc_dbpw', ''),
            'dbname'   => trim(getSiteSetting('uc_dbname', '')),
            'tablepre' => trim(getSiteSetting('uc_dbtablepre', 'uc_')) ?: 'uc_',
        ];
    }

    /**
     * Discuz 经典 authcode（对称加解密）
     */
    function uc_authcode(string $string, string $operation = 'DECODE', string $key = '', int $expiry = 0): string
    {
        $ckeyLength = 4;
        $key = md5($key !== '' ? $key : (string) getSiteSetting('uc_key', ''));
        $keya = md5(substr($key, 0, 16));
        $keyb = md5(substr($key, 16, 16));
        $keyc = $ckeyLength ? ($operation === 'DECODE'
            ? substr($string, 0, $ckeyLength)
            : substr(md5(microtime()), -$ckeyLength)) : '';

        $cryptkey = $keya . md5($keya . $keyc);
        $keyLength = strlen($cryptkey);

        $string = $operation === 'DECODE'
            ? base64_decode(substr($string, $ckeyLength))
            : sprintf('%010d', $expiry ? $expiry + time() : 0) . substr(md5($string . $keyb), 0, 16) . $string;

        $stringLength = strlen($string);
        $result = '';
        $box = range(0, 255);
        $rndkey = [];
        for ($i = 0; $i <= 255; $i++) {
            $rndkey[$i] = ord($cryptkey[$i % $keyLength]);
        }
        for ($j = $i = 0; $i < 256; $i++) {
            $j = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }
        for ($a = $j = $i = 0; $i < $stringLength; $i++) {
            $a = ($a + 1) % 256;
            $j = ($j + $box[$a]) % 256;
            $tmp = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
        }

        if ($operation === 'DECODE') {
            if ((substr($result, 0, 10) == 0 || (int) substr($result, 0, 10) - time() > 0)
                && substr($result, 10, 16) === substr(md5(substr($result, 26) . $keyb), 0, 16)
            ) {
                return substr($result, 26);
            }
            return '';
        }
        return $keyc . str_replace('=', '', base64_encode($result));
    }

    /**
     * 向 UCenter 发起 HTTP 请求（POST，与 Discuz! X UCenter 协议一致）。
     * @param string $endpoint 目标地址，通常为 uc_api . '/index.php'
     * @param string $postdata 已编码的请求体（m/a/inajax/release/input/appid）
     * @param int $timeout
     * @return string 原始响应体；失败返回 ''
     */
    function uc_http_send(string $endpoint, string $postdata, int $timeout = 15, string $userAgent = 'UCenter Client/1.6'): string
    {
        $cfg = uc_cfg();
        $ip = $cfg['ip'];
        $host = parse_url($endpoint, PHP_URL_HOST);
        $url = $endpoint;
        if ($ip !== '' && $host !== '') {
            $url = str_replace($host, $ip, $endpoint);
        }
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            // 必须与服务端校验的 agent（md5(User-Agent)）保持一致
            curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
            $headers = ['Accept: */*', 'Content-Type: application/x-www-form-urlencoded'];
            // 若强制 IP 访问，需补 Host 头
            if ($ip !== '' && $host !== '') {
                $headers[] = 'Host: ' . $host;
            }
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            $body = (string) curl_exec($ch);
            curl_close($ch);
            return $body;
        }
        $ctx = stream_context_create(['http' => [
            'timeout' => $timeout,
            'user_agent' => $userAgent,
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => $postdata,
        ]]);
        return (string) @file_get_contents($url, false, $ctx);
    }

    /**
     * 向 UCenter 发起 API 请求（应用 -> UCenter）
     *
     * 协议严格遵循 Discuz! X UCenter 客户端（uc_server/model/base.php::init_input）：
     *  1) 服务端先以 appid 对应的 authkey 解密 input，再 parse_str 成 $input 数组；
     *  2) 必须校验 $input['m'] / $input['a'] / $input['appid'] 与 query 参数一致；
     *  3) 必须校验 $input['agent'] == md5(服务端收到的 User-Agent)；
     *  4) $input['time'] 距服务端当前时间不得超过 3600 秒。
     * 因此加密明文必须是一个“完整 query string”，且包含 m / a / appid / agent / time。
     * 缺任意一项都会直接返回 “Access denied for operation changed / agent changed”。
     *
     * 请求体（POST）：m / a / inajax=2 / release / input / appid
     *
     * @return string|null 原始响应体（user 模块为 PHP 序列化数组；synlogin/synlogout 为 HTML 脚本）；失败返回 null
     */
    function uc_api_request(string $module, string $action, array $args = []): ?string
    {
        if (!uc_is_enabled()) {
            return null;
        }
        $cfg = uc_cfg();
        if ((int) $cfg['appid'] <= 0) {
            error_log('[UCenter] uc_appid 未配置（必须 > 0），跳过请求');
            return null;
        }

        // 明文 = 完整 query string，含 m/a/appid（服务端校验）/ agent（=md5(UA)）/ time
        $payload = array_merge(
            [
                'm'     => $module,
                'a'     => $action,
                'appid' => $cfg['appid'],
            ],
            $args,
            [
                'agent' => md5(UC_CLIENT_UA),
                'time'  => time(),
            ]
        );
        $plain = http_build_query($payload, '', '&', PHP_QUERY_RFC1738);
        $input = urlencode(uc_authcode($plain, 'ENCODE', $cfg['key']));

        $data = 'm=' . rawurlencode($module)
            . '&a=' . rawurlencode($action)
            . '&inajax=2&release=' . UC_RELEASE
            . '&input=' . $input
            . '&appid=' . $cfg['appid'];

        $response = uc_http_send($cfg['api'] . '/index.php', $data, 15, UC_CLIENT_UA);
        return ($response === '' || $response === false) ? null : $response;
    }

    /**
     * 解析 UCenter 返回的响应体。
     * 关键点（见 uc_server/index.php）：
     *  - 数组结果（login / get_user）经 xml_serialize 输出为 XML：
     *      <root><item id="0">uid</item><item id="1">username</item><item id="2">email</item>…</root>
     *  - 标量结果（register / edit / delete 的整型状态码）直接原样输出字符串（如 "7" 或 "-3"）。
     * 因此这里先尝试 XML 解析；无法解析时按标量字符串返回，交由调用方转 int。
     * @return array|string|null
     */
    function uc_unserialize(string $s)
    {
        $s = trim($s ?? '');
        if ($s === '') {
            return null;
        }
        if (stripos($s, '<root') !== false || stripos($s, '<?xml') !== false) {
            $arr = uc_xml_unserialize($s);
            if (is_array($arr)) {
                return $arr;
            }
        }
        return $s;
    }

    /** 解析 uc_server 的 xml_serialize 输出（扁平数组，<item id="N"> 的 id 即键） */
    function uc_xml_unserialize(string $xml): ?array
    {
        if (preg_match_all('/<item\s+id="([^"]*)">(.*?)<\/item>/s', $xml, $m, PREG_SET_ORDER)) {
            $map = [];
            foreach ($m as $grp) {
                $val = $grp[2];
                if (preg_match('/^\s*<!\[CDATA\[(.*)\]\]>\s*$/s', $val, $cm)) {
                    $val = $cm[1];
                }
                $map[$grp[1]] = $val;
            }
            return $map;
        }
        return null;
    }

    // ==================== 业务封装 ====================

    /** 注册到 UCenter（返回 uc_uid；-1 用户名不合法 / -2 含禁用词 / -3 已存在 / -4 email 不合法 / -5 email 已存在 / -6 email 已占 / >0 成功 uid） */
    function uc_user_register(string $username, string $password, string $email, string $question = '', string $answer = ''): int
    {
        if (!uc_is_enabled()) {
            return 0;
        }
        $args = [
            'username' => $username,
            'password' => $password,
            'email'    => $email,
        ];
        if ($question !== '') {
            $args['questionid'] = $question;
            $args['answer'] = $answer;
        }
        $resp = uc_api_request('user', 'register', $args);
        $val = uc_unserialize($resp ?? '');
        if (is_array($val)) {
            return isset($val[0]) ? (int) $val[0] : 0;
        }
        return is_numeric($val) ? (int) $val : 0;
    }

    /**
     * 登录到 UCenter，返回 [uid, username, password, email, merge] 或 null。
     * 注意 onlogin 返回数组顺序为 [status, username, password, email, merge]，
     * 成功时 status(=uid) > 0；失败时 status 为 -1/-2/-3/-4。
     */
    function uc_user_login(string $username, string $password, int $isUid = 0): ?array
    {
        if (!uc_is_enabled()) {
            return null;
        }
        $val = uc_unserialize((string) (uc_api_request('user', 'login', [
            'username' => $username,
            'password' => $password,
            'isuid'    => $isUid,
        ]) ?? ''));
        if (!is_array($val) || empty($val) || !isset($val[0]) || (int) $val[0] <= 0) {
            return null;
        }
        return $val;
    }

    /** 获取 UCenter 用户信息 [uid, username, email] 或 null（不存在返回标量 0 → null） */
    function uc_get_user(string $username, int $isUid = 0): ?array
    {
        if (!uc_is_enabled()) {
            return null;
        }
        $val = uc_unserialize((string) (uc_api_request('user', 'get_user', [
            'username' => $username,
            'isuid'    => $isUid,
        ]) ?? ''));
        if (!is_array($val) || empty($val) || !isset($val[0]) || (int) $val[0] <= 0) {
            return null;
        }
        return $val;
    }

    /**
     * 修改 UCenter 用户资料（改密码 / 改邮箱 / 改用户名）
     * @param string $oldpw 旧密码（改密时必填，否则传 ''）
     * @param string $newpw 新密码（不改传 ''）
     * @return int 1=成功 0=无变化 -1 旧密码错误 -4 email 格式错 -5 email 被占 -7 无权限 -8 当前账号受保护
     */
    function uc_user_edit(string $username, string $oldpw, string $newpw, string $email = '', int $ignoreOldPw = 0): int
    {
        if (!uc_is_enabled()) {
            return 1;
        }
        $resp = uc_api_request('user', 'edit', [
            'username'    => $username,
            'oldpw'       => $oldpw,
            'newpw'       => $newpw,
            'email'       => $email,
            'ignoreoldpw' => $ignoreOldPw,
        ]);
        $val = uc_unserialize($resp ?? '');
        return is_array($val) ? (int) ($val[0] ?? 1) : (is_numeric($val) ? (int) $val : 1);
    }

    /** 删除 UCenter 用户（uid 可为整数/数组/逗号分隔字符串；返回 1=成功 0=未找到/失败） */
    function uc_user_delete($uids): int
    {
        if (!uc_is_enabled()) {
            return 1;
        }
        if (is_array($uids)) {
            $uids = implode(',', $uids);
        }
        // 注意：uc_server 的 ondelete 读取的是 input('uid')，而非 'uids'
        $val = uc_unserialize((string) (uc_api_request('user', 'delete', ['uid' => $uids]) ?? ''));
        return is_array($val) ? (int) ($val[0] ?? 1) : (is_numeric($val) ? (int) $val : 1);
    }

    /** 同步登录：返回需注入页面的 <script> 片段（UCenter 返回 HTML，原样透传） */
    function uc_user_synlogin(int $uid): string
    {
        if (!uc_is_enabled() || $uid <= 0) {
            return '';
        }
        $ret = uc_api_request('user', 'synlogin', ['uid' => $uid]);
        return is_string($ret) ? trim($ret) : '';
    }

    /** 同步登出：返回需注入页面的 <script> 片段（UCenter 返回 HTML，原样透传） */
    function uc_user_synlogout(): string
    {
        if (!uc_is_enabled()) {
            return '';
        }
        $ret = uc_api_request('user', 'synlogout', []);
        return is_string($ret) ? trim($ret) : '';
    }

    // ==================== 本地 <-> UCenter 绑定 ====================

    /** 记录绑定：本地用户 id <-> UCenter uid */
    function uc_bind_user(int $userId, int $ucUid, string $username = '', string $email = ''): void
    {
        try {
            $db = getDB();
            $db->prepare(
                "INSERT INTO user_ucenter (user_id, uc_uid, username, email, synced_at) "
                . "VALUES (?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE uc_uid=VALUES(uc_uid), username=VALUES(username), email=VALUES(email), synced_at=NOW()"
            )->execute([$userId, $ucUid, $username, $email]);
        } catch (Throwable $e) {
            error_log('uc_bind_user failed: ' . $e->getMessage());
        }
    }

    /** 通过本地 user_id 找到 UCenter uid */
    function uc_find_ucuid(int $userId)
    {
        try {
            $db = getDB();
            $s = $db->prepare("SELECT uc_uid FROM user_ucenter WHERE user_id=? LIMIT 1");
            $s->execute([$userId]);
            $v = $s->fetchColumn();
            return $v === false ? null : (int) $v;
        } catch (Throwable $e) {
            return null;
        }
    }

    /** 通过 UCenter uid 找到本地 user_id */
    function uc_find_local(int $ucUid)
    {
        try {
            $db = getDB();
            $s = $db->prepare("SELECT user_id FROM user_ucenter WHERE uc_uid=? LIMIT 1");
            $s->execute([$ucUid]);
            $v = $s->fetchColumn();
            return $v === false ? null : (int) $v;
        } catch (Throwable $e) {
            return null;
        }
    }

    /**
     * 综合同步：本地注册成功后同步到 UCenter。
     * 若已存在同名（uc_user_register 返回 -3），尝试用登录拿到 uid 再绑定。
     */
    function uc_sync_register(string $username, string $password, string $email, int $localUserId): void
    {
        if (!uc_is_enabled()) {
            return;
        }
        $uid = uc_user_register($username, $password, $email);
        if ($uid > 0) {
            uc_bind_user($localUserId, $uid, $username, $email);
            return;
        }
        // 已存在：尝试登录取 uid（兼容 Discuz 侧已存在账号）
        $login = uc_user_login($username, $password);
        if (is_array($login) && isset($login[0]) && (int) $login[0] > 0) {
            uc_bind_user($localUserId, (int) $login[0], $username, $email);
        }
    }

    /**
     * 登录时确保绑定并返回同步登录脚本。
     */
    function uc_sync_login(int $localUserId, string $username, string $password): string
    {
        if (!uc_is_enabled()) {
            return '';
        }
        $ucUid = uc_find_ucuid($localUserId);
        if ($ucUid === null || $ucUid <= 0) {
            // 尚未绑定：尝试登录 UCenter 取得 uid
            $login = uc_user_login($username, $password);
            if (is_array($login) && isset($login[0]) && (int) $login[0] > 0) {
                $ucUid = (int) $login[0];
                uc_bind_user($localUserId, $ucUid, $username);
            }
        }
        if ($ucUid === null || $ucUid <= 0) {
            return '';
        }
        return uc_user_synlogin($ucUid);
    }

    /**
     * 本站改密 → 同步 UCenter。
     * 本站已校验过原密码，故以 ignoreoldpw=1 跳过 UCenter 侧的旧密码校验。
     * @return bool true=已同步/无需同步；false=已启用策略但实际同步失败
     */
    function uc_sync_password(string $username, string $newpw): bool
    {
        if (!uc_strategy('uc_sync_password')) {
            return true;
        }
        $r = uc_user_edit($username, '', $newpw, '', 1);
        if ($r < 0) {
            error_log("[UCenter] uc_sync_password 失败 user={$username} code={$r}");
            return false;
        }
        return true;
    }

    /**
     * 本站改资料 → 同步邮箱。
     * @return bool true=已同步/无需同步；false=已启用策略但实际同步失败
     */
    function uc_sync_email(string $username, string $email): bool
    {
        if (!uc_strategy('uc_sync_email')) {
            return true;
        }
        $r = uc_user_edit($username, '', '', $email, 1);
        if ($r < 0) {
            error_log("[UCenter] uc_sync_email 失败 user={$username} code={$r}");
            return false;
        }
        return true;
    }

    /**
     * UCenter 连通性诊断（供后台/工具调用，定位“未返回有效数据”的根因）。
     * 依次检查：启用状态 → appid → UC_API 网络可达 → 真实接口调用返回。
     * @return array 结构化诊断报告
     */
    function uc_diagnose(): array
    {
        $report = [
            'enabled' => uc_is_enabled(),
            'config'  => uc_cfg(),
            'checks'  => [],
        ];
        // 隐藏敏感字段
        $report['config']['key'] = $report['config']['key'] !== '' ? '***已设置***' : '';
        unset($report['config']['dbpw']);

        if (!uc_is_enabled()) {
            $report['checks'][] = [
                'name'   => '启用与密钥',
                'ok'     => false,
                'detail' => 'uc_enabled 未开启，或 uc_api / uc_key 为空',
            ];
            $report['strategy'] = uc_strategy_snapshot();
            return $report;
        }

        $cfg = uc_cfg();

        $report['checks'][] = [
            'name'   => '应用 ID(appid)',
            'ok'     => (int) $cfg['appid'] > 0,
            'detail' => (int) $cfg['appid'] > 0
                ? "appid={$cfg['appid']}"
                : 'uc_appid 未配置（必须为 >0 的整数，需与 UCenter 后台「应用管理」中的应用 ID 完全一致）',
        ];

        // 网络可达性（HEAD 探测 UC_API 根地址）
        $reachable = false;
        $httpCode = 0;
        $curlErr = '';
        if (function_exists('curl_init')) {
            $ch = curl_init($cfg['api']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 8);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_setopt($ch, CURLOPT_USERAGENT, 'UCenter Client/1.6');
            curl_exec($ch);
            $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlErr = curl_error($ch);
            $reachable = $httpCode > 0;
            curl_close($ch);
        }
        $report['checks'][] = [
            'name'   => 'UC_API 网络可达',
            'ok'     => $reachable,
            'detail' => $reachable ? "HTTP {$httpCode}" : ("无法连接 {$cfg['api']}" . ($curlErr ? "（{$curlErr}）" : '')),
        ];

        // 真实接口调用（user/synlogout 为轻量只读探测）
        $raw = uc_api_request('user', 'synlogout', []);
        if ($raw === null) {
            $report['checks'][] = [
                'name'   => '接口调用(user/synlogout)',
                'ok'     => false,
                'detail' => '未返回有效数据。最常见原因：①UC_KEY 与服务端不一致；②appid 不匹配；③UC_API 指向的 uc_server 不可达或路径错误；④本机 PHP 未开启 curl/file_get_contents 远程访问。',
            ];
        } else {
            $trimmed = trim($raw);
            // 服务端可能返回的具体错误（见 uc_server/model/base.php::init_input）
            $errMap = [
                'Access denied for operation changed' => '加密载荷中的 m/a/appid 与服务端收到参数不一致（请求构造错误）',
                'Access denied for agent changed'     => 'agent 字段与 User-Agent 不匹配（客户端 UA 不一致）',
                'Authorization has expired'           => 'time 过期（本机与服务端时间差超过 3600 秒）',
                'Invalid Request'                     => 'UC_KEY 或 appid 校验失败（密钥/ID 不一致）',
                'Invalid input'                       => 'input 为空或无法解密',
            ];
            $isError = false;
            $errDetail = '';
            foreach ($errMap as $needle => $desc) {
                if (stripos($trimmed, $needle) !== false) {
                    $isError = true;
                    $errDetail = $desc;
                    break;
                }
            }
            $report['checks'][] = [
                'name'   => '接口调用(user/synlogout)',
                'ok'     => !$isError,
                'detail' => $isError
                    ? '服务端返回错误：' . $trimmed . '（' . $errDetail . '）'
                    : '成功，原始响应长度 ' . strlen($raw),
                'raw'    => mb_substr($trimmed, 0, 500),
            ];
        }

        // 同步策略开关快照
        $report['strategy'] = uc_strategy_snapshot();

        return $report;
    }

    /** 生成 6 个同步策略开关的快照数组 */
    function uc_strategy_snapshot(): array
    {
        $snap = [];
        foreach (['uc_sync_register', 'uc_sync_login', 'uc_sync_password', 'uc_sync_email', 'uc_allow_uc_login', 'uc_auto_create'] as $k) {
            $snap[$k] = uc_strategy($k);
        }
        return $snap;
    }
}
