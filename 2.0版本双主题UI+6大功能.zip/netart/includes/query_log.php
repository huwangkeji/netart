<?php
/**
 * NetworkPanel - 查询记录公共函数库
 *
 * 用于记录前台所有查询功能（IP 查询 / 流量计算 / 字节转换 / IP 进阶 / 测速 等）
 * 的用户与游客行为，供后台「查询记录管理」做数据溯源与追踪。
 *
 * 约定：
 *  - 仅依赖 config/config.php（getDB / getClientIP / jsonResponse）与 helpers.php（request_param）；
 *  - 所有写入均为「尽力而为」，失败仅记日志，不影响主业务流程；
 *  - 未登录用户记为游客（user_id=0，username='游客'）。
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';

/** 受支持的查询类型白名单 */
define('QUERY_LOG_TYPES', ['ip', 'ip_advanced', 'traffic', 'byte', 'speedtest', 'ip_tools']);

/**
 * 解析当前操作用户：
 *   1) 若已存在会话 Cookie，则启动会话读取 user_id / username；
 *   2) 否则尝试用请求中的 access_token 反查用户；
 *   3) 都失败则视为游客（user_id=0, username='游客'）。
 *
 * 注意：仅当客户端携带会话 Cookie 时才 session_start，避免给游客无端创建大量空会话。
 *
 * @return array{user_id:int, username:string}
 */
function resolveQueryUser(): array
{
    $userId = 0;
    $username = '';

    // 1) 会话（同域登录态）
    $cookieName = session_name();
    if (isset($_COOKIE[$cookieName])) {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        if (!empty($_SESSION['user_id'])) {
            $userId = (int) $_SESSION['user_id'];
            $username = (string) ($_SESSION['username'] ?? '');
        }
    }

    // 2) access_token 兜底（前端可能在请求体 / Authorization 头携带）
    if ($userId === 0) {
        $token = (string) request_param('access_token', '');
        if ($token === '' && isset($_SERVER['HTTP_AUTHORIZATION'])) {
            if (preg_match('/Bearer\s+(\S+)/i', (string) $_SERVER['HTTP_AUTHORIZATION'], $m)) {
                $token = $m[1];
            }
        }
        if ($token !== '') {
            try {
                $db = getDB();
                $stmt = $db->prepare('SELECT id, username FROM users WHERE access_token = ? LIMIT 1');
                $stmt->execute([$token]);
                $row = $stmt->fetch();
                if ($row) {
                    $userId = (int) $row['id'];
                    $username = (string) $row['username'];
                }
            } catch (Throwable $e) {
                error_log('[query_log] resolve token failed: ' . $e->getMessage());
            }
        }
    }

    return ['user_id' => $userId, 'username' => $username];
}

/**
 * 写入一条查询记录（尽力而为）。
 *
 * @param string $type    查询类型，必须是 QUERY_LOG_TYPES 之一（否则归为 other）
 * @param string $input   查询输入（目标 IP / 域名 / 参数摘要）
 * @param string $summary 结果摘要
 */
function logQuery(string $type, string $input, string $summary = ''): void
{
    static $allowed = QUERY_LOG_TYPES;
    if (!in_array($type, $allowed, true)) {
        $type = 'other';
    }

    $input = mb_substr($input, 0, 1000);
    $summary = mb_substr($summary, 0, 500);

    try {
        $db = getDB();
        $user = resolveQueryUser();
        $ip = getClientIP();
        $ua = mb_substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500);
        $account = $user['user_id'] > 0 ? $user['username'] : '游客';

        $stmt = $db->prepare(
            'INSERT INTO query_logs '
            . '(`user_id`, `username`, `query_type`, `query_input`, `result_summary`, `ip`, `user_agent`, `created_at`) '
            . 'VALUES (?, ?, ?, ?, ?, ?, ?, NOW())'
        );
        $stmt->execute([$user['user_id'], $account, $type, $input, $summary, $ip, $ua]);
    } catch (Throwable $e) {
        error_log('[query_log] insert failed: ' . $e->getMessage());
    }
}
