<?php
/**
 * NetworkPanel 公共函数库
 *
 * 统一提供：站点配置读取、输出转义、内容净化、数字/字节格式化、
 * 请求参数读取、客户端 IP 判定、API 统一响应、轻量限流。
 *
 * 约定：
 * 1. 本文件只依赖 config/config.php，不再依赖任何业务代码；
 * 2. 所有函数以 app_/format_/request_/api_/throttle_ 前缀命名，避免与旧代码冲突；
 * 3. 运行环境为 PHP 7.4，禁止使用 PHP 8 专有语法。
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';

/* ============================================================
 * 一、站点配置（一次请求内只查库一次）
 * ============================================================ */

/**
 * 读取全部站点配置（进程内缓存）
 *
 * @return array<string,string>
 */
function app_settings(): array
{
    if (!isset($GLOBALS['_app_settings_cache']) || !is_array($GLOBALS['_app_settings_cache'])) {
        $GLOBALS['_app_settings_cache'] = [];
        try {
            $stmt = getDB()->query('SELECT setting_key, setting_value FROM site_settings');
            foreach ($stmt->fetchAll() as $row) {
                $GLOBALS['_app_settings_cache'][(string) $row['setting_key']] = (string) $row['setting_value'];
            }
        } catch (Throwable $e) {
            error_log('[helpers] 读取站点配置失败: ' . $e->getMessage());
        }
    }

    return $GLOBALS['_app_settings_cache'];
}

/**
 * 写入单个站点配置（UPSERT，写入后失效本地缓存）
 *
 * @param string $key
 * @param mixed  $value
 * @return bool
 */
function app_setting_set(string $key, $value): bool
{
    try {
        $sql = 'INSERT INTO site_settings (setting_key, setting_value, updated_at)
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()';
        getDB()->prepare($sql)->execute([$key, (string) $value]);
        unset($GLOBALS['_app_settings_cache']);

        return true;
    } catch (Throwable $e) {
        error_log('[helpers] 写入站点配置失败: ' . $e->getMessage());

        return false;
    }
}

/**
 * 批量写入站点配置
 *
 * @param array<string,string|int|bool> $map
 * @return bool
 */
function app_setting_set_many(array $map): bool
{
    $ok = true;
    foreach ($map as $k => $v) {
        if (!app_setting_set((string) $k, $v)) {
            $ok = false;
        }
    }

    return $ok;
}

/**
 * 读取单个站点配置
 *
 * @param string $key
 * @param mixed  $default 配置缺失或为空时返回的默认值
 * @return mixed
 */
function app_setting(string $key, $default = '')
{
    $settings = app_settings();
    return (array_key_exists($key, $settings) && $settings[$key] !== '') ? $settings[$key] : $default;
}

/** 站点名称 */
function app_site_name(): string
{
    return (string) app_setting('site_name', '网络面板');
}

/** 默认流量单价（元/GB），供流量计算器使用 */
function app_default_price(): string
{
    return (string) app_setting('traffic_price', '1.10');
}

/* ============================================================
 * 二、输出转义与内容净化
 * ============================================================ */

/**
 * HTML 转义输出
 *
 * @param mixed $value
 */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** 允许出现在自定义页面（协议/隐私）中的标签白名单 */
function page_allowed_tags(): string
{
    return '<p><br><hr><h1><h2><h3><h4><h5><ul><ol><li><strong><b><em><i><u><s>'
        . '<blockquote><code><pre><span><div><section><small><sub><sup>'
        . '<table><thead><tbody><tr><th><td><a><img>';
}

/**
 * 净化后台编辑的富文本内容
 *
 * 后台允许管理员写 HTML，但前台渲染必须做白名单过滤，避免存储型 XSS。
 * 仅保留 href/title/target 三个安全属性，并拦截 javascript: 协议。
 */
function sanitize_page_html(string $html): string
{
    $clean = strip_tags($html, page_allowed_tags());

    // 去掉注释与 CDATA，避免绕过
    $clean = preg_replace('/<!--.*?-->/s', '', $clean) ?? $clean;

    // 逐标签重建属性
    $clean = preg_replace_callback('/<\s*([a-zA-Z0-9]+)([^>]*)>/', static function (array $m): string {
        $tag = strtolower($m[1]);
        $attrs = $m[2] ?? '';

        $keep = '';
        if (preg_match_all('/([a-zA-Z-]+)\s*=\s*("([^"]*)"|\'([^\']*)\')/', $attrs, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $one) {
                $name = strtolower($one[1]);
                $value = $one[3] ?? $one[4] ?? '';

                if (!in_array($name, ['href', 'title', 'target', 'src', 'alt', 'width', 'height', 'loading'], true)) {
                    continue;
                }
                if (($name === 'href' || $name === 'src') && preg_match('/^\s*javascript:/i', $value)) {
                    continue;
                }
                if ($name === 'target') {
                    $value = $value === '_blank' ? '_blank' : '_self';
                }

                $keep .= ' ' . $name . '="' . htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '"';
            }
        }

        return '<' . $tag . $keep . '>';
    }, $clean) ?? $clean;

    return trim($clean);
}

/**
 * 把纯文本（可能带 Markdown 风格空行）转成安全 HTML
 *
 * 后台若直接粘贴纯文本，也保证页面有合理排版。
 */
function page_text_to_html(string $text): string
{
    $text = str_replace(["\r\n", "\r"], "\n", $text);
    $blocks = preg_split("/\n\s*\n/", trim($text)) ?: [];
    $html = '';

    foreach ($blocks as $block) {
        $block = trim($block);
        if ($block === '') {
            continue;
        }
        $html .= '<p>' . nl2br(e($block)) . '</p>';
    }

    return $html;
}

/* ============================================================
 * 三、数值与单位格式化
 * ============================================================ */

/**
 * 去掉多余的小数 0（1.500000 → 1.5，2.000000 → 2）
 */
function number_trim($value, int $decimals = 6): string
{
    $value = (float) $value;

    if (!is_finite($value)) {
        return '0';
    }
    // 极大/极小数使用科学计数法，避免丢失有效位
    if ($value !== 0.0 && (abs($value) >= 1e15 || abs($value) < 1e-6)) {
        return sprintf('%.' . $decimals . 'E', $value);
    }

    $formatted = number_format($value, $decimals, '.', '');
    $formatted = rtrim(rtrim($formatted, '0'), '.');

    return $formatted === '' ? '0' : $formatted;
}

/**
 * 字节数格式化为可读字符串（1024 进制）
 */
function format_bytes($bytes, int $precision = 2): string
{
    $bytes = (float) $bytes;

    if ($bytes < 0) {
        return '-' . format_bytes(abs($bytes), $precision);
    }

    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $index = 0;

    while ($bytes >= 1024 && $index < count($units) - 1) {
        $bytes /= 1024;
        $index++;
    }

    return number_format($bytes, $index === 0 ? 0 : $precision, '.', '') . ' ' . $units[$index];
}

/** 速率格式化（字节/秒 → 可读速率） */
function format_speed_bps($bytesPerSecond, int $precision = 2): string
{
    return format_bytes((float) $bytesPerSecond, $precision) . '/s';
}

/* ============================================================
 * 四、请求上下文
 * ============================================================ */

/**
 * 读取请求参数（POST 优先于 GET）
 *
 * @param mixed $default
 * @return mixed
 */
function request_param(string $key, $default = '')
{
    if (isset($_POST[$key])) {
        return is_string($_POST[$key]) ? trim($_POST[$key]) : $_POST[$key];
    }
    if (isset($_GET[$key])) {
        return is_string($_GET[$key]) ? trim($_GET[$key]) : $_GET[$key];
    }

    // 兼容 application/json 请求体
    $raw = file_get_contents('php://input');
    if ($raw !== false && $raw !== '') {
        $json = json_decode($raw, true);
        if (is_array($json) && array_key_exists($key, $json)) {
            return is_string($json[$key]) ? trim($json[$key]) : $json[$key];
        }
    }

    return $default;
}

/** 当前请求方法 */
function request_method(): string
{
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

/* ============================================================
 * 五、API 统一响应
 * ============================================================ */

/**
 * 成功响应
 *
 * @param mixed $data
 */
function api_ok($data = [], string $message = 'ok', array $extra = []): void
{
    jsonResponse(array_merge([
        'status' => 0,
        'code' => 200,
        'message' => $message,
        'data' => $data,
    ], $extra));
}

/**
 * 失败响应
 *
 * @param mixed $data
 */
function api_fail(string $message, int $code = 400, $data = null, int $httpCode = 200): void
{
    jsonResponse([
        'status' => 1,
        'code' => $code,
        'message' => $message,
        'data' => $data,
    ], $httpCode);
}

/* ============================================================
 * 六、轻量限流（文件型，无外部依赖）
 * ============================================================ */

/**
 * 简单滑动窗口限流
 *
 * @param string $bucket 业务标识
 * @param int    $limit  窗口内允许次数
 * @param int    $window 窗口秒数
 * @return bool true=允许通过
 */
function throttle_pass(string $bucket, int $limit = 60, int $window = 60): bool
{
    $key = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $bucket) . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', request_ip());
    $dir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'np_throttle';

    if (!is_dir($dir) && !@mkdir($dir, 0777, true) && !is_dir($dir)) {
        return true; // 无法限流时放行，保证功能可用
    }

    $file = $dir . DIRECTORY_SEPARATOR . $key . '.txt';
    $now = time();
    $records = [];

    if (is_file($file)) {
        $raw = (string) @file_get_contents($file);
        $records = array_filter(array_map('intval', explode(',', $raw)));
    }

    $records = array_values(array_filter($records, static function (int $ts) use ($now, $window): bool {
        return ($now - $ts) < $window;
    }));

    if (count($records) >= $limit) {
        return false;
    }

    $records[] = $now;
    @file_put_contents($file, implode(',', array_slice($records, -$limit)), LOCK_EX);

    return true;
}

/* ============================================================
 * 七、HTTP 客户端（带 CA 与超时，供 IP 查询等外部调用）
 * ============================================================ */

/**
 * 发起 HTTP GET 并返回原始响应
 *
 * @param string[] $headers 可选自定义请求头（如 Bearer Token），统一在此处理，避免与 http_get_with_headers 重复实现
 * @return array{ok:bool,code:int,body:string,error:string}
 */
function http_get(string $url, int $timeout = 6, array $headers = []): array
{
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'code' => 0, 'body' => '', 'error' => 'curl 扩展未安装'];
    }

    $options = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => min(3, $timeout),
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_USERAGENT => 'NetworkPanel/1.0 (+https://net.arsn.cn)',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ];

    // 本地 Windows 环境常未配置 curl.cainfo，使用项目内置证书包
    $caBundle = __DIR__ . '/../config/cacert.pem';
    if (is_file($caBundle)) {
        $options[CURLOPT_CAINFO] = $caBundle;
    }

    if (!empty($headers)) {
        $options[CURLOPT_HTTPHEADER] = array_values($headers);
    }

    $ch = curl_init();
    curl_setopt_array($ch, $options);
    $body = curl_exec($ch);
    $error = curl_error($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false) {
        return ['ok' => false, 'code' => $code, 'body' => '', 'error' => $error ?: '请求失败'];
    }

    return [
        'ok' => $code >= 200 && $code < 300,
        'code' => $code,
        'body' => (string) $body,
        'error' => '',
    ];
}

/** HTTP GET + JSON 解析 */
function http_get_json(string $url, int $timeout = 6): ?array
{
    $response = http_get($url, $timeout);
    if (!$response['ok'] || $response['body'] === '') {
        return null;
    }

    $data = json_decode($response['body'], true);

    return is_array($data) ? $data : null;
}

/**
 * HTTP GET（支持自定义请求头，用于 Bearer Token 等鉴权场景）
 * 直接委托 http_get()，避免重复实现。
 *
 * @param string[] $headers 形如 ['Authorization: Bearer xxxx', 'Accept: application/json']
 */
function http_get_with_headers(string $url, array $headers = [], int $timeout = 8): array
{
    return http_get($url, $timeout, $headers);
}

/** HTTP GET + JSON 解析，支持自定义请求头 */
function http_get_json_with_headers(string $url, array $headers = [], int $timeout = 8): ?array
{
    $response = http_get_with_headers($url, $headers, $timeout);
    if (!$response['ok'] || $response['body'] === '') {
        return null;
    }

    $data = json_decode($response['body'], true);

    return is_array($data) ? $data : null;
}
