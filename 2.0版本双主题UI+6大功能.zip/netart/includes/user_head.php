<?php
/**
 * 会员中心页 <head> 渲染
 * 期望外部变量：
 *   $pageTitle (必填)
 *   $assetBase (可选, 默认 '../')
 *   $siteDesc  (可选, 站点描述)
 *   $extraHead (可选, 页面专属 <style>)
 */
$__assetBase = $assetBase ?? '../';
$__title     = $pageTitle ?? 'NetworkPanel';
$__desc      = $siteDesc ?? '';
$__extra     = $extraHead ?? '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($__title, ENT_QUOTES); ?></title>
    <?php if ($__desc): ?><meta name="description" content="<?php echo htmlspecialchars($__desc, ENT_QUOTES); ?>"><?php endif; ?>
    <link rel="icon" type="image/svg+xml" href="<?php echo $__assetBase; ?>public/favicon.svg">
    <link rel="icon" type="image/png" sizes="144x144" href="<?php echo $__assetBase; ?>public/icon.png">
    <link rel="stylesheet" href="<?php echo $__assetBase; ?>css/style.css">
    <?php echo $__extra; ?>
</head>
<body>
