<?php
/**
 * 单位换算与流量计算（纯函数，无 IO，便于单测）
 *
 * 统一口径：
 *  - 存储单位按 1024 进制：1 KB = 1024 B，1 MB = 1024 KB …
 *  - 速率单位 Kbps/Mbps/Gbps 为「比特每秒」，按 1000 进制换算；
 *    1 Mbps = 0.125 MB/s（兆字节每秒）。
 *
 * 修复源站遗留缺陷：
 *  1. 旧流量计算器把「MB 数值」当成「字节」传给 formatBytes，导致结果缩小 1024² 倍；
 *  2. 旧费用公式流量(MB) / 1024³ 计费，应为流量(GB) = 流量(MB) / 1024。
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

/** 存储单位 → 字节 的换算系数 */
function unit_factors(): array
{
    return [
        'B' => 1,
        'KB' => 1024,
        'MB' => 1024 ** 2,
        'GB' => 1024 ** 3,
        'TB' => 1024 ** 4,
        'PB' => 1024 ** 5,
    ];
}

/** 速率单位 → Mbps 的换算系数 */
function rate_factors(): array
{
    return [
        'Kbps' => 0.001,
        'Mbps' => 1.0,
        'Gbps' => 1000.0,
    ];
}

/** 判断是否为合法存储单位 */
function is_valid_unit(string $unit): bool
{
    return isset(unit_factors()[strtoupper($unit)]);
}

/** 判断是否为合法速率单位 */
function is_valid_rate_unit(string $unit): bool
{
    return isset(rate_factors()[$unit]);
}

/**
 * 存储单位换算
 *
 * @param float  $value 数值
 * @param string $from  源单位
 * @param string $to    目标单位
 * @return float 目标单位下的数值
 */
function convert_bytes(float $value, string $from, string $to): float
{
    $factors = unit_factors();
    $from = strtoupper($from);
    $to = strtoupper($to);

    if (!isset($factors[$from], $factors[$to])) {
        throw new InvalidArgumentException('无效的存储单位：' . $from . ' / ' . $to);
    }

    return ($value * $factors[$from]) / $factors[$to];
}

/**
 * 把某个数值换算到全部存储单位
 *
 * @return array<int,array{unit:string,value:string,bytes:float}>
 */
function convert_to_all_units(float $value, string $from): array
{
    $from = strtoupper($from);
    if (!is_valid_unit($from)) {
        throw new InvalidArgumentException('无效的存储单位：' . $from);
    }

    $bytes = $value * unit_factors()[$from];
    $result = [];

    foreach (unit_factors() as $unit => $factor) {
        $result[] = [
            'unit' => $unit,
            'value' => number_trim($bytes / $factor),
            'raw' => $bytes / $factor,
            'bytes' => $bytes,
        ];
    }

    return $result;
}

/**
 * 速率 → 每秒字节数
 *
 * @param float  $speed 速率数值
 * @param string $unit  Kbps / Mbps / Gbps
 */
function rate_to_bytes_per_second(float $speed, string $unit = 'Mbps'): float
{
    if (!is_valid_rate_unit($unit)) {
        throw new InvalidArgumentException('无效的速率单位：' . $unit);
    }

    $mbPerSecond = $speed * rate_factors()[$unit] * 0.125; // Mbps → MB/s

    return $mbPerSecond * 1024 * 1024;
}

/**
 * 流量计算：按速率与单价，计算每小时/每天/每月/每年的流量与费用
 *
 * @param float  $speed 速率数值
 * @param string $unit  Kbps / Mbps / Gbps
 * @param float  $price 单价（元/GB），小于 0 按 0 处理
 * @return array{input:array,rows:array<int,array>}
 */
function traffic_report(float $speed, string $unit = 'Mbps', float $price = 0.0): array
{
    if (!is_valid_rate_unit($unit)) {
        throw new InvalidArgumentException('无效的速率单位：' . $unit);
    }
    if ($speed < 0) {
        throw new InvalidArgumentException('速率不能为负数');
    }

    $price = max(0.0, $price);
    $bytesPerSecond = rate_to_bytes_per_second($speed, $unit);

    $periods = [
        ['key' => 'hour', 'label' => '每小时', 'seconds' => 3600],
        ['key' => 'day', 'label' => '每天', 'seconds' => 3600 * 24],
        ['key' => 'month', 'label' => '每月', 'seconds' => 3600 * 24 * 30],
        ['key' => 'year', 'label' => '每年', 'seconds' => 3600 * 24 * 365],
    ];

    $rows = [];
    foreach ($periods as $period) {
        $bytes = $bytesPerSecond * $period['seconds'];
        $gigabytes = $bytes / (1024 ** 3);

        $rows[] = [
            'key' => $period['key'],
            'label' => $period['label'],
            'seconds' => $period['seconds'],
            'bytes' => $bytes,
            'gigabytes' => $gigabytes,
            'traffic' => format_bytes($bytes),
            'cost' => number_format($gigabytes * $price, 2, '.', ''),
        ];
    }

    return [
        'input' => [
            'speed' => $speed,
            'unit' => $unit,
            'price' => $price,
            'bytes_per_second' => $bytesPerSecond,
            'mb_per_second' => $speed * rate_factors()[$unit] * 0.125,
        ],
        'rows' => $rows,
    ];
}
