<?php
/**
 * 公共页顶部导航栏（与首页/排行榜共用）
 * 期望外部变量：
 *   $activeNav (可选, 'home' | 'rank'，控制高亮)
 *   $siteName  (站点名称，来自页面已定义的变量)
 */
$__active    = $activeNav ?? 'home';
$__siteName  = $siteName ?? '';
?>
    <!-- 顶部导航栏 -->
    <header class="header">
        <div class="header-inner">
            <div class="logo-section">
                <div class="logo-icon">
                    <svg viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg">
                        <path d="M568.96 459.242667l144-189.205334A382.208 382.208 0 0 0 512 213.333333c-212.074667 0-384 171.925333-384 384a382.293333 382.293333 0 0 0 93.397333 251.008l-64.554666 55.808A467.584 467.584 0 0 1 42.666667 597.333333C42.666667 338.133333 252.8 128 512 128c93.098667 0 179.861333 27.093333 252.842667 73.856l75.882666-99.690667 67.541334 51.413334-273.28 359.04a149.333333 149.333333 0 1 1-66.048-53.376z m266.453333-69.056l54.357334-71.424A467.242667 467.242667 0 0 1 981.333333 597.333333c0 113.706667-40.64 221.226667-113.237333 305.728l-64.725333-55.616A382.272 382.272 0 0 0 896 597.333333c0-76.288-22.250667-147.370667-60.586667-207.146666zM512 661.333333a64 64 0 1 0 0-128 64 64 0 0 0 0 128z" fill="#ffffff"></path>
                    </svg>
                </div>
                <span class="title"><?php echo htmlspecialchars($__siteName, ENT_QUOTES); ?></span>
            </div>
            <nav class="nav-links">
                <a href="./index.php" class="nav-link nav-btn<?php echo $__active === 'home' ? ' active' : ''; ?>" data-nav-home>首页</a>
                <a href="./tools.php" class="nav-link nav-btn<?php echo $__active === 'tools' ? ' active' : ''; ?>">工具箱</a>
                <a href="./ip.php" class="nav-link nav-btn<?php echo $__active === 'ip' ? ' active' : ''; ?>">IP 查询</a>
                <a href="./traffic.php" class="nav-link nav-btn<?php echo $__active === 'traffic' ? ' active' : ''; ?>">流量计算器</a>
                <a href="./byte.php" class="nav-link nav-btn<?php echo $__active === 'byte' ? ' active' : ''; ?>">字节转换</a>
                <a href="./ip-tools.php" class="nav-link nav-btn<?php echo $__active === 'iptools' ? ' active' : ''; ?>">IP 进阶</a>
                <a href="./rank.php" class="nav-link nav-btn<?php echo $__active === 'rank' ? ' active' : ''; ?>">排行榜</a>
                <span id="topNavContainer"></span>
                <!-- 主导航已固定，topNavContainer 仅用于后台自定义的附加外链/入口 -->
                <div id="authArea">
                    <a href="./user/login.php" class="nav-link" id="btnLogin">登录</a>
                    <a href="./user/center.php" class="nav-link nav-user-center btn-center" id="btnUserCenter" style="display:none;" target="_blank">个人中心</a>
                    <div id="userBadge" style="display:none;align-items:center;gap:6px;">
                        <span class="user-avatar-sm" id="userAvatarSm">U</span>
                        <span id="userNameDisplay"></span>
                    </div>
                </div>
                <a href="./admin/index.php" class="nav-link nav-user" id="btnAdminLink" target="_blank" style="display:none;">管理后台</a>
                <button class="btn-link btn-app" id="btnApp" style="display:none;">APP</button>
            </nav>
        </div>
    </header>
