<?php
/**
 * 文档型页面渲染（用户协议 / 隐私政策）
 *
 * 两个页面共用同一套渲染逻辑，内容取自数据库（可后台自定义），
 * 未自定义时自动回退到内置默认模板。
 */

declare(strict_types=1);

require_once __DIR__ . '/layout.php';
require_once __DIR__ . '/pages.php';

/**
 * 渲染文档页
 */
function render_document_page(string $slug): void
{
    $page = page_get($slug);
    $html = page_with_anchors($page['html']);
    $toc = page_toc($page['html']);
    $updatedAt = $page['updated_at'] !== ''
        ? date('Y-m-d H:i', strtotime($page['updated_at']))
        : '';

    render_page_header([
        'title' => $page['title'],
        'subtitle' => $page['description'],
        'description' => $page['description'],
        'active' => $slug,
    ]);
    ?>
    <div class="np-doc-layout">
        <?php if ($toc !== []): ?>
        <aside class="np-toc" aria-label="目录">
            <div class="np-toc-title">目录</div>
            <ul class="np-toc-list" id="npToc">
                <?php foreach ($toc as $item): ?>
                    <li><a href="#<?= e($item['id']) ?>" data-toc-target="<?= e($item['id']) ?>"><?= e($item['text']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </aside>
        <?php endif; ?>

        <article class="np-card">
            <div class="np-doc-meta">
                <span>最后更新：<span class="np-doc-updated"><?= e($updatedAt !== '' ? $updatedAt : '—') ?></span></span>
                <span><?= $page['is_custom'] ? '当前为自定义内容' : '当前为默认模板' ?></span>
                <span>生效范围：全站用户</span>
            </div>

            <?php if (trim(strip_tags($html)) === ''): ?>
                <div class="np-doc-empty">暂无内容，请前往后台「页面管理」填写。</div>
            <?php else: ?>
                <div class="np-doc-body" id="npDocBody"><?= $html ?></div>
            <?php endif; ?>
        </article>
    </div>

    <button class="np-backtop" id="npBackTop" title="返回顶部" aria-label="返回顶部">↑</button>
    <?php
    render_page_footer(['scripts' => ['./js/doc.js']]);
}
