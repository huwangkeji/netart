<?php
/**
 * 公共页 <head> 渲染（与首页/排行榜共用）
 * 期望外部变量：
 *   $pageTitle   (必填, 原始字符串；内部做 htmlspecialchars)
 *   $assetBase   (可选, 资源基路径, 默认 './'；用户页用 '../')
 *   $extraHead   (可选, <head> 内追加的原始 HTML，如页面专属 <style>)
 *   $loadEcharts (可选, bool, 是否在 head 内加载 echarts)
 *   $viewport    (可选, 默认带 user-scalable=no)
 *   $siteDesc    (可选, 站点描述，非空时输出 meta description)
 */
$__assetBase = $assetBase ?? './';
$__title     = $pageTitle ?? 'NetworkPanel';
$__desc      = $siteDesc ?? '';
$__viewport  = $viewport ?? 'width=device-width, initial-scale=1.0, user-scalable=no';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="<?php echo htmlspecialchars($__viewport, ENT_QUOTES); ?>">
    <title><?php echo htmlspecialchars($__title, ENT_QUOTES); ?></title>
    <?php if ($__desc): ?><meta name="description" content="<?php echo htmlspecialchars($__desc, ENT_QUOTES); ?>"><?php endif; ?>
    <link rel="icon" type="image/svg+xml" href="<?php echo $__assetBase; ?>public/favicon.svg">
    <link rel="icon" type="image/png" sizes="144x144" href="<?php echo $__assetBase; ?>public/icon.png">
    <link rel="stylesheet" href="<?php echo $__assetBase; ?>css/style.css">
    <?php if (!empty($loadEcharts)): ?><script src="<?php echo $__assetBase; ?>public/echarts.min.js"></script><?php endif; ?>
    <?php echo $extraHead ?? ''; ?>
</head>
<body>
