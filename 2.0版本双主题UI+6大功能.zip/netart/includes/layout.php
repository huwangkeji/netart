<?php
/**
 * 站点页面框架（统一头部 / 底部）
 *
 * 所有新增页面（工具页 + 协议页）统一调用 render_page_header() / render_page_footer()，
 * 避免每个页面复制粘贴一段 HTML（源站 tools/*.php 就是这么散的）。
 *
 * 页面视觉参考 https://net.arsn.cn：
 *  - 1280px 容器 + 白底卡片 + 1px 细边框 + 10~14px 圆角；
 *  - 弱阴影、大字重标题、正文 15px/1.8 行高；
 *  - 主色沿用本站品牌色 #5668EE，并支持深色模式。
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

/**
 * 构造主题切换链接（保留当前 URL 其他查询参数，仅替换 theme）
 *
 * @param string $targetTheme new|classic
 * @return string
 */
function np_theme_switch_url(string $targetTheme): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? '127.0.0.5';
    $uri = $_SERVER['REQUEST_URI'] ?? '/';

    // 去掉已有的 theme 参数（以及可能重复的 ?）
    $uri = preg_replace('/([?&])theme=[^&]*&?/', '$1', $uri) ?? $uri;
    $uri = rtrim($uri, '?&');

    $sep = strpos($uri, '?') === false ? '?' : '&';
    return $scheme . '://' . $host . $uri . $sep . 'theme=' . $targetTheme;
}

/**
 * 给本地静态资源追加基于文件修改时间的版本号，避免浏览器沿用旧缓存。
 *
 * 背景：Nginx 对 .js/.css 只发 ETag/Last-Modified，Chromium 会做启发式缓存，
 * 导致改完 JS 后前台仍加载旧文件（表现为「功能改了但页面没变」）。
 *
 * - 仅处理站内相对路径；绝对 URL（http/https//）原样返回；
 * - 文件不存在时原样返回，不影响页面渲染。
 *
 * @param string $path 形如 ./js/app.js
 * @return string 形如 ./js/app.js?v=1699999999
 */
function asset_url(string $path): string
{
    if ($path === '' || preg_match('#^(https?:)?//#', $path)) {
        return $path;
    }

    // 去掉已有查询串后定位文件
    $bare = preg_replace('/[?#].*$/', '', $path) ?? $path;
    $file = __DIR__ . '/../' . ltrim(preg_replace('#^\./#', '', $bare) ?? $bare, '/');

    if (!is_file($file)) {
        return $path;
    }

    $mtime = @filemtime($file);
    if ($mtime === false) {
        return $path;
    }

    $sep = strpos($path, '?') === false ? '?' : '&';
    return $path . $sep . 'v=' . $mtime;
}

/**
 * 输出页面头部
 *
 * @param array{
 *     title?:string, subtitle?:string, description?:string, active?:string,
 *     css?:array<int,string>, body_class?:string, wide?:bool
 * } $options
 */
function render_page_header(array $options = []): void
{
    $siteName = app_site_name();
    $pageTitle = (string) ($options['title'] ?? '');
    $subtitle = (string) ($options['subtitle'] ?? '');
    $description = (string) ($options['description'] ?? '');
    $active = (string) ($options['active'] ?? '');
    $bodyClass = (string) ($options['body_class'] ?? '');
    $wide = !empty($options['wide']);

    // 主题切换：URL 参数 ?theme=classic 优先，次优 cookie np_theme
    $currentTheme = 'new';
    if (isset($_GET['theme']) && in_array($_GET['theme'], ['new', 'classic'], true)) {
        $currentTheme = $_GET['theme'];
        setcookie('np_theme', $currentTheme, time() + 86400 * 30, '/', '', false, true);
    } elseif (isset($_COOKIE['np_theme']) && in_array($_COOKIE['np_theme'], ['new', 'classic'], true)) {
        $currentTheme = $_COOKIE['np_theme'];
    }
    $isClassic = $currentTheme === 'classic';
    $themeClass = $isClassic ? 'np-theme-classic' : 'np-theme-new';
    // 切换链接：当前 URL 替换 theme 参数后在新标签页打开
    $themeSwitchUrl = np_theme_switch_url($isClassic ? 'new' : 'classic');
    $themeSwitchText = $isClassic ? '切换新版' : '切换经典版';

    $fullTitle = $pageTitle !== '' ? $pageTitle . ' - ' . $siteName : $siteName;

    // 四个工具（IP 查询 / 流量计算器 / 字节转换 / IP 进阶）已聚合到「工具箱」页，
    // 此处不再单独列出，以减少导航按钮数量。
    $navItems = [
        'home' => ['url' => './index.php', 'label' => '首页'],
        'overview' => ['url' => './home.php', 'label' => '概览'],
        'tools' => ['url' => './tools.php', 'label' => '工具箱'],
        'nat' => ['url' => './nat.php', 'label' => 'NAT 检测'],
        'settings' => ['url' => './settings.php', 'label' => '面板设置'],
        'rank' => ['url' => './rank.php', 'label' => '排行榜'],
        'about' => ['url' => './about.php', 'label' => '关于我们'],
    ];

    header('Content-Type: text/html; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    ?><!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>window.__NP_LAYOUT = true;</script>
    <?php /* 首帧前应用主题 / 紧凑模式，避免闪烁（最小内联，不依赖外部脚本） */ ?>
    <script>
        (function () {
            try {
                var raw = localStorage.getItem('np_panel_settings');
                var cfg = raw ? JSON.parse(raw) : null;
                if (!cfg) cfg = {};
                var dark = false, byTime = !!cfg.autoThemeByTime;
                function inWin(now, s, e) {
                    function m(x){var p=String(x||'0:0').split(':');return (parseInt(p[0],10)||0)*60+(parseInt(p[1],10)||0);}
                    var c = now.getHours()*60+now.getMinutes(), a=m(s), b=m(e);
                    if(a===b) return false; if(a<b) return c>=a&&c<b; return c>=a||c<b;
                }
                if (byTime && inWin(new Date(), cfg.darkStart||'18:00', cfg.darkEnd||'06:00')) dark = true;
                else if (cfg.theme === 'system' || !cfg.theme) {
                    dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
                } else dark = cfg.theme === 'dark';
                document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
                if (cfg.compact) document.documentElement.classList.add('np-compact');
            } catch (e) {}
        })();
    </script>
    <title><?= e($fullTitle) ?></title>
    <meta name="description" content="<?= e($description !== '' ? $description : app_setting('site_description', '网络测速、流量消耗与 IP 工具集合')) ?>">
    <meta name="theme-color" content="#5668EE">
    <link rel="icon" type="image/svg+xml" href="./public/favicon.svg">
    <link rel="icon" type="image/png" sizes="144x144" href="./public/icon.png">
    <link rel="stylesheet" href="<?= e(asset_url('./css/pages.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset_url('./css/panel.css')) ?>">
    <?php if ($isClassic): ?>
    <link rel="stylesheet" href="<?= e(asset_url('./css/classic.css')) ?>">
    <?php endif; ?>
    <?php foreach (($options['css'] ?? []) as $cssFile): ?>
    <link rel="stylesheet" href="<?= e(asset_url($cssFile)) ?>">
    <?php endforeach; ?>
</head>
<body class="np-body <?= e($bodyClass) ?> <?= e($themeClass) ?>">
    <header class="np-header">
        <div class="np-container np-header-inner">
            <a class="np-brand" href="./home.php">
                <span class="np-brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"><path d="M568.96 459.24l144-189.2A382.2 382.2 0 0 0 512 213.33c-212.07 0-384 171.93-384 384a382.3 382.3 0 0 0 93.4 251.01l-64.56 55.81A467.6 467.6 0 0 1 42.67 597.33C42.67 338.13 252.8 128 512 128c93.1 0 179.86 27.09 252.84 73.86l75.88-99.69 67.54 51.41-273.28 359.04a149.3 149.3 0 1 1-66.05-53.38zm266.45-69.06l54.36-71.42A467.2 467.2 0 0 1 981.33 597.33c0 113.71-40.64 221.23-113.24 305.73l-64.72-55.62A382.3 382.3 0 0 0 896 597.33c0-76.29-22.25-147.37-60.59-207.15zM512 661.33a64 64 0 1 0 0-128 64 64 0 0 0 0 128z" fill="currentColor"></path></svg>
                </span>
                <span class="np-brand-name"><?= e($siteName) ?></span>
            </a>

            <nav class="np-nav" aria-label="主导航">
                <?php foreach ($navItems as $key => $item): ?>
                    <a class="np-nav-link<?= $active === $key ? ' is-active' : '' ?>" href="<?= e($item['url']) ?>"><?= e($item['label']) ?></a>
                <?php endforeach; ?>
                <span id="topNavContainer" class="np-nav-extra"></span>
            </nav>

            <div class="np-header-actions" id="authArea">
                <a class="np-theme-switch" href="<?= e($themeSwitchUrl) ?>" target="_blank" rel="noopener" title="<?= e($themeSwitchText) ?>" aria-label="<?= e($themeSwitchText) ?>">
                    <span class="np-theme-switch-dot"></span>
                    <span class="np-theme-switch-text"><?= e($themeSwitchText) ?></span>
                </a>
                <div class="np-theme-menu" id="npThemeMenu">
                    <button class="np-theme-btn" id="npThemeBtn" type="button" aria-haspopup="true" aria-expanded="false" title="外观主题">
                        <span class="np-theme-btn-ico" aria-hidden="true">🌓</span>
                        <span id="npThemeBtnText">外观</span>
                    </button>
                    <div class="np-theme-pop" role="menu">
                        <button class="np-theme-item" type="button" data-theme="light"><span>☀️</span> 浅色</button>
                        <button class="np-theme-item" type="button" data-theme="dark"><span>🌙</span> 深色</button>
                        <button class="np-theme-item" type="button" data-theme="system"><span>🖥️</span> 跟随系统</button>
                        <div style="height:1px;background:var(--np-border);margin:6px 4px;"></div>
                        <button class="np-theme-item" type="button" id="npCompactToggle"><span>📐</span> 紧凑排版：<b id="npCompactState">关</b></button>
                    </div>
                </div>
                <a class="np-btn np-btn-ghost" href="./user/login.php" id="btnLogin">登录</a>
                <a class="np-btn np-btn-ghost" href="./user/register.php" id="btnRegister">注册</a>
                <a class="np-btn np-btn-primary" href="./user/center.php" id="btnUserCenter" style="display:none;">个人中心</a>
                <a class="np-btn np-btn-ghost" href="./admin/index.php" id="btnAdminLink" target="_blank" rel="noopener" style="display:none;">管理后台</a>
            </div>
        </div>
    </header>

    <main class="np-main <?= $wide ? 'np-container-wide' : 'np-container' ?>">
        <?php if ($pageTitle !== ''): ?>
        <div class="np-page-head">
            <h1 class="np-page-title"><?= e($pageTitle) ?></h1>
            <?php if ($subtitle !== ''): ?>
                <p class="np-page-subtitle"><?= e($subtitle) ?></p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
<?php
}

/**
 * 输出页面底部
 *
 * @param array{scripts?:array<int,string>} $options
 */
function render_page_footer(array $options = []): void
{
    $year = date('Y');
    ?>
    </main>

    <footer class="np-footer">
        <div class="np-container">
            <div class="np-footer-links">
                <a href="./agreement.php">用户协议</a>
                <span class="np-dot">·</span>
                <a href="./privacy.php">隐私政策</a>
                <span class="np-dot">·</span>
                <a href="./tools.php">工具箱</a>
                <span class="np-dot">·</span>
                <a href="./ip.php">IP 查询</a>
                <span class="np-dot">·</span>
                <a href="./nat.php">NAT 检测</a>
                <span class="np-dot">·</span>
                <a href="./about.php">关于我们</a>
            </div>
            <div class="np-footer-text" id="footerCustomText"></div>
            <div class="np-footer-meta">
                <span id="footerCopyright">&copy; <?= e($year) ?> <?= e(app_site_name()) ?></span>
                <a class="np-footer-icp" id="footerIcp" href="#" target="_blank" rel="noopener" style="display:none;"></a>
            </div>
            <div class="np-footer-html" id="footerHtmlArea"></div>
        </div>
    </footer>

    <script src="<?= e(asset_url('./js/layout.js')) ?>"></script>
    <script src="<?= e(asset_url('./js/theme.js')) ?>"></script>
    <?php foreach (($options['scripts'] ?? []) as $script): ?>
    <script src="<?= e(asset_url($script)) ?>"></script>
    <?php endforeach; ?>
</body>
</html>
<?php
}
