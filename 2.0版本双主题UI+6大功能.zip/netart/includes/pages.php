<?php
/**
 * 自定义页面内容（用户协议 / 隐私政策）
 *
 * 存储方式：site_settings 表，setting_key = page_agreement / page_privacy
 * 读取流程：数据库内容 → 缺失时回退默认模板 → 输出前做 HTML 白名单净化
 *
 * 这样既满足"内容可自定义修改"，又避免后台写入恶意脚本造成存储型 XSS。
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/default_pages.php';

/**
 * 可管理的页面定义
 *
 * @return array<string,array{key:string,title:string,slug:string,description:string,default:string}>
 */
function page_definitions(): array
{
    return [
        'agreement' => [
            'slug' => 'agreement',
            'key' => 'page_agreement',
            'title' => '用户协议',
            'description' => '用户使用本站服务前需确认的权利义务约定',
            'default' => default_page_agreement(),
        ],
        'privacy' => [
            'slug' => 'privacy',
            'key' => 'page_privacy',
            'title' => '隐私政策',
            'description' => '本站如何收集、使用与保护您的个人信息',
            'default' => default_page_privacy(),
        ],
        'about' => [
            'slug' => 'about',
            'key' => 'page_about',
            'title' => '关于我们',
            'description' => '项目介绍、核心能力、联系方式与致谢',
            'default' => default_page_about(),
        ],
    ];
}

/**
 * 校验 slug 是否合法
 */
function page_exists(string $slug): bool
{
    return isset(page_definitions()[$slug]);
}

/**
 * 读取页面内容（含更新时间）
 *
 * @return array{slug:string,title:string,description:string,content:string,html:string,updated_at:string,is_custom:bool}
 */
function page_get(string $slug): array
{
    $definitions = page_definitions();

    if (!isset($definitions[$slug])) {
        throw new InvalidArgumentException('未知的页面标识：' . $slug);
    }

    $definition = $definitions[$slug];

    $stored = null;
    $updatedAt = '';
    $isCustom = false;

    try {
        $stmt = getDB()->prepare('SELECT setting_value, updated_at FROM site_settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute([$definition['key']]);
        $row = $stmt->fetch();

        if ($row) {
            $stored = (string) $row['setting_value'];
            $updatedAt = (string) ($row['updated_at'] ?? '');
            $isCustom = trim($stored) !== '';
        }
    } catch (Throwable $e) {
        error_log('[pages] 读取页面内容失败: ' . $e->getMessage());
    }

    $content = $isCustom ? $stored : $definition['default'];

    // 纯文本（无 HTML 标签）自动分段，保证排版
    if (strip_tags($content) === $content) {
        $content = page_text_to_html($content);
    }

    return [
        'slug' => $definition['slug'],
        'title' => $definition['title'],
        'description' => $definition['description'],
        'content' => $content,
        'html' => sanitize_page_html($content),
        'updated_at' => $updatedAt,
        'is_custom' => $isCustom,
    ];
}

/**
 * 保存页面内容（后台调用）
 *
 * @return array{ok:bool,message:string}
 */
function page_save(string $slug, string $content): array
{
    $definitions = page_definitions();

    if (!isset($definitions[$slug])) {
        return ['ok' => false, 'message' => '未知的页面标识'];
    }

    $key = $definitions[$slug]['key'];
    $clean = sanitize_page_html($content);

    if (trim(strip_tags($clean)) === '' && trim($content) !== '') {
        return ['ok' => false, 'message' => '内容为空或包含不受支持的标签'];
    }

    try {
        $sql = 'INSERT INTO site_settings (setting_key, setting_value, setting_type, title, description, group_name, sort_order)
                VALUES (:key, :value, \'text\', :title, :description, \'pages\', :sort)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()';

        getDB()->prepare($sql)->execute([
            ':key' => $key,
            ':value' => $clean,
            ':title' => $definitions[$slug]['title'] . '内容',
            ':description' => $definitions[$slug]['description'],
            ':sort' => $slug === 'agreement' ? 1 : 2,
        ]);

        return ['ok' => true, 'message' => '保存成功'];
    } catch (Throwable $e) {
        error_log('[pages] 保存页面内容失败: ' . $e->getMessage());

        return ['ok' => false, 'message' => '保存失败：' . $e->getMessage()];
    }
}

/**
 * 恢复默认内容
 */
function page_reset(string $slug): array
{
    $definitions = page_definitions();

    if (!isset($definitions[$slug])) {
        return ['ok' => false, 'message' => '未知的页面标识'];
    }

    try {
        $stmt = getDB()->prepare('DELETE FROM site_settings WHERE setting_key = ?');
        $stmt->execute([$definitions[$slug]['key']]);

        return ['ok' => true, 'message' => '已恢复为默认内容'];
    } catch (Throwable $e) {
        error_log('[pages] 恢复默认内容失败: ' . $e->getMessage());

        return ['ok' => false, 'message' => '恢复失败：' . $e->getMessage()];
    }
}

/**
 * 提取正文中的 h2 标题，用于生成目录
 *
 * @return array<int,array{id:string,text:string}>
 */
function page_toc(string $html): array
{
    $toc = [];

    if (preg_match_all('/<h2[^>]*>(.*?)<\/h2>/is', $html, $matches)) {
        foreach ($matches[1] as $index => $text) {
            $plain = trim(strip_tags($text));
            if ($plain === '') {
                continue;
            }
            $toc[] = [
                'id' => 'section-' . ($index + 1),
                'text' => $plain,
            ];
        }
    }

    return $toc;
}

/**
 * 给正文中的 h2 增加锚点 id
 */
function page_with_anchors(string $html): string
{
    $index = 0;

    return preg_replace_callback('/<h2([^>]*)>/i', static function (array $m) use (&$index): string {
        $index++;
        $attrs = $m[1];
        if (strpos($attrs, 'id=') !== false) {
            return '<h2' . $attrs . '>';
        }

        return '<h2' . $attrs . ' id="section-' . $index . '">';
    }, $html) ?? $html;
}
