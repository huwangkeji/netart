<?php
/**
 * 公共页底部（与首页/排行榜共用，支持后台自定义内容）
 * 容器 id 与 app.js 的 loadFooterSettings() 渲染逻辑保持一致。
 */
?>
    <!-- 公共底部（支持自定义） -->
    <footer class="footer footer-public" id="publicFooter">
        <div class="footer-inner">
            <div class="footer-custom-text" id="footerCustomText"></div>
            <div class="footer-links" style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;margin-bottom:8px;font-size:13px;">
                <a href="./agreement.php" style="color:var(--text-info);text-decoration:none;">用户协议</a>
                <a href="./privacy.php" style="color:var(--text-info);text-decoration:none;">隐私政策</a>
                <a href="./tools.php" style="color:var(--text-info);text-decoration:none;">工具箱</a>
                <a href="./ip.php" style="color:var(--text-info);text-decoration:none;">IP 查询</a>
            </div>
            <div class="footer-bottom-row">
                <span class="footer-copyright" id="footerCopyright">&copy; 2026 NetArt 网络测速系统</span>
                <span class="footer-divider" id="footerDivider">|</span>
                <a class="footer-icp" id="footerIcp" href="#" target="_blank"></a>
            </div>
            <div class="footer-html-area" id="footerHtmlArea"></div>
        </div>
    </footer>
