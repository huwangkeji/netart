<?php
/**
 * IP / 域名归属查询服务
 *
 * 设计要点：
 *  1. 支持 IPv4、IPv6 与域名（自动解析 A/AAAA 记录）；
 *  2. 内网/保留地址直接返回本地结论，不再请求外部接口；
 *  3. 结果写入 ip_cache 缓存 24 小时，SQL 兼容 MySQL 5.7（不使用 8.0.19+ 的别名语法）；
 *  4. 多数据源回退，任一源可用即可返回结果；
 *  5. 输出结构保持与首页 (js/app.js) 既有契约一致，避免改动首页逻辑。
 */

declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

/** 缓存有效期（秒） */
function ip_cache_ttl(): int
{
    return 86400;
}

/**
 * 规范化查询目标：支持 IP、域名、带协议或端口的 URL
 *
 * @return array{type:string,value:string,host:string}
 */
function ip_normalize_target(string $input): array
{
    $input = trim($input);

    // 去掉协议
    $input = preg_replace('#^[a-zA-Z][a-zA-Z0-9+.-]*://#', '', $input) ?? $input;
    // 去掉路径与查询串
    $input = preg_replace('#[/?\#].*$#', '', $input) ?? $input;
    // 去掉端口（仅对 host:port 形式，避免误伤 IPv6）
    if (preg_match('/^\[(.+)\](:\d+)?$/', $input, $m)) {
        $input = $m[1];
    } elseif (substr_count($input, ':') === 1) {
        $input = explode(':', $input)[0];
    }
    $input = trim($input, " \t\n\r\0\x0B[]");

    if (filter_var($input, FILTER_VALIDATE_IP)) {
        return ['type' => 'ip', 'value' => $input, 'host' => $input];
    }

    return ['type' => 'domain', 'value' => $input, 'host' => $input];
}

/**
 * 域名解析（优先 A 记录，其次 AAAA）
 *
 * @return array{ip:string,error:string}
 */
function ip_resolve_domain(string $domain): array
{
    if (!preg_match('/^(?=.{1,253}$)([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/', $domain)) {
        return ['ip' => '', 'error' => '域名格式不正确'];
    }

    $records = @dns_get_record($domain, DNS_A | DNS_AAAA);
    if (!is_array($records) || $records === []) {
        $fallback = @gethostbyname($domain);
        if ($fallback && $fallback !== $domain && filter_var($fallback, FILTER_VALIDATE_IP)) {
            return ['ip' => $fallback, 'error' => ''];
        }

        return ['ip' => '', 'error' => '域名解析失败，请检查域名是否正确'];
    }

    foreach ($records as $record) {
        foreach (['ip', 'ipv6'] as $key) {
            if (!empty($record[$key]) && filter_var($record[$key], FILTER_VALIDATE_IP)) {
                return ['ip' => $record[$key], 'error' => ''];
            }
        }
    }

    return ['ip' => '', 'error' => '未解析到有效的 IP 记录'];
}

/**
 * 读取缓存
 */
function ip_cache_get(string $ip): ?array
{
    try {
        $stmt = getDB()->prepare('SELECT * FROM ip_cache WHERE `ip` = ? LIMIT 1');
        $stmt->execute([$ip]);
        $row = $stmt->fetch();

        if (!$row) {
            return null;
        }

        $age = time() - strtotime((string) ($row['cached_at'] ?? '1970-01-01'));

        return ['row' => $row, 'fresh' => $age < ip_cache_ttl()];
    } catch (Throwable $e) {
        error_log('[ip_service] 读取缓存失败: ' . $e->getMessage());

        return null;
    }
}

/**
 * 写入缓存（MySQL 5.7 兼容 UPSERT）
 */
function ip_cache_put(array $data): void
{
    try {
        $sql = 'INSERT INTO ip_cache
                    (`ip`, `country_code`, `country_name`, `registered_country_code`, `registered_country_name`,
                     `regions`, `regions_short`, `asn_number`, `asn_name`, `asn_info`, `type`, `addr`, `cached_at`)
                VALUES (:ip, :country_code, :country_name, :registered_country_code, :registered_country_name,
                        :regions, :regions_short, :asn_number, :asn_name, :asn_info, :type, :addr, NOW())
                ON DUPLICATE KEY UPDATE
                    `country_code` = VALUES(`country_code`),
                    `country_name` = VALUES(`country_name`),
                    `registered_country_code` = VALUES(`registered_country_code`),
                    `registered_country_name` = VALUES(`registered_country_name`),
                    `regions` = VALUES(`regions`),
                    `regions_short` = VALUES(`regions_short`),
                    `asn_number` = VALUES(`asn_number`),
                    `asn_name` = VALUES(`asn_name`),
                    `asn_info` = VALUES(`asn_info`),
                    `type` = VALUES(`type`),
                    `addr` = VALUES(`addr`),
                    `cached_at` = NOW()';

        getDB()->prepare($sql)->execute([
            ':ip' => $data['ip'],
            ':country_code' => $data['country_code'],
            ':country_name' => $data['country_name'],
            ':registered_country_code' => $data['registered_country_code'],
            ':registered_country_name' => $data['registered_country_name'],
            ':regions' => $data['regions'],
            ':regions_short' => $data['regions_short'],
            ':asn_number' => $data['asn_number'],
            ':asn_name' => $data['asn_name'],
            ':asn_info' => $data['asn_info'],
            ':type' => $data['type'],
            ':addr' => $data['addr'],
        ]);
    } catch (Throwable $e) {
        error_log('[ip_service] 写入缓存失败: ' . $e->getMessage());
    }
}

/**
 * 统一结果结构
 */
function ip_result_shape(array $overrides = []): array
{
    $base = [
        'ip' => '',
        'type' => 'IPv4',
        'country' => ['code' => '', 'name' => ''],
        'registered_country' => ['code' => '', 'name' => ''],
        'regions' => [],
        'regions_short' => [],
        'as' => ['number' => 0, 'name' => '', 'info' => ''],
        'addr' => '',
        'isp' => '',
        'location' => '',
        'query' => '',
        'resolved_from' => '',
        'private' => false,
        'source' => '',
        'cached' => false,
    ];

    return array_replace_recursive($base, $overrides);
}

/**
 * 内网 / 保留地址结果
 */
function ip_private_result(string $ip): array
{
    return ip_result_shape([
        'ip' => $ip,
        'type' => strpos($ip, ':') !== false ? 'IPv6' : 'IPv4',
        'country' => ['code' => 'LAN', 'name' => '局域网'],
        'registered_country' => ['code' => 'LAN', 'name' => '局域网'],
        'regions' => ['内网地址'],
        'regions_short' => ['内网'],
        'as' => ['number' => 0, 'name' => '私有网络', 'info' => 'Private Network'],
        'addr' => '内网地址',
        'isp' => '私有网络',
        'location' => '内网地址（局域网 / 本机）',
        'private' => true,
        'source' => 'local',
    ]);
}

/**
 * 数据源：ip9.com.cn（项目原有接口，免费，配合缓存使用）
 */
function ip_source_ip9(string $ip): ?array
{
    $data = http_get_json(IP_QUERY_API . '?ip=' . rawurlencode($ip), 8);
    if (!$data) {
        return null;
    }

    // 兼容多种返回结构：{ret:200,data:{...}} 或 {code:0,data:{...}}
    $ok = (int) ($data['ret'] ?? $data['code'] ?? 0);
    $payload = $data['data'] ?? null;
    if ((!is_array($payload) || $payload === []) || !in_array($ok, [200, 0], true)) {
        return null;
    }

    $regions = array_values(array_filter([
        $payload['prov'] ?? '',
        $payload['city'] ?? '',
        $payload['area'] ?? '',
    ], static function ($v) {
        return (string) $v !== '';
    }));

    $country = (string) ($payload['country'] ?? '');
    $asnName = (string) ($payload['isp'] ?? '');

    return [
        'ip' => (string) ($payload['ip'] ?? $ip),
        'country_code' => strtoupper((string) ($payload['country_code'] ?? '')),
        'country_name' => $country,
        'regions' => $regions,
        'regions_short' => array_values(array_filter([$payload['prov'] ?? '', $payload['city'] ?? ''])),
        'asn_number' => (int) preg_replace('/\D/', '', (string) ($payload['ip_asn'] ?? '')),
        'asn_name' => $asnName,
        'asn_info' => $asnName,
    ];
}

/**
 * 数据源：ipapi.co（HTTPS，免费额度足够个人站点）
 */
function ip_source_ipapi(string $ip): ?array
{
    $data = http_get_json('https://ipapi.co/' . rawurlencode($ip) . '/json/', 8);
    if (!$data || !empty($data['error'])) {
        return null;
    }

    $regions = array_values(array_filter([
        $data['region'] ?? '',
        $data['city'] ?? '',
    ], static function ($v) {
        return (string) $v !== '';
    }));

    $asnName = (string) ($data['org'] ?? '');

    return [
        'ip' => (string) ($data['ip'] ?? $ip),
        'country_code' => strtoupper((string) ($data['country_code'] ?? '')),
        'country_name' => (string) ($data['country_name'] ?? ''),
        'regions' => $regions,
        'regions_short' => $regions,
        'asn_number' => (int) preg_replace('/\D/', '', (string) ($data['asn'] ?? '')),
        'asn_name' => $asnName,
        'asn_info' => $asnName,
    ];
}

/**
 * 数据源兜底：ip-api.com（免费版仅 HTTP）
 */
function ip_source_ip_api_com(string $ip): ?array
{
    $data = http_get_json('http://ip-api.com/json/' . rawurlencode($ip) . '?fields=status,message,country,countryCode,regionName,city,isp,as,query', 8);
    if (!$data || ($data['status'] ?? '') !== 'success') {
        return null;
    }

    $regions = array_values(array_filter([
        $data['regionName'] ?? '',
        $data['city'] ?? '',
    ], static function ($v) {
        return (string) $v !== '';
    }));

    $asnRaw = (string) ($data['as'] ?? '');
    $asnNumber = 0;
    if (preg_match('/AS(\d+)/i', $asnRaw, $m)) {
        $asnNumber = (int) $m[1];
    }
    $asnName = trim((string) preg_replace('/^AS\d+\s*/i', '', $asnRaw));

    return [
        'ip' => (string) ($data['query'] ?? $ip),
        'country_code' => strtoupper((string) ($data['countryCode'] ?? '')),
        'country_name' => (string) ($data['country'] ?? ''),
        'regions' => $regions,
        'regions_short' => $regions,
        'asn_number' => $asnNumber,
        'asn_name' => $asnName !== '' ? $asnName : (string) ($data['isp'] ?? ''),
        'asn_info' => (string) ($data['isp'] ?? ''),
    ];
}

/* ============================================================
 * 新增数据源（可在后台自由切换生效源）
 * ============================================================ */

/**
 * 可用 IP 归属数据源注册表
 *
 * 顺序即「回退优先级」：ip_source_active 指定的源优先，其余按本表顺序兜底，
 * 确保新增供应商不影响既有数据源的正常使用。
 *
 * @return array<string,array{fn:string,name:string,endpoint:string,needs_token:bool,desc:string}>
 */
function ip_source_registry(): array
{
    return [
        'ip9'        => [
            'fn' => 'ip_source_ip9',
            'name' => 'IP9（ip9.com.cn）',
            'endpoint' => IP_QUERY_API,
            'needs_token' => false,
            'desc' => '国内免费接口，返回省份/城市/运营商',
        ],
        'ipapi'      => [
            'fn' => 'ip_source_ipapi',
            'name' => 'ipapi.co',
            'endpoint' => 'https://ipapi.co/{ip}/json/',
            'needs_token' => false,
            'desc' => '海外免费接口，HTTPS',
        ],
        'ip_api_com' => [
            'fn' => 'ip_source_ip_api_com',
            'name' => 'ip-api.com',
            'endpoint' => 'http://ip-api.com/json/{ip}',
            'needs_token' => false,
            'desc' => '免费版仅 HTTP',
        ],
        'uapis'      => [
            'fn' => 'ip_source_uapis',
            'name' => 'UAPIS（uapis.cn）',
            'endpoint' => 'https://uapis.cn/api/v1/network/ipinfo',
            'needs_token' => true,
            'desc' => '需 Bearer Token 鉴权，Token 由后台配置，不硬编码',
        ],
        'xxapi'      => [
            'fn' => 'ip_source_xxapi',
            'name' => 'XXAPI（xxapi.cn）',
            'endpoint' => 'https://v2.xxapi.cn/api/ip',
            'needs_token' => false,
            'desc' => '国内免费接口，返回地址 + 运营商',
        ],
    ];
}

/**
 * 常见国家中文名 → ISO 3166-1 alpha-2 代码
 */
function ip_country_name_to_code(string $name): string
{
    $map = [
        '中国' => 'CN', '中国香港' => 'HK', '中国台湾' => 'TW', '中国澳门' => 'MO',
        '香港' => 'HK', '台湾' => 'TW', '澳门' => 'MO',
        '美国' => 'US', '日本' => 'JP', '韩国' => 'KR', '朝鲜' => 'KP', '蒙古' => 'MN',
        '英国' => 'GB', '德国' => 'DE', '法国' => 'FR', '意大利' => 'IT', '西班牙' => 'ES',
        '荷兰' => 'NL', '瑞典' => 'SE', '瑞士' => 'CH', '波兰' => 'PL', '俄罗斯' => 'RU',
        '乌克兰' => 'UA', '加拿大' => 'CA', '澳大利亚' => 'AU', '新西兰' => 'NZ', '印度' => 'IN',
        '巴基斯坦' => 'PK', '孟加拉国' => 'BD', '新加坡' => 'SG', '马来西亚' => 'MY', '泰国' => 'TH',
        '越南' => 'VN', '菲律宾' => 'PH', '印度尼西亚' => 'ID', '缅甸' => 'MM', '柬埔寨' => 'KH',
        '老挝' => 'LA', '土耳其' => 'TR', '巴西' => 'BR', '墨西哥' => 'MX', '南非' => 'ZA',
        '埃及' => 'EG', '沙特阿拉伯' => 'SA', '阿联酋' => 'AE', '伊朗' => 'IR', '以色列' => 'IL',
        '尼日利亚' => 'NG', '肯尼亚' => 'KE', '阿根廷' => 'AR', '智利' => 'CL', '哥伦比亚' => 'CO',
        '比利时' => 'BE', '奥地利' => 'AT', '挪威' => 'NO', '丹麦' => 'DK', '芬兰' => 'FI',
        '葡萄牙' => 'PT', '希腊' => 'GR', '爱尔兰' => 'IE', '捷克' => 'CZ', '匈牙利' => 'HU',
    ];

    return $map[trim($name)] ?? '';
}

/**
 * 解析中文组合地址（如 "中国浙江省" / "中国浙江温州" / "中国浙江省杭州市"）
 *
 * @return array{0:string,1:array<int,string}  [国家名, [省, 市, ...]]
 */
function ip_parse_cn_address(string $address): array
{
    $address = trim((string) $address);
    if ($address === '') {
        return ['', []];
    }

    $country = '';
    if (mb_strpos($address, '中国') === 0) {
        $country = '中国';
        $address = mb_substr($address, 2);
    } elseif (in_array($address, ['香港', '台湾', '澳门', '美国', '日本', '韩国', '英国', '德国',
        '法国', '新加坡', '俄罗斯', '加拿大', '澳大利亚', '印度', '巴西', '泰国', '越南',
        '马来西亚', '印度尼西亚', '土耳其', '墨西哥', '南非', '荷兰', '意大利', '西班牙',
        '瑞士', '波兰', '乌克兰', '埃及', '沙特阿拉伯', '阿联酋', '伊朗'], true)) {
        $country = $address;
        $address = '';
    }

    $regions = [];
    if ($address !== '') {
        // 优先按省级（省/自治区/特别行政区）切出第一级
        if (preg_match('/^(.+?(?:省|自治区|特别行政区))/u', $address, $m)) {
            $regions[] = $m[1];
            $rest = mb_substr($address, mb_strlen($m[1]));
            // 再按市级切出第二级
            if (preg_match('/^(.+?市)/u', $rest, $m2)) {
                $regions[] = $m2[1];
                $rest = mb_substr($rest, mb_strlen($m2[1]));
            }
            if ($rest !== '') {
                $regions[] = $rest;
            }
        } else {
            // 无省后缀（如「浙江温州」「杭州市」），整体作为一个地区
            $regions[] = $address;
        }
    }

    return [$country, array_values(array_filter($regions, static function ($v) {
        return $v !== '';
    }))];
}

/**
 * 数据源：uapis.cn（Bearer Token 鉴权，token 由后台配置，不硬编码）
 *
 * GET /api/v1/network/ipinfo?ip=<ip>
 * 响应示例：{ip:"8.8.8.8", region:"美国", isp:"GOOGLE", llc:"GOOGLE", asn:"AS15169", latitude, longitude, beginip, endip}
 *
 * @param string|null $tokenOverride 测试时可由调用方传入，避免未保存即测试
 */
function ip_source_uapis(string $ip, ?string $tokenOverride = null): ?array
{
    $token = $tokenOverride ?? (string) app_setting('ip_source_uapis_token', '');
    if ($token === '') {
        return null; // 未配置 Token 时直接跳过，交由其它源兜底
    }

    $url = 'https://uapis.cn/api/v1/network/ipinfo?ip=' . rawurlencode($ip);
    $data = http_get_json_with_headers($url, [
        'Authorization: Bearer ' . $token,
        'Accept: application/json',
    ], 8);
    if (!$data) {
        return null;
    }

    // 失败标识：error 字段、缺 ip、或返回非预期结构
    if (!empty($data['error']) || empty($data['ip'])) {
        return null;
    }

    $countryName = (string) ($data['region'] ?? '');
    $asnRaw = (string) ($data['asn'] ?? '');
    $asnNumber = 0;
    if (preg_match('/AS(\d+)/i', $asnRaw, $m)) {
        $asnNumber = (int) $m[1];
    }
    $isp = (string) ($data['isp'] ?? $data['llc'] ?? '');

    $addrParts = array_values(array_filter([$countryName, $isp], static function ($v) {
        return (string) $v !== '';
    }));

    return [
        'ip' => (string) ($data['ip'] ?? $ip),
        'country_code' => ip_country_name_to_code($countryName),
        'country_name' => $countryName,
        'regions' => [],
        'regions_short' => [],
        'asn_number' => $asnNumber,
        'asn_name' => $isp,
        'asn_info' => $isp,
        'addr' => implode(' ', $addrParts),
    ];
}

/**
 * 数据源：xxapi.cn（国内免费接口）
 *
 * GET https://v2.xxapi.cn/api/ip?ip=<ip>
 * 响应示例：{code:200, msg:"数据请求成功", data:{address:"中国浙江省", ip:"x", isp:"数据中心", lat, lng}, request_id}
 */
function ip_source_xxapi(string $ip): ?array
{
    $data = http_get_json('https://v2.xxapi.cn/api/ip?ip=' . rawurlencode($ip), 8);
    if (!$data || (int) ($data['code'] ?? 0) !== 200) {
        return null;
    }
    $payload = $data['data'] ?? null;
    if (!is_array($payload) || empty($payload['ip'])) {
        return null;
    }

    $address = (string) ($payload['address'] ?? '');
    $isp = (string) ($payload['isp'] ?? '');
    [$countryName, $regions] = ip_parse_cn_address($address);

    $addrParts = array_values(array_filter([
        $countryName !== '' ? $countryName : '',
        implode(' ', $regions),
        $isp,
    ], static function ($v) {
        return (string) $v !== '';
    }));

    return [
        'ip' => (string) ($payload['ip'] ?? $ip),
        'country_code' => $countryName !== '' ? 'CN' : '',
        'country_name' => $countryName,
        'regions' => $regions,
        'regions_short' => $regions,
        'asn_number' => 0,
        'asn_name' => $isp,
        'asn_info' => $isp,
        'addr' => implode(' ', $addrParts),
    ];
}

/**
 * 汇总数据源结果（优先使用后台配置的生效源，其余按注册表顺序兜底）
 */
function ip_fetch_remote(string $ip, ?string $preferred = null): ?array
{
    $registry = ip_source_registry();
    $order = [];

    // 1. 优先使用前端指定的源（下拉切换）或后台配置的生效源
    $active = ($preferred !== null && $preferred !== '' && isset($registry[$preferred]))
        ? $preferred
        : (string) app_setting('ip_source_active', 'ip9');
    if (isset($registry[$active]) && function_exists($registry[$active]['fn'])) {
        $order[] = $active;
    }

    // 2. 其余源按注册表顺序兜底（不重复），确保新增供应商不影响既有源
    foreach (array_keys($registry) as $id) {
        if (!in_array($id, $order, true) && function_exists($registry[$id]['fn'])) {
            $order[] = $id;
        }
    }

    foreach ($order as $id) {
        $fn = $registry[$id]['fn'];
        $result = $fn($ip);
        if (is_array($result) && ($result['country_name'] !== '' || $result['regions'] !== [] || $result['asn_name'] !== '')) {
            $result['_source'] = $id;

            return $result;
        }
    }

    return null;
}

/**
 * IP / 域名归属查询主入口
 *
 * @param string $target IP 或域名，留空则查询客户端本机
 * @return array{status:int,message:string,data:array}
 */
function ip_lookup(string $target = '', ?string $sourceOverride = null): array
{
    $target = trim($target);
    $normalized = ip_normalize_target($target);
    $resolvedFrom = '';
    $queryLabel = $normalized['value'];

    // 1. 域名解析
    if ($normalized['type'] === 'domain') {
        if ($normalized['value'] === '') {
            $ip = request_ip();
        } else {
            $resolved = ip_resolve_domain($normalized['value']);
            if ($resolved['ip'] === '') {
                return [
                    'status' => 1,
                    'message' => $resolved['error'] ?: '域名解析失败',
                    'data' => null,
                ];
            }
            $ip = $resolved['ip'];
            $resolvedFrom = $normalized['value'];
        }
    } else {
        $ip = $normalized['value'];
    }

    if ($ip === '') {
        $ip = request_ip();
    }

    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return [
            'status' => 1,
            'message' => '请输入有效的 IP 地址或域名',
            'data' => null,
        ];
    }

    // 2. 内网地址直接返回
    if (is_private_ip($ip)) {
        $result = ip_private_result($ip);
        $result['query'] = $queryLabel;
        $result['resolved_from'] = $resolvedFrom;

        return ['status' => 0, 'message' => 'ok', 'data' => $result];
    }

    // 3. 读取缓存（指定源覆盖时跳过，确保切换到所选源实时查询）
    $cache = $sourceOverride === null ? ip_cache_get($ip) : null;
    if ($sourceOverride === null && $cache && $cache['fresh']) {
        $row = $cache['row'];
        $result = ip_result_shape([
            'ip' => (string) $row['ip'],
            'type' => (string) $row['type'],
            'country' => ['code' => (string) $row['country_code'], 'name' => (string) $row['country_name']],
            'registered_country' => [
                'code' => (string) $row['registered_country_code'],
                'name' => (string) $row['registered_country_name'],
            ],
            'regions' => json_decode((string) ($row['regions'] ?? '[]'), true) ?: [],
            'regions_short' => json_decode((string) ($row['regions_short'] ?? '[]'), true) ?: [],
            'as' => [
                'number' => (int) $row['asn_number'],
                'name' => (string) $row['asn_name'],
                'info' => (string) $row['asn_info'],
            ],
            'addr' => (string) $row['addr'],
            'isp' => (string) $row['asn_name'],
            'location' => (string) $row['addr'],
            'query' => $queryLabel,
            'resolved_from' => $resolvedFrom,
            'source' => 'cache',
            'cached' => true,
        ]);

        return ['status' => 0, 'message' => 'ok', 'data' => $result];
    }

    // 4. 远程查询
    $remote = ip_fetch_remote($ip);

    if ($remote === null) {
        // 接口全部不可用时，回退到过期缓存（若有）
        if ($cache) {
            $row = $cache['row'];
            $result = ip_result_shape([
                'ip' => (string) $row['ip'],
                'country' => ['code' => (string) $row['country_code'], 'name' => (string) $row['country_name']],
                'regions' => json_decode((string) ($row['regions'] ?? '[]'), true) ?: [],
                'regions_short' => json_decode((string) ($row['regions_short'] ?? '[]'), true) ?: [],
                'as' => ['number' => (int) $row['asn_number'], 'name' => (string) $row['asn_name'], 'info' => (string) $row['asn_info']],
                'addr' => (string) $row['addr'],
                'location' => (string) $row['addr'],
                'query' => $queryLabel,
                'resolved_from' => $resolvedFrom,
                'source' => 'stale-cache',
                'cached' => true,
            ]);

            return ['status' => 0, 'message' => 'ok（外部接口暂不可用，返回缓存数据）', 'data' => $result];
        }

        return [
            'status' => 1,
            'message' => '归属查询服务暂时不可用，请稍后重试',
            'data' => null,
        ];
    }

    $regions = $remote['regions'] ?? [];
    $addrParts = array_values(array_filter(array_merge(
        [$remote['country_name'] ?? ''],
        $regions
    ), static function ($v) {
        return (string) $v !== '';
    }));

    $result = ip_result_shape([
        'ip' => (string) ($remote['ip'] ?: $ip),
        'type' => strpos($ip, ':') !== false ? 'IPv6' : 'IPv4',
        'country' => ['code' => (string) $remote['country_code'], 'name' => (string) $remote['country_name']],
        'registered_country' => ['code' => (string) $remote['country_code'], 'name' => (string) $remote['country_name']],
        'regions' => $regions,
        'regions_short' => $remote['regions_short'] ?? $regions,
        'as' => [
            'number' => (int) ($remote['asn_number'] ?? 0),
            'name' => (string) ($remote['asn_name'] ?? ''),
            'info' => (string) ($remote['asn_info'] ?? $remote['asn_name'] ?? ''),
        ],
        'addr' => implode(' ', $addrParts),
        'isp' => (string) ($remote['asn_info'] ?? $remote['asn_name'] ?? ''),
        'location' => implode(' ', $addrParts),
        'query' => $queryLabel,
        'resolved_from' => $resolvedFrom,
        'source' => (string) ($remote['_source'] ?? 'remote'),
    ]);

    // 5. 写缓存（指定源覆盖时不写，避免污染默认缓存）
    if ($sourceOverride === null) {
        ip_cache_put([
            'ip' => $ip,
            'country_code' => $result['country']['code'],
            'country_name' => $result['country']['name'],
            'registered_country_code' => $result['country']['code'],
            'registered_country_name' => $result['country']['name'],
            'regions' => json_encode($result['regions'], JSON_UNESCAPED_UNICODE),
            'regions_short' => json_encode($result['regions_short'], JSON_UNESCAPED_UNICODE),
            'asn_number' => $result['as']['number'],
            'asn_name' => $result['as']['name'],
            'asn_info' => $result['as']['info'],
            'type' => $result['type'],
            'addr' => $result['addr'],
        ]);
    }

    return ['status' => 0, 'message' => 'ok', 'data' => $result];
}

/* ============================================================
 * 进阶能力（多地一致性 / CDN 检测 / 延迟探测 / 多解析器 DNS）
 * ============================================================ */

/**
 * 同时向所有数据源发起查询并汇总（用于多地一致性对比 / 供应商探测）
 *
 * @return array<string,array|null>
 */
function ip_fetch_all_sources(string $ip): array
{
    $registry = ip_source_registry();
    $out = [];

    foreach ($registry as $key => $meta) {
        $fn = $meta['fn'];
        if (!function_exists($fn)) {
            $out[$key] = null;
            continue;
        }
        try {
            $r = $fn($ip);
        } catch (Throwable $e) {
            $r = null;
        }
        if (is_array($r)) {
            $r['_source'] = $key;
            $out[$key] = $r;
        } else {
            $out[$key] = null;
        }
    }

    return $out;
}

/**
 * 多地 IP 归属一致性对比
 *
 * 同时查询多个数据源，对比国家/省份/ASN 是否一致，
 * 差异通常意味着代理 / VPN / Anycast / 多出口。
 *
 * @return array{status:int,message:string,data:?array}
 */
function ip_consistency(string $target = ''): array
{
    $normalized = ip_normalize_target($target);
    $resolvedFrom = '';

    if ($normalized['type'] === 'domain' && $normalized['value'] !== '') {
        $resolved = ip_resolve_domain($normalized['value']);
        if ($resolved['ip'] === '') {
            return ['status' => 1, 'message' => $resolved['error'] ?: '域名解析失败', 'data' => null];
        }
        $ip = $resolved['ip'];
        $resolvedFrom = $normalized['value'];
    } else {
        $ip = $normalized['value'] === '' ? request_ip() : $normalized['value'];
    }

    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        return ['status' => 1, 'message' => '请输入有效的 IP 或域名', 'data' => null];
    }
    if (is_private_ip($ip)) {
        return ['status' => 1, 'message' => '内网/保留地址无需多地对比', 'data' => null];
    }

    $sources = ip_fetch_all_sources($ip);

    $view = [];
    foreach ($sources as $k => $s) {
        if (!$s) {
            continue;
        }
        $view[$k] = [
            'source' => $k,
            'country_code' => strtoupper((string) ($s['country_code'] ?? '')),
            'country_name' => (string) ($s['country_name'] ?? ''),
            'region' => implode(' ', $s['regions'] ?? []),
            'asn_number' => (int) ($s['asn_number'] ?? 0),
            'asn_name' => (string) ($s['asn_name'] ?? ''),
        ];
    }

    if (count($view) < 2) {
        return [
            'status' => 1,
            'message' => '可用数据源不足，无法对比（可能接口暂时不可用）',
            'data' => ['ip' => $ip, 'resolved_from' => $resolvedFrom, 'sources' => array_values($view)],
        ];
    }

    $countries = array_values(array_unique(array_filter(array_column($view, 'country_code'))));
    $asns = array_values(array_unique(array_filter(array_column($view, 'asn_number'))));
    $regionSet = [];
    foreach ($view as $v) {
        if ($v['region'] !== '') {
            $regionSet[$v['region']] = true;
        }
    }

    $consistent = count($countries) <= 1;

    return [
        'status' => 0,
        'message' => 'ok',
        'data' => [
            'ip' => $ip,
            'resolved_from' => $resolvedFrom,
            'sources' => array_values($view),
            'consistent' => $consistent,
            'country_variants' => $countries,
            'asn_variants' => $asns,
            'region_variants' => array_keys($regionSet),
            'note' => $consistent ? '各数据源归属一致' : '数据源之间存在归属差异，可能是代理 / VPN / Anycast / 多出口导致',
        ],
    ];
}

/**
 * CDN / 云厂商 / 运营商特征库
 *
 * @return array<int,array{0:string,1:string,2:string,3:?string}>
 *         [lowercase 关键字, 厂商名, 类别(CDN/Cloud/ISP/Hosting), 官网]
 */
function ip_cdn_vendors(): array
{
    return [
        ['cloudflare', 'Cloudflare', 'CDN', 'https://www.cloudflare.com'],
        ['akamai', 'Akamai', 'CDN', null],
        ['fastly', 'Fastly', 'CDN', null],
        ['cloudfront', 'Amazon CloudFront', 'CDN', null],
        ['amazon', 'Amazon AWS', 'Cloud', null],
        ['alibaba', '阿里云 (Alibaba Cloud)', 'Cloud/CDN', null],
        ['aliyun', '阿里云 CDN', 'CDN', null],
        ['tencent', '腾讯云 (Tencent Cloud)', 'Cloud/CDN', null],
        ['edgeone', '腾讯 EdgeOne', 'CDN', null],
        ['baidu', '百度云加速', 'CDN', null],
        ['huawei', '华为云', 'Cloud/CDN', null],
        ['wangsu', '网宿科技 (Wangsu)', 'CDN', null],
        ['chinacache', '蓝汛 ChinaCache', 'CDN', null],
        ['qiniu', '七牛云', 'CDN', null],
        ['ucloud', 'UCloud', 'Cloud', null],
        ['baishan', '白山云 (Baishan)', 'CDN', null],
        ['dnion', '帝联科技 (Dnion)', 'CDN', null],
        ['jd', '京东云', 'Cloud/CDN', null],
        ['volcengine', '火山引擎 (ByteDance)', 'Cloud/CDN', null],
        ['bytedance', '字节跳动', 'Cloud/CDN', null],
        ['kwai', '快手云', 'Cloud/CDN', null],
        ['upai', '又拍云 (UPYUN)', 'CDN', null],
        ['digitalocean', 'DigitalOcean', 'Cloud', null],
        ['linode', 'Linode', 'Cloud', null],
        ['vultr', 'Vultr', 'Cloud', null],
        ['google', 'Google Cloud', 'Cloud', null],
        ['microsoft', 'Microsoft Azure', 'Cloud', null],
        ['azure', 'Microsoft Azure', 'Cloud', null],
        ['oracle', 'Oracle Cloud', 'Cloud', null],
        ['hetzner', 'Hetzner', 'Cloud', null],
        ['ovh', 'OVH', 'Cloud', null],
        ['chinanet', '中国电信 (China Telecom)', 'ISP', null],
        ['china unicom', '中国联通 (China Unicom)', 'ISP', null],
        ['china mobile', '中国移动 (China Mobile)', 'ISP', null],
        ['cnc', '中国网通', 'ISP', null],
        ['cernet', '教育网 (CERNET)', 'ISP', null],
        ['comcast', 'Comcast', 'ISP', null],
        ['verizon', 'Verizon', 'ISP', null],
        ['at&t', 'AT&T', 'ISP', null],
        ['vodafone', 'Vodafone', 'ISP', null],
        ['ntt', 'NTT Communications', 'ISP', null],
        ['softlayer', 'IBM SoftLayer', 'Cloud', null],
        ['leaseweb', 'Leaseweb', 'Cloud', null],
        ['contabo', 'Contabo', 'Cloud', null],
        ['godaddy', 'GoDaddy', 'Hosting', null],
        ['namecheap', 'Namecheap', 'Hosting', null],
    ];
}

/**
 * 根据 ASN 名称 / 组织推断 CDN / 云厂商 / 运营商
 *
 * 优先按「类别=CDN」排序，确保命中 CDN 时优先返回 CDN 厂商。
 *
 * @return array{detected:bool,vendor:string,category:string,official:?string,evidence:string,all:array}
 */
function ip_detect_cdn(string $asnName, string $asnInfo = '', int $asnNumber = 0): array
{
    $text = strtolower(trim($asnName . ' ' . $asnInfo));
    $matches = [];
    foreach (ip_cdn_vendors() as [$kw, $vendor, $category, $official]) {
        if ($kw !== '' && strpos($text, $kw) !== false) {
            $matches[] = ['vendor' => $vendor, 'category' => $category, 'official' => $official, 'keyword' => $kw];
        }
    }

    // 知名 ASN 编号直接命中（作为兜底）
    $asnMap = [
        13335 => ['Cloudflare', 'CDN'],
        15133 => ['Edgecast/Verizon', 'CDN'],
        16625 => ['Akamai', 'CDN'],
        20940 => ['Akamai', 'CDN'],
        54113 => ['Fastly', 'CDN'],
        16509 => ['Amazon AWS', 'Cloud'],
        14618 => ['Amazon AWS', 'Cloud'],
        15169 => ['Google Cloud', 'Cloud'],
        8075 => ['Microsoft Azure', 'Cloud'],
        37963 => ['阿里云', 'Cloud/CDN'],
        45102 => ['阿里云', 'Cloud/CDN'],
        45090 => ['阿里云', 'Cloud/CDN'],
        132203 => ['腾讯云', 'Cloud/CDN'],
        45062 => ['腾讯云', 'Cloud/CDN'],
        55967 => ['百度', 'CDN'],
        9808 => ['中国移动', 'ISP'],
        4837 => ['中国联通', 'ISP'],
        4809 => ['中国电信', 'ISP'],
        4134 => ['中国电信', 'ISP'],
        14061 => ['DigitalOcean', 'Cloud'],
        36351 => ['SoftLayer', 'Cloud'],
        24940 => ['Hetzner', 'Cloud'],
        16276 => ['OVH', 'Cloud'],
    ];
    if ($asnNumber > 0 && isset($asnMap[$asnNumber]) && $matches === []) {
        $matches[] = ['vendor' => $asnMap[$asnNumber][0], 'category' => $asnMap[$asnNumber][1], 'official' => null, 'keyword' => 'AS' . $asnNumber];
    }

    if ($matches === []) {
        return ['detected' => false, 'vendor' => '', 'category' => '', 'official' => null, 'evidence' => '', 'all' => []];
    }

    usort($matches, static function ($a, $b) {
        return ((int) ($b['category'] === 'CDN')) - ((int) ($a['category'] === 'CDN'));
    });
    $top = $matches[0];

    return [
        'detected' => true,
        'vendor' => $top['vendor'],
        'category' => $top['category'],
        'official' => $top['official'],
        'evidence' => 'AS' . $asnNumber . ' · ' . $asnName,
        'all' => $matches,
    ];
}

/**
 * TCP 连接延迟探测（替代 ICMP ping，沙箱友好）
 *
 * 对目标主机在指定端口上做 TCP 连接，取多次探测的最优/平均耗时，
 * 作为「可达性 + 网络延迟」的近似指标。
 *
 * @param int[] $ports
 * @return array{status:int,message:string,data:?array}
 */
function ip_tcp_latency(string $host, array $ports = [80, 443, 53, 22], int $attempts = 3): array
{
    if (!is_array($ports) || $ports === []) {
        $ports = [80, 443, 53, 22];
    }

    $ip = $host;
    if (!filter_var($host, FILTER_VALIDATE_IP)) {
        $resolved = ip_resolve_domain($host);
        if ($resolved['ip'] === '') {
            return ['status' => 1, 'message' => $resolved['error'] ?: '域名解析失败', 'data' => null];
        }
        $ip = $resolved['ip'];
    }

    $results = [];
    foreach ($ports as $port) {
        $port = (int) $port;
        if ($port <= 0 || $port > 65535) {
            continue;
        }
        $samples = [];
        $ok = 0;
        for ($i = 0; $i < $attempts; $i++) {
            $start = microtime(true);
            $fp = @fsockopen($ip, $port, $errno, $errstr, 2.0);
            $elapsed = (microtime(true) - $start) * 1000;
            if ($fp !== false) {
                fclose($fp);
                $samples[] = round($elapsed, 1);
                $ok++;
            }
        }
        if ($ok === 0) {
            $results[] = ['port' => $port, 'reachable' => false, 'min_ms' => null, 'avg_ms' => null, 'max_ms' => null, 'samples' => []];
        } else {
            sort($samples);
            $results[] = [
                'port' => $port,
                'reachable' => true,
                'min_ms' => $samples[0],
                'avg_ms' => round(array_sum($samples) / count($samples), 1),
                'max_ms' => $samples[count($samples) - 1],
                'samples' => $samples,
            ];
        }
    }

    return ['status' => 0, 'message' => 'ok', 'data' => ['host' => $host, 'ip' => $ip, 'results' => $results]];
}

/**
 * 通过 DNS-over-HTTPS 查询指定域名的记录
 *
 * @return array{resolver:string,ok:bool,error:string,records:string[]}
 */
function ip_doh_query(string $resolverName, string $url, string $domain, string $type = 'A'): array
{
    if (!function_exists('curl_init')) {
        return ['resolver' => $resolverName, 'ok' => false, 'error' => 'curl 扩展未安装', 'records' => []];
    }

    $endpoint = $url . '?name=' . rawurlencode($domain) . '&type=' . rawurlencode($type);
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $endpoint,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 6,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_HTTPHEADER => ['Accept: application/dns-json'],
        CURLOPT_USERAGENT => 'NetworkPanel/1.0 (+https://net.arsn.cn)',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_CAINFO => __DIR__ . '/../config/cacert.pem',
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($body === false) {
        return ['resolver' => $resolverName, 'ok' => false, 'error' => ($err ?: '请求失败'), 'records' => []];
    }

    $data = json_decode((string) $body, true);
    if (!is_array($data)) {
        return ['resolver' => $resolverName, 'ok' => false, 'error' => '响应解析失败', 'records' => []];
    }
    if (!empty($data['Status']) && (int) $data['Status'] !== 0) {
        return ['resolver' => $resolverName, 'ok' => false, 'error' => 'DNS 状态 ' . (int) $data['Status'], 'records' => []];
    }

    $typeId = $type === 'AAAA' ? 28 : 1;
    $records = [];
    foreach (($data['Answer'] ?? []) as $ans) {
        if ((int) ($ans['type'] ?? 0) === $typeId && !empty($ans['data'])) {
            $records[] = (string) $ans['data'];
        }
    }

    return ['resolver' => $resolverName, 'ok' => true, 'error' => '', 'records' => $records];
}

/**
 * 多解析器 DNS 对比（DNS 泄漏 / 分地区解析 / CDN 调度检测）
 *
 * 通过多个公共 DoH 解析器查询同一域名的 A 记录，比较结果是否一致；
 * 同时读取域名的权威 NS 记录（常能直接暴露所用 CDN）。
 *
 * @return array{status:int,message:string,data:?array}
 */
function ip_dns_comparison(string $domain): array
{
    if (!preg_match('/^(?=.{1,253}$)([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/', $domain)) {
        return ['status' => 1, 'message' => '域名格式不正确', 'data' => null];
    }

    $resolvers = [
        'Cloudflare' => 'https://cloudflare-dns.com/dns-query',
        'Google' => 'https://dns.google/resolve',
        'Aliyun' => 'https://dns.alidns.com/resolve',
    ];

    $out = [];
    foreach ($resolvers as $name => $url) {
        $out[] = ip_doh_query($name, $url, $domain, 'A');
    }

    $ns = [];
    $nsRecs = @dns_get_record($domain, DNS_NS);
    if (is_array($nsRecs)) {
        foreach ($nsRecs as $r) {
            if (!empty($r['target'])) {
                $ns[] = $r['target'];
            }
        }
    }

    $sets = [];
    foreach ($out as $r) {
        if ($r['ok']) {
            // 以「记录集合」而非「有序数组」判定一致，忽略返回顺序差异
            $sorted = $r['records'];
            sort($sorted);
            $sets[] = $sorted;
        }
    }
    $consistent = count($sets) >= 2;
    foreach ($sets as $s) {
        $consistent = $consistent && ($s === $sets[0]);
    }

    return [
        'status' => 0,
        'message' => 'ok',
        'data' => [
            'domain' => $domain,
            'resolvers' => $out,
            'ns' => $ns,
            'consistent' => (bool) $consistent,
            'note' => $consistent
                ? '各公共 DNS 返回的 A 记录一致'
                : '不同 DNS 解析结果存在差异（可能启用分地区解析 / CDN / DNS 调度）',
        ],
    ];
}
