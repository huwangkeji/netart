<?php
/**
 * 面板设置
 *
 * 纯 Web/PWA 降级实现：所有开关状态持久化到 localStorage（NPSettings 统一管理），
 * 重启浏览器后生效。其中「开机自动启动」「关闭窗口后台常驻/托盘」属于桌面原生能力，
 * 浏览器无法提供，UI 保留并标注「需桌面客户端」，状态仅作存储，便于将来接入 pywebview 壳。
 */
require_once __DIR__ . '/includes/layout.php';

render_page_header([
    'title'    => '面板设置',
    'subtitle' => '主题、紧凑排版、定时测速与熄屏常亮（配置存于本地，重启后生效）',
    'active'   => 'settings',
    'css'      => ['./css/panel.css', './css/aod.css'],
]);
?>
<main class="np-main np-container">
    <div class="np-settings">

        <!-- 外观 / 主题 -->
        <section class="np-settings-section">
            <h2>外观与主题</h2>
            <p class="np-section-desc">支持浅色 / 深色 / 跟随系统三模式；可开启按时间段自动切换深色。切换无闪烁。</p>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">显示主题</div>
                    <div class="np-row-hint">浅色、深色，或跟随系统</div>
                </div>
                <div class="np-row-control">
                    <select class="np-select" id="setTheme">
                        <option value="light">浅色</option>
                        <option value="dark">深色</option>
                        <option value="system">跟随系统</option>
                    </select>
                </div>
            </div>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">按时间段自动切换深色</div>
                    <div class="np-row-hint">开启后，在指定时间段内强制深色，优先级高于跟随系统</div>
                </div>
                <div class="np-row-control">
                    <label class="np-switch">
                        <input type="checkbox" id="setAutoTime">
                        <span class="np-switch-track"></span><span class="np-switch-knob"></span>
                    </label>
                </div>
            </div>

            <div class="np-row" id="timeRangeRow" style="display:none;">
                <div class="np-row-text">
                    <div class="np-row-title">深色时间段</div>
                    <div class="np-row-hint">起点至终点之间使用深色（支持跨午夜，如 18:00–06:00）</div>
                </div>
                <div class="np-row-control">
                    <input type="time" class="np-num" id="setDarkStart" style="width:110px;">
                    <span>—</span>
                    <input type="time" class="np-num" id="setDarkEnd" style="width:110px;">
                </div>
            </div>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">紧凑排版</div>
                    <div class="np-row-hint">缩减卡片间距、内边距与字号，小窗口不换行、可滚动</div>
                </div>
                <div class="np-row-control">
                    <label class="np-switch">
                        <input type="checkbox" id="setCompact">
                        <span class="np-switch-track"></span><span class="np-switch-knob"></span>
                    </label>
                </div>
            </div>
        </section>

        <!-- 定时自动测速 -->
        <section class="np-settings-section">
            <h2>定时自动测速</h2>
            <p class="np-section-desc">开启后，只要本页面保持打开，将按间隔自动测速；可限定仅联网时执行，并写入本地历史。</p>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">启用定时测速</div>
                    <div class="np-row-hint">页面处于打开状态时生效；浏览器关闭后将停止（浏览器沙箱限制）</div>
                </div>
                <div class="np-row-control">
                    <label class="np-switch">
                        <input type="checkbox" id="setStEnabled">
                        <span class="np-switch-track"></span><span class="np-switch-knob"></span>
                    </label>
                </div>
            </div>

            <div class="np-inline-controls">
                <label>间隔（分钟）
                    <input type="number" class="np-num" id="setStInterval" min="1" max="1440" step="1" value="30">
                </label>
                <label>
                    <input type="checkbox" id="setStOnline"> 仅联网时执行
                </label>
                <label>
                    <input type="checkbox" id="setStHistory"> 写入历史记录
                </label>
                <button class="np-btn" id="btnRunNow">立即测速</button>
                <span id="stStatus" class="np-row-hint"></span>
            </div>

            <div class="np-history-list" id="stHistory">
                <div class="np-empty">暂无测速记录</div>
            </div>
        </section>

        <!-- 熄屏显示 AOD -->
        <section class="np-settings-section">
            <h2>熄屏常亮（AOD）</h2>
            <p class="np-section-desc">开启后，点击「预览」可全屏常亮显示指定信息并使用屏幕常亮锁（Wake Lock）避免息屏。注意：浏览器在屏幕真正关闭/锁屏后不渲染，需桌面客户端方可实现真·熄屏常亮。</p>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">启用 AOD</div>
                    <div class="np-row-hint">启用后可在下方预览；亮度与超时为模拟项</div>
                </div>
                <div class="np-row-control">
                    <label class="np-switch">
                        <input type="checkbox" id="setAodEnabled">
                        <span class="np-switch-track"></span><span class="np-switch-knob"></span>
                    </label>
                </div>
            </div>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">熄灯模式</div>
                    <div class="np-row-hint">网页内全屏：仅覆盖页面区域；整体全屏：覆盖整个浏览器窗口 / 系统屏幕（需浏览器支持 Fullscreen）</div>
                </div>
                <div class="np-row-control">
                    <div class="np-seg" id="setAodMode" role="group" aria-label="熄灯模式">
                        <button type="button" class="np-seg-btn" data-mode="web">网页内全屏</button>
                        <button type="button" class="np-seg-btn" data-mode="whole">整体全屏</button>
                    </div>
                </div>
            </div>
            <p class="np-row-hint" id="aodModeIndicator" style="margin:0 0 8px;">当前模式：网页内全屏</p>

            <div class="np-inline-controls">
                <label>亮度（模拟）<span id="aodBrightVal">60</span>%
                    <input type="range" class="np-range" id="setAodBright" min="10" max="100" step="5" value="60" style="width:180px;">
                </label>
                <label>超时（秒，0=常亮）
                    <input type="number" class="np-num" id="setAodTimeout" min="0" max="3600" step="1" value="0">
                </label>
            </div>

            <div class="np-inline-controls">
                <label><input type="checkbox" id="setAodTime" checked> 时间</label>
                <label><input type="checkbox" id="setAodTraffic" checked> 流量</label>
                <label><input type="checkbox" id="setAodSpeed" checked> 实时速率</label>
                <button class="np-btn np-btn-ghost" id="btnAodPreview">预览 AOD</button>
                <button class="np-btn np-btn-ghost" id="btnAodExit" style="display:none;">退出 AOD</button>
            </div>

            <div class="np-row" style="border-top:1px solid var(--np-border);">
                <div class="np-row-text">
                    <div class="np-row-title">自定义显示内容</div>
                    <div class="np-row-hint">支持纯文本，将展示于 AOD 底部</div>
                </div>
            </div>
            <textarea class="np-num" id="setAodCustom" style="width:100%;height:64px;resize:vertical;font-family:var(--np-font);"
                placeholder="例如：抖音@农村杨小帆· 当前在线"></textarea>
        </section>

        <!-- 桌面端专属（Web 降级） -->
        <section class="np-settings-section">
            <h2>桌面客户端能力（需桌面端）</h2>
            <p class="np-section-desc">以下能力依赖操作系统/桌面外壳，纯浏览器无法提供。开关状态仍会保存，待接入桌面客户端（如 pywebview 壳）后可直接启用。</p>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">开机自动启动</div>
                    <div class="np-row-hint">写入系统启动项 / 注册表（需桌面客户端）</div>
                </div>
                <div class="np-row-control">
                    <label class="np-switch">
                        <input type="checkbox" id="setAutoStart" disabled>
                        <span class="np-switch-track"></span><span class="np-switch-knob"></span>
                    </label>
                    <span class="np-disabled-note">需桌面客户端</span>
                </div>
            </div>

            <div class="np-row">
                <div class="np-row-text">
                    <div class="np-row-title">关闭主窗口后后台常驻（托盘/菜单栏唤出）</div>
                    <div class="np-row-hint">最小化到系统托盘，可再次唤起（需桌面客户端）</div>
                </div>
                <div class="np-row-control">
                    <label class="np-switch">
                        <input type="checkbox" id="setBackground" disabled>
                        <span class="np-switch-track"></span><span class="np-switch-knob"></span>
                    </label>
                    <span class="np-disabled-note">需桌面客户端</span>
                </div>
            </div>
        </section>

        <!-- 存储管理 -->
        <section class="np-settings-section">
            <h2>配置存储</h2>
            <p class="np-section-desc">所有配置存储于浏览器 localStorage（键 np_panel_settings），清空浏览器数据将丢失。</p>
            <div class="np-inline-controls">
                <button class="np-btn np-btn-ghost" id="btnExport">导出配置</button>
                <button class="np-btn np-btn-ghost" id="btnImport">导入配置</button>
                <button class="np-btn" id="btnReset" style="--_bg:var(--np-danger);">恢复默认</button>
                <span id="storeStatus" class="np-row-hint"></span>
            </div>
            <textarea id="cfgJson" class="np-num" style="width:100%;height:120px;margin-top:10px;font-family:var(--np-font-mono);font-size:12px;resize:vertical;" readonly></textarea>
        </section>

    </div>
</main>

<!-- AOD 叠层（结构由 js/aod.js 复用，settings 预览与首页「息屏」共用） -->
<div id="npAod" aria-hidden="true">
    <div class="aod-container">
        <div class="aod-left">
            <div class="aod-brand" id="aodBrand">网络面板</div>
            <div class="aod-time" id="aodTime">--:--</div>
            <div class="aod-date" id="aodDate"></div>
            <div class="aod-device">
                <span id="aodBattery">电量 --%</span>
                <span id="aodRuntime">运行 00s</span>
            </div>
        </div>
        <div class="aod-right">
            <div class="aod-stat"><span>总流量</span><strong id="aodTraffic">—</strong></div>
            <div class="aod-stat"><span>平均速度</span><strong id="aodSpeed">—</strong></div>
            <div class="aod-stat"><span>平均带宽</span><strong id="aodBandwidth">—</strong></div>
        </div>
    </div>
    <div class="aod-custom" id="aodCustom" style="display:none;"></div>
    <div class="aod-hint">点击任意处或按 Esc 退出</div>
</div>

<div class="np-toast" id="npToast"></div>

<?php
render_page_footer([
    'scripts' => ['./js/theme.js', './js/aod.js', './js/settings.js'],
]);
