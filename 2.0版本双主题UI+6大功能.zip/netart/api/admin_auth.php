<?php
/**
 * NetworkPanel - 后台管理认证API
 * 接口:
 *   POST /api/admin_auth.php?action=login    管理员登录
 *   POST /api/admin_auth.php?action=logout   管理员登出
 *   GET  /api/admin_auth.php?action=check    检查登录状态
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type,Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

// 兼容 JSON POST 和普通表单 POST
$action = $_GET['action'] ?? $_POST['action'] ?? '';
if (empty($action) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawInput = file_get_contents('php://input');
    if ($rawInput) {
        $jsonData = json_decode($rawInput, true);
        $action = $jsonData['action'] ?? '';
    }
}

switch ($action) {
    case 'login':  adminLogin();  break;
    case 'logout': adminLogout(); break;
    case 'check':  adminCheck();  break;
    default:       jsonResponse(['status'=>1,'message'=>'无效操作'], 400);
}

function adminLogin(): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $username = trim($input['username'] ?? '');
    $password = $input['password'] ?? '';
    $captcha = trim($input['captcha'] ?? '');

    if (empty($username) || empty($password)) {
        jsonResponse(['status' => 1, 'message' => '请输入账号密码']);
    }

    $db = getDB();
    $stmt = $db->prepare("SELECT id,username,password_hash,nickname,`role`,`status` FROM admins WHERE username=?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        jsonResponse(['status' => 1, 'message' => '账号或密码错误']);
    }
    if ((int)$admin['status'] === 0) {
        jsonResponse(['status' => 1, 'message' => '账号已被禁用']);
    }

    // 更新登录信息
    $ip = getClientIP();
    $stmt = $db->prepare("UPDATE admins SET last_login=NOW(), last_ip=?, login_count=login_count+1 WHERE id=?");
    $stmt->execute([$ip, $admin['id']]);

    session_start();
    $_SESSION['admin_id'] = (int)$admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_nickname'] = $admin['nickname'];
    $_SESSION['admin_role'] = $admin['role'];

    jsonResponse([
        'status' => 0,
        'data' => [
            'id' => (int)$admin['id'],
            'username' => $admin['username'],
            'nickname' => $admin['nickname'],
            'role' => $admin['role'],
        ]
    ]);
}

function adminLogout(): void {
    session_start();
    unset($_SESSION['admin_id'], $_SESSION['admin_username'], $_SESSION['admin_role']);
    session_destroy();
    jsonResponse(['status' => 0]);
}

function adminCheck(): void {
    session_start();
    if (!empty($_SESSION['admin_id'])) {
        jsonResponse([
            'status' => 0,
            'data' => [
                'id' => (int)$_SESSION['admin_id'],
                'username' => $_SESSION['admin_username'] ?? '',
                'nickname' => $_SESSION['admin_nickname'] ?? '',
                'role' => $_SESSION['admin_role'] ?? '',
            ]
        ]);
    } else {
        jsonResponse(['status' => 1, 'message' => '未登录']);
    }
}
