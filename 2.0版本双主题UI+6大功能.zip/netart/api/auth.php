<?php
/**
 * NetworkPanel - 会员认证API
 * 接口:
 *   POST /api/auth.php?action=register   注册
 *   POST /api/auth.php?action=login      登录
 *   GET  /api/auth.php?action=profile    获取当前用户信息
 *   POST /api/auth.php?action=logout     登出
 *   POST /api/auth.php?action=update     修改个人信息
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/site_settings.php';
require_once __DIR__ . '/../includes/UCenter.php';

// ========== 全局异常/错误兜底：确保始终返回JSON而非HTML ==========
set_exception_handler(function (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    error_log('[auth] 未捕获异常: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    echo json_encode(['status' => 1, 'message' => '服务器内部错误，请稍后重试'], JSON_UNESCAPED_UNICODE);
    exit;
});
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) return false;
    throw new ErrorException($errstr, $errno, $errno, $errfile, $errline);
});
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_RECOVERABLE_ERROR])) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        error_log('[auth] PHP致命错误: ' . $error['message'] . ' @ ' . $error['file'] . ':' . $error['line']);
        echo json_encode([
            'status' => 1,
            'message' => '服务器内部错误，请稍后重试'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
});

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type,Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

// 支持从 GET、POST 表单、JSON body 中获取 action
$action = $_GET['action'] ?? $_POST['action'] ?? '';
if (!$action && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawBody = file_get_contents('php://input');
    if ($rawBody) {
        $jsonInput = json_decode($rawBody, true);
        if (is_array($jsonInput)) {
            $action = $jsonInput['action'] ?? '';
        }
    }
}

try {
switch ($action) {
    case 'register': handleRegister(); break;
    case 'login':    handleLogin(); break;
    case 'uc_login': handleUcLogin(); break;
    case 'logout':   handleLogout(); break;
    case 'profile':  handleProfile(); break;
    case 'update':   handleUpdate(); break;
    case 'reset_password': handleResetPassword(); break;
    case 'reset_stat':  handleResetStat(); break;
    case 'refresh_token': handleRefreshToken(); break;
    case 'submit_feedback': handleSubmitFeedback(); break;
    default:         jsonResponse(['status'=>1,'message'=>'无效的操作'], 400);
}
} catch (Exception $e) {
    error_log('[auth] 操作异常: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    jsonResponse(['status' => 1, 'message' => '操作失败，请稍后重试']);
}

// ==================== 注册 ====================
function handleRegister(): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $username = trim($input['username'] ?? '');
    $password = $input['password'] ?? '';
    $email = trim($input['email'] ?? '');

    // 验证是否开放注册
    $db = getDB();
    $regOpen = getSetting($db, 'register_open', '1');
    if ($regOpen !== '1') {
        jsonResponse(['status' => 1, 'message' => '注册已关闭']);
    }

    // 校验
    if (strlen($username) < 2 || strlen($username) > 20 || !preg_match('/^[a-zA-Z0-9_\x{4e00}-\x{9fa5}]+$/u', $username)) {
        jsonResponse(['status' => 1, 'message' => '用户名需为2-20位，支持中英文数字下划线']);
    }
    if (strlen($password) < 6) {
        jsonResponse(['status' => 1, 'message' => '密码至少6位']);
    }
    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['status' => 1, 'message' => '邮箱格式不正确']);
    }

    // 检查重名
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        jsonResponse(['status' => 1, 'message' => '用户名已存在']);
    }

    // 创建用户
    $accessToken = bin2hex(random_bytes(32));
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $db->prepare(
        "INSERT INTO users (`username`,`email`,`password_hash`,`access_token`,`ip`) VALUES (?,?,?,?,?)"
    );
    $stmt->execute([$username, $email, $passwordHash, $accessToken, getClientIP()]);

    $userId = (int)$db->lastInsertId();

    // 同步到 UCenter（未启用或策略关闭则静默跳过）
    $synloginHtml = '';
    if (uc_strategy('uc_sync_register')) {
        uc_sync_register($username, $password, $email, $userId);
        $ucUid = uc_find_ucuid($userId);
        if ($ucUid !== null && $ucUid > 0) {
            $synloginHtml = uc_user_synlogin($ucUid);
        }
    }

    // 设置session
    setAuthSession($userId, $username, $accessToken, 'user');

    jsonResponse([
        'status' => 0,
        'message' => '注册成功',
        'data' => [
            'id' => $userId,
            'username' => $username,
            'access_token' => $accessToken,
            'role' => 'user',
            'synlogin_html' => $synloginHtml
        ]
    ]);
}

// ==================== 登录 ====================
function handleLogin(): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $username = trim($input['username'] ?? '');
    $password = $input['password'] ?? '';

    if (!$username || !$password) {
        jsonResponse(['status' => 1, 'message' => '请输入账号和密码']);
    }

    $db = getDB();
    // 支持用户名或邮箱登录
    if (strpos($username, '@') !== false) {
        $stmt = $db->prepare("SELECT id,username,password_hash,access_token,`role`,`status`,headimg FROM users WHERE email = ?");
    } else {
        $stmt = $db->prepare("SELECT id,username,password_hash,access_token,`role`,`status`,headimg FROM users WHERE username = ?");
    }
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        // 本地校验失败：若已启用 UCenter 且允许 UCenter 账号登录，自动尝试用 UCenter 账号回退
        $ucData = (uc_is_enabled() && uc_strategy('uc_allow_uc_login'))
            ? tryUcLogin($username, $password)
            : null;
        if ($ucData !== null) {
            jsonResponse([
                'status' => 0,
                'message' => '登录成功（UCenter 回退）',
                'data' => $ucData,
            ]);
        }
        jsonResponse(['status' => 1, 'message' => '账号或密码错误']);
    }
    if ((int)$user['status'] === 0) {
        jsonResponse(['status' => 1, 'message' => '账号已被禁用']);
    }

    // 更新登录信息
    $ip = getClientIP();
    $stmt = $db->prepare("UPDATE users SET `ip`=?, `last_active`=NOW() WHERE id=?");
    $stmt->execute([$ip, $user['id']]);

    setAuthSession((int)$user['id'], $user['username'], $user['access_token'], $user['role']);

    // 同步登录到 UCenter 体系（注入页面后由浏览器执行；未启用或策略关闭则空串）
    $synloginHtml = '';
    if (uc_strategy('uc_sync_login')) {
        $synloginHtml = uc_sync_login((int)$user['id'], $user['username'], $password);
    }

    jsonResponse([
        'status' => 0,
        'message' => '登录成功',
        'data' => [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'access_token' => $user['access_token'],
            'role' => $user['role'],
            'headimg' => $user['headimg'],
            'synlogin_html' => $synloginHtml
        ]
    ]);
}

// ==================== UCenter 账号登录（显式入口） ====================
function handleUcLogin(): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $username = trim($input['username'] ?? '');
    $password = $input['password'] ?? '';

    if (!$username || !$password) {
        jsonResponse(['status' => 1, 'message' => '请输入账号和密码']);
    }
    if (!uc_is_enabled() || !uc_strategy('uc_allow_uc_login')) {
        jsonResponse(['status' => 1, 'message' => '未启用 UCenter 登录，请使用本站账号登录']);
    }
    $ucData = tryUcLogin($username, $password);
    if ($ucData === null) {
        jsonResponse(['status' => 1, 'message' => 'UCenter 验证失败：账号或密码错误']);
    }
    jsonResponse(['status' => 0, 'message' => '登录成功（UCenter）', 'data' => $ucData]);
}

/**
 * 用 UCenter 账号登录（账号在 UCenter 中，但尚未在本地建档，或本地密码不同步时回退）。
 * 成功：本地建档/绑定 + 写入会话 + 返回同步登录脚本；失败返回 null。
 * @return array|null 成功时返回待输出的 data 数组，失败返回 null
 */
function tryUcLogin(string $username, string $password): ?array
{
    if (!uc_is_enabled() || !uc_strategy('uc_allow_uc_login')) {
        return null;
    }
    $uc = uc_user_login($username, $password);
    if (!is_array($uc) || (int) ($uc[0] ?? 0) <= 0) {
        return null;
    }
    $ucUid = (int) $uc[0];
    // onlogin 返回顺序：[status, username, password, email, merge] —— email 在索引 3
    $email = $uc[3] ?? '';

    $db = getDB();
    $stmt = $db->prepare(
        "SELECT id,username,password_hash,access_token,`role`,`status`,headimg FROM users WHERE username=? LIMIT 1"
    );
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user) {
        // 首次：需开启「自动建号」，否则拒绝（避免未授权地在本地创建账号）
        if (!uc_strategy('uc_auto_create')) {
            return null;
        }
        // 本地化建档（本地密码使用随机强密码，真实凭证以 UCenter 为准）
        $accessToken = bin2hex(random_bytes(32));
        $passwordHash = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);
        $db->prepare(
            "INSERT INTO users (username,email,password_hash,access_token,ip,role,status) VALUES (?,?,?,?,?,'user',1)"
        )->execute([$username, $email, $passwordHash, $accessToken, getClientIP()]);
        $userId = (int) $db->lastInsertId();
        $user = ['id' => $userId, 'username' => $username, 'access_token' => $accessToken, 'role' => 'user', 'status' => 1, 'headimg' => ''];
    } elseif ((int) $user['status'] === 0) {
        return null; // 本地已禁用，不回退
    }

    uc_bind_user((int) $user['id'], $ucUid, $username, $email);
    setAuthSession((int) $user['id'], $user['username'], $user['access_token'], $user['role']);

    $synloginHtml = uc_user_synlogin($ucUid);
    return [
        'id'            => (int) $user['id'],
        'username'      => $user['username'],
        'access_token'  => $user['access_token'],
        'role'          => $user['role'],
        'headimg'       => $user['headimg'] ?? '',
        'synlogin_html' => $synloginHtml,
    ];
}

// ==================== 登出 ====================
function handleLogout(): void {
    session_start();
    // 更新最后活跃时间
    if (!empty($_SESSION['user_id'])) {
        try {
            $db = getDB();
            $stmt = $db->prepare("UPDATE users SET last_active = NOW() WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
        } catch (Exception $e) { /* 忽略 */ }
    }
    session_unset();
    session_destroy();

    // 同步登出到 UCenter 体系（未启用则空串）
    $synlogoutHtml = uc_is_enabled() ? uc_user_synlogout() : '';
    jsonResponse(['status' => 0, 'message' => '已登出', 'data' => ['synlogout_html' => $synlogoutHtml]]);
}

// ==================== 获取个人信息 ====================
function handleProfile(): void {
    $user = requireLogin();
    
    $db = getDB();
    $stmt = $db->prepare(
        "SELECT id,username,email,headimg,role,status,total_bytes,total_time,last_active,created_at "
        . "FROM users WHERE id=?"
    );
    $stmt->execute([$user['id']]);
    $profile = $stmt->fetch();

    // 会员中心自定义卡片设置
    $ucCard = [];
    foreach (['uc_card_enabled','uc_card_text','uc_card_url'] as $key) {
        $s = $db->prepare("SELECT setting_value FROM site_settings WHERE setting_key=?");
        $s->execute([$key]);
        $ucCard[$key] = $s->fetchColumn() ?? '';
        if ($key === 'uc_card_enabled') $ucCard[$key] = ($ucCard[$key] === '1' || $ucCard[$key] === 1) ? 1 : 0;
    }

    jsonResponse([
        'status' => 0,
        'data' => array_merge($profile ?: [], ['uc_card' => $ucCard])
    ]);
}

// ==================== 修改个人信息 ====================
function handleUpdate(): void {
    $user = requireLogin();
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $db = getDB();
    $updates = [];
    $params = [];

    $newEmail = null;
    $newPassword = null;

    // 修改邮箱
    if (isset($input['email'])) {
        $email = trim($input['email']);
        if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['status' => 1, 'message' => '邮箱格式错误']);
        }
        $updates[] = "`email`=?";
        $params[] = $email ?: '';
        $newEmail = $email;
    }

    // 修改头像
    if (isset($input['headimg'])) {
        $updates[] = "`headimg`=?";
        $params[] = substr(trim($input['headimg']), 0, 500);
    }

    // 修改密码
    if (!empty($input['new_password'])) {
        if (empty($input['old_password'])) {
            jsonResponse(['status' => 1, 'message' => '请输入原密码']);
        }
        $stmt = $db->prepare("SELECT password_hash FROM users WHERE id=?");
        $stmt->execute([$user['id']]);
        $current = $stmt->fetchColumn();
        
        if (!password_verify($input['old_password'], $current)) {
            jsonResponse(['status' => 1, 'message' => '原密码错误']);
        }
        if (strlen($input['new_password']) < 6) {
            jsonResponse(['status' => 1, 'message' => '新密码至少6位']);
        }
        $updates[] = "`password_hash`=?";
        $params[] = password_hash($input['new_password'], PASSWORD_DEFAULT);
        $newPassword = $input['new_password'];
    }

    if (empty($updates)) {
        jsonResponse(['status' => 1, 'message' => '没有需要更新的内容']);
    }

    $params[] = $user['id'];
    $sql = "UPDATE users SET " . implode(',', $updates) . ",updated_at=NOW() WHERE id=?";
    $db->prepare($sql)->execute($params);

    // 同步到 UCenter（站内改密 / 改资料）；失败仅告警、不影响本站已完成的更新
    $syncNotes = [];
    if ($newPassword !== null && uc_strategy('uc_sync_password')) {
        if (!uc_sync_password($user['username'], $newPassword)) {
            $syncNotes[] = 'UCenter 改密同步失败（本站密码已更新）';
        }
    }
    if ($newEmail !== null && uc_strategy('uc_sync_email')) {
        if (!uc_sync_email($user['username'], $newEmail)) {
            $syncNotes[] = 'UCenter 邮箱同步失败（本站邮箱已更新）';
        }
    }

    $extra = $syncNotes ? '（' . implode('；', $syncNotes) . '）' : '';
    jsonResponse(['status' => 0, 'message' => '更新成功' . $extra]);
}

// ==================== 重置统计数据 ====================
function handleResetStat(): void {
    $user = requireLogin();
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $field = trim($input['field'] ?? '');
    if (!in_array($field, ['total_bytes', 'total_time'])) {
        jsonResponse(['status' => 1, 'message' => '无效的重置字段']);
    }

    $db = getDB();
    $stmt = $db->prepare("UPDATE users SET {$field}=0 WHERE id=?");
    $stmt->execute([$user['id']]);

    jsonResponse(['status' => 0, 'message' => '重置成功']);
}

// ==================== 刷新令牌 ====================
function handleRefreshToken(): void {
    $user = requireLogin();
    $db = getDB();

    // 生成新令牌
    $newToken = bin2hex(random_bytes(32));

    // 更新数据库
    $stmt = $db->prepare("UPDATE users SET access_token=? WHERE id=?");
    $stmt->execute([$newToken, $user['id']]);

    // 更新session
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['access_token'] = $newToken;

    jsonResponse([
        'status' => 0,
        'message' => '令牌已刷新',
        'data' => ['access_token' => $newToken]
    ]);
}

// ==================== 用户反馈提交 ====================
function handleSubmitFeedback(): void {
    $user = requireLogin();
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $content = trim($input['content'] ?? '');
    if (empty($content)) {
        jsonResponse(['status' => 1, 'message' => '请输入反馈内容']);
    }
    if (mb_strlen($content) > 200) {
        jsonResponse(['status' => 1, 'message' => '反馈内容不能超过200字']);
    }

    try {
        $db = getDB();

        // 兜底：自动检查并创建表（防止手动漏执行 SQL）
        ensureFeedbackTable($db);

        // 限制每用户每天最多提交10条
        $todayCount = $db->prepare("SELECT COUNT(*) FROM user_feedback WHERE user_id=? AND DATE(created_at)=CURDATE()");
        $todayCount->execute([$user['id']]);
        if ((int)$todayCount->fetchColumn() >= 10) {
            jsonResponse(['status' => 1, 'message' => '今日提交次数已达上限，请明天再试']);
        }

        $stmt = $db->prepare(
            "INSERT INTO user_feedback (user_id, username, content, ip) VALUES (?,?,?,?)"
        );
        $stmt->execute([$user['id'], $user['username'], $content, getClientIP()]);

        $insertId = (int)$db->lastInsertId();

        jsonResponse([
            'status' => 0,
            'message' => '感谢您的反馈！我们会尽快处理',
            'data' => ['id' => $insertId]
        ]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '提交失败：' . $e->getMessage()]);
    }
}

/**
 * 确保 user_feedback 表存在，不存在则自动创建
 */
function ensureFeedbackTable(PDO $db): void {
    try {
        $db->query("SELECT 1 FROM user_feedback LIMIT 1");
    } catch (Exception $e) {
        $db->exec(
            "CREATE TABLE IF NOT EXISTS `user_feedback` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED NOT NULL,
                `username` VARCHAR(50) NOT NULL DEFAULT '',
                `content` TEXT NOT NULL,
                `status` TINYINT DEFAULT 0 COMMENT '0未读 1已读 2已处理',
                `reply` TEXT DEFAULT NULL,
                `ip` VARCHAR(45) DEFAULT '',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                `replied_at` DATETIME DEFAULT NULL,
                INDEX `idx_user_id` (`user_id`),
                INDEX `idx_status` (`status`),
                INDEX `idx_created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户反馈表'"
        );
    }
}

// ==================== 找回密码 ====================
function handleResetPassword(): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $email = trim($input['email'] ?? '');

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['status' => 1, 'message' => '请输入有效的邮箱地址']);
    }

    // 检查用户是否存在
    $db = getDB();
    $stmt = $db->prepare("SELECT id, username FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        jsonResponse(['status' => 1, 'message' => '该邮箱未注册']);
    }

    // 生成重置令牌（有效期24小时）
    $token = bin2hex(random_bytes(32));
    $expiresAt = date('Y-m-d H:i:s', time() + 86400);

    // 存储或更新密码重置记录（复用 users 表的 access_token 字段临时存储）
    // 简化方案：直接返回成功提示，让管理员通过 reset_password.php 工具重置
    jsonResponse([
        'status' => 0,
        'message' => '重置邮件已发送！请联系管理员使用密码重置工具重置密码'
    ]);
}

// ==================== 辅助函数 ====================

function requireLogin(): array {
    session_start();
    if (empty($_SESSION['user_id'])) {
        jsonResponse(['status' => -1, 'message' => '请先登录'], 401);
    }
    return [
        'id' => (int)$_SESSION['user_id'],
        'username' => $_SESSION['username'] ?? '',
        'role' => $_SESSION['role'] ?? 'user',
        'access_token' => $_SESSION['access_token'] ?? '',
    ];
}

function setAuthSession(int $id, string $username, string $token, string $role): void {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $_SESSION['user_id'] = $id;
    $_SESSION['username'] = $username;
    $_SESSION['access_token'] = $token;
    $_SESSION['role'] = $role;
    $_SESSION['login_time'] = time();
}

/** 获取网站设置 */
function getSetting(PDO $db, string $key, string $default = ''): string {
    static $cache = [];
    if (isset($cache[$key])) return $cache[$key];
    $stmt = $db->prepare("SELECT setting_value FROM site_settings WHERE setting_key=?");
    $stmt->execute([$key]);
    $val = $stmt->fetchColumn();
    return $cache[$key] = $val !== false ? $val : $default;
}
