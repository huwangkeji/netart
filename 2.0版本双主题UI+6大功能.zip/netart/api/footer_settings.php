<?php
/**
 * NetworkPanel - 底部设置读取API（公开接口）
 * 返回自定义文字、ICP备案号、版权信息、自定义HTML等
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$action = $_GET['action'] ?? '';

if ($action === 'announcements') {
    try {
        $db = getDB();
        $db->exec("CREATE TABLE IF NOT EXISTS `announcements` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(100) DEFAULT '公告',
            `content` TEXT NOT NULL,
            `status` TINYINT DEFAULT 1,
            `sort_order` INT DEFAULT 0,
            `show_popup` TINYINT DEFAULT 1,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_status` (`status`),
            INDEX `idx_sort` (`sort_order`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $stmt = $db->query("SELECT id, title, content, show_popup FROM announcements WHERE status=1 ORDER BY sort_order ASC, id DESC");
        jsonResponse(['status' => 0, 'data' => $stmt->fetchAll()]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '获取公告失败']);
    }
    exit;
}

if ($action === 'ads') {
    try {
        $db = getDB();
        $db->exec("CREATE TABLE IF NOT EXISTS `ads` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `title` VARCHAR(200) NOT NULL,
            `url` VARCHAR(500) NOT NULL,
            `color` VARCHAR(20) DEFAULT '',
            `status` TINYINT DEFAULT 1,
            `sort_order` INT DEFAULT 0,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $stmt = $db->query("SELECT id, title, url, color FROM ads WHERE status=1 ORDER BY sort_order ASC, id DESC");
        jsonResponse(['status' => 0, 'data' => $stmt->fetchAll()]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '获取广告失败']);
    }
    exit;
}

try {
    $db = getDB();
    
    // 批量获取所有底部相关设置
    $stmt = $db->query("SELECT setting_key, setting_value FROM site_settings WHERE setting_key IN ('footer_custom_text','footer_copyright','footer_icp','footer_icp_url','footer_html','friend_links','notices','nav_links')");
    $rows = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // 解析公告（每行一条）
    $noticesRaw = $rows['notices'] ?? '';
    $noticesArr = [];
    if ($noticesRaw) {
        // 尝试JSON解析
        $decoded = json_decode($noticesRaw, true);
        if (is_array($decoded)) {
            foreach ($decoded as $n) { if (trim($n)) $noticesArr[] = trim($n); }
        } else {
            // 按换行分割
            foreach (explode("\n", $noticesRaw) as $line) {
                if (trim($line)) $noticesArr[] = trim($line);
            }
        }
    }

    // 如果notices字段不存在于数据库中，尝试自动创建默认值
    if (!isset($rows['notices']) && empty($noticesArr)) {
        try {
            $db->exec("INSERT IGNORE INTO site_settings (setting_key, setting_value, title, type, description, group_name, sort_order) VALUES ('notices', '', 'text', '公告/广告内容', '多行公告文字，每行一条。支持HTML标签', 'footer', 7)");
        } catch (Exception $e2) { /* 忽略 */ }
    }

    // 自动创建nav_links默认值（顶部导航配置，不含首页和排行榜，因为它们已在HTML中固定）
    if (!isset($rows['nav_links'])) {
        try {
            $defaultNav = json_encode([
                ['name' => 'IP查询', 'url' => '#ipPanel'],
                ['name' => '流量计算器', 'url' => '#']
            ], JSON_UNESCAPED_UNICODE);
            $db->exec("INSERT IGNORE INTO site_settings (setting_key, setting_value, title, type, description, group_name, sort_order) VALUES ('nav_links', '" . addslashes($defaultNav) . "', 'JSON数组', '顶部导航链接（全部可自定义）', JSON格式: [{\"name\":\"显示名\",\"url\":\"地址\",\"active\":true/false,\"target\":\"_self/_blank\"}]。所有按钮均可在后台增删改。', 'header', 0)");
        } catch (Exception $e3) { /* 忽略 */ }
    }

    // 自动创建friend_links默认值（如果不存在）
    if (!isset($rows['friend_links'])) {
        try {
            $defaultLinks = json_encode([['name' => '示例链接', 'url' => '#']], JSON_UNESCAPED_UNICODE);
            $db->exec("INSERT IGNORE INTO site_settings (setting_key, setting_value, title, type, description, group_name, sort_order) VALUES ('friend_links', '" . addslashes($defaultLinks) . "', '友情链接', 'json', 'JSON数组格式：[{\"name\":\"显示名\",\"url\":\"地址\"}]', 'footer', 5)");
            // 重新查询以获取新插入的值
            $rows['friend_links'] = $defaultLinks;
        } catch (Exception $e4) { /* 忽略 */ }
    }

    jsonResponse([
        'status' => 0,
        'data' => [
            'custom_text' => $rows['footer_custom_text'] ?? '',
            'copyright'   => $rows['footer_copyright'] ?? '',
            'icp'         => $rows['footer_icp'] ?? '',
            'icp_url'     => $rows['footer_icp_url'] ?? '',
            'custom_html' => $rows['footer_html'] ?? '',
            'friend_links'=> $rows['friend_links'] ?? '',
            'notices'     => $noticesArr,
            'nav_links'   => $rows['nav_links'] ?? '',
        ]
    ]);

} catch (Exception $e) {
    jsonResponse(['status' => 1, 'message' => '获取失败']);
}
