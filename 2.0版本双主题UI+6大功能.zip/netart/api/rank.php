<?php
/**
 * NetworkPanel - 排行榜查询API
 * 对应原版: get.ajax
 * 
 * GET参数:
 *   grade - 统计维度: 3=小时, 2=天, 1=月, 0=年
 *   sorted_by - 排序字段: allUsed(总流量), averageSpeed(平均速度), onlineTime(在线时长)
 *   isPast - 是否查看上个统计周期
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$grade = (int)($_GET['grade'] ?? 3); // 默认小时
$sortedBy = $_GET['sorted_by'] ?? 'allUsed';
$isPast = isset($_GET['isPast']) && $_GET['isPast'] === 'true';
$limit = (int)($_GET['limit'] ?? 100);

// 验证参数
$validGrades = [0, 1, 2, 3];
if (!in_array($grade, $validGrades)) $grade = 3;
$validSorts = ['allUsed', 'averageSpeed', 'onlineTime'];
if (!in_array($sortedBy, $validSorts)) $sortedBy = 'allUsed';

// 映射到数据库表和字段
$tableMap = [
    3 => ['table' => 'stats_hourly', 'period_col' => 'hour_start'],
    2 => ['table' => 'stats_daily', 'period_col' => 'day_start'],
    1 => ['table' => 'stats_monthly', 'period_col' => 'month_start'],
    0 => ['table' => 'stats_yearly', 'period_col' => 'year'],
];

$sortFieldMap = [
    'allUsed' => 'total_bytes',
    'averageSpeed' => 'avg_speed',
    'onlineTime' => 'total_duration',
];

$config = $tableMap[$grade];
$table = $config['table'];
$periodCol = $config['period_col'];
$sortField = $sortFieldMap[$sortedBy];

$db = getDB();

try {
    // 计算当前周期时间范围
    if ($isPast) {
        $periodCondition = getPastPeriodCondition($db, $table, $periodCol);
    } else {
        $periodCondition = getCurrentPeriodCondition($db, $table, $periodCol);
    }

    // 查询排行榜数据（按user_id聚合，确保每个用户只占一个名额）
    $sql = "SELECT s.user_id, SUM(s.total_bytes) AS total_bytes, SUM(s.total_duration) AS total_duration, "
         . "AVG(s.avg_speed) AS avg_speed, "
         . "u.username AS user, u.headimg, u.isp, u.region AS addr, u.region_short AS `short` "
         . "FROM `$table` s "
         . "LEFT JOIN users u ON s.user_id = u.id "
         . "WHERE $periodCondition AND s.`$sortField` > 0 "
         . "GROUP BY s.user_id "
         . "ORDER BY SUM(s.`$sortField`) DESC "
         . "LIMIT ?";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$limit]);
    $results = $stmt->fetchAll();

    // 格式化返回数据
    $formattedResults = [];
    foreach ($results as $row) {
        switch ($sortedBy) {
            case 'allUsed':
                $dataValue = (float)$row['total_bytes'];
                break;
            case 'averageSpeed':
                $dataValue = (float)$row['avg_speed']; // B/s
                break;
            case 'onlineTime':
                $dataValue = (float)$row['total_duration'];
                break;
            default:
                $dataValue = 0;
        }

        $formattedResults[] = [
            'user' => $row['user'] ?? '匿名用户',
            'headimg' => $row['headimg'] ?? '',
            'data' => $dataValue,
            'isp' => $row['isp'] ?? '未知',
            'addr' => $row['addr'] ?? '',
            'short' => is_string($row['short'] ?? null) ? (json_decode($row['short'], true) ?: $row['short']) : ($row['short'] ?? []),
        ];
    }

    jsonResponse(['status' => 0, 'data' => $formattedResults]);

} catch (Exception $e) {
    error_log('Rank query failed: ' . $e->getMessage());
    jsonResponse(['status' => 1, 'message' => '查询失败: ' . $e->getMessage()]);
}

/**
 * 获取当前周期的SQL条件
 */
function getCurrentPeriodCondition(PDO $db, string $table, string $periodCol): string {
    switch ($periodCol) {
        case 'hour_start':
            return "$periodCol = DATE_FORMAT(NOW(), '%Y-%m-%d %H:00:00')";
        case 'day_start':
            return "$periodCol = CURDATE()";
        case 'month_start':
            return "$periodCol = DATE_FORMAT(NOW(), '%Y-%m-01')";
        case 'year':
            return "`year` = YEAR(NOW())";
        default:
            return "1=1";
    }
}

/**
 * 获取上一个周期的SQL条件
 */
function getPastPeriodCondition(PDO $db, string $table, string $periodCol): string {
    switch ($periodCol) {
        case 'hour_start':
            return "$periodCol = DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 HOUR), '%Y-%m-%d %H:00:00')";
        case 'day_start':
            return "$periodCol = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
        case 'month_start':
            return "$periodCol = DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 MONTH), '%Y-%m-01')";
        case 'year':
            return "`year` = YEAR(NOW()) - 1";
        default:
            return "1=1";
    }
}
