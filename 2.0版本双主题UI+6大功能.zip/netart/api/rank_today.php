<?php
/**
 * NetworkPanel - 今日流量消耗排行榜API（首页展示用）
 * 统计今日流量消耗TOP 10会员排名
 * 
 * GET ?limit=10
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$limit = min(20, max(1, (int)($_GET['limit'] ?? 10)));

try {
    $db = getDB();

    // 从 traffic_logs 表统计今日每个用户的总流量
    $sql = "SELECT 
                u.id,
                u.username,
                u.headimg,
                COALESCE(SUM(t.bytes_used), 0) as today_bytes
            FROM users u
            LEFT JOIN traffic_logs t ON t.user_id = u.id AND DATE(t.created_at) = CURDATE()
            GROUP BY u.id, u.username, u.headimg
            HAVING today_bytes > 0
            ORDER BY today_bytes DESC
            LIMIT ?";
    
    $stmt = $db->prepare($sql);
    $stmt->execute([$limit]);
    $rows = $stmt->fetchAll();

    $result = [];
    foreach ($rows as $i => $row) {
        $result[] = [
            'rank' => $i + 1,
            'user_id' => (int)$row['id'],
            'username' => $row['username'] ?: '匿名用户',
            'headimg' => $row['headimg'] ?? '',
            'bytes' => (float)$row['today_bytes'],
        ];
    }

    jsonResponse(['status' => 0, 'data' => $result]);

} catch (Exception $e) {
    error_log('Today rank error: ' . $e->getMessage());
    jsonResponse(['status' => 1, 'message' => '查询失败']);
}
