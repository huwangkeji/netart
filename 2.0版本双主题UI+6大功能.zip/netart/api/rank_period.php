<?php
/**
 * NetworkPanel - 独立排行榜页面专用API
 * GET参数: period = day(今日) | month(本月) | year(本年)
 * 返回: [{username, headimg, bytes}, ...]
 * 根据period从不同统计表获取数据
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

$period = $_GET['period'] ?? 'day';
$db = getDB();

try {
    switch ($period) {
        case 'day':
            // 今日排行：从 stats_daily 获取今日数据（按user_id聚合，确保每用户只占一个名额）
            $sql = "SELECT u.id, u.username, u.headimg, COALESCE(SUM(s.total_bytes), 0) as total_bytes
                    FROM users u
                    LEFT JOIN stats_daily s ON s.user_id = u.id AND s.day_start = CURDATE()
                    WHERE s.total_bytes > 0
                    GROUP BY u.id, u.username, u.headimg
                    ORDER BY total_bytes DESC LIMIT 100";
            break;
        case 'month':
            // 本月排行：从 stats_monthly 获取本月数据（按user_id聚合）
            $sql = "SELECT u.id, u.username, u.headimg, COALESCE(SUM(s.total_bytes), 0) as total_bytes
                    FROM users u
                    LEFT JOIN stats_monthly s ON s.user_id = u.id AND s.month_start = DATE_FORMAT(NOW(), '%Y-%m-01')
                    WHERE s.total_bytes > 0
                    GROUP BY u.id, u.username, u.headimg
                    ORDER BY total_bytes DESC LIMIT 100";
            break;
        case 'year':
            // 本年排行：从 stats_yearly 获取本年数据（按user_id聚合）
            $sql = "SELECT u.id, u.username, u.headimg, COALESCE(SUM(s.total_bytes), 0) as total_bytes
                    FROM users u
                    LEFT JOIN stats_yearly s ON s.user_id = u.id AND s.`year` = YEAR(NOW())
                    WHERE s.total_bytes > 0
                    GROUP BY u.id, u.username, u.headimg
                    ORDER BY total_bytes DESC LIMIT 100";
            break;
        default:
            // 默认今日（按user_id聚合）
            $sql = "SELECT u.id, u.username, u.headimg, COALESCE(SUM(s.total_bytes), 0) as total_bytes
                    FROM users u
                    LEFT JOIN stats_daily s ON s.user_id = u.id AND s.day_start = CURDATE()
                    WHERE s.total_bytes > 0
                    GROUP BY u.id, u.username, u.headimg
                    ORDER BY total_bytes DESC LIMIT 100";
            break;
    }

    $stmt = $db->query($sql);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $data = array_map(function($r) {
        return [
            'username' => $r['username'] ?: '匿名',
            'headimg'  => $r['headimg'] ?? '',
            'bytes'    => (float)($r['total_bytes'] ?? 0),
        ];
    }, $rows);

    jsonResponse(['status' => 0, 'data' => $data]);
} catch (Exception $e) {
    error_log('Rank period error: ' . $e->getMessage());
    jsonResponse(['status' => 1, 'message' => '查询失败']);
}
