<?php
/**
 * 轻量测速端点（供面板设置「定时自动测速」与「手动立即测速」调用）
 *
 *  - ?action=ping      → 立即返回空响应，由客户端测量 RTT（延迟）
 *  - ?action=download&size=4 → 流式返回约 size MB 的随机字节，由客户端计时算下行吞吐
 *
 * 设计要点（安全 / 边界）：
 *  - size 严格 clamp 到 1..16（MB），防止被当作无限下载攻击；
 *  - 采用分块输出并 flush，避免一次性占满内存；
 *  - 不读取/不写入任何请求体或文件，纯计算流；
 *  - 关闭输出压缩以得到真实传输量（gzip 会让字节数失真）。
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/helpers.php';

$action = (string) ($_GET['action'] ?? '');

if ($action === 'ping') {
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    header('Content-Length: 0');
    // 立即结束，客户端用 performance.now() 量 RTT
    exit;
}

if ($action === 'download') {
    // 关闭压缩，保证传输字节数真实
    if (function_exists('ini_set')) {
        @ini_set('zlib.output_compression', '0');
    }
    header('Content-Type: application/octet-stream');
    header('Cache-Control: no-store');

    $sizeMb = isset($_GET['size']) ? (float) $_GET['size'] : 4.0;
    if (!is_finite($sizeMb) || $sizeMb < 1) $sizeMb = 1.0;
    if ($sizeMb > 16) $sizeMb = 16.0;

    $total = (int) ($sizeMb * 1024 * 1024);
    $chunk = 256 * 1024; // 256KB 一块
    $block = str_repeat("\x00", $chunk); // 压缩伪随机填充，足够拉满带宽

    // 不允许客户端缓存
    header('Content-Length: ' . $total);

    $sent = 0;
    while ($sent < $total) {
        $remaining = $total - $sent;
        $out = $remaining < $chunk ? str_repeat("\x00", $remaining) : $block;
        echo $out;
        $sent += strlen($out);
        if ($sent % (1024 * 1024) === 0) {
            if (function_exists('flush')) flush();
        }
    }
    if (function_exists('flush')) flush();
    exit;
}

// 未知 action
jsonResponse(['status' => 1, 'message' => 'unknown action']);
