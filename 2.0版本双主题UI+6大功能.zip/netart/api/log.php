<?php
/**
 * NetworkPanel - 流量日志上报API
 * 对应原版: log (POST)
 * 
 * POST JSON body:
 *   AccessToken - 用户访问令牌
 *   url - 测速URL
 *   threadNum - 线程数
 *   used - 使用的流量字节数
 *   time - 持续时间（秒）
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/query_log.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['status' => 1, 'message' => '仅支持POST请求'], 405);
}

// 获取请求数据
$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true);

if (!$input) {
    jsonResponse(['status' => 1, 'message' => '无效的请求体']);
}

$accessToken = $input['AccessToken'] ?? '';
$url = substr($input['url'] ?? '', 0, 500);
$threadNum = max(1, min(16, (int)($input['threadNum'] ?? 1)));
$bytesUsed = max(0, (int)($input['used'] ?? 0));
$duration = max(0, (float)($input['time'] ?? 0));

// 计算平均速度（字节/秒），取整以兼容 traffic_logs.speed 的 BIGINT 类型
$speed = ($duration > 0 && $bytesUsed > 0) ? (int)round($bytesUsed / $duration) : 0;

// 如果流量和时间都为0，无需记录（避免产生无意义记录）
if ($bytesUsed <= 0 && $duration <= 0) {
    jsonResponse(['status' => 0, 'message' => '无数据需记录']);
}

// 验证用户令牌并获取用户ID
$db = getDB();
$userId = 0;
$userData = null;

if (!empty($accessToken)) {
    $stmt = $db->prepare("SELECT id, username, headimg, isp, region, region_short, ip FROM users WHERE access_token = ?");
    $stmt->execute([$accessToken]);
    $userData = $stmt->fetch();
    
    if (!$userData) {
        // Token无效
        jsonResponse(['status' => -1, 'message' => '无效的访问令牌']);
    }
    $userId = (int)$userData['id'];
}

$clientIP = getClientIP();
$userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500);

try {
    // 插入流量日志
    $stmt = $db->prepare(
        "INSERT INTO traffic_logs (`user_id`, `url`, `thread_num`, `bytes_used`, `duration`, `speed`, `ip`, `user_agent`) "
        . "VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([$userId, $url, $threadNum, $bytesUsed, $duration, $speed, $clientIP, $userAgent]);

    // 更新统计表（如果表不存在则跳过，不阻塞主流程）
    try {
        updateStatistics($db, $userId, $bytesUsed, $duration, $speed);
    } catch (Exception $statErr) {
        error_log('Stats update failed (non-fatal): ' . $statErr->getMessage());
    }

    // 同步更新用户表累计数据（供用户中心展示）
    if ($userId > 0) {
        try {
            $db->prepare("UPDATE users SET total_bytes = total_bytes + ?, total_time = total_time + ?, last_active = NOW() WHERE id = ?")
                ->execute([$bytesUsed, $duration, $userId]);
        } catch (Exception $userErr) {
            error_log('User stats update failed (non-fatal): ' . $userErr->getMessage());
        }
    }

    // 同步记录到「查询记录管理」（测速属于前台查询行为，便于统一溯源）
    try {
        $summary = '流量 ' . format_bytes($bytesUsed) . ' / 速率 ' . format_bytes($speed) . '/s';
        logQuery('speedtest', $url, $summary);
    } catch (Throwable $e) {
        error_log('[query_log] speedtest log failed (non-fatal): ' . $e->getMessage());
    }

    jsonResponse(['status' => 0, 'message' => '日志记录成功']);

} catch (Exception $e) {
    error_log('Log insert failed: ' . $e->getMessage());
    jsonResponse(['status' => 1, 'message' => '日志记录失败']);
}

/**
 * 更新各时间维度的统计数据
 */
function updateStatistics(PDO $db, int $userId, float $bytesUsed, float $duration, float $speed): void {
    $now = new DateTime();
    $hourStart = clone $now; $hourStart->setTime((int)$now->format('H'), 0, 0);
    $dayStart = clone $now; $dayStart->setTime(0, 0, 0);
    $monthStart = clone $now; $monthStart->modify('first day of this month')->setTime(0, 0, 0);
    $year = (int)$now->format('Y');

    // 更新小时统计
    upsertStat($db, 'stats_hourly', ['user_id', 'hour_start'], $userId, $hourStart->format('Y-m-d H:i:s'), $bytesUsed, $duration, $speed);
    // 更新天统计
    upsertStat($db, 'stats_daily', ['user_id', 'day_start'], $userId, $dayStart->format('Y-m-d'), $bytesUsed, $duration, $speed);
    // 更新月统计
    upsertStat($db, 'stats_monthly', ['user_id', 'month_start'], $userId, $monthStart->format('Y-m-d'), $bytesUsed, $duration, $speed);
    // 更新年统计
    upsertStatYearly($db, $userId, $year, $bytesUsed, $duration, $speed);
}

function upsertStat(PDO $db, string $table, array $ukCols, int $userId, string $periodStart, float $bytesUsed, float $duration, float $speed): void {
    $colName = end($ukCols); // hour_start / day_start / month_start
    // 使用 VALUES() 函数语法，兼容 MySQL 5.7 和 MySQL 8.0 所有版本
    $sql = "INSERT INTO `$table` (`user_id`, `$colName`, `total_bytes`, `total_duration`, `avg_speed`) "
         . "VALUES (?, ?, ?, ?, ?) "
         . "ON DUPLICATE KEY UPDATE "
         . "`total_bytes` = `total_bytes` + VALUES(`total_bytes`), "
         . "`total_duration` = `total_duration` + VALUES(`total_duration`), "
         . "`avg_speed` = CASE WHEN `total_duration` + VALUES(`total_duration`) > 0 THEN "
         . "(`total_bytes` + VALUES(`total_bytes`)) / (`total_duration` + VALUES(`total_duration`)) ELSE 0 END";
    $stmt = $db->prepare($sql);
    $stmt->execute([$userId, $periodStart, $bytesUsed, $duration, $speed]);
}

function upsertStatYearly(PDO $db, int $userId, int $year, float $bytesUsed, float $duration, float $speed): void {
    // 使用 VALUES() 函数语法，兼容 MySQL 5.7 和 MySQL 8.0 所有版本
    $sql = "INSERT INTO `stats_yearly` (`user_id`, `year`, `total_bytes`, `total_duration`, `avg_speed`) "
         . "VALUES (?, ?, ?, ?, ?) "
         . "ON DUPLICATE KEY UPDATE "
         . "`total_bytes` = `total_bytes` + VALUES(`total_bytes`), "
         . "`total_duration` = `total_duration` + VALUES(`total_duration`), "
         . "`avg_speed` = CASE WHEN `total_duration` + VALUES(`total_duration`) > 0 THEN "
         . "(`total_bytes` + VALUES(`total_bytes`)) / (`total_duration` + VALUES(`total_duration`)) ELSE 0 END";
    $stmt = $db->prepare($sql);
    $stmt->execute([$userId, $year, $bytesUsed, $duration, $speed]);
}
