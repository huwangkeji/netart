<?php
/**
 * NAT 检测 - 服务端出口 IP 回显（交叉校验用）
 *
 * 浏览器通过 WebRTC / STUN 拿到的是「公网映射地址」，本接口回显「服务端看到的客户端出口 IP」，
 * 二者用于交叉校验：一致说明没有多层 NAT / 出口偏移；不一致通常意味着存在 CGNAT、多出口或 ECMP。
 *
 * 说明：本接口不收集、不上传任何 ICE candidate，仅回显连接层客户端 IP。
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

if (request_method() === 'OPTIONS') {
    exit(0);
}

$ip = getClientIP();
$isPublic = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;

/**
 * 解析常见代理 / 负载均衡头，用于「多层 NAT / 多出口」线索。
 * 注意：此类头可被客户端伪造，仅在服务端信任链完整时才有参考价值，
 * 因此前端只作为「线索」展示，不作为判定依据。
 */
$headerIpKeys = [
    'HTTP_X_FORWARDED_FOR',
    'HTTP_X_REAL_IP',
    'HTTP_CF_CONNECTING_IP',
    'HTTP_TRUE_CLIENT_IP',
    'HTTP_X_CLIENT_IP',
    'HTTP_FORWARDED',
];

$forwarded = [];
foreach ($headerIpKeys as $key) {
    if (empty($_SERVER[$key])) {
        continue;
    }
    $raw = (string) $_SERVER[$key];
    foreach (preg_split('/\s*,\s*/', $raw) ?: [] as $part) {
        $part = trim($part);
        if ($part === '') {
            continue;
        }
        // RFC 7239 Forwarded: for=1.2.3.4;proto=https
        if (stripos($part, 'for=') === 0) {
            $part = trim(substr($part, 4), " \t\"[]");
        }
        if (filter_var($part, FILTER_VALIDATE_IP)) {
            $forwarded[] = $part;
        }
    }
}
$forwarded = array_values(array_unique($forwarded));

$via = trim((string) ($_SERVER['HTTP_VIA'] ?? ''));

echo json_encode([
    'status'    => 0,
    'ip'        => $ip,
    'is_public' => $isPublic,
    'family'    => (strpos($ip, ':') !== false) ? 'IPv6' : 'IPv4',
    // 代理链线索（仅供交叉校验参考，可能被伪造）
    'forwarded' => array_slice($forwarded, 0, 8),
    'xff_count' => count($forwarded),
    'via'       => $via,
    'server_addr' => $_SERVER['SERVER_ADDR'] ?? '',
    'server_port' => $_SERVER['SERVER_PORT'] ?? '',
    'https'     => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'ua'        => $_SERVER['HTTP_USER_AGENT'] ?? '',
    'ts'        => time(),
], JSON_UNESCAPED_UNICODE);
exit(0);
