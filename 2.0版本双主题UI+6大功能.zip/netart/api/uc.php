<?php
/**
 * UCenter 回调入口（Discuz 规范文件名 api/uc.php）
 *
 * UCenter 后台「应用管理」中的「应用接口文件名」默认为 `uc.php`，
 * 因此 UCenter 会以如下地址回调本应用：
 *     {应用主 URL}/api/uc.php?code=<authcode 加密的 querystring>
 *
 * 用于：连通性测试（后台「通信情况」显示「通信成功」）、同步登录/登出、
 * 删除用户、改名、改密等事件通知。
 *
 * 实际处理逻辑统一收敛在 api/ucenter.php（二者完全等价，
 * 保留 ucenter.php 以兼容历史上按该文件名配置的 UCenter 应用）。
 */

require __DIR__ . '/ucenter.php';
