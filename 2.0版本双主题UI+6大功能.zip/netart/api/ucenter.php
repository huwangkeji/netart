<?php
/**
 * UCenter 应用接入端点（UCenter -> 本应用 通知）· 共享处理逻辑
 *
 * 入口文件：
 *   - api/uc.php       ← UCenter「应用接口文件名」默认值，UCenter 实际回调地址
 *   - api/ucenter.php  ← 本文件，历史兼容入口（api/uc.php 会 require 本文件）
 * 二者行为完全一致，均以「登录集成」中的 uc_key 校验回调合法性。
 *
 * UCenter 会在以下事件时回调本文件：
 *  - synlogin     同步登录（其余应用登录后，使本应用也登录）
 *  - synlogout    同步登出
 *  - deleteuser   删除用户
 *  - renameuser   改名
 *  - updatepw     改密码（UCenter 侧已加密，本侧仅做占位，密码同步以本侧->UCenter 为准）
 *  - test         连通性测试（返回 1）
 *
 * 跨域设置 Cookie 需 P3P 头，已添加；现代浏览器若禁用第三方 Cookie 将降级为单站登录。
 */

// P3P（跨域 cookie 兼容）
header('P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR"');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/site_settings.php';
require_once __DIR__ . '/../includes/UCenter.php';

if (!uc_is_enabled()) {
    exit('UCenter 未启用');
}

// 解析 UCenter 下发的数据包
$code = (string) ($_GET['code'] ?? '');
$get = [];
if ($code !== '') {
    parse_str(uc_authcode($code, 'DECODE', getSiteSetting('uc_key', '')), $get);
}
if (empty($get)) {
    exit('Invalid Request');
}
if (time() - (int) ($get['time'] ?? 0) > 3600) {
    exit('Auth Failed');
}

$action = (string) ($get['action'] ?? '');

// 本地登录会话建立（供 synlogin 使用）
function uc_local_login(int $ucUid, string $username = ''): bool
{
    if ($ucUid <= 0 && $username === '') {
        return false;
    }
    try {
        $db = getDB();
        $localId = uc_find_local($ucUid);
        if ($localId === null) {
            // 尝试按用户名匹配（UCenter 侧用户名）
            if ($username !== '') {
                $s = $db->prepare("SELECT id,username,access_token,role FROM users WHERE username=? LIMIT 1");
                $s->execute([$username]);
                $row = $s->fetch();
                if ($row) {
                    $localId = (int) $row['id'];
                    uc_bind_user($localId, $ucUid, $username);
                }
            }
        }
        if ($localId === null) {
            return false;
        }
        $s = $db->prepare("SELECT id,username,access_token,role FROM users WHERE id=? AND status=1 LIMIT 1");
        $s->execute([$localId]);
        $user = $s->fetch();
        if (!$user) {
            return false;
        }
        if (session_status() === PHP_SESSION_NONE) session_start();
        $_SESSION['user_id'] = (int) $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['access_token'] = $user['access_token'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['login_time'] = time();
        $db->prepare("UPDATE users SET last_active=NOW() WHERE id=?")->execute([$user['id']]);
        return true;
    } catch (Throwable $e) {
        error_log('uc_local_login failed: ' . $e->getMessage());
        return false;
    }
}

switch ($action) {
    case 'test':
        exit('1');

    case 'synlogin':
        $uid = (int) ($get['uid'] ?? 0);
        $username = (string) ($get['username'] ?? '');
        if (uc_local_login($uid, $username)) {
            // 同步登录到 UCenter 体系下的其它应用（本应用作为「被同步方」，无需再输出脚本）
            header('Content-Type: text/html; charset=utf-8');
            exit('');
        }
        header('Content-Type: text/html; charset=utf-8');
        exit('');

    case 'synlogout':
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_unset();
        session_destroy();
        header('Content-Type: text/html; charset=utf-8');
        exit('');

    case 'deleteuser':
        $ids = (string) ($get['ids'] ?? '');
        if ($ids !== '') {
            try {
                $db = getDB();
                $uids = array_filter(array_map('intval', explode(',', $ids)), function ($v) { return $v > 0; });
                foreach ($uids as $ucUid) {
                    $localId = uc_find_local($ucUid);
                    if ($localId !== null) {
                        $db->prepare("UPDATE users SET status=0 WHERE id=?")->execute([$localId]);
                    }
                }
            } catch (Throwable $e) {
                error_log('uc deleteuser failed: ' . $e->getMessage());
            }
        }
        exit('1');

    case 'renameuser':
        $uid = (int) ($get['uid'] ?? 0);
        $newName = (string) ($get['newusername'] ?? '');
        if ($uid > 0 && $newName !== '') {
            try {
                $db = getDB();
                $localId = uc_find_local($uid);
                if ($localId !== null) {
                    // 仅在该用户名本地未被占用时改名
                    $chk = $db->prepare("SELECT id FROM users WHERE username=? AND id<>? LIMIT 1");
                    $chk->execute([$newName, $localId]);
                    if (!$chk->fetch()) {
                        $db->prepare("UPDATE users SET username=? WHERE id=?")->execute([$newName, $localId]);
                    }
                }
            } catch (Throwable $e) {
                error_log('uc renameuser failed: ' . $e->getMessage());
            }
        }
        exit('1');

    case 'updatepw':
        // UCenter 侧的密码已加密，本侧无法解密；密码同步以「本侧 -> UCenter」为准，此处仅占位
        exit('1');

    case 'updatebadwords':
    case 'updatehosts':
    case 'updateapps':
    case 'updateclient':
        exit('1');

    default:
        exit('Action not found');
}
