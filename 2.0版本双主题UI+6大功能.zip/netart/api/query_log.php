<?php
/**
 * NetworkPanel - 查询记录上报接口
 *
 * 供纯前端工具（流量计算器 / 字节转换 等本地计算页面）上报查询行为。
 * 服务端查询（api/ip.php / api/ip_advanced.php / api/log.php）直接调用
 * includes/query_log.php 的 logQuery()，无需经过本接口，避免重复记录。
 *
 * POST JSON：{ type, input, summary, access_token? }
 *   - type    : ip | ip_advanced | traffic | byte | speedtest | ip_tools
 *   - input   : 查询输入（最长 1000 字符）
 *   - summary : 结果摘要（最长 500 字符）
 *   - access_token?: 登录用户令牌，用于把游客查询归属到具体账号（可选）
 *
 * 游客（无令牌）记 user_id=0，username='游客'。
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/query_log.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['status' => 1, 'message' => '仅支持 POST 请求'], 405);
}

// 单 IP 限流，防刷（不影响正常用户）
if (!throttle_pass('query_log', 30, 60)) {
    jsonResponse(['status' => 1, 'message' => '提交过于频繁，请稍后再试'], 429);
}

$raw = (string) file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
    $body = $_POST;
}

$type = (string) ($body['type'] ?? request_param('type', ''));
$input = (string) ($body['input'] ?? request_param('input', ''));
$summary = (string) ($body['summary'] ?? request_param('summary', ''));

if ($type === '' || $input === '') {
    jsonResponse(['status' => 1, 'message' => '参数缺失：type 与 input 必填']);
}

$allowed = QUERY_LOG_TYPES;
if (!in_array($type, $allowed, true)) {
    jsonResponse(['status' => 1, 'message' => '不支持的查询类型：' . $type]);
}

// 若前端携带令牌，注入到请求参数中，供 resolveQueryUser() 反查用户
$token = (string) ($body['access_token'] ?? '');
if ($token !== '') {
    $_POST['access_token'] = $token;
}

logQuery($type, $input, $summary);

jsonResponse(['status' => 0, 'message' => 'ok']);
