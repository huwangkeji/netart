<?php
/**
 * NetworkPanel - 后台管理API（需管理员登录）
 * 接口:
 *   GET  ?action=dashboard       仪表盘数据
 *   GET  ?action=nodes          获取节点列表
 *   POST ?action=node_add       添加节点
 *   POST ?action=node_edit      编辑节点
 *   POST ?action=node_delete    删除节点
 *   GET  ?action=users          获取会员列表
 *   POST ?action=user_update    更新会员状态/角色
 *   GET  ?action=settings       获取设置
 *   POST ?action=setting_save   保存设置
 *   GET  ?action=logs           操作日志
 *   GET  ?action=feedback_list  用户反馈列表
 *   GET  ?action=speed_logs     测速记录列表
 *   POST ?action=feedback_reply 回复反馈
 */

// ========== 终极防线：输出缓冲，拦截所有非JSON输出 ==========
if (!headers_sent()) {
    ob_start(function($buffer) {
        // 如果缓冲区包含非空内容且不是JSON开头，说明有异常HTML输出
        $trimmed = trim($buffer);
        if (strlen($trimmed) > 0 && strpos($trimmed, '{') !== 0 && strpos($trimmed, '[') !== 0) {
            // 有非法输出（PHP警告/Notice等），用JSON替换
            return json_encode(['status' => 1, 'message' => '服务器内部错误', 'raw' => substr($trimmed, 0, 500)], JSON_UNESCAPED_UNICODE);
        }
        return $buffer;
    });
}

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/UCenter.php';

// ========== 全局异常/错误兜底：确保始终返回JSON而非HTML ==========
set_exception_handler(function (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    error_log('[admin] 未捕获异常: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    echo json_encode(['status' => 1, 'message' => '服务器内部错误，请稍后重试'], JSON_UNESCAPED_UNICODE);
    exit;
});
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (!(error_reporting() & $errno)) return false;
    throw new ErrorException($errstr, $errno, $errno, $errfile, $errline);
});
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_RECOVERABLE_ERROR])) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        error_log('[admin] PHP致命错误: ' . $error['message'] . ' @ ' . $error['file'] . ':' . $error['line']);
        echo json_encode([
            'status' => 1,
            'message' => '服务器内部错误，请稍后重试'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
});

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type,Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

// 管理员权限验证
$admin = requireAdmin();
$action = $_GET['action'] ?? $_POST['action'] ?? '';
if (empty($action) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawInput = file_get_contents('php://input');
    if ($rawInput) {
        $jsonData = json_decode($rawInput, true);
        $action = $jsonData['action'] ?? '';
    }
}

// 路由分发
try {
    switch ($action) {
        case 'dashboard':     dashboard($admin); break;
        case 'nodes':         listNodes(); break;
        case 'node_add':      addNode($admin); break;
        case 'node_edit':     editNode($admin); break;
        case 'node_delete':   deleteNode($admin); break;
        case 'users':         listUsers(); break;
        case 'user_detail':   getUserDetail(); break;
        case 'user_update':   updateUser($admin); break;
        case 'user_delete':   deleteUser($admin); break;
        case 'settings':      getSettings(); break;
        case 'setting_save':  saveSetting($admin); break;
        case 'logs':          getLogs(); break;
    case 'speed_logs':    getSpeedLogs(); break;
    case 'feedback_list': getFeedbackList(); break;
    case 'feedback_set_status': handleFeedbackSetStatus($admin); break;
    case 'feedback_clear': handleFeedbackClear($admin); break;
    case 'announcements': listAnnouncements(); break;
    case 'announcement_add': addAnnouncement($admin); break;
    case 'announcement_edit': editAnnouncement($admin); break;
    case 'announcement_delete': deleteAnnouncement($admin); break;
    case 'ads': listAds(); break;
    case 'ad_add': addAd($admin); break;
    case 'ad_edit': editAd($admin); break;
    case 'ad_delete': deleteAd($admin); break;
    case 'redirect_settings': getRedirectSettings(); break;
    case 'redirect_settings_save': saveRedirectSettings($admin); break;
    case 'page_list':         listPages(); break;
    case 'page_get':          getPage(); break;
    case 'page_save':         savePage($admin); break;
    case 'page_reset':        resetPage($admin); break;
    case 'query_log_list':   getQueryLogs(); break;
    case 'query_log_delete': deleteQueryLog($admin); break;
    case 'query_log_clear':  clearQueryLogs($admin); break;
        default:              jsonResponse(['status'=>1,'message'=>'无效操作'], 400);
    }
} catch (Exception $e) {
    error_log('[admin] 操作异常: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    jsonResponse(['status' => 1, 'message' => '操作失败，请稍后重试']);
}

/** 需要管理员登录 */
function requireAdmin(): array {
    session_start();
    if (empty($_SESSION['admin_id'])) {
        jsonResponse(['status' => -1, 'message' => '请先登录管理后台'], 401);
    }
    return [
        'id' => (int)$_SESSION['admin_id'],
        'username' => $_SESSION['admin_username'],
        'role'     => $_SESSION['admin_role']
    ];
}

function addLog(array $admin, string $action, string $targetType = '', int $targetId = 0, string $detail = ''): void {
    try {
        $db = getDB();
        $stmt = $db->prepare(
            "INSERT INTO admin_logs (admin_id,`action`,target_type,target_id,detail,ip) VALUES (?,?,?,?,?,?)"
        );
        $stmt->execute([$admin['id'], $action, $targetType, $targetId, $detail, getClientIP()]);
    } catch (Exception $e) { error_log("Log error: ".$e->getMessage()); }
}

// ==================== 仪表盘 ====================
function dashboard(array $admin): void {
    try {
        $db = getDB();

        // 基础统计
        $totalUsers = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $todayUsers = $db->query("SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURDATE()")->fetchColumn();

        // 流量表可能不存在，加保护
        try { $totalTraffic = $db->query("SELECT COALESCE(SUM(bytes_used),0) FROM traffic_logs")->fetchColumn(); } catch (Exception $_) { $totalTraffic = 0; }
        try { $todayTraffic = $db->query("SELECT COALESCE(SUM(bytes_used),0) FROM traffic_logs WHERE DATE(created_at)=CURDATE()")->fetchColumn(); } catch (Exception $_) { $todayTraffic = 0; }

        // 节点表保护
        try { $totalNodes = $db->query("SELECT COUNT(*) FROM nodes")->fetchColumn(); } catch (Exception $_) { $totalNodes = 0; }
        try { $activeNodes = $db->query("SELECT COUNT(*) FROM nodes WHERE `status`=1")->fetchColumn(); } catch (Exception $_) { $activeNodes = 0; }

        // 反馈未读数 - user_feedback 表可能不存在，必须加保护
        try { $unreadFeedback = $db->query("SELECT COUNT(*) FROM user_feedback WHERE `status`=0")->fetchColumn(); } catch (Exception $_) { $unreadFeedback = 0; }

        // 最近7天流量趋势
        $trend = [];
        try {
            $trendStmt = $db->query(
                "SELECT DATE(created_at) as dt, SUM(bytes_used) as bytes "
                . "FROM traffic_logs WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) "
                . "GROUP BY DATE(created_at) ORDER BY dt"
            );
            while ($row = $trendStmt->fetch()) {
                $trend[] = ['date' => $row['dt'], 'bytes' => (float)$row['bytes']];
            }
        } catch (Exception $_) {}

        // 最新用户
        $newUsers = [];
        try {
            $newUsersStmt = $db->query(
                "SELECT id,username,email,role,last_active,created_at FROM users ORDER BY created_at DESC LIMIT 5"
            );
            $newUsers = $newUsersStmt->fetchAll();
        } catch (Exception $_) {}

        // 最新日志
        $recentLogs = [];
        try {
            $logStmt = $db->query(
                "SELECT l.*, a.username as admin_name FROM admin_logs l LEFT JOIN admins a ON l.admin_id=a.id "
                . "ORDER BY l.created_at DESC LIMIT 10"
            );
            $recentLogs = $logStmt->fetchAll();
        } catch (Exception $_) {}

        jsonResponse([
            'status' => 0,
            'data' => [
                'stats' => [
                    'total_users'       => (int)$totalUsers,
                    'today_users'       => (int)$todayUsers,
                    'total_traffic'     => (float)$totalTraffic,
                    'today_traffic'     => (float)$todayTraffic,
                    'total_nodes'       => (int)$totalNodes,
                    'active_nodes'      => (int)$activeNodes,
                    'unread_feedback'   => (int)$unreadFeedback,
                ],
                'trend' => $trend,
                'recent_users' => $newUsers,
                'recent_logs'  => $recentLogs
            ]
        ]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载仪表盘失败：' . $e->getMessage()]);
    }
}

// ==================== 节点CRUD ====================
function listNodes(): void {
    try {
        $db = getDB();
        $id = (int)($_GET['id'] ?? 0);

        // 单条查询（编辑回填用）
        if ($id > 0) {
            $stmt = $db->prepare("SELECT * FROM nodes WHERE id = ?");
            $stmt->execute([$id]);
            $node = $stmt->fetch();
            if (!$node) {
                jsonResponse(['status' => 1, 'message' => '节点不存在'], 404);
            }
            jsonResponse(['status' => 0, 'data' => $node]);
            return;
        }

        // 列表查询
        $group = $_GET['group'] ?? '';
        if ($group) {
            $stmt = $db->prepare("SELECT * FROM nodes WHERE `group_name`=? ORDER BY sort_order ASC");
            $stmt->execute([$group]);
        } else {
            $stmt = $db->query("SELECT * FROM nodes ORDER BY `group_name`, sort_order ASC");
        }
        jsonResponse(['status' => 0, 'data' => $stmt->fetchAll()]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载节点失败：' . $e->getMessage()]);
    }
}

function addNode(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $groupName = trim($input['group_name'] ?? '默认');
    $label = trim($input['label'] ?? '');
    $url = trim($input['url'] ?? '');
    $urlType = in_array($input['url_type'] ?? '', ['http','api']) ? $input['url_type'] : 'http';
    $sortOrder = max(0, min(9999, (int)($input['sort_order'] ?? 0)));
    $description = substr(trim($input['description'] ?? ''), 0, 255);

    if (!$label || !$url) {
        jsonResponse(['status'=>1,'message'=>'节点名称和URL不能为空']);
    }

    $db = getDB();
    $stmt = $db->prepare(
        "INSERT INTO nodes (`group_name`,label,url,url_type,sort_order,description,`status`) VALUES (?,?,?,?,?,?,1)"
    );
    $stmt->execute([$groupName, $label, $url, $urlType, $sortOrder, $description]);

    addLog($admin, 'create', 'node', (int)$db->lastInsertId(), json_encode(['label'=>$label,'url'=>$url]));
    jsonResponse(['status' => 0, 'message' => '添加成功']);
}

function editNode(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $id = (int)($input['id'] ?? 0);
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少节点ID']);

    $sets = [];
    $params = [];

    foreach (['group_name','label','url','url_type','description','status','sort_order'] as $f) {
        if (array_key_exists($f, $input)) {
            if ($f === 'status') $input[$f] = (int)$input[$f];
            if ($f === 'sort_order') $input[$f] = max(0, min(9999, (int)$input[$f]));
            if ($f === 'url_type' && !in_array($input[$f], ['http','api'])) continue;
            $sets[] = "`$f`=?";
            $params[] = $input[$f];
        }
    }

    if (empty($sets)) {
        jsonResponse(['status'=>1,'message'=>'没有需要更新的内容']);
    }
    $params[] = $id;

    $db = getDB();
    $db->prepare("UPDATE nodes SET ".implode(',',$sets).",updated_at=NOW() WHERE id=?")->execute($params);
    addLog($admin, 'update', 'node', $id, json_encode($input));
    jsonResponse(['status' => 0, 'message' => '更新成功']);
}

function deleteNode(array $admin): void {
    $id = (int)(json_decode(file_get_contents('php://input'), true)['id'] ?? ($_POST['id']??0));
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少ID']);

    $db = getDB();
    $db->prepare("DELETE FROM nodes WHERE id=?")->execute([$id]);
    addLog($admin, 'delete', 'node', $id);
    jsonResponse(['status' => 0, 'message' => '删除成功']);
}

// ==================== 会员管理 ====================
function listUsers(): void {
    $db = getDB();
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = max(1, min(100, (int)($_GET['limit'] ?? 20)));
    $search = trim($_GET['search'] ?? '');
    $role = $_GET['role'] ?? '';
    $offset = ($page - 1) * $limit;

    $where = '1=1';
    $params = [];
    if ($search) { $where .= ' AND (username LIKE ? OR email LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($role && in_array($role,['user','vip','admin'])) { $where .= ' AND `role`=?'; $params[] = $role; }

    // 总数
    $stmtCount = $db->prepare("SELECT COUNT(*) FROM users WHERE $where");
    $stmtCount->execute($params);
    $total = (int)$stmtCount->fetchColumn();

    // 列表
    $dataSql = "SELECT id,username,email,headimg,`role`,`status`,total_bytes,total_time,last_active,created_at "
              . "FROM users WHERE $where ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params2 = array_merge($params, [$limit, $offset]);
    $stmtData = $db->prepare($dataSql);
    $stmtData->execute($params2);
    $rows = $stmtData->fetchAll(PDO::FETCH_ASSOC);

    jsonResponse([
        'status' => 0,
        'data' => [
            'list'  => $rows,
            'total' => $total,
            'page'  => $page,
            'limit' => $limit,
        ]
    ]);
}

/** 获取用户详细信息（含注册信息、登录信息、流量统计、最近登录记录） */
function getUserDetail(): void {
    try {
        $db = getDB();
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonResponse(['status'=>1,'message'=>'缺少用户ID']);

        // 基本信息
        $stmt = $db->prepare("SELECT id,username,email,headimg,`role`,`status`,total_bytes,total_time,ip,last_active,created_at,updated_at FROM users WHERE id=?");
        $stmt->execute([$id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) jsonResponse(['status'=>1,'message'=>'用户不存在'], 404);

        // 令牌
        $tokenStmt = $db->prepare("SELECT access_token FROM users WHERE id=?");
        $tokenStmt->execute([$id]);
        $user['access_token'] = $tokenStmt->fetchColumn() ?? '';

        // 最近登录记录（从 traffic_logs 获取，含IP、UA、时间）
        $loginLogs = [];
        try {
            $logStmt = $db->prepare(
                "SELECT ip, user_agent, created_at FROM traffic_logs "
                . "WHERE user_id=? ORDER BY created_at DESC LIMIT 10"
            );
            $logStmt->execute([$id]);
            while ($row = $logStmt->fetch()) {
                $ua = $row['user_agent'] ?? '';
                $browser = parseUserAgent($ua, 'browser');
                $os = parseUserAgent($ua, 'os');
                $loginLogs[] = [
                    'ip' => $row['ip'],
                    'time' => $row['created_at'],
                    'user_agent_raw' => $ua,
                    'browser' => $browser,
                    'os' => $os,
                ];
            }
        } catch (Exception $_) {}

        // 登录次数
        $loginCount = 0;
        try {
            $cnt = $db->prepare("SELECT COUNT(DISTINCT DATE(created_at)) FROM traffic_logs WHERE user_id=?");
            $cnt->execute([$id]);
            $loginCount = (int)$cnt->fetchColumn();
        } catch (Exception $_) {}

        // 流量统计摘要
        $trafficSummary = ['total_bytes' => (float)($user['total_bytes'] ?? 0), 'total_time' => (float)($user['total_time'] ?? 0)];
        try {
            $ts = $db->prepare("SELECT COALESCE(SUM(bytes_used),0) as tb, COALESCE(SUM(duration),0) as tt, COUNT(*) as cnt FROM traffic_logs WHERE user_id=?");
            $ts->execute([$id]);
            $tRow = $ts->fetch();
            if ($tRow) {
                $trafficSummary['log_total_bytes'] = (float)$tRow['tb'];
                $trafficSummary['log_total_time'] = (float)$tRow['tt'];
                $trafficSummary['log_count'] = (int)$tRow['cnt'];
            }
        } catch (Exception $_) {}

        jsonResponse([
            'status' => 0,
            'data' => [
                'user'           => $user,
                'access_token'   => $user['access_token'],
                'traffic_summary' => $trafficSummary,
                'login_count'     => $loginCount,
                'login_logs'      => $loginLogs,
            ]
        ]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '获取用户详情失败：' . $e->getMessage()]);
    }
}

/**
 * 简单解析 UserAgent，提取浏览器和操作系统
 * @return string
 */
function parseUserAgent(string $ua, string $type): string {
    $ua = strtolower($ua);
    if ($type === 'browser') {
        if (strpos($ua, 'edg') !== false) return 'Microsoft Edge';
        if (strpos($ua, 'chrome') !== false) return 'Google Chrome';
        if (strpos($ua, 'firefox') !== false) return 'Mozilla Firefox';
        if (strpos($ua, 'safari') !== false) return 'Safari';
        if (strpos($ua, 'opera') || strpos($ua, 'opr')) return 'Opera';
        if (strpos($ua, 'msie') || strpos($ua, 'trident')) return 'Internet Explorer';
        return '未知浏览器';
    }
    // os
    if (strpos($ua, 'windows nt 10') !== false) return 'Windows 10/11';
    if (strpos($ua, 'windows nt 6.3') !== false) return 'Windows 8.1';
    if (strpos($ua, 'windows nt 6.2') !== false) return 'Windows 8';
    if (strpos($ua, 'windows nt 6.1') !== false) return 'Windows 7';
    if (strpos($ua, 'mac os x') !== false) return 'macOS';
    if (strpos($ua, 'android') !== false) return 'Android';
    if (strpos($ua, 'iphone') || strpos($ua, 'ipad') || strpos($ua, 'ipod')) return 'iOS';
    if (strpos($ua, 'linux') !== false) return 'Linux';
    return '未知系统';
}

function updateUser(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少用户ID']);

    $sets = []; $params = [];
    // 角色（字符串：user/vip/admin）
    if (isset($input['role']) && in_array($input['role'], ['user','vip','admin'])) {
        $sets[] = "`role`=?";
        $params[] = $input['role'];
    }
    // 状态
    if (isset($input['status'])) {
        $sets[] = "`status`=?";
        $params[] = (int)$input['status'];
    }
    // 用户名
    if (isset($input['username']) && trim($input['username']) !== '') {
        $sets[] = "`username`=?";
        $params[] = trim($input['username']);
    }
    // 邮箱
    if (isset($input['email'])) {
        $sets[] = "`email`=?";
        $params[] = trim($input['email']) === '' ? null : trim($input['email']);
    }
    // 密码（非空时才加密更新，写入password_hash列）
    if (!empty($input['password'])) {
        try {
            $db = getDB();
            $cols = $db->query("SHOW COLUMNS FROM users LIKE 'password_hash'");
            if ($cols->rowCount() > 0) {
                $sets[] = "`password_hash`=?";
                $params[] = password_hash(trim($input['password']), PASSWORD_DEFAULT);
            }
        } catch (Exception $_) {}
    }

    if (empty($sets)) jsonResponse(['status'=>1,'message'=>'没有更新内容']);

    $params[] = $id;
    $db = getDB();
    $db->prepare("UPDATE users SET ".implode(',',$sets).",updated_at=NOW() WHERE id=?")->execute($params);
    addLog($admin, 'update_user', 'user', $id, json_encode($input));
    jsonResponse(['status' => 0]);
}

function deleteUser(array $admin): void {
    $id = (int)(json_decode(file_get_contents('php://input'),true)['id'] ?? 0);
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少ID']);
    $db = getDB();
    $db->prepare("UPDATE users SET `status`=0 WHERE id=?")->execute([$id]); // 软删除(禁用)
    addLog($admin, 'disable_user', 'user', $id);
    jsonResponse(['status' => 0]);
}

// ==================== 设置管理 ====================
function getSettings(): void {
    $db = getDB();
    $group = $_GET['group'] ?? '';
    // 读取 UCenter 分组时，先补齐同步策略开关默认值，确保后台表单显示正确
    if ($group === 'ucenter' && function_exists('uc_ensure_defaults')) {
        uc_ensure_defaults();
    }
    if ($group) {
        $stmt = $db->prepare("SELECT * FROM site_settings WHERE `group_name`=? ORDER BY sort_order");
        $stmt->execute([$group]);
    } else {
        $stmt = $db->query("SELECT * FROM site_settings ORDER BY `group_name`,sort_order");
    }
    jsonResponse(['status' => 0, 'data' => $stmt->fetchAll()]);
}

function saveSetting(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;
    $key = trim($input['key'] ?? '');
    $value = $input['value'];

    if (!$key || !isset($value)) {
        jsonResponse(['status'=>1,'message'=>'参数不完整']);
    }

    $db = getDB();
    $stmt = $db->prepare("UPDATE site_settings SET setting_value=?, updated_at=NOW() WHERE setting_key=?");
    $stmt->execute([$value, $key]);

    if ($stmt->rowCount() > 0) {
        addLog($admin, 'update_setting', 'setting', 0, "$key=$value");
        jsonResponse(['status' => 0, 'message' => '保存成功']);
    } else {
        // 记录不存在，尝试INSERT（自动推断group_name）
        try {
            $footerKeys = ['footer_custom_text','footer_copyright','footer_icp','footer_icp_url','friend_links','footer_html','notices'];
            $headerKeys = ['nav_links'];
            $contactKeys = ['site_name','contact_qq','contact_qq_group','contact_email'];
            if (in_array($key, $footerKeys)) {
                $group = 'footer';
                $titleMap = [
                    'notices' => '公告/广告内容',
                    'footer_html' => '自定义HTML代码',
                    'friend_links' => '友情链接',
                ];
                $title = $titleMap[$key] ?? '底部设置';
            } elseif (in_array($key, $headerKeys)) {
                $group = 'header';
                $title = '顶部导航链接';
            } elseif (in_array($key, $contactKeys)) {
                $group = 'contact';
                $title = '联系信息';
            } else {
                $group = 'custom';
                $title = '手动添加';
            }
            $ins = $db->prepare("INSERT IGNORE INTO site_settings (setting_key, setting_value, title, `group_name`) VALUES (?, ?, ?, ?)");
            $ins->execute([$key, $value, $title, $group]);

            if ($ins->rowCount() === 0) {
                $stmt2 = $db->prepare("UPDATE site_settings SET setting_value=?, updated_at=NOW() WHERE setting_key=?");
                $stmt2->execute([$value, $key]);
            }
            jsonResponse(['status' => 0, 'message' => '已新增并保存']);
        } catch (Exception $e) {
            jsonResponse(['status' => 1, 'message' => '保存失败：' . $e->getMessage()]);
        }
    }
}

// ==================== 操作日志 ====================
function getLogs(): void {
    try {
        $db = getDB();
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = max(1, min(50, (int)($_GET['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;

        try { $count = $db->query("SELECT COUNT(*) FROM admin_logs")->fetchColumn(); } catch (Exception $_) { $count = 0; }
        try {
            $stmt = $db->query(
                "SELECT l.*, a.username as admin_name FROM admin_logs l "
                ."LEFT JOIN admins a ON l.admin_id=a.id ORDER BY l.created_at DESC LIMIT $limit OFFSET $offset"
            );
            $rows = $stmt->fetchAll();
        } catch (Exception $_) { $rows = []; }

        jsonResponse([
            'status' => 0,
            'data' => [
                'list'  => $rows,
                'total' => (int)$count,
                'page'  => $page
            ]
        ]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载日志失败：' . $e->getMessage()]);
    }
}

// ==================== 测速记录 ====================
function getSpeedLogs(): void {
    try {
        $db = getDB();

        // 确保表存在，不存在则自动创建
        ensureTrafficLogTable($db);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = max(1, min(50, (int)($_GET['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;
        $keyword = trim($_GET['keyword'] ?? '');

        // 构建查询条件（兼容列可能不存在的情况）
        $hasUrl = hasColumn($db, 'traffic_logs', 'url');
        $hasUA = hasColumn($db, 'traffic_logs', 'user_agent');
        $selectCols = 't.id, t.user_id, COALESCE(u.username, \'游客\') as username';
        if ($hasUrl) $selectCols .= ', t.url';
        if (hasColumn($db, 'traffic_logs', 'thread_num')) $selectCols .= ', t.thread_num';
        if (hasColumn($db, 'traffic_logs', 'bytes_used')) $selectCols .= ', t.bytes_used';
        if (hasColumn($db, 'traffic_logs', 'duration')) $selectCols .= ', t.duration';
        if (hasColumn($db, 'traffic_logs', 'speed')) $selectCols .= ', t.speed';
        if (hasColumn($db, 'traffic_logs', 'ip')) $selectCols .= ', t.ip';
        if ($hasUA) $selectCols .= ', t.user_agent';
        $selectCols .= ', t.created_at';

        $where = '1=1';
        $params = [];
        if (!empty($keyword) && $hasUrl && $hasUA) {
            $where .= ' AND (t.url LIKE ? OR t.user_agent LIKE ? OR u.username LIKE ?)';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
            $params[] = '%' . $keyword . '%';
        } elseif (!empty($keyword)) {
            $where .= ' AND u.username LIKE ?';
            $params[] = '%' . $keyword . '%';
        }

        $countSql = "SELECT COUNT(*) FROM traffic_logs t LEFT JOIN users u ON t.user_id=u.id WHERE $where";
        $countStmt = $db->prepare($countSql);
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sql = "SELECT $selectCols FROM traffic_logs t LEFT JOIN users u ON t.user_id=u.id "
              . "WHERE $where ORDER BY t.created_at DESC LIMIT ? OFFSET ?";
        $stmt = $db->prepare($sql);
        $listParams = array_merge($params, [$limit, $offset]);
        $stmt->execute($listParams);
        $rows = $stmt->fetchAll();

        jsonResponse([
            'status' => 0,
            'data' => [
                'list'   => $rows,
                'total'  => $total,
                'page'   => $page,
                'limit'  => $limit,
                'diag'   => [
                    'table_exists' => true,
                    'has_url'      => $hasUrl,
                    'has_ua'       => $hasUA,
                    'row_count'    => $total,
                ],
            ]
        ]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载测速记录失败：' . $e->getMessage()]);
    }
}

/* ============================================================
 * 查询记录管理（用户 / 游客查询行为溯源）
 * ============================================================ */

function getQueryLogs(): void {
    try {
        $db = getDB();

        // 确保表存在（幂等）
        $db->exec(
            "CREATE TABLE IF NOT EXISTS `query_logs` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED DEFAULT 0 COMMENT '用户ID，0表示游客',
                `username` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '用户名或游客标识',
                `query_type` VARCHAR(32) NOT NULL DEFAULT '' COMMENT '查询类型',
                `query_input` VARCHAR(1000) NOT NULL DEFAULT '' COMMENT '查询输入',
                `result_summary` VARCHAR(500) NOT NULL DEFAULT '' COMMENT '结果摘要',
                `ip` VARCHAR(45) DEFAULT '' COMMENT '客户端IP',
                `user_agent` VARCHAR(500) DEFAULT '' COMMENT '浏览器UA',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '查询时间',
                INDEX `idx_user_id` (`user_id`),
                INDEX `idx_query_type` (`query_type`),
                INDEX `idx_created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='前台查询记录表'"
        );

        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = max(1, min(50, (int)($_GET['limit'] ?? 20)));
        $offset = ($page - 1) * $limit;
        $keyword = trim($_GET['keyword'] ?? '');
        $type = trim($_GET['type'] ?? '');

        $where = '1=1';
        $params = [];
        if ($type !== '') {
            $where .= ' AND query_type = ?';
            $params[] = $type;
        }
        if ($keyword !== '') {
            $where .= ' AND (username LIKE ? OR ip LIKE ? OR query_input LIKE ? OR result_summary LIKE ?)';
            $kw = '%' . $keyword . '%';
            $params[] = $kw; $params[] = $kw; $params[] = $kw; $params[] = $kw;
        }

        $countStmt = $db->prepare("SELECT COUNT(*) FROM query_logs WHERE $where");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sql = "SELECT id, user_id, username, query_type, query_input, result_summary, ip, user_agent, created_at "
             . "FROM query_logs WHERE $where ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $stmt = $db->prepare($sql);
        $stmt->execute(array_merge($params, [$limit, $offset]));
        $rows = $stmt->fetchAll();

        jsonResponse([
            'status' => 0,
            'data'   => [
                'list'  => $rows,
                'total' => $total,
                'page'  => $page,
                'limit' => $limit,
            ]
        ]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载查询记录失败：' . $e->getMessage()]);
    }
}

function deleteQueryLog(array $admin): void {
    $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
    if ($id <= 0) {
        jsonResponse(['status' => 1, 'message' => '无效的记录ID']);
    }
    try {
        $db = getDB();
        $db->prepare("DELETE FROM query_logs WHERE id = ?")->execute([$id]);
        addLog($admin, 'delete', 'query_log', $id, '删除查询记录 #' . $id);
        jsonResponse(['status' => 0, 'message' => '已删除']);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '删除失败：' . $e->getMessage()]);
    }
}

function clearQueryLogs(array $admin): void {
    try {
        $db = getDB();
        $cnt = $db->exec("DELETE FROM query_logs");
        addLog($admin, 'clear', 'query_log', 0, '清空全部查询记录（' . ((int)$cnt) . ' 条）');
        jsonResponse(['status' => 0, 'message' => '已清空 ' . ((int)$cnt) . ' 条记录']);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '清空失败：' . $e->getMessage()]);
    }
}

/**
 * 确保 traffic_logs 表存在，不存在则自动创建完整结构
 */
function ensureTrafficLogTable(PDO $db): void {
    try {
        $db->query("SELECT 1 FROM traffic_logs LIMIT 1");
    } catch (Exception $_) {
        $db->exec(
            "CREATE TABLE IF NOT EXISTS `traffic_logs` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '用户ID，0表示游客',
                `url` VARCHAR(500) NOT NULL DEFAULT '' COMMENT '测速URL/节点地址',
                `thread_num` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '线程数',
                `bytes_used` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '消耗流量(字节)',
                `duration` DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '耗时(秒)',
                `speed` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '平均速度(B/s)',
                `ip` VARCHAR(45) NOT NULL DEFAULT '' COMMENT '客户端IP',
                `user_agent` VARCHAR(500) NOT NULL DEFAULT '' COMMENT '浏览器UA',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
                INDEX `idx_user_id` (`user_id`),
                INDEX `idx_created_at` (`created_at`),
                INDEX `idx_url` (`url`(100))
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测速流量日志'"
        );
    }
}

/** 检查表中是否存在某列 */
function hasColumn(PDO $db, string $table, string $col): bool {
    static $cache = [];
    $key = "$table.$col";
    if (isset($cache[$key])) return $cache[$key];
    // 防御性校验：表名/列名仅允许合法标识符字符，杜绝任何注入面
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $table) || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $col)) {
        $cache[$key] = false;
        return false;
    }
    try {
        $s = $db->query("SHOW COLUMNS FROM `$table` LIKE '$col'");
        $exists = $s->rowCount() > 0;
        $cache[$key] = $exists;
        return $exists;
    } catch (Exception $_) { return false; }
}

// ==================== 用户反馈管理 ====================
function getFeedbackList(): void {
    try {
        $db = getDB();

        // 兜底：自动检查并创建表
        ensureAdminFeedbackTable($db);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = max(1, min(50, (int)($_GET['limit'] ?? 20)));
        $statusRaw = $_GET['status'] ?? '';
        $status = $statusRaw !== '' ? (int)$statusRaw : null;
        $offset = ($page - 1) * $limit;

        $where = '1=1';
        $params = [];
        if ($status !== null) {
            $where .= ' AND `status`=?';
            $params[] = $status;
        }

        $countStmt = $db->prepare("SELECT COUNT(*) FROM user_feedback WHERE $where");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        // 诊断信息：总条数
        $sql = "SELECT f.* FROM user_feedback f WHERE $where ORDER BY f.created_at DESC LIMIT ? OFFSET ?";
        $listParams = array_merge($params, [$limit, $offset]);
        $stmt = $db->prepare($sql);
        $stmt->execute($listParams);

        $rows = $stmt->fetchAll();

        jsonResponse([
            'status' => 0,
            'data' => [
                'list'  => $rows,
                'total' => $total,
                'page'  => $page,
                'limit' => $limit,
            ]
        ]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载反馈列表失败：' . $e->getMessage()]);
    }
}

/**
 * 确保 user_feedback 表存在（admin 端独立函数，避免依赖 auth.php）
 */
function ensureAdminFeedbackTable(PDO $db): void {
    try {
        $db->query("SELECT 1 FROM user_feedback LIMIT 1");
    } catch (Exception $e) {
        $db->exec(
            "CREATE TABLE IF NOT EXISTS `user_feedback` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT UNSIGNED NOT NULL,
                `username` VARCHAR(50) NOT NULL DEFAULT '',
                `content` TEXT NOT NULL,
                `status` TINYINT DEFAULT 0 COMMENT '0未读 1已读 2已处理',
                `reply` TEXT DEFAULT NULL,
                `ip` VARCHAR(45) DEFAULT '',
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                `replied_at` DATETIME DEFAULT NULL,
                INDEX `idx_user_id` (`user_id`),
                INDEX `idx_status` (`status`),
                INDEX `idx_created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户反馈表'"
        );
    }
}

/** 设置反馈状态（快捷操作：待处理/已读/已处理） */
function handleFeedbackSetStatus(array $admin): void {
    try {
        $raw = file_get_contents('php://input');
        $input = json_decode($raw, true) ?: $_POST;

        $id = (int)($input['id'] ?? 0);
        if (!$id) jsonResponse(['status'=>1,'message'=>'缺少反馈ID']);

        $newStatus = in_array((int)($input['status'] ?? -1), [0,1,2]) ? (int)$input['status'] : null;
        if ($newStatus === null) jsonResponse(['status'=>1,'message'=>'无效状态值（需0/1/2）']);

        $db = getDB();
        $stmt = $db->prepare("UPDATE user_feedback SET `status`=?, replied_at=NOW() WHERE id=?");
        $stmt->execute([$newStatus, $id]);

        if ($stmt->rowCount() > 0) {
            $statusNames = [0=>'待处理', 1=>'已读', 2=>'已处理'];
            addLog($admin, 'set_feedback_status', 'feedback', $id, "状态改为: ".$statusNames[$newStatus]);
            jsonResponse(['status' => 0, 'message' => '状态已更新']);
        } else {
            jsonResponse(['status' => 1, 'message' => '反馈不存在或状态未变化']);
        }
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '操作失败：' . $e->getMessage()]);
    }
}

/** 清空所有用户反馈 */
function handleFeedbackClear(array $admin): void {
    try {
        $db = getDB();

        // 先确保表存在
        ensureAdminFeedbackTable($db);

        // 检查是否有数据
        $count = $db->query("SELECT COUNT(*) FROM user_feedback")->fetchColumn();
        if ($count == 0) {
            jsonResponse(['status' => 1, 'message' => '当前没有需要清空的反馈数据']);
            return;
        }

        // 清空表（TRUNCATE更快且重置自增ID，或用DELETE保留ID）
        $rawInput = file_get_contents('php://input');
        $input = json_decode($rawInput, true) ?: [];
        $hardReset = !empty($input['hard_reset']); // 是否重置ID

        if ($hardReset) {
            $db->exec("TRUNCATE TABLE `user_feedback`");
        } else {
            $db->exec("DELETE FROM `user_feedback`");
        }

        addLog($admin, 'clear_feedback', 'feedback', 0, "清空了 {$count} 条反馈数据");
        jsonResponse(['status' => 0, 'message' => "已成功清空 {$count} 条反馈记录"]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '清空失败：' . $e->getMessage()]);
    }
}

// ==================== 公告管理CRUD ====================
function ensureAnnouncementsTable(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS `announcements` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `title` VARCHAR(100) DEFAULT '公告',
        `content` TEXT NOT NULL,
        `status` TINYINT DEFAULT 1,
        `sort_order` INT DEFAULT 0,
        `show_popup` TINYINT DEFAULT 1,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_status` (`status`),
        INDEX `idx_sort` (`sort_order`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function listAnnouncements(): void {
    try {
        $db = getDB();
        ensureAnnouncementsTable($db);
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $stmt = $db->prepare("SELECT * FROM announcements WHERE id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if (!$row) jsonResponse(['status' => 1, 'message' => '公告不存在'], 404);
            jsonResponse(['status' => 0, 'data' => $row]);
            return;
        }
        $stmt = $db->query("SELECT * FROM announcements ORDER BY sort_order ASC, id DESC");
        jsonResponse(['status' => 0, 'data' => $stmt->fetchAll()]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载公告失败：' . $e->getMessage()]);
    }
}

function addAnnouncement(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;
    $title = trim($input['title'] ?? '公告');
    $content = trim($input['content'] ?? '');
    $status = (int)($input['status'] ?? 1);
    $sortOrder = max(0, min(9999, (int)($input['sort_order'] ?? 0)));
    $showPopup = (int)($input['show_popup'] ?? 1);
    if (!$content) jsonResponse(['status'=>1,'message'=>'公告内容不能为空']);
    $db = getDB();
    ensureAnnouncementsTable($db);
    $stmt = $db->prepare("INSERT INTO announcements (title,content,status,sort_order,show_popup) VALUES (?,?,?,?,?)");
    $stmt->execute([$title, $content, $status, $sortOrder, $showPopup]);
    addLog($admin, 'create', 'announcement', (int)$db->lastInsertId(), json_encode(['title'=>$title]));
    jsonResponse(['status' => 0, 'message' => '添加成功']);
}

function editAnnouncement(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少公告ID']);
    $sets = [];
    $params = [];
    foreach (['title','content','status','sort_order','show_popup'] as $f) {
        if (array_key_exists($f, $input)) {
            if ($f === 'status') $input[$f] = (int)$input[$f];
            if ($f === 'sort_order') $input[$f] = max(0, min(9999, (int)$input[$f]));
            if ($f === 'show_popup') $input[$f] = (int)$input[$f];
            $sets[] = "`$f`=?";
            $params[] = $input[$f];
        }
    }
    if (empty($sets)) jsonResponse(['status'=>1,'message'=>'没有需要更新的内容']);
    $params[] = $id;
    $db = getDB();
    ensureAnnouncementsTable($db);
    $db->prepare("UPDATE announcements SET ".implode(',',$sets).",updated_at=NOW() WHERE id=?")->execute($params);
    addLog($admin, 'update', 'announcement', $id, json_encode($input));
    jsonResponse(['status' => 0, 'message' => '更新成功']);
}

function deleteAnnouncement(array $admin): void {
    $id = (int)(json_decode(file_get_contents('php://input'), true)['id'] ?? ($_POST['id']??0));
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少ID']);
    $db = getDB();
    $db->prepare("DELETE FROM announcements WHERE id=?")->execute([$id]);
    addLog($admin, 'delete', 'announcement', $id);
    jsonResponse(['status' => 0, 'message' => '删除成功']);
}

// ==================== 广告管理CRUD ====================
function ensureAdsTable(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS `ads` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        `title` VARCHAR(200) NOT NULL,
        `url` VARCHAR(500) NOT NULL,
        `color` VARCHAR(20) DEFAULT '',
        `status` TINYINT DEFAULT 1,
        `sort_order` INT DEFAULT 0,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_status` (`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function listAds(): void {
    try {
        $db = getDB();
        ensureAdsTable($db);
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $stmt = $db->prepare("SELECT * FROM ads WHERE id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if (!$row) jsonResponse(['status' => 1, 'message' => '广告不存在'], 404);
            jsonResponse(['status' => 0, 'data' => $row]);
            return;
        }
        $stmt = $db->query("SELECT * FROM ads ORDER BY sort_order ASC, id DESC");
        jsonResponse(['status' => 0, 'data' => $stmt->fetchAll()]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '加载广告失败：' . $e->getMessage()]);
    }
}

function addAd(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;
    $title = trim($input['title'] ?? '');
    $url = trim($input['url'] ?? '');
    $color = trim($input['color'] ?? '');
    $status = (int)($input['status'] ?? 1);
    $sortOrder = max(0, min(9999, (int)($input['sort_order'] ?? 0)));
    if (!$title || !$url) jsonResponse(['status'=>1,'message'=>'广告文字和链接不能为空']);
    $db = getDB();
    ensureAdsTable($db);
    $stmt = $db->prepare("INSERT INTO ads (title,url,color,status,sort_order) VALUES (?,?,?,?,?)");
    $stmt->execute([$title, $url, $color, $status, $sortOrder]);
    addLog($admin, 'create', 'ad', (int)$db->lastInsertId(), json_encode(['title'=>$title]));
    jsonResponse(['status' => 0, 'message' => '添加成功']);
}

function editAd(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少广告ID']);
    $sets = [];
    $params = [];
    foreach (['title','url','color','status','sort_order'] as $f) {
        if (array_key_exists($f, $input)) {
            if ($f === 'status') $input[$f] = (int)$input[$f];
            if ($f === 'sort_order') $input[$f] = max(0, min(9999, (int)$input[$f]));
            $sets[] = "`$f`=?";
            $params[] = $input[$f];
        }
    }
    if (empty($sets)) jsonResponse(['status'=>1,'message'=>'没有需要更新的内容']);
    $params[] = $id;
    $db = getDB();
    ensureAdsTable($db);
    $db->prepare("UPDATE ads SET ".implode(',',$sets).",updated_at=NOW() WHERE id=?")->execute($params);
    addLog($admin, 'update', 'ad', $id, json_encode($input));
    jsonResponse(['status' => 0, 'message' => '更新成功']);
}

function deleteAd(array $admin): void {
    $id = (int)(json_decode(file_get_contents('php://input'), true)['id'] ?? ($_POST['id']??0));
    if (!$id) jsonResponse(['status'=>1,'message'=>'缺少ID']);
    $db = getDB();
    $db->prepare("DELETE FROM ads WHERE id=?")->execute([$id]);
    addLog($admin, 'delete', 'ad', $id);
    jsonResponse(['status' => 0, 'message' => '删除成功']);
}

// ==================== 跳转页配置 ====================
function getRedirectSettings(): void {
    try {
        $db = getDB();
        $defaults = [
            'redirect_title' => '广告跳转提示',
            'redirect_loading_text' => '广告加载中，请稍后...',
            'redirect_disclaimer' => '本站不担保任何广告内容，网络交易请谨慎自行甄别。如遇欺诈或纠纷，请联系管理员投诉下架该广告。',
            'redirect_countdown' => '5'
        ];
        $result = [];
        foreach ($defaults as $key => $defVal) {
            $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key=?");
            $stmt->execute([$key]);
            $row = $stmt->fetch();
            $result[$key] = $row ? $row['setting_value'] : $defVal;
        }
        jsonResponse(['status' => 0, 'data' => $result]);
    } catch (Exception $e) {
        jsonResponse(['status' => 1, 'message' => '获取跳转配置失败']);
    }
}

function saveRedirectSettings(array $admin): void {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;
    $db = getDB();
    $count = 0;
    foreach (['redirect_title','redirect_loading_text','redirect_disclaimer','redirect_countdown'] as $key) {
        if (isset($input[$key])) {
            // 修复：原语句写入了不存在的 settings 表与 setting_group 列，导致跳转页配置无法保存
            $stmt = $db->prepare("INSERT INTO site_settings (setting_key,setting_value,setting_type,title,`group_name`) VALUES (?,?,'string',?,'redirect') ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_at=NOW()");
            $stmt->execute([$key, $input[$key], $key]);
            $count++;
        }
    }
    addLog($admin, 'update', 'redirect_settings', 0, json_encode($input));
    jsonResponse(['status' => 0, 'message' => "已保存 {$count} 项配置"]);
}

/* ============================================================
 * 自定义页面内容（用户协议 / 隐私政策）
 * ============================================================ */

function listPages(): void {
    require_once __DIR__ . '/../includes/pages.php';

    try {
        $list = [];
        foreach (array_keys(page_definitions()) as $slug) {
            $page = page_get($slug);
            $list[] = [
                'slug' => $page['slug'],
                'title' => $page['title'],
                'description' => $page['description'],
                'url' => '../' . $page['slug'] . '.php',
                'updated_at' => $page['updated_at'],
                'is_custom' => $page['is_custom'] ? 1 : 0,
                'length' => function_exists('mb_strlen') ? mb_strlen(strip_tags($page['content'])) : strlen(strip_tags($page['content'])),
            ];
        }
        jsonResponse(['status' => 0, 'data' => $list]);
    } catch (Throwable $e) {
        jsonResponse(['status' => 1, 'message' => '获取页面列表失败：' . $e->getMessage()]);
    }
}

function getPage(): void {
    require_once __DIR__ . '/../includes/pages.php';

    $slug = trim($_GET['slug'] ?? '');
    if ($slug === '' || !page_exists($slug)) {
        jsonResponse(['status' => 1, 'message' => '未知的页面标识']);
    }

    try {
        $page = page_get($slug);
        jsonResponse([
            'status' => 0,
            'data' => [
                'slug' => $page['slug'],
                'title' => $page['title'],
                'content' => $page['content'],
                'updated_at' => $page['updated_at'],
                'is_custom' => $page['is_custom'] ? 1 : 0,
            ],
        ]);
    } catch (Throwable $e) {
        jsonResponse(['status' => 1, 'message' => '获取页面内容失败：' . $e->getMessage()]);
    }
}

function savePage(array $admin): void {
    require_once __DIR__ . '/../includes/pages.php';

    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $slug = trim($input['slug'] ?? '');
    $content = $input['content'] ?? null;

    if ($slug === '' || !page_exists($slug)) {
        jsonResponse(['status' => 1, 'message' => '未知的页面标识']);
    }
    if ($content === null || !is_string($content)) {
        jsonResponse(['status' => 1, 'message' => '内容不能为空']);
    }

    $result = page_save($slug, $content);
    if (!$result['ok']) {
        jsonResponse(['status' => 1, 'message' => $result['message']]);
    }

    addLog($admin, 'update', 'page', 0, '更新页面内容：' . $slug);
    jsonResponse(['status' => 0, 'message' => $result['message']]);
}

function resetPage(array $admin): void {
    require_once __DIR__ . '/../includes/pages.php';

    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: $_POST;

    $slug = trim($input['slug'] ?? $_POST['slug'] ?? '');
    if ($slug === '' || !page_exists($slug)) {
        jsonResponse(['status' => 1, 'message' => '未知的页面标识']);
    }

    $result = page_reset($slug);
    if (!$result['ok']) {
        jsonResponse(['status' => 1, 'message' => $result['message']]);
    }

    addLog($admin, 'reset', 'page', 0, '恢复默认内容：' . $slug);
    jsonResponse(['status' => 0, 'message' => $result['message']]);
}
