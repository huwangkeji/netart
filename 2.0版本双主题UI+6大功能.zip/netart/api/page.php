<?php
/**
 * 自定义页面内容 API（用户协议 / 隐私政策）
 *
 * GET /api/page.php?slug=agreement   获取用户协议
 * GET /api/page.php?slug=privacy     获取隐私政策
 * GET /api/page.php                  获取全部页面清单
 *
 * 响应：{status:0, data:{slug,title,content,html,updated_at,is_custom}}
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/pages.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if (request_method() === 'OPTIONS') {
    exit(0);
}

if (request_method() !== 'GET') {
    api_fail('仅支持 GET 请求', 405);
}

$slug = (string) request_param('slug', '');

if ($slug === '') {
    $list = [];
    foreach (array_keys(page_definitions()) as $key) {
        $page = page_get($key);
        $list[] = [
            'slug' => $page['slug'],
            'title' => $page['title'],
            'description' => $page['description'],
            'updated_at' => $page['updated_at'],
            'is_custom' => $page['is_custom'],
        ];
    }

    api_ok($list);
}

if (!page_exists($slug)) {
    api_fail('未知的页面标识：' . $slug, 404);
}

$page = page_get($slug);

api_ok([
    'slug' => $page['slug'],
    'title' => $page['title'],
    'description' => $page['description'],
    'content' => $page['content'],
    'html' => $page['html'],
    'updated_at' => $page['updated_at'],
    'is_custom' => $page['is_custom'],
]);
