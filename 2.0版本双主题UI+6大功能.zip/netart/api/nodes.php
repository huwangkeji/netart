<?php
/**
 * NetworkPanel - 公开节点列表API（无需登录）
 * 返回所有启用状态的节点供前台测速使用
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type,Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

try {
    $db = getDB();
    $stmt = $db->query("SELECT `group_name`, label, url, url_type, `status` FROM nodes WHERE `status`=1 ORDER BY `group_name`, sort_order ASC");
    $nodes = $stmt->fetchAll();
    jsonResponse(['status' => 0, 'data' => $nodes]);
} catch (Exception $e) {
    jsonResponse(['status' => 1, 'message' => '加载节点失败']);
}
