<?php
/**
 * UCenter 连通性诊断工具
 *
 * 用法：
 *   命令行： php api/ucenter_diag.php
 *   浏览器： http://域名/api/ucenter_diag.php?run=1
 *
 * 用于定位“通信失败：UCenter 未返回有效数据”的根因：
 *   1) uc_enabled / uc_api / uc_key 是否就绪
 *   2) uc_appid 是否配置（服务端靠 appid 识别应用，缺省会返回空）
 *   3) UC_API 网络是否可达
 *   4) 真实接口调用是否返回有效数据
 *
 * 注意：uc_key 等敏感字段会被脱敏，仅用于本地排障。
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/site_settings.php';
require_once __DIR__ . '/../includes/UCenter.php';

if (PHP_SAPI !== 'cli' && ($_GET['run'] ?? '') !== '1') {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "拒绝访问：请使用 php api/ucenter_diag.php 或在 URL 后追加 ?run=1 运行诊断。\n";
    exit;
}

$report = uc_diagnose();

if (PHP_SAPI === 'cli') {
    echo "===== UCenter 诊断报告 =====\n";
    echo "启用状态: " . ($report['enabled'] ? "是" : "否") . "\n";
    echo "配置:\n";
    foreach ($report['config'] as $k => $v) {
        echo "  {$k} = " . (is_scalar($v) ? $v : json_encode($v, JSON_UNESCAPED_UNICODE)) . "\n";
    }
    echo "检查项:\n";
    foreach ($report['checks'] as $c) {
        echo "  [" . ($c['ok'] ? "OK" : "FAIL") . "] {$c['name']}: {$c['detail']}\n";
        if (isset($c['raw']) && $c['raw'] !== null) {
            echo "      raw: " . $c['raw'] . "\n";
        }
    }
} else {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($report, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}
