<?php
/**
 * NetworkPanel - URL解析API
 * 对应原版: url.ajax
 * 
 * GET参数:
 *   host - NetworkPanelApi:// 协议中的主机名
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$host = $_GET['host'] ?? '';
$cacheHost = $_GET['cache'] ?? ''; // 来源域名（用于缓存key）

if (empty($host)) {
    jsonResponse(['status' => 1, 'message' => '缺少host参数']);
}

// 预定义的NetworkPanelApi映射表（对应实际可用的大文件下载地址）
$urlMappings = [
    'listen.10155.com' => [
        // 联通电视音频流（持续输出的大文件）
        'urls' => [
            'https://audio-ssl.itrfm.cn/live/1024.mp3',
        ],
    ],
];

try {
    if (isset($urlMappings[$host])) {
        $mapping = $urlMappings[$host];
        if (isset($mapping['urls']) && is_array($mapping['urls'])) {
            $url = $mapping['urls'][array_rand($mapping['urls'])];
        } elseif (isset($mapping['url'])) {
            $url = $mapping['url'];
        } else {
            throw new Exception('无效的映射配置');
        }
        jsonResponse(['status' => 0, 'url' => $url]);
    } else {
        jsonResponse(['status' => 1, 'message' => '未知的节点: ' . $host]);
    }
} catch (Exception $e) {
    jsonResponse(['status' => 1, 'message' => $e->getMessage()]);
}
