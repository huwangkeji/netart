<?php
/**
 * 工具计算 API（字节转换 / 流量计算）
 *
 * 请求方式：
 *   POST /api/tools.php?action=convert        单位互转      {value, from_unit, to_unit}
 *   POST /api/tools.php?action=convert_all    转全部单位    {value, from_unit}
 *   GET|POST /api/tools.php?action=calc_traffic 流量计算    {speed, unit, price}
 *
 * 统一响应：{status:0, message, data} / {status:1, message}
 * 计算口径与前端保持一致，均由 includes/units.php 提供，避免前后端结果不一致。
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/units.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if (request_method() === 'OPTIONS') {
    exit(0);
}

$action = (string) request_param('action', '');

if (!throttle_pass('tools_' . $action, 120, 60)) {
    api_fail('请求过于频繁，请稍后再试', 429);
}

switch ($action) {
    case 'convert':
        convert_action();
        break;
    case 'convert_all':
        convertAll_action();
        break;
    case 'calc_traffic':
        calcTraffic_action();
        break;
    default:
        api_fail('无效的操作：' . $action, 404);
}

/**
 * 单位互转
 */
function convert_action(): void
{
    $value = (float) request_param('value', 0);
    $from = strtoupper((string) request_param('from_unit', 'B'));
    $to = strtoupper((string) request_param('to_unit', 'B'));

    if (!is_valid_unit($from) || !is_valid_unit($to)) {
        api_fail('无效的单位，仅支持：' . implode('、', array_keys(unit_factors())), 400);
    }
    if ($value < 0) {
        api_fail('请输入非负数值', 400);
    }

    try {
        $result = convert_bytes($value, $from, $to);
    } catch (Throwable $e) {
        api_fail($e->getMessage(), 400);
    }

    api_ok([
        'value' => number_trim($result),
        'from' => number_trim($value) . ' ' . $from,
        'to' => number_trim($result) . ' ' . $to,
        'bytes' => number_trim($value * unit_factors()[$from]),
    ]);
}

/**
 * 转换为全部单位
 */
function convertAll_action(): void
{
    $value = (float) request_param('value', 0);
    $from = strtoupper((string) request_param('from_unit', 'B'));

    if (!is_valid_unit($from)) {
        api_fail('无效的单位，仅支持：' . implode('、', array_keys(unit_factors())), 400);
    }
    if ($value < 0) {
        api_fail('请输入非负数值', 400);
    }

    try {
        $results = convert_to_all_units($value, $from);
    } catch (Throwable $e) {
        api_fail($e->getMessage(), 400);
    }

    api_ok([
        'input' => ['value' => number_trim($value), 'unit' => $from],
        'results' => array_map(static function (array $item): array {
            return [
                'unit' => $item['unit'],
                'value' => $item['value'],
            ];
        }, $results),
    ]);
}

/**
 * 流量与费用计算
 */
function calcTraffic_action(): void
{
    $speed = request_param('speed', null);
    $unit = (string) request_param('unit', 'Mbps');
    $price = (float) request_param('price', 0);

    if ($speed === null || !is_numeric($speed)) {
        api_fail('请输入有效的网络速率', 400);
    }

    $speed = (float) $speed;

    if ($speed < 0) {
        api_fail('网络速率不能为负数', 400);
    }
    if (!is_valid_rate_unit($unit)) {
        api_fail('无效的速率单位，仅支持 Kbps / Mbps / Gbps', 400);
    }
    if ($price < 0) {
        $price = 0.0;
    }

    try {
        $report = traffic_report($speed, $unit, $price);
    } catch (Throwable $e) {
        api_fail($e->getMessage(), 400);
    }

    api_ok([
        'input' => [
            'speed' => number_trim($report['input']['speed']),
            'unit' => $report['input']['unit'],
            'price' => number_trim($report['input']['price'], 4),
            'mb_per_second' => number_trim($report['input']['mb_per_second'], 4),
        ],
        'rows' => array_map(static function (array $row): array {
            return [
                'label' => $row['label'],
                'traffic' => $row['traffic'],
                'gigabytes' => (float) number_format($row['gigabytes'], 4, '.', ''),
                'cost' => $row['cost'],
            ];
        }, $report['rows']),
    ]);
}
