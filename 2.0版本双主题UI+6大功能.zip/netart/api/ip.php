<?php
/**
 * IP / 域名归属查询 API
 *
 * 请求：
 *   GET|POST /api/ip.php                  查询客户端本机出口 IP
 *   GET|POST /api/ip.php?target=8.8.8.8   查询指定 IP 或域名（推荐）
 *   GET|POST /api/ip.php?ip=8.8.8.8       同上（旧参数，保留以兼容首页 js/app.js 调用）
 *
 * 响应（与首页既有契约一致）：
 *   {status:0, message:'ok', data:{ip, type, country:{code,name}, registered_country:{...},
 *    regions:[], regions_short:[], as:{number,name,info}, addr, isp, location, source, cached, private}}
 *   {status:1, message:'错误原因', data:null}
 *
 * 能力：IPv4 / IPv6 / 域名解析、内网判定、24 小时缓存、多数据源回退、简单限流。
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/ip_service.php';
require_once __DIR__ . '/../includes/query_log.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('X-Content-Type-Options: nosniff');

if (request_method() === 'OPTIONS') {
    exit(0);
}

// 限流：单 IP 每分钟 60 次，避免外部接口被刷
if (!throttle_pass('ip_query', 60, 60)) {
    api_fail('查询过于频繁，请稍后再试', 429);
}

// target 为新参数；ip 为历史参数（首页 js/app.js 在用）；q 兼容其他调用方
$target = (string) request_param('target', '');
if ($target === '') {
    $target = (string) request_param('ip', '');
}
if ($target === '') {
    $target = (string) request_param('q', '');
}

$target = trim($target);

$action = (string) request_param('action', 'lookup');

// 前端下拉切换 IP 数据源：仅在本请求内覆盖，不影响后台全局生效源
$registry = ip_source_registry();
$sourceOverride = trim((string) request_param('source', ''));
if ($sourceOverride === '' || !isset($registry[$sourceOverride])) {
    $sourceOverride = null;
}

switch ($action) {
    case 'sources':
        handle_ip_sources($target);
        break;
    case 'registry':
        handle_ip_registry();
        break;
    case 'ipv6':
        handle_ip_ipv6();
        break;
    case 'latency':
        handle_ip_latency();
        break;
    case 'lookup':
    default:
        handle_ip_lookup($target, $sourceOverride);
        break;
}

function handle_ip_lookup(string $target, ?string $sourceOverride = null): void
{
    // 长度限制，避免超长输入打到外部接口
    if (strlen($target) > 253) {
        api_fail('查询目标过长', 400);
    }

    $result = ip_lookup($target, $sourceOverride);

    if ($result['status'] !== 0) {
        api_fail($result['message'], 400);
    }

    // 记录查询行为（用户 / 游客均可溯源）
    $summary = '';
    $d = $result['data'] ?? [];
    if (!empty($d['addr'])) {
        $summary .= $d['addr'];
    }
    if (!empty($d['isp'])) {
        $summary .= ' / ' . $d['isp'];
    }
    logQuery('ip', $target, trim($summary));

    api_ok($result['data'], $result['message']);
}

/**
 * 可用 IP 数据源清单（供前端下拉构建选项）
 *
 * 返回结构：
 * {
 *   active: string,                 // 当前后台生效源 key
 *   sources: [
 *     {key, name, desc, needs_token, active},
 *     ...
 *   ]
 * }
 */
function handle_ip_registry(): void
{
    $registry = ip_source_registry();
    $active = (string) app_setting('ip_source_active', 'ip9');
    $list = [];
    foreach ($registry as $key => $meta) {
        $list[] = [
            'key'         => $key,
            'name'        => $meta['name'] ?? $key,
            'desc'        => $meta['desc'] ?? '',
            'needs_token' => !empty($meta['needs_token']),
            'active'      => ($key === $active),
        ];
    }
    api_ok(['active' => $active, 'sources' => $list], 'ok');
}

/**
 * 多源视角（国内 / 国际）结果
 *
 * 返回结构：
 * {
 *   ip: string,
 *   sources: [
 *     {name, tag, tagClass, ip, location, isp, asn},
 *     ...
 *   ]
 * }
 */
function handle_ip_sources(string $target): void
{
    if (strlen($target) > 253) {
        api_fail('查询目标过长', 400);
    }

    $ip = '';
    if ($target === '') {
        $ip = request_ip();
    } else {
        $norm = ip_normalize_target($target);
        if ($norm['type'] === 'ip') {
            $ip = $norm['value'];
        } else {
            $resolved = ip_resolve_domain($norm['value']);
            if ($resolved['error'] !== '') {
                api_fail($resolved['error'], 400);
            }
            $ip = $resolved['ip'];
        }
    }

    if ($ip === '' || !filter_var($ip, FILTER_VALIDATE_IP)) {
        api_fail('无法获取有效的 IP 地址', 400);
    }

    $all = ip_fetch_all_sources($ip);
    $active = (string) app_setting('ip_source_active', 'ip9');

    // 构造多源结果，标签与参考页视觉一致
    $sources = [];

    // 国内源 1：当前生效源
    $dom1 = $all[$active] ?? ($all['ip9'] ?? ($all['xxapi'] ?? null));
    if ($dom1) {
        $sources[] = format_source_row('ip138.com', '国内', 'domestic', $dom1);
    }

    // 国内源 2：ip9（若与 active 不同则优先，否则 xxapi）
    $dom2 = !empty($all['ip9']) && ($active !== 'ip9') ? $all['ip9'] : ($all['xxapi'] ?? null);
    if ($dom2) {
        $sources[] = format_source_row('IP.cn 查询网', '国内', 'domestic', $dom2);
    }

    // 国际源 1：ipapi.co
    $int1 = $all['ipapi'] ?? null;
    if ($int1) {
        $sources[] = format_source_row('Cloudflare', '国际', 'international', $int1);
    }

    // 国际源 2：ip-api.com
    $int2 = $all['ip_api_com'] ?? null;
    if ($int2) {
        $sources[] = format_source_row('IPinfo.io', '国际', 'international', $int2);
    }

    // 兜底：任意源只要有数据就至少保证一条
    if ($sources === []) {
        $fallback = ip_fetch_remote($ip);
        if ($fallback) {
            $sources[] = format_source_row('综合查询', '国内', 'domestic', $fallback);
        }
    }

    api_ok(['ip' => $ip, 'sources' => $sources], 'ok');
}

function format_source_row(string $name, string $tag, string $tagClass, array $data): array
{
    $regions = $data['regions_short'] ?? $data['regions'] ?? [];
    $country = $data['country_name'] ?? '';
    $location = trim($country . ' ' . implode(' ', $regions));
    $isp = $data['isp'] ?? ($data['asn_name'] ?? ($data['asn_info'] ?? ''));
    $asn = ($data['asn_number'] ?? 0) ? ('AS' . $data['asn_number']) : '';

    return [
        'name' => $name,
        'tag' => $tag,
        'tagClass' => $tagClass,
        'ip' => $data['ip'] ?? '',
        'location' => $location !== '' ? $location : '未知',
        'isp' => $isp !== '' ? $isp : '未知',
        'asn' => $asn,
    ];
}

/**
 * IPv6 服务端视角（若用户通过 IPv6 访问本站则返回，否则提示不支持）
 */
function handle_ip_ipv6(): void
{
    $ip = request_ip();
    if (strpos($ip, ':') !== false && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        $result = ip_lookup($ip);
        api_ok([
            'supported' => true,
            'ip' => $ip,
            'location' => $result['data']['addr'] ?? '未知',
            'isp' => $result['data']['isp'] ?? '未知',
        ], 'ok');
    }

    api_ok(['supported' => false, 'message' => '你的网络可能不支持 IPv6'], 'ok');
}

/**
 * 延迟检测目标列表（由前端在用户浏览器侧实测）
 *
 * 返回每个目标的：名称、类型（domestic/international）、探测 URL（小资源）。
 * 前端使用 fetch(..., {mode:'no-cors', cache:'no-store'}) 测量加载耗时。
 */
function handle_ip_latency(): void
{
    $targets = [
        ['key' => 'douyin',     'name' => '字节跳动', 'type' => 'domestic',       'url' => 'https://www.douyin.com/favicon.ico'],
        ['key' => 'bilibili',   'name' => 'Bilibili', 'type' => 'domestic',       'url' => 'https://www.bilibili.com/favicon.ico'],
        ['key' => 'weixin',     'name' => '微信',     'type' => 'domestic',       'url' => 'https://weixin.qq.com/favicon.ico'],
        ['key' => 'taobao',     'name' => '淘宝',     'type' => 'domestic',       'url' => 'https://www.taobao.com/favicon.ico'],
        ['key' => 'github',     'name' => 'GitHub',   'type' => 'international',  'url' => 'https://github.com/favicon.ico'],
        ['key' => 'jsdelivr',   'name' => 'jsDelivr', 'type' => 'international',  'url' => 'https://cdn.jsdelivr.net/npm/jquery@3/dist/jquery.min.js'],
        ['key' => 'cloudflare', 'name' => 'Cloudflare','type' => 'international', 'url' => 'https://www.cloudflare.com/favicon.ico'],
        ['key' => 'youtube',    'name' => 'YouTube',  'type' => 'international',  'url' => 'https://www.youtube.com/favicon.ico'],
    ];

    api_ok(['targets' => $targets], 'ok');
}
