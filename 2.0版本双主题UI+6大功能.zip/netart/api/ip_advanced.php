<?php
/**
 * IP 进阶能力 API
 *
 * 动作：
 *  - consistency : 多地 IP 归属一致性对比
 *  - cdn         : CDN / 云厂商 / 运营商识别
 *  - latency     : TCP 延迟探测（替代 ICMP ping）
 *  - dns         : 多解析器 DNS 对比（DNS 泄漏 / 分地区解析 / CDN 调度）
 *
 * 返回契约：{status:0,code:200,message,data} / {status:1,...}
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/ip_service.php';
require_once __DIR__ . '/../includes/query_log.php';

header('Content-Type: application/json; charset=utf-8');

$action = (string) request_param('action', '');
$advTarget = (string) request_param('target', '');

// 轻量限流，防止滥用（与首页 IP 查询共用窗口思路）
$throttleKey = 'ip_adv';
if (!throttle_pass($throttleKey, 60, 60)) {
    api_fail('请求过于频繁，请稍后再试', 429);
    exit;
}

$r = ['status' => 1, 'message' => '未知操作', 'data' => null];

switch ($action) {
    case 'consistency':
        $r = ip_consistency((string) request_param('target', ''));
        break;

    case 'cdn':
        $target = (string) request_param('target', '');
        $lookup = ip_lookup($target);
        if ($lookup['status'] !== 0 || empty($lookup['data'])) {
            $r = ['status' => 1, 'message' => $lookup['message'] ?: '归属查询失败', 'data' => null];
            break;
        }
        $d = $lookup['data'];
        $cdn = ip_detect_cdn(
            (string) ($d['as']['name'] ?? ''),
            (string) ($d['as']['info'] ?? ''),
            (int) ($d['as']['number'] ?? 0)
        );
        $cdn['ip'] = $d['ip'];
        $cdn['query'] = $d['query'];
        $r = ['status' => 0, 'message' => 'ok', 'data' => $cdn];
        break;

    case 'latency':
        $host = (string) request_param('target', '');
        if ($host === '') {
            $r = ['status' => 1, 'message' => '请输入要探测的主机（IP 或域名）', 'data' => null];
            break;
        }
        $ports = array_filter(
            array_map('intval', explode(',', (string) request_param('ports', '80,443,53,22'))),
            static function ($p) {
                return $p > 0 && $p <= 65535;
            }
        );
        $r = ip_tcp_latency($host, $ports ? array_values($ports) : [80, 443, 53, 22], 3);
        break;

    case 'dns':
        $domain = (string) request_param('target', '');
        if ($domain === '') {
            $r = ['status' => 1, 'message' => '请输入域名', 'data' => null];
            break;
        }
        $r = ip_dns_comparison($domain);
        break;

    default:
        // 未知 action 已在上方初始化
        break;
}

if ($r['status'] === 0) {
    // 记录查询行为（用户 / 游客均可溯源）
    logQuery('ip_advanced', $advTarget, (string) $action);
    api_ok($r['data'], $r['message']);
} else {
    api_fail($r['message'], 400, $r['data']);
}
